(function(w) {
	var Cookies = {};
	Cookies.addCookie = function(name, value, expireHours) {
		var cookieString = name + "=" + encodeURIComponent(value);
		if (expireHours && expireHours > 0) {
			var date = new Date();
			date.setTime(date.getTime + expireHours);
			cookieString = cookieString + "; expire=" + date.toUTCString();
			alert((new Date()).toGMTString());
		}
		document.cookie = cookieString;
	}
	Cookies.getCookie = function(name) {
		var strcookie = document.cookie;
		var arrcookie = strcookie.split("; ");
		for (var i = 0; i < arrcookie.length; i++) {
			var arr = arrcookie[i].split("=");
			if (arr[0] == name)
				return decodeURIComponent(arr[1]);
		}
		return "";
		//var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
		//  if(arr != null) return unescape(arr[2]); return null;
	}
	Cookies.delCookie = function(name)//cookie
	{
		var exp = new Date();
		exp.setTime(exp.getTime() - 1);
		var cval = Cookies.getCookie(name);
		if (cval != "")
			document.cookie = name + "=" + cval + ";expires="
					+ exp.toUTCString();
	}
	w.$cookie = Cookies;
/*******************************************json*/
	var myjson={};
	myjson.stringify = (function() {
		var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, gap, indent, meta = {
			'\b' : '\\b',
			'\t' : '\\t',
			'\n' : '\\n',
			'\f' : '\\f',
			'\r' : '\\r',
			'"' : '\\"',
			'\\' : '\\\\'
		}, rep;
		function quote(string) {
			escapable.lastIndex = 0;
			return escapable.test(string) ? '"'
					+ string.replace(escapable, function(a) {
								var c = meta[a];
								return typeof c === 'string' ? c : '\\u'
										+ ('0000' + a.charCodeAt(0)
												.toString(16)).slice(-4);
							}) + '"' : '"' + string + '"';
		}
		function str(key, holder) {
			var i, k, v, length, mind = gap, partial, value = holder[key];
			if (value && typeof value === 'object'
					&& typeof value.toJSON === 'function') {
				alert("value=" + value + ",typeof value=" + typeof value
						+ ",typeof value.toJSON=" + typeof value.toJSON);
				value = value.toJSON(key);
			}
			if (typeof rep === 'function') {
				value = rep.call(holder, key, value);
			}
			switch (typeof value) {
				case 'string' :
					return quote(value);

				case 'number' :
					return isFinite(value) ? String(value) : 'null';

				case 'boolean' :
				case 'null' :
					return String(value);
				case 'object' :
					if (!value) {
						return 'null';
					}
					gap += indent;
					partial = [];
					if (Object.prototype.toString.apply(value) === '[object Array]') {
						length = value.length;
						for (i = 0; i < length; i += 1) {
							partial[i] = str(i, value) || 'null';
						}
						v = partial.length === 0 ? '[]' : gap
								? '[\n' + gap + partial.join(',\n' + gap)
										+ '\n' + mind + ']'
								: '[' + partial.join(',') + ']';
						gap = mind;
						return v;
					}
					if (rep && typeof rep === 'object') {
						alert("rep && typeof rep === 'object'");
						length = rep.length;
						for (i = 0; i < length; i += 1) {
							k = rep[i];
							if (typeof k === 'string') {
								v = str(k, value);
								if (v) {
									partial.push(quote(k) + (gap ? ': ' : ':')
											+ v);
								}
							}
						}
					} else {
						for (k in value) {

							if (Object.hasOwnProperty.call(value, k)) {
								v = str(k, value);
								if (v) {
									partial.push(quote(k) + (gap ? ': ' : ':')
											+ v);
								}
							}
						}
					}
					v = partial.length === 0 ? '{}' : gap
							? '{\n' + gap + partial.join(',\n' + gap) + '\n'
									+ mind + '}'
							: '{' + partial.join(',') + '}';
					gap = mind;
					return v;
			}
		}
		return function(value, replacer, space) {
			var i;
			gap = '';
			indent = '';
			if (typeof space === 'number') {
				for (i = 0; i < space; i += 1) {
					indent += ' ';
				}
			} else if (typeof space === 'string') {
				indent = space;
			}
			/*function Array*/
			rep = replacer;
			if (replacer
					&& typeof replacer !== 'function'
					&& (typeof replacer !== 'object' || typeof replacer.length !== 'number')) {
				throw new Error('number2 param error! fn(handle,k,v)||[] ');
			}
			return str('', {
						'' : value
					});
		};
	})(window)
	myjson.find=function(target,fex){
		var re=[];
	    for(var i in target){
	       for(var j in fex){
	          if(target[i][j]==fex[j]){
	             re.push(target[i]);
	          }
	       }
	    }
	    return re;
	}
	if (!(window.JSON && window.JSON.stringify)) {
		window.JSON=myjson;
	}
	w.$JSON = myjson;
	/*******************************************date*/
	var date = {};
	date.parse = function(str, fmt) {
		if (!/(y+)/.test(fmt) || !/(M+)/.test(fmt) || !/(d+)/.test(fmt)
				|| fmt.length != str.length) {
			return;
		}
		var copyStr = str;
		var o = {
			"y+" : {
				start : fmt.search(/(y+)/),
				end : RegExp.$1.length,
				fn : function(date, s) {
					date.setFullYear(s)
				}
			},
			"M+" : {
				start : fmt.search(/(M+)/),
				end : RegExp.$1.length,
				fn : function(date, s) {
					date.setMonth(s - 1)
				}
			},
			"d+" : {
				start : fmt.search(/(d+)/),
				end : RegExp.$1.length,
				fn : function(date, s) {
					date.setDate(s)
				}
			},
			"h+" : {
				start : fmt.search(/(h+)/),
				end : RegExp.$1.length,
				fn : function(date, s) {
					date.setHours(s)
				}
			},
			"m+" : {
				start : fmt.search(/(m+)/),
				end : RegExp.$1.length,
				fn : function(date, s) {
					date.setMinutes(s)
				}
			},
			"s+" : {
				start : fmt.search(/(s+)/),
				end : RegExp.$1.length,
				fn : function(date, s) {
					date.setSeconds(s)
				}
			}
		};
		// var matchs1=fmt.match(/([yMdhsm])(\1*)/g);
		// var matchs2=str.match(/(\d)+/g);
		var date = new Date;
		date.setMonth(0);
		date.setDate(1);
		for (var k in o)
			if (o[k].start != -1)
				o[k].fn(date, str.substring(o[k].start, o[k].start + o[k].end));
		return date;
	};
   date.convert = function(dd) {
   	var nowDate = new Date();
   	var $dur = ((nowDate.getTime() - dd.getTime()) / 1000).toFixed(0);
   	
		if ($dur < 0)
			return a;
		if ($dur < 60) {
			$dur == 0 ? $dur++ : $dur;
			return $dur + '��ǰ';
		} else if ($dur < 3600) {
			return Math.floor($dur / 60) + '����ǰ';
		} else if ($dur < 86400) {
			return Math.floor($dur / 3600) + 'Сʱǰ';
		} else if ($dur < 259200) {//
			return Math.floor($dur / 86400) + '��ǰ';
		} else {
			return a;
		}
	}
window.$date=date;
})(window)