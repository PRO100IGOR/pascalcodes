
(function () {

	var link = function (c) {
	    var list={};
	    c.url=c.url.indexOf('?')==-1?c.url+'?desk=true&SESSIONID='+data.sessionid+'&resource='+c.name+'&callback=?':c.url+'&desk=true&SESSIONID='+data.sessionid+'&resource='+c.name+'&callback=?';
		$.ajax({url: c.url,type:"post",dataType:"jsonp", data:{deskPage:c.page, deskCount:(c.count ? c.count : data.pageCount)}, async:false, success:function (json) {
		   
			list.count=(json.count);
			list.list=( $.map(json.list, function (n) {
				return "<li>" +"<a href='javascript:return false;' class='arrow link' url='"+n.link+"'>" + n.id+"."+n.ltext + "</a>" + "<span class='date_r'>" + n.rtext + " </span>" + "</li>";
			}));
			c.fn(list);
		}, error:function (a, b, c) {
			
			
		}});
		return list;
	};

	var temp = function (name, text, url, style) {
		var tt = $(">.temp", document.body).clone();
		tt.attr("name", name);
		tt.attr("text", text);
		tt.attr("url", url);
		style?tt.attr("style", ss):0;
		tt.find(".tity_l").text(text);
		tt.find("span[name=countR]").text(text);
		tt.attr("pageNo", "1");
		if (url) {
		         link({name:name,url:url,page:1,fn:function(json){
				
				              tt.find("span[name=count]").text(json.count);
								var count = tt.find("span[name=count]").text() - 0;
								if (count == 0)
									tt.find('.pageHidden').hide();
								tt.find(".txt_list>*").remove();
								if (!$.isEmptyObject(json.list))
									tt.find(".txt_list").append(json.list.join(" "));
				}});
			
			
		}
		tt.show();
		return tt;
	};
	var targetLink = function(a) {
		
		var tt = $(this).parents(".temp:eq(0)");
		var pageNo = tt.attr("pageNo") - 0+parseInt(a);
		
		var count = tt.find("span[name=count]").text() - 0;
		if (count == 0)
			tt.find('.pageHidden').hide();
		var totalPage = 0;
		if (count % data.pageCount == 0)
			totalPage = count / data.pageCount;
		else
			totalPage = (count / data.pageCount).toFixed(0)-0 + 1;
		
		if (pageNo < 1)
			pageNo = 1;
		if (pageNo > totalPage)
			pageNo = totalPage;
		
		link({name:tt.attr('name'),url:tt.attr('url'),page:pageNo,fn:function(json){
		              tt.find("span[name=count]").text(json.count);
					tt.find(".txt_list>*").remove();
					tt.find(".txt_list").hide();
					if (!$.isEmptyObject(json.list))
						tt.find(".txt_list").append(json.list.join(" "));
					tt.find(".txt_list").fadeIn('show');
					tt.attr('pageNo', pageNo);
		 }});
		
	}
	var change = function (a) {
		var str = "";
		if (a == 0) {
			str = "<tr id='scopeTableTr'><td style='width:50%;'><div class=\"tl\"  ></div></td>";
			str += "<td style='width:50%;'> <div class=\"tl\"  ></div></td></tr>";
		} else {
			if (a == 1) {
				str = "<tr id='scopeTableTr'><td style='width:33.3%;'><div class=\"tl\"  ></div></td>";
				str += "<td style='width:33.3%;'><div class=\"tl\"  ></div></td><td style='width:33.3%;'> <div class=\"tl\"  ></div></td></tr>";
			} else {
				str = "<tr id='scopeTableTr'><td ><div class=\"tl\" style='height:600px;' ></div></td></tr>";
			}
		}
		$("#scopeTable *").remove();
		$("#scopeTable").append(str);
		$("#scopeTableTr>td").attr("valign", "top");
	};
	var events=function(){
						$( ".tl" ).droppable({
						   accept:"#draggUl li",
						   activeClass: "ui-state-default",
							hoverClass: "aa",
							activate: function( event, ui ) {
								ui.helper.css({cursor:'not-allowed'});
							},
							over: function( event, ui ) {
									ui.helper.css({cursor:'move'});
							},
							out: function( event, ui ) {
								ui.helper.css({cursor:'not-allowed'});
							},
							drop: function( event, ui ) {//
				                ui.draggable.addClass('aa');
				                var th=temp(ui.draggable.attr("name"),ui.draggable.text(),ui.draggable.attr('url'));
				                $(this).append(th);
				                if($(":radio[name=deskType]").index($(":radio:checked"))==2){
				                   th.resizable().draggable({scroll: false,
																	opacity:0.7,
																			cursor: "move",containment:this});
				                }			
							}
						})
						$( ".tl" ).sortable({connectWith: ".tl",opacity:0.5});
						$("#scopeTable td").resizable({containment: "#scopeTable","handles":"e"});
					};
	var data = {pageCount:5, basePath:null,type:-1,deskData:[],menus:[]};
	var desk = function () {
	};
	desk.setting=function(){
		try{
			window.top.$menu.showDesk();
		}catch(e){}
	     
	};
	desk.init = function () {
		$.extend(data, arguments[0]);
		if(!$.isEmptyObject(data.menus)){
			//??????
		    $("#draggUl").append((function(a){
					    var r=[];
					      for(var i=0,length=a.length;i<length;i++){
							      if(a[i].resource&&a[i].resource.length>0){
							         r=r.concat(arguments.callee(a[i].resource));
							      }else{
							        var str=" <li url='"+a[i].resourceurl+"' name='"+a[i].resourceid+"'>"+
							                   "<a class='bb'>"+a[i].resourcename+"</a>"+
									        "</li>";
							         r.push(str);
							      }
					    }
					      return r;
			 })(data.menus).join(' '));
			 //?????
			  $( "#draggUl>li" ).draggable({
					scroll: false,
					helper:"clone",
					revert:'invalid',
					opacity:0.7,
					cursor: "move",
					zIndex:'99999',
					cancel:'.aa'
			});
		}
	};
	$(function () {
		$(".link").live('click',function(){
			var t=$(this).parents(".temp:eq(0)");
			var basePath=t.attr("url").match(/http:\/*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d{1,5}\/*\w*\/*/i);
			if(!$(this).attr('url'))return false;
		     win({
				 id:(((1+Math.random())*0x10000)|0).toString(16).substring(1),
					title : t.attr("text"),
					url : basePath+$(this).attr('url'),
					width : document.body.clientWidth - 100,
					height : document.body.clientHeight - 70,
					cover : "yes",
					btnBar : "yes",
					xBtn : "yes"
				})
					return false;
		})
		$("*[name=prevPage]").live("click", function () {
			targetLink.call(this,-1);
		});
		$("*[name=nextPage]").live("click", function () {
			targetLink.call(this,1);
		});
		$("*[name=blowup]").live("click", function () {
			var t=$(this).parents(".temp:eq(0)");
		win({
					title : t.attr('text'),
					url : t.attr('url'),
					width : document.body.clientWidth - 100,
					height : document.body.clientHeight - 70,
					cover : "yes",
					btnBar : "no",
					xBtn : "yes"
				})
		});
		$("a[name=del]").live('click',function(){
			    $(this).parents(".temp:eq(0)").fadeOut(500,function(){
			        $("#draggUl>li[name="+$(this).attr('name')+"]").removeClass('aa');
			        $(this).remove();
			    });
			    return false;
			});
		  if(data.type>=0&&data.type<=1&&data.deskData!==''){
		       try{
             (typeof data.deskData==='string')?data.deskData=eval('('+data.deskData+')'):0;
             $("input[name=deskType]:eq("+data.type+")").attr('checked',true);
             change(data.type);
			  $.each(data.deskData,function(i,n){
			      var td=$("#scopeTableTr>td:eq("+i+")");
			      td.width(n.width);
			       $.each(n.config,function(i,nn){
			          $(".tl",td).append( temp(nn.name,nn.text,nn.url,nn.style))});
			  });
			   $(".tl>div").each(function(){
			     $("#draggUl>li[name="+ $(this).attr('name')+"]").addClass("aa");
			  })	
           }catch(e){
           }
		  }else{
		     change(0);//??????
		  }
		if(!$.isEmptyObject(data.menus)){
		    $("#save").click(function(){
				    var deskType=$(":radio").index($(":radio:checked"));
				    var desk=[];
				    $.each($(".tl"),function(i){
				         desk[i]={};
				         desk[i].width=(($(this).parents("td:eq(0)").width()/$("#scopeTable").width()).toFixed(3)*100)+'%';
				         desk[i].config=$.map($(">div",$(this)),function(n){
				            if(deskType==2){
				                 return {name:$(n).attr('name'),text:$(n).attr('text'),url:$(n).attr('url'),style:$(n).attr('style')} 
				            }	
				            return {name:$(n).attr('name'),text:$(n).attr('text'),url:$(n).attr('url')};
				         })
				    });
				    $.ajax({
						   type: "POST",
						   url: data.basePath+"/siheAction.do?action=saveDesk&r="+Math.random(),
						    data: {desk:(JSON.stringify(desk)),deskType:deskType},
						   success: function(n){
						   	try{
						   		window.top.frames['index'].location.reload();
						   	}catch(e){}
						     	 $.msgBar ({
										type: 'info',
										text: '����ɹ�,������ҳ�鿴.',
										position: 'center-center',
										lifetime: 2000
								});
						   }
					}); 
				});
				$("#close").click(function(){
					ask({
			           message:"ȷ��Ҫ�ر���",
						fn:function(data){
							if(data == "yes"){
								 window.close();
							}
						}
					});
				   
				})
			$(":radio[name=deskType]").change(function(){
				     $("#draggUl>li").removeClass('aa');
			        change($(":radio").index($(":radio:checked")));
			        events();
			})
			  events();
			  if(data.type==='2'){
			     $(".tl>div").resizable().draggable({scroll: false,
																	opacity:0.7,
																			cursor: "move",containment:".tl"});
			  }
		}
		if(data.show&&!$("#scopeTable .temp").length&&$("#box")[0]){
		    $("#box").show();
		}
	});
	window.$desk = desk;
})();
