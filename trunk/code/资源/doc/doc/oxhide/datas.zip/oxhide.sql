/*
Navicat MySQL Data Transfer

Source Server         : localhost_3309
Source Server Version : 50045
Source Host           : 127.0.0.1:3309
Source Database       : oxhide

Target Server Type    : MYSQL
Target Server Version : 50045
File Encoding         : 65001

Date: 2012-09-07 15:27:44
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `application`
-- ----------------------------
DROP TABLE IF EXISTS `application`;
CREATE TABLE `application` (
  `APPID` varchar(32) NOT NULL COMMENT 'ID',
  `APPNAME` varchar(32) default NULL COMMENT '系统名字',
  `APPURL` varchar(400) default NULL COMMENT '系统地址',
  `APPINDEX` varchar(400) default NULL COMMENT '首页地址',
  `APPTITLE` varchar(32) default NULL COMMENT '默认标题',
  `ICO` varchar(60) default NULL COMMENT '图标',
  `BIGICO` varchar(60) default NULL COMMENT '大图标',
  `ORDERNO` int(11) default NULL COMMENT '排序号',
  `APPCODE` varchar(32) default NULL COMMENT '系统编码 ',
  `LARGEICO` varchar(60) default NULL COMMENT '超大图标',
  `SIMPLYNAME` varchar(8) default NULL COMMENT '简称',
  `REMARK` varchar(400) default NULL COMMENT '简介',
  `APPURLW` varchar(400) default NULL COMMENT '外网地址',
  `APPLEKEY` varchar(64) default NULL COMMENT '苹果证书密码',
  `ANDROIDKEY` varchar(64) default NULL COMMENT '安卓证书密码',
  `APPLEKF` varchar(1) default NULL COMMENT '苹果是否开发版',
  `ANDROIDKF` varchar(1) default NULL COMMENT '安卓是否开发版',
  `TIMEENABLE` varchar(1) default NULL COMMENT '是否定时提醒',
  `TIMER` varchar(5) default NULL COMMENT '提醒间隔',
  `TIMES` varchar(4) default NULL COMMENT '提醒次数',
  PRIMARY KEY  (`APPID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of application
-- ----------------------------
INSERT INTO application VALUES ('8a8a80f22f8a792c012f8a7d9a5a0020', '系统管理', 'http://127.0.0.1:8081/oxhide', 'pages/admin/index.jsp', '系统管理', 'resource/base/theme/public/img/icon/999.png', 'resource/base/theme/public/img/bigicon/583.png', '1', 'XTGL', 'resource/base/theme/public/img/largeicon/077.png', '系统管理', '对平台的组成、基本元素进行维护、管理', 'http://10.10.0.141:8081/oxhide', '', null, '1', null, '0', '', '');

-- ----------------------------
-- Table structure for `boxmenus`
-- ----------------------------
DROP TABLE IF EXISTS `boxmenus`;
CREATE TABLE `boxmenus` (
  `BID` varchar(32) NOT NULL,
  `USERID` varchar(32) default NULL COMMENT 'ID',
  `MENUNAME` varchar(32) default NULL,
  `MENUURL` varchar(200) default NULL,
  PRIMARY KEY  (`BID`),
  KEY `FK_Reference_29` (`USERID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of boxmenus
-- ----------------------------
INSERT INTO boxmenus VALUES ('390BE1A35983CFA9205F5E76CFEA5892', '1', '应用系统', 'http://10.10.0.141:8081/oxhide//applicationShowAction.do?action=showUpdate&id=7653EE70D4E0AD950E4AC201559EAB5D');

-- ----------------------------
-- Table structure for `columns`
-- ----------------------------
DROP TABLE IF EXISTS `columns`;
CREATE TABLE `columns` (
  `CID` varchar(32) NOT NULL,
  `TID` varchar(32) default NULL,
  `CNAME` varchar(32) default NULL COMMENT '列名',
  `RULE` varchar(4000) default NULL COMMENT '规则',
  `LTYPE` varchar(1) default NULL COMMENT '列类型 1主键 2主属性 3普通属性.\r\n            ',
  `SHOWTYPE` varchar(1) default NULL COMMENT '显示类型',
  `ORDERNO` varchar(1) default NULL COMMENT '排序号',
  `ISSHOW` varchar(1) default NULL COMMENT '显示到列表',
  `WIDTH` varchar(32) default NULL COMMENT '列表宽度',
  `CCODE` varchar(32) default NULL COMMENT '列编码',
  `TIMER` varchar(32) default NULL COMMENT '时间控件',
  `DATA` varchar(4000) default NULL COMMENT '取数值',
  `GETDATA` varchar(1) default NULL COMMENT '取数类型 1=不取，2=数据字典，3=静态',
  `ISMUST` varchar(1) default NULL COMMENT '1=是 0=否',
  `ISMAIN` varchar(1) default NULL COMMENT '1=是 0=否',
  PRIMARY KEY  (`CID`),
  KEY `FK_Reference_9` (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of columns
-- ----------------------------

-- ----------------------------
-- Table structure for `commonmenus`
-- ----------------------------
DROP TABLE IF EXISTS `commonmenus`;
CREATE TABLE `commonmenus` (
  `CID` varchar(32) NOT NULL,
  `RESOURCEID` varchar(32) default NULL COMMENT '资源ID',
  `USERID` varchar(32) default NULL COMMENT 'ID',
  PRIMARY KEY  (`CID`),
  KEY `FK_Reference_27` (`RESOURCEID`),
  KEY `FK_Reference_28` (`USERID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of commonmenus
-- ----------------------------
INSERT INTO commonmenus VALUES ('8a8a800d3922a8d3013922c5c4f00021', '87D9B871BADC38DA45E13B712BDF2856', '1');
INSERT INTO commonmenus VALUES ('8a8a800d392968fa013929a08acc0049', 'D2ACBECEC96D2044133975887DB2A569', '1');
INSERT INTO commonmenus VALUES ('8a8a800d392968fa013929a092db004a', 'D94B316A57E4C3B68FDA5E37F7D33996', '1');
INSERT INTO commonmenus VALUES ('8a8a800d399e75db01399e7940ea0002', '8a8a80f22f8f7b78012f8f7cc7d40011', '6752505C04F192FC3787FF6F59B3DE92');
INSERT INTO commonmenus VALUES ('8a8a800d399e75db01399e796c8d0004', '8a8a80f22f8f7b78012f8f7e09d3003a', '6752505C04F192FC3787FF6F59B3DE92');

-- ----------------------------
-- Table structure for `dataid`
-- ----------------------------
DROP TABLE IF EXISTS `dataid`;
CREATE TABLE `dataid` (
  `DTID` varchar(32) NOT NULL,
  `TID` varchar(32) default NULL,
  `PDTID` varchar(32) default NULL COMMENT '引用属性',
  PRIMARY KEY  (`DTID`),
  KEY `FK_Reference_10` (`PDTID`),
  KEY `FK_Reference_4` (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of dataid
-- ----------------------------

-- ----------------------------
-- Table structure for `datas`
-- ----------------------------
DROP TABLE IF EXISTS `datas`;
CREATE TABLE `datas` (
  `DID` varchar(32) NOT NULL,
  `CID` varchar(32) default NULL COMMENT '列ID',
  `DTID` varchar(32) default NULL COMMENT '记录数',
  `DVALUE` varchar(4000) default NULL COMMENT '值',
  PRIMARY KEY  (`DID`),
  KEY `FK_Reference_2` (`CID`),
  KEY `FK_Reference_3` (`DTID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of datas
-- ----------------------------

-- ----------------------------
-- Table structure for `deptment`
-- ----------------------------
DROP TABLE IF EXISTS `deptment`;
CREATE TABLE `deptment` (
  `DEPTID` varchar(32) NOT NULL COMMENT '部门ID',
  `ORGANID` varchar(32) default NULL COMMENT '机构id',
  `DEPTPID` varchar(32) default NULL COMMENT '部门ID',
  `AREAID` varchar(32) default NULL COMMENT '地区编号',
  `DEPTCODE` varchar(32) default NULL COMMENT '部门编码',
  `DEPTNAME` varchar(32) default NULL COMMENT '部门名称',
  `ORDERNO` int(11) default NULL COMMENT '序号',
  `REMARK` varchar(100) default NULL COMMENT '备注',
  `ISVALIDATION` int(11) default NULL COMMENT '是否有效',
  `DEPTMAN` varchar(32) default NULL,
  `DEPTMANID` varchar(32) default NULL,
  PRIMARY KEY  (`DEPTID`),
  KEY `FK_Reference_1` (`ORGANID`),
  KEY `FK_Reference_20` (`DEPTPID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of deptment
-- ----------------------------
INSERT INTO deptment VALUES ('8a8a800d392ce22201392ce35373000c', '8a8a800d392ce22201392ce321a50006', null, null, 'YFB', '研发部', '1', '', null, '', '');

-- ----------------------------
-- Table structure for `dictionary`
-- ----------------------------
DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE `dictionary` (
  `DID` varchar(32) NOT NULL COMMENT 'ID',
  `DNAME` varchar(32) default NULL COMMENT '数据字典名称',
  `DCODE` varchar(32) default NULL COMMENT '数据字典类型编码',
  `REMARK` varchar(100) default NULL COMMENT '说明',
  PRIMARY KEY  (`DID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of dictionary
-- ----------------------------
INSERT INTO dictionary VALUES ('8a8a801a31b8308f0131b866657700b3', '户口性质', 'HKXZ', '');
INSERT INTO dictionary VALUES ('8a8a801a31b8308f0131b86684d700b6', '职称性质', 'ZCXZ', null);
INSERT INTO dictionary VALUES ('8a8a801a31bb6b1b0131bb73f676000e', '民族', 'MZ', null);
INSERT INTO dictionary VALUES ('8a8a801a31bb6b1b0131bb760b1d002c', '政治面貌', 'ZZMM', null);
INSERT INTO dictionary VALUES ('8a8a801a31bb6b1b0131bb770915003d', '学历', 'XL', null);
INSERT INTO dictionary VALUES ('8a8a801a31bbe82e0131bd6848cc00a1', '学历类型', 'XLLX', null);
INSERT INTO dictionary VALUES ('8a8a80cf324be36e0132658085c602ce', '其他职业资格', 'QTZYZG', null);
INSERT INTO dictionary VALUES ('8a8a801f357abd1a01357ee0f0520125', '婚姻状况', 'MARRY', '');
INSERT INTO dictionary VALUES ('8a8a801f357abd1a01357ee03f9f0119', '血型', 'BLOOD', '');
INSERT INTO dictionary VALUES ('8a8a800d392ce22201392ce4bac30061', '煤矿类型', 'coaltype', '');
INSERT INTO dictionary VALUES ('8a8a800d392968fa01392969e7ec0006', '摄像头地址', 'videopath', '');

-- ----------------------------
-- Table structure for `dictionarycontent`
-- ----------------------------
DROP TABLE IF EXISTS `dictionarycontent`;
CREATE TABLE `dictionarycontent` (
  `DCID` varchar(32) NOT NULL COMMENT 'id',
  `DID` varchar(32) default NULL COMMENT 'ID',
  `DCVALUE` varchar(200) default NULL COMMENT '内容',
  `DCODE` varchar(200) default NULL COMMENT '编码',
  `REMARK` varchar(100) default NULL COMMENT '说明',
  PRIMARY KEY  (`DCID`),
  KEY `FK_Reference_10` (`DID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of dictionarycontent
-- ----------------------------
INSERT INTO dictionarycontent VALUES ('8a8a801f357abd1a01357ee13922012a', '8a8a801f357abd1a01357ee0f0520125', '单身', '单身', '');
INSERT INTO dictionarycontent VALUES ('8a8a801f357abd1a01357ee092240120', '8a8a801f357abd1a01357ee03f9f0119', 'A', 'A', '');
INSERT INTO dictionarycontent VALUES ('8a8a801f357abd1a01357ee07f19011d', '8a8a801f357abd1a01357ee03f9f0119', 'O', 'O', '');
INSERT INTO dictionarycontent VALUES ('8a8a801a31bbe82e0131bd687fab00a6', '8a8a801a31bbe82e0131bd6848cc00a1', '第一学历', '第一学历', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31b8308f0131b866d0f300ba', '8a8a801a31b8308f0131b866657700b3', '农业', '农业', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31b8308f0131b866ff4600bd', '8a8a801a31b8308f0131b866657700b3', '城镇', '城镇', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31b8308f0131b867885c00c7', '8a8a801a31b8308f0131b86684d700b6', '公有制（市人事局/省人事厅）', '公有制（市人事局/省人事厅）', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb74f2a80019', '8a8a801a31bb6b1b0131bb73f676000e', '汉族', '汉族', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb751bcc001c', '8a8a801a31bb6b1b0131bb73f676000e', '维吾尔族', '维吾尔族', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb756c3d0023', '8a8a801a31bb6b1b0131bb73f676000e', '高山族', '高山族', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb75c6a20028', '8a8a801a31b8308f0131b86684d700b6', '非公有制（各直属企业）', '非公有制（各直属企业）', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb7633f20030', '8a8a801a31bb6b1b0131bb760b1d002c', '团员', '团员', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb764fe70033', '8a8a801a31bb6b1b0131bb760b1d002c', '党员', '党员', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb7679c50036', '8a8a801a31bb6b1b0131bb760b1d002c', '群众', '群众', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb76a28b0039', '8a8a801a31bb6b1b0131bb760b1d002c', '九三学社', '九三学社', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb7756e70041', '8a8a801a31bb6b1b0131bb770915003d', '小学', '小学', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb7772db0044', '8a8a801a31bb6b1b0131bb770915003d', '初中', '初中', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb778d580047', '8a8a801a31bb6b1b0131bb770915003d', '高中', '高中', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb77a96c004a', '8a8a801a31bb6b1b0131bb770915003d', '本科', '本科', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb77c60c004d', '8a8a801a31bb6b1b0131bb770915003d', '大专', '大专', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb7831f50050', '8a8a801a31bb6b1b0131bb770915003d', '研究生', '研究生', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bb6b1b0131bb788d440055', '8a8a801a31bb6b1b0131bb770915003d', '教授', '教授', null);
INSERT INTO dictionarycontent VALUES ('8a8a801a31bbe82e0131bd689c7a00a9', '8a8a801a31bbe82e0131bd6848cc00a1', '最高学历', '最高学历', null);
INSERT INTO dictionarycontent VALUES ('8a8a80cf324be36e01326580d59c02d2', '8a8a80cf324be36e0132658085c602ce', '结构工程师', '结构工程师', null);
INSERT INTO dictionarycontent VALUES ('8a8a80cf324be36e0132658107b802d5', '8a8a80cf324be36e0132658085c602ce', '监理工程师', '监理工程师', null);
INSERT INTO dictionarycontent VALUES ('8a8a80cf324be36e013265812c4702d8', '8a8a80cf324be36e0132658085c602ce', '建造师', '建造师', null);
INSERT INTO dictionarycontent VALUES ('8a8a80cf324be36e01326581516302db', '8a8a80cf324be36e0132658085c602ce', '其他', '其他', null);
INSERT INTO dictionarycontent VALUES ('8a8a801f357abd1a01357ee1572a012d', '8a8a801f357abd1a01357ee0f0520125', '二婚', '二婚', '');
INSERT INTO dictionarycontent VALUES ('8a8a800d392968fa0139296a3f43000c', '8a8a800d392968fa01392969e7ec0006', '煤矿1地址', 'http://10.10.0.147:8087', '');
INSERT INTO dictionarycontent VALUES ('8a8a800d392ce22201392ce736430070', '8a8a800d392ce22201392ce4bac30061', '煤炭板块', 'mtbk', '');

-- ----------------------------
-- Table structure for `educationhistory`
-- ----------------------------
DROP TABLE IF EXISTS `educationhistory`;
CREATE TABLE `educationhistory` (
  `EID` varchar(32) NOT NULL,
  `EMPLOYEEID` varchar(32) default NULL COMMENT '员工ID',
  `EDUCATION` varchar(32) default NULL COMMENT '学历',
  `SCHOOLNAME` varchar(100) default NULL COMMENT '学校名称',
  `PROFESSIONAL` varchar(100) default NULL COMMENT '专业',
  `GRADUATION` varchar(10) default NULL COMMENT '取证时间',
  `CERTIFICATE` varchar(100) default NULL COMMENT '证书号',
  `EDUTYPE` varchar(10) default NULL COMMENT '学历类型',
  PRIMARY KEY  (`EID`),
  KEY `FK_Reference_18` (`EMPLOYEEID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of educationhistory
-- ----------------------------

-- ----------------------------
-- Table structure for `employee`
-- ----------------------------
DROP TABLE IF EXISTS `employee`;
CREATE TABLE `employee` (
  `EMPLOYEEID` varchar(32) NOT NULL COMMENT '员工ID',
  `POSTID` varchar(32) default NULL COMMENT '岗位ID',
  `EMPLOYEECODE` varchar(32) default NULL COMMENT '员工编码',
  `EMPLOYEENAME` varchar(32) default NULL COMMENT '员工名字',
  `SEX` int(11) default NULL COMMENT '性别',
  `BIRTHDAY` varchar(10) default NULL COMMENT '生日',
  `ISVALIDATION` int(11) default NULL COMMENT '是否有效',
  `REMARK` varchar(100) default NULL COMMENT '备注',
  `ORDERNO` int(11) default NULL COMMENT '排序号',
  `NATION` varchar(32) default NULL COMMENT '民族',
  `WORKSTARTTIME` varchar(10) default NULL COMMENT '参加工作时间',
  `OUTLOOK` varchar(100) default NULL COMMENT '政治面貌',
  `ORIGIN` varchar(100) default NULL COMMENT '籍贯',
  `TITLE` varchar(100) default NULL COMMENT '职称',
  `EDUCATION` varchar(100) default NULL COMMENT '学历',
  `PROFESSIONAL` varchar(100) default NULL COMMENT '执业资格',
  `TITLEID` varchar(100) default NULL COMMENT '职称证编号',
  `ACCOUNTTYPE` varchar(100) default NULL COMMENT '户口性质',
  `ACCOUNT` varchar(100) default NULL COMMENT '户口所在地',
  `IDENTITY` varchar(18) default NULL COMMENT '身份证号码',
  `IDENTITYPLACE` varchar(100) default NULL COMMENT '身份证地址',
  `EMAIL` varchar(100) default NULL COMMENT '电子邮箱',
  `PHONE` varchar(100) default NULL COMMENT '联系电话',
  `PROFESSIONALLIFE` varchar(100) default NULL COMMENT '职称专业',
  `PROFESSIONALTYPE` varchar(30) default NULL COMMENT '职称性质',
  `WORKTIME` varchar(3) default NULL COMMENT '从业时间',
  `NOWWORKBEGIN` varchar(10) default NULL COMMENT '现机构服务开始时间',
  `NOWWORKEND` varchar(10) default NULL COMMENT '现机构服务结束时间',
  `WORKTYPE` varchar(100) default NULL COMMENT '工作性质',
  `OTHERPROFESSIONAL` varchar(100) default NULL COMMENT '其他职业资格',
  `OTHERPROFESSIONALID` varchar(100) default NULL COMMENT '其他职业资格证书编号',
  `NATIONAL` varchar(100) default NULL COMMENT '人大、政协任职',
  `ASSOCIATION` varchar(100) default NULL COMMENT '协会职务',
  `TRAINTIME` varchar(5) default NULL COMMENT '参加培训累计学时',
  `REPORTSCORES` varchar(5) default NULL COMMENT '签署报告分数（累计）',
  `PHOTO` longblob COMMENT '照片',
  `PEN` longblob COMMENT '电子签名',
  `OTHERPROFESSIONALIDTIME` varchar(10) default NULL COMMENT '其他职业资格取证时间',
  `MAINPLACE` varchar(100) default NULL COMMENT '主要工作场所',
  `BLOOD` varchar(10) default NULL COMMENT '血型',
  `MARRY` varchar(10) default NULL COMMENT '婚姻状况',
  `MOBILE` varchar(11) default NULL COMMENT '手机号码',
  `DUTYDATE` varchar(32) default NULL COMMENT '工种证件有效日期',
  `CARDID` varchar(16) default NULL COMMENT '识别卡编号',
  `EMAILPASSWORD` varchar(32) default NULL,
  PRIMARY KEY  (`EMPLOYEEID`),
  KEY `FK_Reference_3` (`POSTID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of employee
-- ----------------------------
INSERT INTO employee VALUES ('D5AD7B7A4C7B1FE4C3D29AC19489F8E6', '8a8a800d392ce22201392ce37d230012', 'LPP', '刘跑跑', '1', '', '1', '', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', null, '', '', '', '', '', '', null, null, '', '', '', '', '18624153462', '', '', '');

-- ----------------------------
-- Table structure for `feedback`
-- ----------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `FID` varchar(32) NOT NULL,
  `RID` varchar(32) default NULL COMMENT '资源ID',
  `RPATH` varchar(500) default NULL COMMENT '访问路径',
  `RCONTENT` text COMMENT '详细bug',
  `RNAME` varchar(32) default NULL COMMENT '资源名称',
  `RUSER` varchar(32) default NULL COMMENT '问题反馈者',
  `RUSERID` varchar(32) default NULL COMMENT '反馈者ID',
  `RTIME` varchar(19) default NULL COMMENT '反馈时间',
  `RTYPE` varchar(1) default NULL COMMENT '反馈类型',
  `RSTATE` varchar(1) default NULL COMMENT '处理状态',
  `RDOER` varchar(32) default NULL COMMENT '处理人',
  `RDOTIME` varchar(19) default NULL COMMENT '处理时间',
  `RDOTYPE` text COMMENT '处理方式',
  `REMARK` varchar(500) default NULL COMMENT '备注',
  `DUTYER` varchar(32) default NULL COMMENT '责任人',
  PRIMARY KEY  (`FID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of feedback
-- ----------------------------

-- ----------------------------
-- Table structure for `helpdoc`
-- ----------------------------
DROP TABLE IF EXISTS `helpdoc`;
CREATE TABLE `helpdoc` (
  `HID` varchar(32) NOT NULL,
  `HCONTENT` text,
  `ITEMID` varchar(64) default NULL COMMENT '业务ID',
  PRIMARY KEY  (`HID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of helpdoc
-- ----------------------------

-- ----------------------------
-- Table structure for `jdbcconfigurationinfo`
-- ----------------------------
DROP TABLE IF EXISTS `jdbcconfigurationinfo`;
CREATE TABLE `jdbcconfigurationinfo` (
  `JDBCID` varchar(32) NOT NULL COMMENT '主键ID',
  `DBNAME` varchar(50) default NULL COMMENT '数据库名',
  `DIALECT` varchar(100) default NULL COMMENT '方言',
  `URL` varchar(100) default NULL,
  `USERNAME` varchar(50) default NULL COMMENT '用户名',
  `PASSWORD` varchar(50) default NULL COMMENT '密码',
  PRIMARY KEY  (`JDBCID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of jdbcconfigurationinfo
-- ----------------------------
INSERT INTO jdbcconfigurationinfo VALUES ('8a8a800d38da9c520138dac9469a0123', 'oxhide', 'com.mysql.jdbc.Driver', 'jdbc:mysql://127.0.0.1:3309/oxhide?characterEncoding=gb2312', 'root', '');

-- ----------------------------
-- Table structure for `organ`
-- ----------------------------
DROP TABLE IF EXISTS `organ`;
CREATE TABLE `organ` (
  `ORGANID` varchar(32) NOT NULL COMMENT '机构id',
  `ORGANPID` varchar(32) default NULL COMMENT '机构id',
  `ORGANNAME` varchar(32) default NULL COMMENT '机构名称',
  `AREAID` varchar(32) default NULL COMMENT '地区编号',
  `ORGANCODE` varchar(32) default NULL COMMENT '编码',
  `ORGANALIAS` varchar(32) default NULL COMMENT '别名',
  `POSTCODE` varchar(10) default NULL COMMENT '邮编',
  `ADDRESS` varchar(32) default NULL COMMENT '地址',
  `TELEPHONE` varchar(32) default NULL COMMENT '单位电话',
  `FAX` varchar(50) default NULL COMMENT '传真',
  `REMARK` varchar(100) default NULL COMMENT '备注',
  `ISVALIDATION` int(11) default NULL COMMENT '是否有效',
  `ORGANMAN` varchar(32) default NULL,
  `ORGANMANID` varchar(32) default NULL,
  PRIMARY KEY  (`ORGANID`),
  KEY `FK_Reference_16` (`ORGANPID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312 COMMENT='机构';

-- ----------------------------
-- Records of organ
-- ----------------------------
INSERT INTO organ VALUES ('8a8a800d392ce22201392ce321a50006', null, '四和科技', null, 'SHKJ', '四和科技', null, '', '', '', '', null, '', '');

-- ----------------------------
-- Table structure for `posts`
-- ----------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `POSTID` varchar(32) NOT NULL COMMENT '岗位ID',
  `DEPTID` varchar(32) default NULL COMMENT '部门ID',
  `POSTPID` varchar(32) default NULL COMMENT '岗位ID',
  `POSTNAME` varchar(32) default NULL COMMENT '岗位名称',
  `POSTCODE` varchar(32) default NULL COMMENT '岗位编号',
  `ORDERNO` int(11) default NULL COMMENT '排序号',
  `ISVALIDATION` int(11) default NULL COMMENT '是否有效',
  `REMARK` varchar(100) default NULL COMMENT '备注',
  PRIMARY KEY  (`POSTID`),
  KEY `FK_Reference_19` (`POSTPID`),
  KEY `FK_Reference_2` (`DEPTID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of posts
-- ----------------------------
INSERT INTO posts VALUES ('8a8a800d392ce22201392ce37d230012', '8a8a800d392ce22201392ce35373000c', null, '程序员', 'CXY', '1', null, '');

-- ----------------------------
-- Table structure for `resources`
-- ----------------------------
DROP TABLE IF EXISTS `resources`;
CREATE TABLE `resources` (
  `RESOURCEID` varchar(32) NOT NULL COMMENT '资源ID',
  `RESOURCEPID` varchar(32) default NULL COMMENT '资源ID',
  `APPID` varchar(32) default NULL COMMENT 'ID',
  `RESOURCENAME` varchar(32) default NULL COMMENT '资源名称',
  `RESOURCEURL` varchar(400) default NULL COMMENT '资源地址',
  `ISVALIDATION` varchar(32) default NULL COMMENT '是否有效',
  `RESOURCECODE` varchar(32) default NULL COMMENT '资源编码',
  `ICO` varchar(60) default NULL COMMENT '图标',
  `BIGICO` varchar(60) default NULL COMMENT '大图标',
  `SELFCLICK` varchar(400) default NULL COMMENT '自定义单击事件',
  `TABNAME` varchar(32) default NULL COMMENT '选项卡名称',
  `ORDERNO` int(11) default '0' COMMENT '排序号',
  `DISPLAY` int(11) default '1' COMMENT '隐藏还是显示\r\n            1=显示 0=隐藏',
  `TARGET` int(11) default '1' COMMENT '打开方式 1=普通方式 2=对话框方式 3=新建窗口',
  `MENUTYPE` int(11) default NULL COMMENT '菜单类型 1=3级或3级以上 2=二级',
  `LARGEICO` varchar(60) default NULL COMMENT '超大图标',
  `SIMPLYNAME` varchar(8) default NULL COMMENT '简称',
  `REMARK` varchar(400) default NULL COMMENT '简介',
  `PROMPT` varchar(400) default NULL COMMENT '提示',
  `DISPLAYAPPID` varchar(32) default NULL COMMENT '显示的系统',
  `DISPLAYPID` varchar(32) default NULL COMMENT '显示的父资源',
  `MOBILEICO` varchar(60) default NULL,
  `MOBILEURL` varchar(400) default NULL,
  PRIMARY KEY  (`RESOURCEID`),
  KEY `FK_Reference_12` (`RESOURCEPID`),
  KEY `FK_Reference_13` (`APPID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of resources
-- ----------------------------
INSERT INTO resources VALUES ('8a8a80f22f8a91a8012f8a9c0791004f', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '组织机构', '', null, 'ZZJG', 'resource/base/theme/public/img/icon/013.png', 'resource/base/theme/public/img/bigicon/027.png', '', 'dsf', '1', '1', '1', '2', 'resource/base/theme/public/img/largeicon/050.png', '组织机构', '组织机构', '', '8a8a80f22f8a792c012f8a7d9a5a0020', '', 'resource/base/theme/public/img/mobileicon/001.png', '');
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f7cc7d40011', '8a8a80f22f8a91a8012f8a9c0791004f', '8a8a80f22f8a792c012f8a7d9a5a0020', '机构管理', 'organLoadAction.do?action=showList', null, 'JGGL', 'resource/base/theme/public/img/icon/1082.png', 'resource/base/theme/public/img/bigicon/144.png', '', '机构管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/095.png', '机构管理', '对机构进行管理', '', '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8a91a8012f8a9c0791004f', 'resource/base/theme/public/img/mobileicon/040.png', 'pages/organ.html');
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f7d425d001e', '8a8a80f22f8a91a8012f8a9c0791004f', '8a8a80f22f8a792c012f8a7d9a5a0020', '部门管理', 'pages/admin/dept/deptFrame.jsp', null, 'BMGL', 'resource/base/theme/public/img/icon/066.png', 'resource/base/theme/public/img/bigicon/060.png', null, '部门管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/056.png', '部门管理', '部门管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8a91a8012f8a9c0791004f', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f7dab2a002c', '8a8a80f22f8a91a8012f8a9c0791004f', '8a8a80f22f8a792c012f8a7d9a5a0020', '岗位管理', 'pages/admin/post/postFrame.jsp', null, 'GWGL', 'resource/base/theme/public/img/icon/065.png', 'resource/base/theme/public/img/bigicon/115.png', null, '岗位管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/060.png', '岗位管理', '岗位管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8a91a8012f8a9c0791004f', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f7e09d3003a', '8a8a80f22f8a91a8012f8a9c0791004f', '8a8a80f22f8a792c012f8a7d9a5a0020', '员工管理', 'pages/admin/employee/employeeFrame.jsp', null, 'YGGL', 'resource/base/theme/public/img/icon/021.png', 'resource/base/theme/public/img/bigicon/025.png', null, '员工管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/045.png', '员工管理', '员工管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8a91a8012f8a9c0791004f', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f7e500e0044', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '权限管理', null, null, 'QXGL', 'resource/base/theme/public/img/icon/054.png', 'resource/base/theme/public/img/bigicon/569.png', null, '权限管理', '4', '1', '1', '2', 'resource/base/theme/public/img/largeicon/244.png', '权限管理', '权限管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', null, 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f7ebb3a0051', '8a8a80f22f8f7b78012f8f7e500e0044', '8a8a80f22f8a792c012f8a7d9a5a0020', '资源管理', 'pages/admin/resource/resourceFrame.jsp', null, 'ZYGL', 'resource/base/theme/public/img/icon/287.png', 'resource/base/theme/public/img/bigicon/580.png', null, '资源管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/019.png', '资源管理', '资源管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8f7b78012f8f7e500e0044', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f7f318d005e', '8a8a80f22f8f7b78012f8f7e500e0044', '8a8a80f22f8a792c012f8a7d9a5a0020', '角色管理', 'ssorolesLoadAction.do?action=showList', null, 'JSGL', 'resource/base/theme/public/img/icon/826.png', 'resource/base/theme/public/img/bigicon/058.png', null, '角色管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/193.png', '角色管理', '角色管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8f7b78012f8f7e500e0044', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f7f88e9006b', '8a8a80f22f8f7b78012f8f7e500e0044', '8a8a80f22f8a792c012f8a7d9a5a0020', '用户管理', 'pages/admin/ssouser/userFrame.jsp', null, 'YHGL', 'resource/base/theme/public/img/icon/991.png', 'resource/base/theme/public/img/bigicon/059.png', '', '用户管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/365.png', '用户管理', '用户管理', '', '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8f7b78012f8f7e500e0044', 'resource/base/theme/public/img/mobileicon/001.png', '');
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f80477b0076', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '基本信息', null, null, 'JBXX', 'resource/base/theme/public/img/icon/081.png', 'resource/base/theme/public/img/bigicon/058.png', null, '基本信息', '2', '1', '1', '2', 'resource/base/theme/public/img/largeicon/037.png', '基本信息', '基本信息', null, '8a8a80f22f8a792c012f8a7d9a5a0020', null, 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f8134010082', '8a8a80f22f8f7b78012f8f80477b0076', '8a8a80f22f8a792c012f8a7d9a5a0020', '数据字典类型管理', 'dictionaryLoadAction.do?action=showList', null, 'SJZDLXGL', 'resource/base/theme/public/img/icon/027.png', 'resource/base/theme/public/img/bigicon/030.png', null, '数据字典类型管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/131.png', '数据字典', '数据字典类型管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8f7b78012f8f80477b0076', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f8f7b78012f8f81ada7008f', '8a8a80f22f8f7b78012f8f80477b0076', '8a8a80f22f8a792c012f8a7d9a5a0020', '数据字典内容管理', 'dictionarycontentLoadAction.do?action=showList', null, 'SJZDNRGL', 'resource/base/theme/public/img/icon/068.png', 'resource/base/theme/public/img/bigicon/055.png', null, '数据字典内容管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/329.png', '数据字典', '数据字典内容管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8f7b78012f8f80477b0076', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80f22f948d11012f94924ae10020', '8a8a80f22f8f7b78012f8f7e500e0044', '8a8a80f22f8a792c012f8a7d9a5a0020', '应用系统管理', 'applicationLoadAction.do?action=showList', null, 'XTGL', 'resource/base/theme/public/img/icon/1018.png', 'resource/base/theme/public/img/bigicon/090.png', null, '应用系统管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/356.png', '应用系统', '应用系统管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8f7b78012f8f7e500e0044', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80662fb9081f012fb9093d0a0011', '8a8a80f22f8f7b78012f8f80477b0076', '8a8a80f22f8a792c012f8a7d9a5a0020', '样式管理', 'schemaLoadAction.do?action=showList', null, 'YSGL', 'resource/base/theme/public/img/icon/068.png', 'resource/base/theme/public/img/bigicon/056.png', null, '样式管理', '0', '1', '1', '2', 'resource/base/theme/public/img/largeicon/004.png', '样式管理', '样式管理', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80f22f8f7b78012f8f80477b0076', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80c63155d8e7013155de4c370009', 'D9FF313E55FA6C774AB2EEB9CB922446', '8a8a80f22f8a792c012f8a7d9a5a0020', '系统日志', 'systemlogLoadAction.do?action=showList', null, 'XTRZ', 'resource/base/theme/public/img/icon/1613.png', 'resource/base/theme/public/img/bigicon/001.png', '', '系统日志', '1', '1', '1', '2', 'resource/base/theme/public/img/largeicon/005.png', '系统日志', '可以查看所有用户的操作记录', '', '8a8a80f22f8a792c012f8a7d9a5a0020', 'D9FF313E55FA6C774AB2EEB9CB922446', 'resource/base/theme/public/img/mobileicon/001.png', '');
INSERT INTO resources VALUES ('8a8a80cf31e0f5070131e11b6076001a', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '平台隐藏资源', null, null, 'PTYZZY', 'resource/base/theme/public/img/icon/001.png', 'resource/base/theme/public/img/bigicon/001.png', null, '平台隐藏资源', '5', '0', '1', '2', 'resource/base/theme/public/img/largeicon/001.png', '简称', '平台隐藏资源', null, '8a8a80f22f8a792c012f8a7d9a5a0020', null, 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('8a8a80cf31e0f5070131e11bd578001d', '8a8a80cf31e0f5070131e11b6076001a', '8a8a80f22f8a792c012f8a7d9a5a0020', '在线人员操作', null, null, 'ZXRYCZ', 'resource/base/theme/public/img/icon/001.png', 'resource/base/theme/public/img/bigicon/001.png', null, '在线人员操作', '1', '1', '1', '2', 'resource/base/theme/public/img/largeicon/001.png', '简称', '在线人员操作', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a80cf31e0f5070131e11b6076001a', 'resource/base/theme/public/img/mobileicon/001.png', null);
INSERT INTO resources VALUES ('C6EB122F1798E85707D3A8FBC9190F53', 'D9FF313E55FA6C774AB2EEB9CB922446', '8a8a80f22f8a792c012f8a7d9a5a0020', '动态建表', '/tablesLoadAction.do?action=showList', null, 'DTJB', 'resource/base/theme/public/img/icon/001.png', 'resource/base/theme/public/img/bigicon/001.png', '', '动态建表', '2', '1', '1', '2', 'resource/base/theme/public/img/largeicon/001.png', '动态建表', '系统设置', '', '8a8a80f22f8a792c012f8a7d9a5a0020', 'D9FF313E55FA6C774AB2EEB9CB922446', 'resource/base/theme/public/img/mobileicon/038.png', '');
INSERT INTO resources VALUES ('3B99169A2D1D876DC0AF01816A69EEE1', 'D9FF313E55FA6C774AB2EEB9CB922446', '8a8a80f22f8a792c012f8a7d9a5a0020', '站内搜索实例', '/searchIndexLoadAction.do?action=showList', null, 'ZNSSSL', 'resource/base/theme/public/img/icon/001.png', 'resource/base/theme/public/img/bigicon/001.png', '', '站内搜索实例', '3', '1', '1', '2', 'resource/base/theme/public/img/largeicon/001.png', '站内搜索', '', '', '8a8a80f22f8a792c012f8a7d9a5a0020', 'D9FF313E55FA6C774AB2EEB9CB922446', 'resource/base/theme/public/img/mobileicon/001.png', '');
INSERT INTO resources VALUES ('12DF4111D8BD6F7119624009C148841D', 'D9FF313E55FA6C774AB2EEB9CB922446', '8a8a80f22f8a792c012f8a7d9a5a0020', '索引数据源', '/jdbcconfigurationinfoLoadAction.do?action=showList', null, 'SYSJY', 'resource/base/theme/public/img/icon/001.png', 'resource/base/theme/public/img/bigicon/001.png', '', '索引数据源', '4', '1', '1', '2', 'resource/base/theme/public/img/largeicon/001.png', '索引数据', '', '', '8a8a80f22f8a792c012f8a7d9a5a0020', 'D9FF313E55FA6C774AB2EEB9CB922446', 'resource/base/theme/public/img/mobileicon/001.png', '');
INSERT INTO resources VALUES ('D9FF313E55FA6C774AB2EEB9CB922446', null, '8a8a80f22f8a792c012f8a7d9a5a0020', '插件', '', null, 'CJ', 'resource/base/theme/public/img/icon/001.png', 'resource/base/theme/public/img/bigicon/001.png', '', '插件', '6', '1', '1', '2', 'resource/base/theme/public/img/largeicon/001.png', '插件', '', '', '8a8a80f22f8a792c012f8a7d9a5a0020', '', 'resource/base/theme/public/img/mobileicon/001.png', '');
INSERT INTO resources VALUES ('3EA6925A878ED4A2306C3D9DB180AFD3', 'D9FF313E55FA6C774AB2EEB9CB922446', '8a8a80f22f8a792c012f8a7d9a5a0020', '启动项管理', '/runappsLoadAction.do?action=showList', null, 'QDXGL', 'resource/base/theme/public/img/icon/001.png', 'resource/base/theme/public/img/bigicon/001.png', '', '启动项管理', '5', '1', '1', '2', 'resource/base/theme/public/img/largeicon/001.png', '启动项管', '', '', '8a8a80f22f8a792c012f8a7d9a5a0020', 'D9FF313E55FA6C774AB2EEB9CB922446', 'resource/base/theme/public/img/mobileicon/001.png', '');
INSERT INTO resources VALUES ('D94AACE443D6D5D6BE08CFE6AE264656', 'D9FF313E55FA6C774AB2EEB9CB922446', '8a8a80f22f8a792c012f8a7d9a5a0020', '问题处理', '/feedbackLoadAction.do?action=showList', null, 'WTCL', 'resource/base/theme/public/img/icon/001.png', 'resource/base/theme/public/img/bigicon/001.png', '', '问题处理', '6', '1', '1', '2', 'resource/base/theme/public/img/largeicon/001.png', '问题处理', '', '/feedbackLoadAction.do?action=showTask', '8a8a80f22f8a792c012f8a7d9a5a0020', 'D9FF313E55FA6C774AB2EEB9CB922446', 'resource/base/theme/public/img/mobileicon/001.png', '');

-- ----------------------------
-- Table structure for `rolesapp`
-- ----------------------------
DROP TABLE IF EXISTS `rolesapp`;
CREATE TABLE `rolesapp` (
  `ROLESAPPID` varchar(32) NOT NULL,
  `APPID` varchar(32) default NULL COMMENT 'ID',
  `ROLEID` varchar(32) default NULL COMMENT '角色ID',
  PRIMARY KEY  (`ROLESAPPID`),
  KEY `FK_Reference_14` (`APPID`),
  KEY `FK_Reference_15` (`ROLEID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of rolesapp
-- ----------------------------
INSERT INTO rolesapp VALUES ('8a8a800d399a967901399a97a1c90049', '8a8a80f22f8a792c012f8a7d9a5a0020', '8a8a801f33882abd0133882c57f4000e');

-- ----------------------------
-- Table structure for `rolesresources`
-- ----------------------------
DROP TABLE IF EXISTS `rolesresources`;
CREATE TABLE `rolesresources` (
  `RESOURCEROLEID` varchar(32) NOT NULL COMMENT 'ID',
  `RESOURCEID` varchar(32) default NULL COMMENT '资源ID',
  `ROLEID` varchar(32) default NULL COMMENT '角色ID',
  PRIMARY KEY  (`RESOURCEROLEID`),
  KEY `FK_Reference_5` (`RESOURCEID`),
  KEY `FK_Reference_6` (`ROLEID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of rolesresources
-- ----------------------------
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a1aa0046', '3EA6925A878ED4A2306C3D9DB180AFD3', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a1aa0045', '12DF4111D8BD6F7119624009C148841D', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a19a0044', '3B99169A2D1D876DC0AF01816A69EEE1', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a19a0043', 'C6EB122F1798E85707D3A8FBC9190F53', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a19a0042', '8a8a80c63155d8e7013155de4c370009', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a18b0041', 'D9FF313E55FA6C774AB2EEB9CB922446', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a17b0040', '8a8a80cf31e0f5070131e11bd578001d', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a16b003f', '8a8a80cf31e0f5070131e11b6076001a', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a15c003e', '8a8a80662fb9081f012fb9093d0a0011', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a15c003d', '8a8a80f22f8f7b78012f8f81ada7008f', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a15c003c', '8a8a80f22f8f7b78012f8f8134010082', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a15c003b', '8a8a80f22f8f7b78012f8f80477b0076', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a15c003a', '8a8a80f22f948d11012f94924ae10020', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a15c0039', '8a8a80f22f8f7b78012f8f7f88e9006b', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a14c0038', '8a8a80f22f8f7b78012f8f7f318d005e', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a14c0037', '8a8a80f22f8f7b78012f8f7ebb3a0051', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a14c0036', '8a8a80f22f8f7b78012f8f7e500e0044', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a14c0035', '8a8a80f22f8f7b78012f8f7e09d3003a', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a13d0034', '8a8a80f22f8f7b78012f8f7dab2a002c', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a13d0033', '8a8a80f22f8f7b78012f8f7d425d001e', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a13d0032', '8a8a80f22f8f7b78012f8f7cc7d40011', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a13d0031', '8a8a80f22f8a91a8012f8a9c0791004f', '8a8a801f33882abd0133882c57f4000e');
INSERT INTO rolesresources VALUES ('8a8a800d399a967901399a97a1aa0047', 'D94AACE443D6D5D6BE08CFE6AE264656', '8a8a801f33882abd0133882c57f4000e');

-- ----------------------------
-- Table structure for `runapps`
-- ----------------------------
DROP TABLE IF EXISTS `runapps`;
CREATE TABLE `runapps` (
  `RUNID` varchar(32) NOT NULL,
  `RUNNAME` varchar(32) default NULL COMMENT '启动项名称',
  `RUNPATH` varchar(500) default NULL COMMENT '启动项命令',
  `NEEDCLOSE` varchar(1) default NULL COMMENT '是否需要关闭',
  `ENABLE` varchar(1) default NULL COMMENT '是否有效',
  `REMARK` varchar(500) default NULL COMMENT '备注',
  PRIMARY KEY  (`RUNID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of runapps
-- ----------------------------

-- ----------------------------
-- Table structure for `search_index`
-- ----------------------------
DROP TABLE IF EXISTS `search_index`;
CREATE TABLE `search_index` (
  `SID` varchar(32) NOT NULL COMMENT '主键ID',
  `JDBCID` varchar(32) default NULL COMMENT '主键ID',
  `SEARCH_TABLE` varchar(50) default NULL COMMENT '要查询的表名',
  `SEARCH_ID_COLUMN` varchar(50) default NULL COMMENT '要查询id列名',
  `SEARCH_TITLE_COLUMN` varchar(50) default NULL COMMENT '要查询title列名',
  `SEARCH_CONTENT_COLUMN` varchar(50) default NULL COMMENT '要查询content列名',
  `SEARCH_TABLE_WHERE` varchar(50) default NULL COMMENT '要查询的条件',
  `CONTENTURL` varchar(100) default NULL COMMENT '查看内容的url',
  PRIMARY KEY  (`SID`),
  KEY `FK_Reference_30` (`JDBCID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of search_index
-- ----------------------------
INSERT INTO search_index VALUES ('8a8a800d38dfdaa50138dfdf5fe100a8', '8a8a800d38da9c520138dac9469a0123', 'systemlog', 'SID', 'OPERATE_EMP', 'OPERATE_CONTENT', '', 'http://127.0.0.1:8081/oxhide//systemlogShowAction.do?action=showView');

-- ----------------------------
-- Table structure for `sels`
-- ----------------------------
DROP TABLE IF EXISTS `sels`;
CREATE TABLE `sels` (
  `SID` varchar(32) NOT NULL,
  `CID` varchar(32) default NULL,
  `TID` varchar(32) default NULL,
  `SNAME` varchar(32) default NULL COMMENT '名称',
  `SWITH` int(3) default NULL COMMENT '关系',
  `ORDERNO` varchar(1) default NULL COMMENT '排序号',
  `SHOWTYPE` varchar(200) default NULL COMMENT '显示类型',
  `CNAME` varchar(32) default NULL COMMENT '别名',
  `TIMER` varchar(32) default NULL COMMENT '时间控件',
  `GETDATA` varchar(1) default NULL COMMENT '取数类型 1=不取，2=数据字典，3=静态',
  `DATA` varchar(4000) default NULL COMMENT '取数值',
  PRIMARY KEY  (`SID`),
  KEY `FK_Reference_6` (`CID`),
  KEY `FK_Reference_7` (`TID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of sels
-- ----------------------------

-- ----------------------------
-- Table structure for `ssoroles`
-- ----------------------------
DROP TABLE IF EXISTS `ssoroles`;
CREATE TABLE `ssoroles` (
  `ROLEID` varchar(32) NOT NULL COMMENT '角色ID',
  `ROLENAME` varchar(32) default NULL COMMENT '角色名字',
  `ROLECODE` varchar(32) default NULL COMMENT '角色编码',
  `REMARK` varchar(100) default NULL COMMENT '备注',
  `ISVALIDATION` int(11) default NULL COMMENT '是否有效',
  PRIMARY KEY  (`ROLEID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of ssoroles
-- ----------------------------
INSERT INTO ssoroles VALUES ('8a8a801f33882abd0133882c57f4000e', '管理员', 'GLY', null, null);

-- ----------------------------
-- Table structure for `ssousers`
-- ----------------------------
DROP TABLE IF EXISTS `ssousers`;
CREATE TABLE `ssousers` (
  `USERID` varchar(32) NOT NULL COMMENT 'ID',
  `EMPLOYEEID` varchar(32) default NULL COMMENT '员工ID',
  `USERNAME` varchar(32) default NULL COMMENT '用户名',
  `PASSWORD` varchar(32) default NULL COMMENT '密码',
  `ISVALIDATION` int(11) default NULL COMMENT '是否有效',
  `FACESTYLE` varchar(32) default NULL COMMENT '样式',
  `ISSINGEL` int(11) default '1' COMMENT '是否单点登录 1=是 0=否',
  `APPLE` varchar(64) default NULL COMMENT 'IPAD',
  `ANDROID` varchar(64) default NULL COMMENT '安卓',
  `DESKTYPE` varchar(1) default NULL,
  `DESK` text,
  PRIMARY KEY  (`USERID`),
  KEY `FK_Reference_7` (`EMPLOYEEID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of ssousers
-- ----------------------------
INSERT INTO ssousers VALUES ('6752505C04F192FC3787FF6F59B3DE92', 'D5AD7B7A4C7B1FE4C3D29AC19489F8E6', 'admin', 'be5f1c15b1d51d6f4be84eb34cb965c3', '1', 'sheet2', '0', '', '', '', '');

-- ----------------------------
-- Table structure for `sysconfig`
-- ----------------------------
DROP TABLE IF EXISTS `sysconfig`;
CREATE TABLE `sysconfig` (
  `SCODE` varchar(32) NOT NULL,
  `SVALUE` varchar(200) default NULL,
  PRIMARY KEY  (`SCODE`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of sysconfig
-- ----------------------------
INSERT INTO sysconfig VALUES ('baselogin', '/login/loginCoalNew.jsp');
INSERT INTO sysconfig VALUES ('basesession', '120');
INSERT INTO sysconfig VALUES ('smsopen', '0');
INSERT INTO sysconfig VALUES ('smstime', '30000');
INSERT INTO sysconfig VALUES ('smscom', '12');
INSERT INTO sysconfig VALUES ('smsbaud', '9600');
INSERT INTO sysconfig VALUES ('smstail', '此消息来自<title>,如需取消订阅，请回复QX<code>');
INSERT INTO sysconfig VALUES ('androidopen', '0');
INSERT INTO sysconfig VALUES ('androidport', '5186');
INSERT INTO sysconfig VALUES ('searchCreateIndex', '0');
INSERT INTO sysconfig VALUES ('searchIndexPath', 'd://index');
INSERT INTO sysconfig VALUES ('baseError', '');
INSERT INTO sysconfig VALUES ('smsport', '4444');

-- ----------------------------
-- Table structure for `systemlog`
-- ----------------------------
DROP TABLE IF EXISTS `systemlog`;
CREATE TABLE `systemlog` (
  `SID` varchar(32) NOT NULL,
  `OPERATE_TIME` varchar(19) default NULL COMMENT '操作时间',
  `OPERATE_IP` varchar(15) default NULL COMMENT '操作IP',
  `OPERATE_PERSON` varchar(32) default NULL COMMENT '操作用户',
  `OPERATE_EMP` varchar(32) default NULL COMMENT '操作员工',
  `OPERATE_SYS` varchar(64) default NULL COMMENT '操作系统',
  `OPERATE_MODEL` varchar(64) default NULL COMMENT '操作模块',
  `OPERATE_CONTENT` varchar(32) default NULL COMMENT '操作内容',
  `OPERATE_TYPE` varchar(1) default NULL COMMENT '操作类型 1正常 0异常',
  `REMARK` varchar(500) default NULL COMMENT '备注',
  PRIMARY KEY  (`SID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of systemlog
-- ----------------------------

-- ----------------------------
-- Table structure for `tables`
-- ----------------------------
DROP TABLE IF EXISTS `tables`;
CREATE TABLE `tables` (
  `TID` varchar(32) NOT NULL,
  `PTID` varchar(32) default NULL COMMENT '父表',
  `TCODE` varchar(32) default NULL COMMENT '表名',
  `TNAME` varchar(32) default NULL COMMENT '中文名',
  `REMARK` varchar(200) default NULL COMMENT '备注',
  `MAINCOL` varchar(32) default NULL COMMENT '主要属性',
  `MENUID` varchar(32) default NULL COMMENT '菜单ID',
  PRIMARY KEY  (`TID`),
  KEY `FK_Reference_8` (`PTID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tables
-- ----------------------------

-- ----------------------------
-- Table structure for `tokens`
-- ----------------------------
DROP TABLE IF EXISTS `tokens`;
CREATE TABLE `tokens` (
  `TID` varchar(32) NOT NULL,
  `USERID` varchar(32) default NULL COMMENT 'ID',
  `APPID` varchar(32) default NULL COMMENT 'ID',
  `TOKEN` varchar(80) default NULL COMMENT '令牌',
  `TOKENTYPE` varchar(10) default NULL COMMENT '类型',
  PRIMARY KEY  (`TID`),
  KEY `FK_Reference_23` (`USERID`),
  KEY `FK_Reference_24` (`APPID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of tokens
-- ----------------------------

-- ----------------------------
-- Table structure for `t_accessories`
-- ----------------------------
DROP TABLE IF EXISTS `t_accessories`;
CREATE TABLE `t_accessories` (
  `ACCE_ID` varchar(60) NOT NULL COMMENT '附件ID',
  `ITEM_ID` varchar(160) default NULL COMMENT '业务ID',
  `FILE_PATH` varchar(200) default NULL COMMENT '文件路径',
  `FILE_NAME` varchar(200) default NULL COMMENT '文件名称',
  `FILE_SIZE` float default NULL COMMENT '文件大小',
  `UPLOAD_DATE` varchar(20) default NULL COMMENT '上传日期',
  `SHOW_AS_IMAGE` int(11) default '0' COMMENT '是否以图片显示:0 是1 否',
  `EMPLOYEEID` varchar(32) default NULL,
  `EMPLOYEENAME` varchar(32) default NULL,
  `FILETYPE` varchar(32) default NULL,
  `REALPATH` varchar(300) default NULL,
  PRIMARY KEY  (`ACCE_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312 COMMENT='附件资料表(公共组件)';

-- ----------------------------
-- Records of t_accessories
-- ----------------------------
INSERT INTO t_accessories VALUES ('8a8a800d3922f5030139230214640009', '8a8a80f22f8a792c012f8a7d9a5a0020_sheet1', '/resource/logo/sheet1/8a8a80f22f8a792c012f8a7d9a5a0020_sheet11344912102484.jpg', 'logo_01.jpg', '17508', '2012-08-14 10:41', '0', '1', '超级管理员', 'image', 'C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\oxhide\\/resource/logo/sheet1/8a8a80f22f8a792c012f8a7d9a5a0020_sheet11344912102484.jpg');
INSERT INTO t_accessories VALUES ('8a8a800d38d69a1c0138d6c432730041', '8a8a80f22f8a792c012f8a7d9a5a0020_schema5', '/resource/logo/schema5/8a8a80f22f8a792c012f8a7d9a5a0020_schema51343632978547.jpg', '首页.jpg', '240277', '2012-07-30 15:22', '0', '51814D3F2270C851B06D84B23F12FEBD', '张晓雷', 'image', 'C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\oxhide\\/resource/logo/schema5/8a8a80f22f8a792c012f8a7d9a5a0020_schema51343632978547.jpg');
INSERT INTO t_accessories VALUES ('8a8a800d38d69a1c0138d6c48af30045', '8a8a80f22f8a792c012f8a7d9a5a0020_schema3', '/resource/logo/schema3/8a8a80f22f8a792c012f8a7d9a5a0020_schema31343633001203.jpg', '首页.jpg', '240277', '2012-07-30 15:23', '0', '51814D3F2270C851B06D84B23F12FEBD', '张晓雷', 'image', 'C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\oxhide\\/resource/logo/schema3/8a8a80f22f8a792c012f8a7d9a5a0020_schema31343633001203.jpg');
INSERT INTO t_accessories VALUES ('8a8a800d38d69a1c0138d6c490620046', '8a8a80f22f8a792c012f8a7d9a5a0020_schema4', '/resource/logo/schema4/8a8a80f22f8a792c012f8a7d9a5a0020_schema41343633002594.jpg', '首页.jpg', '240277', '2012-07-30 15:23', '0', '51814D3F2270C851B06D84B23F12FEBD', '张晓雷', 'image', 'C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\oxhide\\/resource/logo/schema4/8a8a80f22f8a792c012f8a7d9a5a0020_schema41343633002594.jpg');
INSERT INTO t_accessories VALUES ('8a8a800d38d69a1c0138d6c498dd0047', '8a8a80f22f8a792c012f8a7d9a5a0020_schema1', '/resource/logo/schema1/8a8a80f22f8a792c012f8a7d9a5a0020_schema11343633004765.jpg', '首页.jpg', '240277', '2012-07-30 15:23', '0', '51814D3F2270C851B06D84B23F12FEBD', '张晓雷', 'image', 'C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\oxhide\\/resource/logo/schema1/8a8a80f22f8a792c012f8a7d9a5a0020_schema11343633004765.jpg');
INSERT INTO t_accessories VALUES ('8a8a800d38d69a1c0138d6c49dcf0048', '8a8a80f22f8a792c012f8a7d9a5a0020_schema2', '/resource/logo/schema2/8a8a80f22f8a792c012f8a7d9a5a0020_schema21343633006015.jpg', '首页.jpg', '240277', '2012-07-30 15:23', '0', '51814D3F2270C851B06D84B23F12FEBD', '张晓雷', 'image', 'C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\oxhide\\/resource/logo/schema2/8a8a80f22f8a792c012f8a7d9a5a0020_schema21343633006015.jpg');
INSERT INTO t_accessories VALUES ('8a8a800d38d69a1c0138d6c4a08e0049', '8a8a80f22f8a792c012f8a7d9a5a0020_schema6', '/resource/logo/schema6/8a8a80f22f8a792c012f8a7d9a5a0020_schema61343633006734.jpg', '首页.jpg', '240277', '2012-07-30 15:23', '0', '51814D3F2270C851B06D84B23F12FEBD', '张晓雷', 'image', 'C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\oxhide\\/resource/logo/schema6/8a8a80f22f8a792c012f8a7d9a5a0020_schema61343633006734.jpg');
INSERT INTO t_accessories VALUES ('8a8a800d3922f5030139230215ac000a', '8a8a80f22f8a792c012f8a7d9a5a0020_sheet2', '/resource/logo/sheet2/8a8a80f22f8a792c012f8a7d9a5a0020_sheet21344912102828.jpg', 'logo_01.jpg', '17508', '2012-08-14 10:41', '0', '1', '超级管理员', 'image', 'C:\\Program Files\\Apache Software Foundation\\Tomcat 6.0\\webapps\\oxhide\\/resource/logo/sheet2/8a8a80f22f8a792c012f8a7d9a5a0020_sheet21344912102828.jpg');

-- ----------------------------
-- Table structure for `t_schema`
-- ----------------------------
DROP TABLE IF EXISTS `t_schema`;
CREATE TABLE `t_schema` (
  `SCHEMAID` varchar(32) NOT NULL,
  `SCHEMANAME` varchar(32) default NULL COMMENT '名臣',
  `FOLDER` varchar(64) default NULL COMMENT '目录 ',
  `DIALOG` varchar(5) default NULL COMMENT '对话框方式',
  PRIMARY KEY  (`SCHEMAID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of t_schema
-- ----------------------------
INSERT INTO t_schema VALUES ('8a8a800d38ea13230138ea15fc840009', '绿色春意', 'sheet2', '');
INSERT INTO t_schema VALUES ('8a8a800d38a1cd930138a21c32b00058', '蓝色海洋', 'sheet1', '');

-- ----------------------------
-- Table structure for `unmobile`
-- ----------------------------
DROP TABLE IF EXISTS `unmobile`;
CREATE TABLE `unmobile` (
  `EMPLOYEEID` varchar(32) default NULL COMMENT '员工ID',
  `UNID` varchar(32) NOT NULL,
  `APPID` varchar(32) default NULL COMMENT 'ID',
  `UDATE` varchar(19) default NULL,
  PRIMARY KEY  (`UNID`),
  KEY `FK_Reference_25` (`EMPLOYEEID`),
  KEY `FK_Reference_26` (`APPID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of unmobile
-- ----------------------------

-- ----------------------------
-- Table structure for `usersroles`
-- ----------------------------
DROP TABLE IF EXISTS `usersroles`;
CREATE TABLE `usersroles` (
  `USERROLEID` varchar(32) NOT NULL,
  `ROLEID` varchar(32) default NULL COMMENT '角色ID',
  `USERID` varchar(32) default NULL COMMENT 'ID',
  PRIMARY KEY  (`USERROLEID`),
  KEY `FK_Reference_21` (`ROLEID`),
  KEY `FK_Reference_22` (`USERID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of usersroles
-- ----------------------------
INSERT INTO usersroles VALUES ('8a8a800d392ce22201392ce435190020', '8a8a801f33882abd0133882c57f4000e', '6752505C04F192FC3787FF6F59B3DE92');

-- ----------------------------
-- Table structure for `workhistory`
-- ----------------------------
DROP TABLE IF EXISTS `workhistory`;
CREATE TABLE `workhistory` (
  `HID` varchar(32) NOT NULL,
  `EMPLOYEEID` varchar(32) default NULL COMMENT '员工ID',
  `BEGINTIME` varchar(10) default NULL COMMENT '开始时间',
  `ENDTIME` varchar(10) default NULL COMMENT '结束时间',
  `ORGANNAME` varchar(32) default NULL COMMENT '机构名',
  `ORGANID` varchar(32) default NULL COMMENT '机构ID',
  `DEPT` varchar(32) default NULL COMMENT '部门',
  `DEPTID` varchar(32) default NULL COMMENT '部门名',
  `POST` varchar(32) default NULL COMMENT '岗位',
  `POSTID` varchar(32) default NULL COMMENT '岗位ID',
  `REMARK` varchar(200) default NULL COMMENT '调用原因',
  PRIMARY KEY  (`HID`),
  KEY `FK_Reference_17` (`EMPLOYEEID`)
) ENGINE=MyISAM DEFAULT CHARSET=gb2312;

-- ----------------------------
-- Records of workhistory
-- ----------------------------
