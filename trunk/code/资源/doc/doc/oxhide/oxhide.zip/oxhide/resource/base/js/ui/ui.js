window.loginurl = window.location.toString().match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/i);
var oxhideBack = {
    /*会话过期事件*/
    sessionOut: function() {
        var LoginDg = htmlWin({
            title: "您登录时间太久，为了您的账户安全，请重新登录！",
            id: "loginTForm",
            html: document.getElementById("loginDiv"),
            width: 400,
            height: 200,
            cancel: "no",
            xButton: "no",
            fns: [{
                name: "注销",
                fn: function() {
                    if (confirm("确定要注销吗？")) {
                        window.location = data.basePath + "/loginAction.do?action=clearSessionSelf";
                    }
                }
            },
            {
                name: "确定",
                fn: function() {
                    if (window.loaders) return;
                    if (!$("#username").val()) {
                        $.msgBar({
                            type: "error",
                            position: "bottom-center",
                            'text': '请输入账号!',
                            lifetime: 3500
                        });
                        return;
                    }
                    window.loaders = true;
                    if (!$("#password").val()) {
                        $.msgBar({
                            type: "error",
                            position: "bottom-center",
                            'text': '请输入密码!',
                            lifetime: 3500
                        });
                        return;
                    }
                    $.msgBar({
                        type: "info",
                        position: "bottom-center",
                        text: '正在验证用户名和密码...',
                        lifetime: 3500
                    });
                    login.checkUser($("#username").val(), $("#password").val(),
                    function(result) {
                        if (result) {
                            $.msgBar({
                                type: "info",
                                position: "bottom-center",
                                'text': '验证成功，正在登录，请稍候！',
                                lifetime: 3500
                            });
                            $(document.loginForm).append($("#username,#password"))[0].submit();
                        } else {
                            $.msgBar({
                                type: "error",
                                position: "bottom-center",
                                'text': '用户名或密码错误！如果忘记了您的密码，请联系管理员！',
                                lifetime: 3500
                            });
                        }
                        window.loaders = false;
                    });
                }
            }]
        });
    }
};
var data = {
    prompt: null,
    one: null,
    appid: null,
    apps: null,
    commonMenus: null,
    boxMenus: null,
    faceStyle: null,
    sessionid: null,
    basePath: null,
    imgPath: null,
    ip: null,
    firstLeft: null,
    userId: null,
    play: "/resource/base/sound/message.mp3",
    ids: {
        appScope: "#appScope",
        appTitle: "#appTitle",
        more: "#more",
        moreTip: "#moretip",
        rolin: "#rolin",
        left: "#left",
        right: "#right",
        boxaon: "#boxaon",
        head: "#head",
        foot: "#foot",
        pageLabelScore: "#pageLabelScore",
        pageScore: "#pageScore",
        tip: "#tip",
        trash: "#trash",
        //箱子ID
        left_tab: "#left_tab",
        right_tab: "#right_tab"
    },
    mustache: {
        top: '#top_mustache',
        scMenuClone: "#scMenuClone"
    },
    dragConfig: {
        scroll: false,
        helper: "clone",
        revert: 'invalid',
        opacity: 0.7,
        zIndex: '99999',
        delay:500,
        stop: function(e, u) {
            $(data.ids.trash).hide('explode');
            $.ZZ();
        },
        start: function(e, ui) {
            if ($(ui.helper).children("ul")[0]) { //有下级菜单的不处理
                return false;
            }
            $.ZZ(1);
            $(ui.helper).parents("div:eq(0)").is(data.ids.rolin) || $(ui.helper).parents("ui:eq(0)").is(data.ids.pageLabelScore) ? //切换图片，已添加和删除为准
            $(data.ids.trash).attr('src', data.imgPath + "1.png") : $(data.ids.trash).attr('src', data.imgPath + "lj_1.png");
            $(data.ids.trash).show('bounce');
        }
    }
};
data.leftHeight = null;
data.cyMinMenuCount = 3;
data.hide = ['#appScopeP', '#msg', '#sendMsg', '#lxr', '#sendMsgBefore'];
data.tophoversrc = [['top_03.png', 'top_03over.png'], ['top_05.png', 'top_05over.png'], ['top_07.png', 'top_07over.png'], ['top_10.png', 'top_10over.png'], ['top_09.png', 'top_09over.png']];
var boxMenu = {};
boxMenu.add = function(o) {
    if (!$.isArray(o)) {
        o = [o];
    }
    $.each(o,
    function(i, n) { 
        var scmenu = $(data.mustache.scMenuClone).clone();
        scmenu.removeAttr('id');
        var url = n.menuurl.indexOf("?") == -1 ? n.menuurl + "?box=true": n.menuurl + "&box=true";
        scmenu.attr({
            name: n.bid,
            t: 2,
            url: url
        });
        scmenu.children("a").text(n.menuname).attr("title", n.menuname);
        scmenu.draggable(data.dragConfig);
        $("#scRolin ul").append(scmenu);
    })
}
var protext = function(n) {
    if (n.length > 9) return n.substring(0, 9) + '..';
    else return n;
}
$(function() {
    $("a", data.ids.head).hover(function() {
        var index = $("a", data.ids.head).index(this);
        if (index > 3) return;
        $("img", this).attr('src', data.imgPath + data.tophoversrc[index][1]);
    },
    function() {
        var index = $("a", data.ids.head).index(this);
        if (index > 3) return;
        $("img", this).attr('src', data.imgPath + data.tophoversrc[index][0]);
    });
}); (function(w) {
    var menu = function() {}
    var tabProcess = function() {
        var wh = $(".pageLabel").width(),
        whx = $(data.ids.pageLabelScore + ">li:last"),
        wha = $(".pageLabel").offset().left + wh;
        if (whx.offset().left + whx.width() > wha) {
            $(data.ids.right_tab).show();
        } else {
            $(data.ids.right_tab).hide();
        }
        var ana = $(".pageLabel>div:eq(0)");
        ana.position().left == 0 ? $(data.ids.left_tab).hide() : $(data.ids.left_tab).show();
    }
    var preTestResource = function(res){
    	if(res.resourceurl) return true;
    	if(res.resource){
    		for(var i = 0,j = res.resource.length;i<j;i++){
    			if( preTestResource(res.resource[i])) return true;
    		}
    	}
    	 return false;
    }
    var fn = function(dd) {
        var cymenu = [];
        var menutype = function(n) {
            if (n == null || n.resource == null || n.resource.length == 0) return "";
            var dept = !n.pid ? 0 : n.pid.length / 32;
            var color = "#" + (0xFFFFFF - dept * 0x222222).toString(16);
            var str = "<ul class='text_list' style='display:none;background-color:"+color+"'>";
            str += $.map(n.resource,
	            function(nn, i) {
            		nn.pid = (n.pid || '') + n.resourceid;
	                return "<li  name='" + nn.resourceid + "' url='" + nn.resourceurl + "'  t='" + nn.target + "'  >" + "<a href='javascript:;' title='" + nn.resourcename + "'>" + protext(nn.resourcename) + (nn.resource.length == 0 ? "": " <img  src='" + data.imgPath + "menu_icon_01.jpg'/>") + "</a>" + menutype(nn) + "</li>";
	            }
           ).join(" ");
            str += "</ul>";
            return str;
        }
        var menuAll = $.map(dd,
        function(n, i) {
            if ($.trim(n.resourceurl) != '') {
                var str1 = "<div class='aaabbb'  style='display:none;'><a  href='javascript:;'>" + n.resourcename + "</a></div>";
                str1 += "<ul class='menu'>";
                str1 += "<li  name='" + n.resourceid + "' url='" + n.resourceurl + "'  t='" + n.target + "' " + " >" + "<a  href='javascript:;' title='" + n.resourcename + "'>" + protext(n.resourcename) + "</a>";;
                str1 += "</ul>";
                return str1;
            }
            
            
            if (n.resource.length > 0 && preTestResource(n)) {
                var str = "<div class='menu_title_e'><a  href='javascript:;'>" + n.resourcename + "</a></div>";
                str += "<ul class='menu' style='display:none;'>";
                var nestingMenu = $.map(n.resource,
                function(n, i) { 
                    if (n.resourceurl == '' && n.resource.length == 0) return '';
                    var str1 = "<li  name='" + n.resourceid + "' url='" + n.resourceurl + "'  t='" + n.target + "' " + " >" + "<a  href='javascript:;' title='" + n.resourcename + "'>" + protext(n.resourcename) + "</a>" + (n.resource.length == 0 ? "": " <img  src='" + data.imgPath + "menu_icon_01.jpg' />");
                    str1 += menutype(n);
                    str1 += "</li>";
                    return str1;
                }).join(' ');
                if ($.trim(nestingMenu) === '') return "";
                str += nestingMenu;
                str += "</ul>";
                return str;
            }
        }).join(" ");
        $(data.ids.rolin).find("*").remove().end().append(menuAll);
        if (!data.leftHeight) {
            var divs = $(data.ids.rolin + ">div:visible");
            data.leftHeight = $(data.ids.rolin).height() - (divs.height() * divs.length);
        }
        $(data.ids.rolin + ">div:visible+ul").css("min-height", data.leftHeight);
        $("div[class=menu_title_e]:eq(0)+ul", data.ids.rolin).show();
        $("div[class=menu_title_e]:eq(0)", data.ids.rolin).removeClass().addClass("menu_title");
        data.one ? $("div:eq(0)", data.ids.rolin).hide() : 0;
        $(data.ids.rolin + " li[name],#cyRolin li[name],#scRolin li[name]").draggable(data.dragConfig);
    };
    var rightFn = function(id, name, url) {
        $(data.ids.pageLabelScore + " .bnon img").hide();
        $(data.ids.pageScore + ">iframe[name=" + $(data.ids.pageLabelScore + " .bnon").attr("name") + "]").hide();
        var oldLab = $(".bnon", data.ids.pageLabelScore).removeClass().addClass("bnoff");
        var rightDiv = $("li[name=" + id + "]", data.ids.pageLabelScore);
        if (!rightDiv.length) { //
            var jLi = $("<li name='" + id + "' class='bnon' ><a  href='javascript:;'><span>" + name + "<img src='" + data.imgPath + "pic_03.jpg'/></span></a></li>");
            var isHi = $(data.ids.pageLabelScore + ">li:hidden").length;
            var after = null;
            $(data.ids.pageLabelScore + ">li").each(function() {
                if ($(this).offset().left > $(".pageLabel").offset().left) {
                    after = $(this);
                    return false;
                }
            });
            $('.ck_button:eq(1)').is(':hidden') ? $(data.ids.pageLabelScore).append(jLi) : after == null ? $(data.ids.pageLabelScore).append(jLi) : after.after(jLi);
            $(data.ids.pageScore).append("<iframe name=\"" + id + "\" src='" + url + "'frameBorder=\"no\" style=\"width: 100%; height: 100%;\">");
            if (id === "index") {
                $(data.ids.pageLabelScore + " img").remove();
            }
            tabProcess();
        } else {
            rightDiv.removeClass().addClass("bnon");
            rightDiv.find("img").show('highlight');
            $(data.ids.pageScore + ">iframe[name=" + id + "]").show();
        }
    };
    menu.init = function() {
        $.extend(data, arguments[0]); (typeof data.apps == "string") ? data.apps = eval("(" + data.apps + ")") : 0;
        if (data.apps.length == 1) $("#appToggle").hide();
        $("body").css('overflow', 'hidden');
        $(".box").height($(document).height() - $(".box").offset().top);
        $("body").height($(document).height());
        $(data.ids.pageScore).height($(".box").height() - 67);
        var _th = $('.admin').offset().top - $(data.ids.rolin).offset().top - 10;
        $(data.ids.rolin + ",#cyRolin,#scRolin").height(_th);
        var of = $('#sendMsgA').offset();
        $("#sendMsg").css({
            position: 'absolute',
            top: of.top - $("#sendMsg").height(),
            left: of.left - 400 - 10
        });
        $("#sendMsgBefore").css({
            position: 'absolute',
            top: of.top - $("#sendMsgBefore").height(),
            left: of.left - 400 - 10
        });
        of = $('#lxrA').offset();
        $("#lxr").css({
            position: 'absolute',
            top: of.top - $("#lxr").height()
        });
        data.one = 0;
        var ctoptem = $(data.mustache.top+">li");//vesion 3-22
        /*添加所有的系统*/
        $(data.ids.appScope).find(">*").remove();
        $.each(data.apps,
        function(i, n) {
            var toptem = ctoptem.clone();
            toptem.attr('name', n.appid);
            toptem.attr('logo', data.basePath + n.logo);
           // toptem.find('img[name=logo]').attr('src', data.basePath + n.logo);
            toptem.find('*[name=apptitle]').text(n.apptitle);
            toptem.find('*[name=remark]').text(n.remark);
            toptem.removeAttr('id');
            toptem.show();
            $(data.ids.appScope).append(toptem);
        });
        
        document.title = data.apps[0].apptitle;
        data.appid = data.apps[0].appid;//缓存当前的APPID
        //常用
        $("#cyRolin ul").append($.map(data.commonMenus,
        function(n, i) { 
            if (n.resourceurl == '') return '';
            var str1 = "<li  name='" + n.resourceid + "' url='" + n.resourceurl + "'  t='" + n.target + "' " + " >" + "<a  href='javascript:;' title='" + n.resourcename + "'>" + protext(n.resourcename) + "</a>";
            str1 += "</li>";
            return str1;
        }).join(' '));
        //收藏,默认处理方式，win
        boxMenu.add(data.boxMenus);
        fn(data.firstLeft);
        $(data.ids.head + " .logo").attr("style", "background-image:url(" + data.basePath + data.apps[0].logo + ");"); //logo
        rightFn("index", "首页", data.basePath + "/" + "loginAction.do?" + $.param({
            action: "showDes",
            sessionid: data.sessionid,
            loginurl: window.loginurl
        }));
        //vesion 3-13
       /* $("#appScopeP").css({
            top: $(data.ids.pageScore + " >iframe:eq(0)").offset().top
        });*/
        menu.bindEvent();
    }
    menu.bindEvent = function() {
        var errorm = function(a) {
            $.msgBar({
                type: a.type,
                text: a.text,
                position: 'bottom-center',
                lifetime: 3000
            });
        }
        $(data.ids.trash).droppable({
            accept: "li[name]",
            activeClass: "ui-state-default",
            hoverClass: "aa",
            activate: function(event, ui) {
            },
            over: function(event, ui) {
                if (!ui.draggable.parents(data.ids.rolin + ":eq(0)")[0]) $(data.ids.trash).attr('src', data.imgPath + "lj_2.png");
                else $(data.ids.trash).attr('src', data.imgPath + "2.png");
            },
            out: function(event, ui) {
                if (!ui.draggable.parents(data.ids.rolin + ":eq(0)")[0]) $(data.ids.trash).attr('src', data.imgPath + "lj_1.png");
                else $(data.ids.trash).attr('src', data.imgPath + "1.png");
            },
            drop: function(event, ui) { 
                var flag = ui.draggable.parents(data.ids.rolin + ":eq(0)")[0];
                if (flag) {
                    if ($("#cyRolin li[name=" + ui.draggable.attr('name') + "]")[0]) return;
                    $.ajax({
                        url: 'siheAction.do?action=addCommonMenu',
                        data: {
                            id: ui.draggable.attr('name')
                        },
                        success: function(json) {
                            if (json == "") {
                                var cl = null;
                                cl = ui.draggable.clone();
                                cl.draggable(data.dragConfig);
                                $("#cyRolin ul").append(cl);
                            } else errorm({
                                type: 'error',
                                text: json
                            });
                        }
                    });

                } else if (ui.draggable.parents("#cyRolin:eq(0)")[0]) {
                    $(data.ids.trash).attr('src', data.imgPath + "lj_2.png");

                    $.ajax({
                        url: 'siheAction.do?action=delCommonMenu',
                        data: {
                            id: ui.draggable.attr('name')
                        },
                        success: function(json) {
                            if (json == "") {
                                ui.draggable.remove();
                            } else errorm({
                                type: 'error',
                                text: json
                            });
                        }
                    });

                } else if (ui.draggable.parents("#scRolin:eq(0)")[0]) {
                    $(data.ids.trash).attr('src', data.imgPath + "lj_2.png");
                    $.ajax({
                        url: 'siheAction.do?action=delBoxMenu',
                        data: {
                            id: ui.draggable.attr('name')
                        },
                        success: function(json) {
                            if (json == "") {
                                ui.draggable.remove();
                            } else errorm({
                                type: 'error',
                                text: json
                            });
                        }
                    });

                }
            }
        });
       //切换系统的点击事件 div【name】
        $(".menu_hover", $(data.ids.appScope)[0]).live("click",
        function() {
        	$.ZZ();
            $("#appScopeP").hide();
            var jd = this,
                title=$(this).find("*[name=apptitle]").text();
            $(data.ids.appScope + ">.now").removeClass('now');
            $(this).addClass('now');
            data.appid = $(this).attr('name');//当前系统ID
            data.leftHeight = null;//切换系统后重新计算left的高
            var begin = new Date;
            dwr.engine.setAsync(false);
            data.one ? fn([data.firstLeft[$(data.ids.appScope + " a").index(this)]]) : login.getResourceByAppidAndUserId($(this).attr('name'), data.userId, data.ip,
            function(a) {
                var lf = eval("(" + a + ")").res;
                data.firstLeft = lf;
                fn(lf);
                $(data.ids.head + " .logo").attr("style", "background-image:url(" + $(jd).attr('logo') + ");");
                document.title =title;
            });
            dwr.engine.setAsync(true);
            if ($.fn.activebar.state != 3 && ((new Date).getTime() - begin.getTime()) > 3000) {
                $("<div id='wsgm' style=\"width:450px;\">您的网速过慢,可能影响您访问本系统,建议您检查网络环境以提高您的访问速度!</div>").activebar({
                    icon: data.basePath + "/resource/base/js/warn/images/activebar-information.png",
                    button: data.basePath + "/resource/base/js/warn/images/activebar-closebtn.png",
                    highlight: "InfoBackground"
                });
            }
        });
        /*切换系统的样式  vesion 3-12
        $(data.ids.appScope + ">div", $(data.ids.appScope)[0]).live('mouseover',
        function() {
            $(this).css({
                border: "2px #fff000 solid",
                padding: '5px'
            });
        });
        $(data.ids.appScope + ">div", $(data.ids.appScope)[0]).live('mouseout',
        function() {
            $(this).removeAttr('style');
        });*/
        /*切换系统拖拽*/
         $("#appScopeP").draggable({
        containment: "body",
        scroll: false,
        cursor:"move",
        handle: ".body_l_tit",
        iframeFix: "true",
        opacity:0.7
    });
        $(".menu_title_e", $(data.ids.rolin)[0]).live("click",
        function() {
            if ($(".menu_title", data.ids.rolin).next().is(":animated")) {
                return false;
            };
            $(this).next().show('blind', {},
            300);
            $(".menu_title", data.ids.rolin).next().hide();
            $(".menu_title", data.ids.rolin).removeClass().addClass("menu_title_e");
            $(this).removeClass().addClass("menu_title");
        });
        var link_fn = function(e) {
            $(document.body).click();
            var chr = $(this).children("ul");
            if (chr[0]) {
                if (chr.is(":animated")) {
                    return false;
                };
                if (chr.is(":hidden")) {
                    $(this).attr("id", 'text_list_top');
                    chr.show('blind', {},
                    100);
                } else {
                    chr.hide('blind', {},
                    100);
                    $(this).removeAttr("id");
                }
                var ob = $(this).siblings("[id=text_list_top]");
                for (var i = 0,j = ob.length; i < j; i++) {
                    link_fn.call(ob[i]);
                }
                return false;
            }
            if ($(this).attr('url')) {
                var url = $(this).attr('url').indexOf("?") == -1 ? $(this).attr('url') + "?": $(this).attr('url');
                var id = $(this).attr('name');
                var t = $(this).attr("t");
                var method = $(this).parents("#scRolin")[0] ? true: false;
                menu.link(id, url, $(this).find("a").attr('title'), t, method);
            }

            return false;
        }
        $.each([$("li[name]", $(data.ids.rolin)[0]), $("li[name]", $("#cyRolin")[0]), $("li[name]", $("#scRolin")[0])],
        function(i) {
            $(this).live('click', link_fn).live('mouseover',
            function() {
                if (i === 2) {
                    $(this).children(".updname").show();
                }
                $(this).addClass('msover');
                return false;
            }).live('mouseout',
            function() {
                if (i === 2) {
                    $(this).children(".updname").hide();
                }
                $(this).removeClass('msover');
                return false;
            })
        });
        $(".updname", $("#scRolin")[0]).live('click',
        function() {
            var div = $('#updDiv');
            var target = $(this).parents("li:eq(0)");
            div.find('*[name=menuurl]').val(target.attr('url'));
            div.find('input[name=menuname]')[0].value = ($.trim(target.text()));
            var wing = htmlWin({
                title: "修改菜单",
                html: div[0],
                width: 400,
                height: 160,
                top: $(this).offset().top,
                left: "215",
                cancelBtn: true,
                cover: "no"
            });
            wing.addBtn('save', '保存',
            function(event) {
                errorm({
                    type: 'info',
                    text: '正在保存数据'
                });
                $.ajax({
                    url: 'siheAction.do?action=updateBoxMenu',
                    data: {
                        id: target.attr('name'),
                        name: encode(div.find('input[name=menuname]').val()),
                        url: div.find('*[name=menuurl]').val()
                    },
                    success: function(json) {
                        if (json == "") {
                            target.children("a:eq(0)").text(div.find('input[name=menuname]').val());
                            errorm({
                                type: 'info',
                                text: '保存成功.'
                            });
                            wing.cancel();
                        } else {
                            errorm({
                                type: 'error',
                                text: json
                            });
                        }
                    }

                });
            },
            'left');
            return false;
        })
        $("li[name]", $(data.ids.pageLabelScore)[0]).live("click",
        function() {
            rightFn($(this).attr('name'));
            $(document.body).click();
            return false;
        });
        $("img", $(data.ids.pageLabelScore)[0]).live("click",
        function() {
            var pDiv = $(this).parents("li:eq(0)");
            var divName = pDiv.attr('name');
            var rightDiv = pDiv.prev();
            rightDiv.removeClass().addClass("bnon");
            rightDiv.find("img").show();
            $(data.ids.pageScore + " >*[name=" + rightDiv.attr("name") + "]").show();
            pDiv.remove();
            $(data.ids.pageScore + " >*[name=" + divName + "]").remove();
            tabProcess();
            $(document.body).click();
            return false;
        });
        $("img", $(data.ids.pageLabelScore)[0]).live("mouseover",
        function() {
            $(this).attr('src', data.imgPath + 'close_hover.png');
        });
        $("img", $(data.ids.pageLabelScore)[0]).live("mouseout",
        function() {
            $(this).attr('src', data.imgPath + 'pic_03.jpg');
        });
        $("li[name]", $(data.ids.pageLabelScore)[0]).live("dblclick",
        function() {
            $("img", this).click();
            return false;
        });
        $(function() {
            $('#tab_search li').click(function() {
                if ($(this).is('.over')) return;
                $('#tab_search li[class=over]').removeClass().addClass('out');
                $(this).removeClass().addClass('over');
                var i = $('#tab_search li').index(this);
                var uls = $('#tab_search').next().find('ul');
                uls.hide();
                uls.eq(i).show();
                $('#tab_search').next().find('ul:eq(1) input[name=key]').val('');
            });
            $('#findBtn').click(function() {
                var key = $('#tab_search').next().find('ul:eq(1) input[name=key]').val();
                if (!$.trim(key)) {
                    info({
                        message: "请输入搜索关键字."
                    });
                    return;
                }
                var rightDiv = $("li[name=search]", data.ids.pageLabelScore);
                if (rightDiv[0]) $(data.ids.pageScore + ">iframe[name=search]").attr('src', data.basePath + '/searchAction.do?action=SearchIndex&key=' + encode(key));
                else {
                    rightFn('search', '搜索', data.basePath + '/searchAction.do?action=SearchIndex&key=' + encode(key));
                }
            });
            $("#tab_menu li").click(function() {
                if ($(data.ids.rolin).is(":animated") || $("#cyRolin").is(":animated") || $("#scRolin").is(":animated")) {
                    return;
                };
                var n = $("#tab_menu li").index(this);
                if (n == 0 && $(data.ids.rolin).is(":visible") || (n == 1 && $("#cyRolin").is(":visible")) || (n == 2 && $("#scRolin").is(":visible")) || n > 2) return;
                $("#tab_menu li>a").removeClass('out');
                $(data.ids.rolin + ",#cyRolin,#scRolin").hide();
                n === 0 ? $(data.ids.rolin).show('slide') : n === 1 ? $("#cyRolin").show('slide') : n === 2 ? $("#scRolin").show('slide') : 0;
                $(this).find('a').addClass('out');
            });
            $(data.ids.left_tab).click(function() {
                var wh = $(".pageLabel").width();
                var ana = $(".pageLabel>div:eq(0)");
                ana.animate({
                    left: "+=" + wh + "px"
                },
                'fast',
                function() {
                    tabProcess();
                })
            });
            $(data.ids.right_tab).click(function() {
                var wh = $(".pageLabel").width();
                var ana = $(".pageLabel>div:eq(0)");
                ana.animate({
                    left: "-=" + wh + "px"
                },
                'fast',
                function() {
                    tabProcess();
                })
            });
            $(data.ids.foot + " img," + data.ids.head + ">.top>span:eq(0)").click(function() {
                return false;
            });
            //DOM关闭所有层
            $(document.body).click(function(e) {
                var config = data.hide;
                for (var i = 0,
                j = config.length; i < j; i++) if ($(e.target).is(config[i] + " *") || ($(e.target).is("#leftLxr"))) return;
                $.ZZ(false);
                $.each(config,
                function(i, n) {
                    $(n).hide();
                })
            });
        })
    };
    menu.link = function(id, url, name, t, f) {
        var link = url.split("://")[1].split(":")[0] == window.document.location.href.split("://")[1].split(":")[0] ? "no": "yes";
        url = f ? url: (data.basePath + "/core/tool/load.jsp?" + $.param({
            url: url.indexOf("?") == -1 ? (url + "?SESSIONID=" + data.sessionid + "&resource=" + id) : (url + "&SESSIONID=" + data.sessionid + "&resource=" + id)
        }));
        t == 1 ? rightFn(id, name, url) : t == "2" ? win({
            title: name,
            id: (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1),
            url: url,
            width: document.body.clientWidth - 100,
            height: document.body.clientHeight - 70,
            cover: "yes",
            btnBar: "no",
            link: link,
            xBtn: "yes"
        }) : window.open(url);
    };
    menu.toggleLeft = function(a) {
        if ($(data.ids.left).is(":animated")) {
            return;
        };
        if ($(data.ids.left).css("margin-left").toUpperCase() == '-185PX') {
            $(data.ids.left).next().css({
                marginLeft: '+=183px'
            });
            $(data.ids.left).animate({
                marginLeft: '0px'
            },
            'fast',
            function() {

});

            $(a).attr('src', data.imgPath + 'left_.jpg');
            $(data.ids.rolin).css({
                "overflow-y": 'scroll'
            })
        } else {
            $(data.ids.left).animate({
                marginLeft: '-185px'
            },
            'fast',
            function() {

                $(data.ids.left).next().css({
                    marginLeft: '-=183px'
                })
            });

            $(data.ids.rolin).css({
                "overflow-y": 'hidden'
            });
            $(a).attr('src', data.imgPath + 'my/left_r.jpg');
        }
    };
    menu.appToggle = function() {
    	var config = data.hide;
    	/*动画ing stop! */
    	 for (var i = 0,
        j = config.length; i < j; i++) if ("#appScopeP" != config[i]) $(config[i]).hide();
         if ($("#appScopeP").is(":animated")) {
            return;
        };
        
        if ($("#appScopeP").is(":hidden")) {
        	$.ZZ(true,0.3);
			$("#appScopeP").show('puff', {}, 300);
		} else {
			$.ZZ(false,0.3);
			$("#appScopeP").hide('puff', {}, 300);
		}
    	// vesion 3-12
       /*
		 * var config = data.hide; for (var i = 0, j = config.length; i < j;
		 * i++) if ("#appScopeP" != config[i]) $(config[i]).hide(); if
		 * ($("#appScopeP").attr('animate') === 'false') { return; };
		 * $("#appScopeP").attr('animate', 'false'); if
		 * ($("#appScopeP").is(":hidden")) { $("#appScopeP").show('fold', {},
		 * 300, function() { $("#appScopeP").attr('animate', 'true') }); } else {
		 * $("#appScopeP").hide('fold', {}, 300, function() {
		 * $("#appScopeP").attr('animate', 'true') }); }
		 */
    }
    menu.toggleHead = function(a) {
        if ($(data.ids.head).is(":hidden")) {
            $('.xxk_er').hide();
            $(data.ids.head).show();
            $(".box").height($(document.body).height() - $(data.ids.head).height());
        } else {
            $('.xxk_er').show();
            $(data.ids.head).hide();
            $(".box").height($(document.body).height());
        }
        $(data.ids.pageScore).height($(data.ids.left).height() - 67);
        var _th = $('.admin').offset().top - $(data.ids.rolin).offset().top - 10;
        $("#cyRolin,#scRolin," + data.ids.rolin).height(_th);
        var divs = $(data.ids.rolin + ">div:visible");
        data.leftHeight = $(data.ids.rolin).height() - (divs.height() * divs.length);
        $(data.ids.rolin + ">div:visible+ul").css("min-height", data.leftHeight);
    }
    menu.reLogin = function() {
        ask({
            message: "确定要注销吗？",
            fn: function(a) {
                if (a === 'yes') {
                    w.location = data.basePath + "/loginAction.do?action=clearSessionSelf";
                }
            }
        })
    };
    menu.showControlPanel = function() { 
        rightFn('showControlPanel', '控制面板', data.basePath + '/loginAction.do?action=showControlPanel');
    };
    menu.showHelp = function() { //====
        rightFn('showHelp', '帮助中心', data.basePath + '/pages/admin/helpdoc/helpDocFrame.jsp');
    };
    menu.showDesk = function() { //====
        rightFn('setting', '桌面设置', data.basePath + '/ssouserShowAction.do?action=showDeskConfig&loginurl=' + window.loginurl);
    }
    w.$menu = menu;
})(window);

var messTool = {};
messTool.show = function(a) {
    if (messTool.data.cache.sendMsgA != null) {
        clearInterval(messTool.data.cache.sendMsgA);
        messTool.data.cache.sendMsgA = null;
        $("#sendMsgA img").css('opacity', 1);
        $("#sendMsgA>img").attr('src', data.imgPath + "icon_02.jpg");
    }
    var config = data.hide;
    for (var i = 0,
    j = config.length; i < j; i++) if (a != config[i]) $(config[i]).hide();
    if ($(a).is(":animated")) {
        return;
    };
    if (a === '#lxr') {
        $($("#lxr .text_list_topo>li").removeClass().addClass('out')[0]).addClass('over');
        $("#lxrTree").show();
        $("#lxrTree").next().hide();
    }
    if ($(a).is(":hidden")) { // scale
        if (a === '#lxr') {
            window.hasUser = window.hasUser || false;
        }
        $.ajax({
            url: 'siheAction.do?action=showOnline&hasUser=' + hasUser,
            dataType: "json",
            success: function(json) {
                $.fn.zTree.init($("#lxrTree"), {
                    data: {
                        simpleData: {
                            enable: true
                        }
                    },
                    view: {
                        addHoverDom: function(treeId, treeNode) {
                            if (treeNode.type == 'employee') {
                                var treeObj = $("#" + treeNode.tId + "_a");
                                if (treeObj.find(".exp_btn").length != 0) return;
                                var temp = $("#btnFlag").clone(true);
                                temp.removeAttr("id");
                                temp.attr('employeeId', treeNode.id);
                                temp.attr('employeeName', treeNode.name);
                                temp.addClass("exp_btn");
                                treeObj.append(temp);
                            } else if (treeNode.type == 'users') {
                                var treeObj = $("#" + treeNode.tId + "_a");
                                if (treeObj.find(".exp_btn").length != 0) return;
                                var temp = $("#btnFlagUser").clone(true);
                                temp.removeAttr("id");
                                temp.attr('userId', treeNode.id);
                                temp.addClass("exp_btn");
                                treeObj.append(temp);
                            }
                        },
                        removeHoverDom: function(treeId, treeNode) {
                            $("#" + treeNode.tId + "_a .exp_btn").remove();
                        }
                    }
                },
                json);
            }
        });

        $(a).show(
        		'scale', 
        		{},
        		500,
        function() {
            if (a === "#sendMsgBefore") {
                $("#sendMsgBefore .miss").text(6); (function() {
                    var val = $("#sendMsgBefore .miss").text() - 0;
                    if (val != 1 && $("#sendMsgBefore").is(':visible')) {
                        $("#sendMsgBefore .miss").text(val - 1);
                        setTimeout(arguments.callee, 1000)
                    } else if (val == 1 && $("#sendMsgBefore").is(':visible')) $("#sendMsgBefore").hide('slide', {
                        direction: 'down'
                    });

                })()
            }
        });

    } else {
        $(a).hide('slide', {
            direction: 'down'
        });
    }

}
messTool.showToggle = function() {
    if ($("#sendMsg").is(":visible")) {
        messTool.show("#sendMsg");
        return;
    }
    if ($("#sendMsg .wx_left>div").length) {
        messTool.show("#sendMsg");
    } else messTool.show("#sendMsgBefore");
}
//显示消息
messTool.showMsg = function(a) {
    if (messTool.data.cache.msgA != null) {
        clearInterval(messTool.data.cache.msgA);
        messTool.data.cache.msgA = null;
        $("#msgA img").css("opacity", 1);
        $("#msgA>img").attr('src', data.imgPath + "icon_01.jpg");
    }
    var config = data.hide;
    for (var i = 0,
    j = config.length; i < j; i++) if ("#msg" != config[i]) $(config[i]).hide();
    if ($("#msg").is(":animated")) {
        return;
    };
    if ($("#msg").is(":hidden")) {
        $("#msg").show('clip', {},
        300);
    } else {
        if (a) $("#msg").hide('clip', {},
        300);
        else $("#msg").hide('clip', {},
        300);
    }
}
messTool.data = {
    cache: {
        msgA: null,
        sendMsgA: null
    }
};
messTool.del = function(o) {
    var f = {
        'yya': '#sendMsg .wx_right ul>li',
        'yy': '#sendMsg .wx_right ul:visible>li',
        'sc': '#sendMsg .wx_right ul:visible>li'
    };

    var id = $.map($(f[o]),
    function(n) {
        return $(n).attr('name');
    });
    for (var i = 0,
    j = id.length; i < j; i++) id[i] && login.unSendData(id[i], 'dwr');
    if (o === 'sc') {
        $("#sendMsg .wx_right ul:visible").remove();
        $("#sendMsg .wx_left>.wx_a").remove();
        $("#sendMsg .wx_left>div:eq(0)").removeClass().addClass('wx_a');
        $("#sendMsg .wx_right ul:eq(0)").show();
    }
}
messTool.date = function(a) {
    var dd = a.getTime ? a: $date.parse(a, 'yyyy-MM-dd hh:mm:ss');
    return $date.convert(dd);
}
messTool.ajaxAdd = function() {
    for (var i = 0,
    length = data.prompt.length; i < length; i++) {
        var j = data.prompt[i];
        var dbmsg = {
            rid: j.id,
            appid: j.appid,
            target: '1',
            id: '-1',
            time: new Date(new Date().getTime() - 3000),
            type: j.name //====
        };
        j.prompt = j.prompt.indexOf("?") == -1 ? j.prompt + "?callback=?": j.prompt + "&callback=?";
        var play = false;
        $.ajax({
            url: j.prompt,
            async: false,
            dataType: "jsonp",
            success: function(html) {
                if (html) {

                    if (play == false) {
                        jsPlay.flashPlay(data.basePath + data.play);
                        play = true;
                    }
                    dbmsg.message = html;
                    messTool.add(dbmsg);
                    messTool.beforeMsg();
                }
            },
            error: function(a, b, c) {}
        });
    }
}
messTool.beforeMsg = function() {
    if (messTool.data.cache.msgA == null) {
        messTool.data.cache.msgA = setInterval(function() {
            $("#msgA>img").attr('src', data.imgPath + "icon_011.gif");

            $("#msgA>img").css('opacity') == 0 ? $("#msgA>img").css('opacity', 1) : $("#msgA>img").css('opacity', 0);
        },
        500);
    }
}
messTool.beforeSendMsg = function() {
    if (messTool.data.cache.sendMsgA == null) {
        messTool.data.cache.sendMsgA = setInterval(function() {
            $("#sendMsgA>img").attr('src', data.imgPath + "icon_022.gif");
            $("#sendMsgA>img").css('opacity') == 0 ? $("#sendMsgA>img").css('opacity', 1) : $("#sendMsgA>img").css('opacity', 0);
        },
        500);
    }
}
messTool.openMsg = function(aid, rid) {
    if (data.appid !== aid) {
        $(data.ids.appScope + ">div[name=" + aid + "]").click();
    }
    if (data.appid === aid) {
        var po = $(data.ids.rolin + " li[name=" + rid + "]");
        po.parents("ul[class=menu]:eq(0)").prev().click();
        po.parents('ul[class=text_list]').click();
        po.focus().click();
    }
}
//后台方法  添加消息
messTool.add = function(a) {
    jsPlay.flashPlay(data.basePath + data.play);
    typeof a === 'string' ? a = $.parseJSON(a) : 0;
    /*通讯录消息*/
    if (a.type === '0_0') {//通讯录消息
        messTool.beforeSendMsg();//通讯录的闪烁处理
        if (a.map && a.map.employeeid) {
            var msgR = $("#sendMsg .wx_left>div[name=" + a.map.employeeid + "]");
            var sendMsgCount = $("#sendMsg .wx_left>div").length;
            if (!msgR[0]) {
                var msg = "<div name='" + a.map.employeeid + "' class='" + (sendMsgCount == 0 ? "wx_a": "wx_y") + "'>" + "<div class='wx_icon'><img src='" + data.imgPath + "wx/icon_04.jpg'/></div>" + "<div class='wx_icon_r'>" + a.map.employeename + "</div></div>";
                $("#sendMsg .wx_left").append(msg);
                msg = "<ul name='" + a.map.employeeid + "' class='wx_right_c' style='" + (sendMsgCount == 0 ? "": "display:none;") + "'></ul>";
                $("#sendMsg .wx_right>.wx_o_t").append(msg);
            }
            $("#sendMsg .wx_right ul[name=" + a.map.employeeid + "]").append("<li name='" + a.id + "'>" + a.map.employeename + "   " + (a.time ? messTool.date(a.time) : "") + "<br/>&nbsp;&nbsp;" + a.message + "</li>");

        }
        return;
    }
    messTool.beforeMsg();//站内消息的闪烁处理
    messTool.msgCount = messTool.msgCount + 1;
    var type = a.type;
    var msg = $("#msg div[name=msges] div[type=" + type + "]");//本消息类型定位
    var oneMsg = "<div class='xx_cent' name='" + a.id + "' rid='" + (a.rid ? a.rid: "") + "' appid='" + (a.appid ? a.appid: "") + "' href='" +(a.href ? a.href: "") + "' t='" + (a.target ? a.target: "") + "'>" + "<span>" + (a.time&&a.id!="-1" ? messTool.date(a.time) : "") + "</span><br/>" + "" + a.message + "</div>";
    if (msg[0]) {
        msg.next().append(oneMsg);
    } else {
        $("#msg div[name=msges]").append("<div type='" + type + "' class='" + (messTool.msgCount == 1 ? "xx_title_cent_y": "xx_title_cent") + "'><a href='javascript:;'>" + a.type + "</a></div><div style='" + (messTool.msgCount == 1 ? "": "display:none;") + "'>" + oneMsg + "</div>");
    }
    $("#msg span[name=count]").html(messTool.msgCount ? ("共" + messTool.msgCount + "条消息") : ("暂无消息"));
}
messTool.msgCount = 0;
messTool.sendMsg = function(args) { //====
    var args = args ? ("&id=" + args.id + "&name=" + encode(args.name)) : "";
    win({
        title: "发送微讯",
        id: "sendMess",
        url: data.basePath + "/ssouserShowAction.do?action=sendMsg" + args,
        width: 500,
        height: 410,
        cover: "yes",
        btnBar: "no",
        xBtn: "yes"
    })
}
$(function() {
    messTool.ajaxAdd();
    $(".xx_title_cent", $("#msg div[name=msges]")[0]).live('click',
    function() {
        $("#msg div[name=msges]>.xx_title_cent_y").next().hide();
        $("#msg div[name=msges]>.xx_title_cent_y").removeClass().addClass('xx_title_cent');
        $(this).removeClass().addClass('xx_title_cent_y');
        var next = $(this).next();
        next.show();
    });
    /**
     * 情况1  》》target:1，appid&&rid   | 跳转 级联
     *          target:2,href&&appid   | win   
     */
    $(".xx_cent", $("#msg div[name=msges]")[0]).live('click',
    function() {
       // login.unSendData($(this).attr('name'), 'dwr');  12-vesion
        if ($(this).attr('t') === '1' && $(this).attr('appid') && $(this).attr('rid')) {
            messTool.openMsg($(this).attr('appid'), $(this).attr('rid'));
        } else if ($(this).attr('href') !== '' && $(this).attr('appid')) {
            var re = $JSON.find(data.apps, {
                appid: $(this).attr('appid')
            });
            if (re.length != 1) return;
            win({
                title: $(this).parent().prev().attr('type'),
                url: re[0].appurl + "/" + $(this).attr('href'),
                width: document.body.clientWidth - 100,
                height: document.body.clientHeight - 70,
                cover: "yes",
                btnBar: "no",
                xBtn: "yes"
            })
        }
    });
    //删除站内消息，除了异步请求的消息 id:-1
    $("#msg .xx_but:eq(0)").click(function() {
        $.each($("#msg .xx_cent"),
        function(i, n) {
            var delId = $(n).attr('name');
            delId != "-1" ? login.unSendData(delId, 'dwr') : 0;
        })

        return false;
    });
    $("#msg").draggable({
        containment: "body",
        scroll: false,
        handle: ".xx_title",
        iframeFix: "true"
    });

    $("#sendMsg .wx_but").click(function() { 
        var msg = $("#sendMsg .wx_wb_z").val();
        if (!msg) {
            info({
                message: "消息内容不能为空!"
            });
            return;
        }
        var rr = $("#sendMsg .wx_left>.wx_a");
        if (!rr[0]) {
            info({
                message: "暂无联系人."
            });
            return;
        }
        login.sendMessage(msg, rr.attr('name'), messTool.data.employeeid, messTool.data.employeename);
        $("#sendMsg .wx_wb_z").val('');
    });
    $(document.body).keydown(function(e) {
        if (document.activeElement === $("#sendMsg .wx_wb_z")[0]) if (e.keyCode === 13 && e.ctrlKey) {
            $("#sendMsg .wx_but").click();
        }
    })
    $(".wx_y", $("#sendMsg .wx_left")[0]).live("click",
    function() {
        var l = $("#sendMsg .wx_left>.wx_a");
        $("#sendMsg .wx_right ul[name=" + l.attr('name') + "]").hide();
        l.removeClass().addClass('wx_y');
        $(this).removeClass().addClass('wx_a');
        $("#sendMsg .wx_right ul[name=" + $(this).attr('name') + "]").show();
    })
    $("#lxr .text_list_topo>li").click(function() {
        if ($("#lxr .text_list_topo>li").index(this) === 0) {
            $("#lxrTree").show();
            $("#lxrTree").next().hide();
            $("#lxr .text_list_topo>li").removeClass().addClass('out');
            $(this).removeClass().addClass('over');
        } else {
            $("#lxrTree").hide();
            $("#lxrTree").next().show();
            $("#lxr .text_list_topo>li").removeClass().addClass('out');
            $(this).removeClass().addClass('over_a');
        }
    });
    $(".btn_msg", $("#lxr")[0]).live('click',
    function() {
        var lxr = $(this).parents(".exp_btn:eq(0)");
        msg({
            employeeId: lxr.attr("employeeId").split('_')[1],
            employeeName: lxr.attr("employeeName")
        });
        return false;
    });
    $(".btn_view", $("#lxr")[0]).live('click',
    function() {
        var lxr = $(this).parents(".exp_btn:eq(0)");
        viewEmp({
            employeeId: lxr.attr("employeeId").split('_')[1],
            employeeName: lxr.attr("employeeName")
        });
        return false;
    });
    $(".btn_view_user", $("#lxr")[0]).live('click',
    function() {
        var lxr = $(this).parents(".exp_btn:eq(0)"),
        id = lxr.attr("userId").split('_')[1];
        win({
            title: "用户信息",
            url: "ssouserShowAction.do?action=showUserView&id=" + id,
            width: 400,
            height: 300,
            cover: "yes",
            btnBar: "no",
            xBtn: "yes"
        });
        $("#lxr").hide();
        return false;
    });
    $(".btn_go", $("#lxr")[0]).live('click',
    function() {
        var lxr = $(this).parents(".exp_btn:eq(0)"),
        id = lxr.attr("userId").split('_')[1];
        $("#lxr").hide();
        ask({
            message: "您确定要将此用户从系统中踢出？",
            fn: function(data) {
                if (data == 'yes') {
                    $.ajax({
                        url: 'siheAction.do?action=tipUser&id=' + id,
                        success: function(data) {
                            var treeObj = $.fn.zTree.getZTreeObj("lxrTree");
                            treeObj.removeNode(treeObj.getNodeByParam("id", data, null));
                        }
                    });
                }
            }
        });
        return false;
    });
});
function msg(obj) {
    if (obj.employeeId === data.employeeid) {
        $.msgBar({
            type: 'info',
            text: '不能给自己发微讯哦.',
            position: 'center-center',
            lifetime: 2000
        });
        return;
    }
    $("#lxr").hide();
    messTool.sendMsg({
        id: obj.employeeId,
        name: obj.employeeName
    });
}
function viewEmp(obj) {
    $("#lxr").hide();
    win({
        title: "员工信息",
        url: data.basePath + "/employeeShowAction.do?action=showView&id=" + obj.employeeId,
        width: document.body.clientWidth - 100,
        height: document.body.clientHeight - 70,
        cover: "yes",
        btnBar: "no",
        xBtn: "yes"
    })
}

$.ZZ = function(open,n) {
    if (!$("#myzz").length) {
        $("body").append($("<div />").css({
            width: "100%",
            height: "100%",
            top: "0px",
            left: "0px",
            position: "absolute",
            opacity: "0",
            background: "#000",
            "z-index": "900"
        }).hide().attr("id", "myzz"));
    }
    if (open) {
        $("#myzz").show().animate({
            opacity: n||0
        });
    } else {
        $("#myzz").animate({
            opacity: n||0
        }).hide();
    }
};