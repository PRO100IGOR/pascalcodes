package com.sxsihe.oxhide.resource.dao.hibernateImpl;

import java.util.*;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.resource.dao.ResourcesDAO;
import com.sxsihe.utils.properties.Reader;

/**
 * <p>
 * Title:com.sxsihe.oxhide.resource.dao.ResourcesDAOImpl
 * </p>
 * <p>
 * Description:DAOImpl
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 *
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class ResourcesDAOImpl extends BaseDAOImpl implements ResourcesDAO {
	/**
	 * (non-Javadoc)
	 *
	 * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	 */
	public Class getEntityClass() {
		// TODO Auto-generated method stub
		return Resources.class;
	}

	/**
	 * ��ȡ��������� zcc Apr 22, 2011
	 *
	 * @return
	 */
	public int getOrderNo(String appid, String reourcepid) {
		List temp = new ArrayList();
		try {
			Reader reader = new Reader("config.properties");
			Class sqlClass = Class.forName("com.sxsihe.base.sql." + reader.getProperty("sql"));
			String sql = sqlClass.getDeclaredField("OrderForResource").get(null).toString();
			SQLQuery sqlquery = this.getSession().createSQLQuery(StringUtils.isNotEmpty(reourcepid) ? (sql + ")") : (sql + " or RESOURCEPID is null)"));
			sqlquery.setParameter("DISPLAYAPPID", appid);
			sqlquery.setParameter("RESOURCEPID", reourcepid);
			sqlquery.addScalar("nonum", Hibernate.INTEGER);
			temp = sqlquery.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp.size() > 0 ? (new Integer(temp.get(0) + "")).intValue() : 0;
	}

	/**
	 * ������Դ��ϵͳ��ɾ��ʱ�������Ѿ���������Ϊ��ʾ�ĸ���Դ��ϵͳ����Դ
	 *
	 * @param appid
	 * @param resourcepid
	 */
	public void correction(String appid, String resourcepid) {
		String sql = StringUtils.isNotEmpty(appid) ? ("update RESOURCES set DISPLAYAPPID = APPID ,DISPLAYPID = RESOURCEPID where  DISPLAYAPPID = '" + appid + "'")
				: ("update RESOURCES set DISPLAYAPPID = APPID ,DISPLAYPID = RESOURCEPID where  DISPLAYPID = '" + resourcepid + "'");
		try {
			this.sqlOperater(sql);
		} catch (BaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}