package com.sxsihe.oxhide.ssoroles.action;

import java.util.*;
import java.io.Serializable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseDeleteAction;
import com.sxsihe.oxhide.ssoroles.form.SsorolesForm;

/**
 *<p>Title:com.sxsihe.oxhide.ssoroles.action.SsorolesDeleteAction</p>
 *<p>Description:��ɫDeleteAction</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class SsorolesDeleteAction extends BaseDeleteAction{

}