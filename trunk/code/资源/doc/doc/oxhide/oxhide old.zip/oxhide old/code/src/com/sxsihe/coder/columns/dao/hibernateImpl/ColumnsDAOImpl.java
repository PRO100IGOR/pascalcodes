package com.sxsihe.coder.columns.dao.hibernateImpl;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.coder.columns.domain.Columns;
import com.sxsihe.coder.columns.dao.ColumnsDAO;
/**
 *
 * <p>Title:com.sxsihe.oxhide.coder.columns.dao.hibernateImpl.ColumnsDAOImpl</p>
 * <p>Description:columns���ݲ�ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-02
 * @modify
 * @date
 */
public class ColumnsDAOImpl extends BaseDAOImpl implements ColumnsDAO {
	/**
	 * ������룬ָ��dao��Ӧʵ����
	 */
	public Class getEntityClass() {
		return Columns.class;
	}
}
