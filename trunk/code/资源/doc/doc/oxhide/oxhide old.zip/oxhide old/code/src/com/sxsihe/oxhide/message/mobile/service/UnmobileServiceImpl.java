package com.sxsihe.oxhide.message.mobile.service;
import com.ite.oxhide.service.BaseServiceImpl;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.message.mobile.service.UnmobileServiceImpl</p>
 * <p>Description:unmobile����ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-12-26
 * @modify
 * @date
 */
 public class UnmobileServiceImpl extends BaseServiceImpl implements UnmobileService{
 }
	