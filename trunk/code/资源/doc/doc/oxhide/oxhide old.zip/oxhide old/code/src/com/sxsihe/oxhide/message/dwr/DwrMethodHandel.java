package com.sxsihe.oxhide.message.dwr;

import org.directwebremoting.ScriptSessions;

/**
 * DWR�������ô�����
* @Title: DwrMethodHandel.java
* @Package com.sxsihe.oxhide.message.dwr
* @Description: TODO
* @author �ų���
* @date 2011-12-21 ����03:52:11
* @version V1.0
 */
public class DwrMethodHandel implements Runnable {
	private String methodName;
	private Object[] args;

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public Object[] getArgs() {
		return args;
	}

	public void setArgs(Object[] args) {
		this.args = args;
	}
	public DwrMethodHandel(String methodName,Object[] args){
		this.setArgs(args);
		this.setMethodName(methodName);
	}
	public void run() {
		ScriptSessions.addFunctionCall(methodName, args);
	}

}
