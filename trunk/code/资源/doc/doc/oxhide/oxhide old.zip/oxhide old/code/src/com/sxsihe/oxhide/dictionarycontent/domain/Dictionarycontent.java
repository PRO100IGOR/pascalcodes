package com.sxsihe.oxhide.dictionarycontent.domain;

import com.sxsihe.oxhide.dictionary.domain.Dictionary;

/**
 * Dictionarycontent entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Dictionarycontent implements java.io.Serializable {

	// Fields

	private String dcid;
	private Dictionary dictionary;
	private String dcvalue;
	private String dcode;
	private String remark;

	// Constructors

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getDcode() {
		return dcode;
	}

	public void setDcode(String dcode) {
		this.dcode = dcode;
	}

	/** default constructor */
	public Dictionarycontent() {
	}

	/** full constructor */
	public Dictionarycontent(Dictionary dictionary, String dcvalue) {
		this.dictionary = dictionary;
		this.dcvalue = dcvalue;
	}

	// Property accessors

	public String getDcid() {
		return this.dcid;
	}

	public void setDcid(String dcid) {
		this.dcid = dcid;
	}

	public Dictionary getDictionary() {
		return this.dictionary;
	}

	public void setDictionary(Dictionary dictionary) {
		this.dictionary = dictionary;
	}

	public String getDcvalue() {
		return this.dcvalue;
	}

	public void setDcvalue(String dcvalue) {
		this.dcvalue = dcvalue;
	}

}