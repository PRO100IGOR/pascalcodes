package com.sxsihe.oxhide.employee.service;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.struts.menu.MenuDataPick;
import com.sxsihe.oxhide.employee.domain.Employee;

import java.util.*;

/**
 * <p>
 * Title:com.sxsihe.oxhide.employee.service.
 * EmployeeService
 * </p>
 * <p>
 * Description:Ա��Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public interface EmployeeService extends BaseServiceIface {
	/**
	 * ��ȡ��������� zcc Apr 22, 2011
	 * 
	 * @return
	 */
	public int getOrderNo(String postid);

	/**
	 * �߼���ѯ����
	 * 
	 * @param condition
	 * @return Administrator
	 *         com.sxsihe.oxhide.employee
	 *         .dao.hibernateImpl
	 *         EmployeeDAOImpl.java 2012����6:54:50
	 *         oxhide
	 */
	public int getEmpAdvCount(ConditionBlock condition);

	/**
	 * �߼���ѯԱ��
	 * 
	 * @param block
	 * @param sortMap
	 * @param index
	 * @param count
	 * @return Administrator
	 *         com.sxsihe.oxhide.employee
	 *         .dao.hibernateImpl
	 *         EmployeeDAOImpl.java 2012����6:37:55
	 *         oxhide
	 */
	public List<Employee> getEmpAdv(ConditionBlock condition, Map sortMap, int beginNo, int pageSize);
}