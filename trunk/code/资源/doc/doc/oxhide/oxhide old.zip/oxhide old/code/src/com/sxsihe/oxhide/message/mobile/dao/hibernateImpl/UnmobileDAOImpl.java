package com.sxsihe.oxhide.message.mobile.dao.hibernateImpl;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.message.mobile.domain.Unmobile;
import com.sxsihe.oxhide.message.mobile.dao.UnmobileDAO;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.message.mobile.dao.hibernateImpl.UnmobileDAOImpl</p>
 * <p>Description:unmobile���ݲ�ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-12-26
 * @modify
 * @date
 */
public class UnmobileDAOImpl extends BaseDAOImpl implements UnmobileDAO {
	/**
	 * ������룬ָ��dao��Ӧʵ����
	 */
	public Class getEntityClass() {
		return Unmobile.class;
	}
}
	