package com.sxsihe.oxhide.employee.form;

import org.apache.struts.upload.FormFile;

import com.ite.oxhide.struts.form.BaseForm;
import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.oxhide.organ.domain.Organ;
import com.sxsihe.oxhide.post.domain.Posts;

/**
 * <p>
 * Title:com.sxsihe.oxhide.employee.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:Ա��
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 *
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class EmployeeForm extends BaseForm {
	private String otherprofessionalidtime;
	/* employeeid */
	private String employeeid;

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmployeeid() {
		return this.employeeid;
	}

	/* ��� */
	private String employeecode;

	public void setEmployeecode(String employeecode) {
		this.employeecode = employeecode;
	}

	public String getEmployeecode() {
		return this.employeecode;
	}

	/* ���� */
	private String employeename;

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public String getEmployeename() {
		return this.employeename;
	}

	/* �Ա� */
	private Integer sex;

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public Integer getSex() {
		return this.sex;
	}

	/* ���� */
	private String birthday;

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getBirthday() {
		return this.birthday;
	}

	/* �Ƿ���Ч */
	private Integer isvalidation;

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	/* ��ע */
	private String remark;

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRemark() {
		return this.remark;
	}

	/* ����� */
	private Integer orderno;

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	public Integer getOrderno() {
		return this.orderno;
	}

	/* ���� */
	private String nation;

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getNation() {
		return this.nation;
	}

	/* �μӹ���ʱ�� */
	private String workstarttime;

	public void setWorkstarttime(String workstarttime) {
		this.workstarttime = workstarttime;
	}

	public String getWorkstarttime() {
		return this.workstarttime;
	}

	/* ������ò */
	private String outlook;

	public void setOutlook(String outlook) {
		this.outlook = outlook;
	}

	public String getOutlook() {
		return this.outlook;
	}

	/* ���� */
	private String origin;

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getOrigin() {
		return this.origin;
	}

	/* ְ�� */
	private String title;

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTitle() {
		return this.title;
	}

	/* ѧ�� */
	private String education;

	public void setEducation(String education) {
		this.education = education;
	}

	public String getEducation() {
		return this.education;
	}

	/* ִҵ�ʸ� */
	private String professional;

	public void setProfessional(String professional) {
		this.professional = professional;
	}

	public String getProfessional() {
		return this.professional;
	}

	/* ְ��֤��� */
	private String titleid;

	public void setTitleid(String titleid) {
		this.titleid = titleid;
	}

	public String getTitleid() {
		return this.titleid;
	}

	/* �������� */
	private String accounttype;

	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}

	public String getAccounttype() {
		return this.accounttype;
	}

	/* �������ڵ� */
	private String account;

	public void setAccount(String account) {
		this.account = account;
	}

	public String getAccount() {
		return this.account;
	}

	/* ����֤���� */
	private String identity;

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getIdentity() {
		return this.identity;
	}

	/* ����֤��ַ */
	private String identityplace;

	public void setIdentityplace(String identityplace) {
		this.identityplace = identityplace;
	}

	public String getIdentityplace() {
		return this.identityplace;
	}

	/* �������� */
	private String email;

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEmail() {
		return this.email;
	}

	/* ��ϵ�绰 */
	private String phone;

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPhone() {
		return this.phone;
	}

	/* ְ��רҵ */
	private String professionallife;

	public void setProfessionallife(String professionallife) {
		this.professionallife = professionallife;
	}

	public String getProfessionallife() {
		return this.professionallife;
	}

	/* ְ������ */
	private String professionaltype;

	public void setProfessionaltype(String professionaltype) {
		this.professionaltype = professionaltype;
	}

	public String getProfessionaltype() {
		return this.professionaltype;
	}

	/* ��ҵʱ�� */
	private String worktime;

	public void setWorktime(String worktime) {
		this.worktime = worktime;
	}

	public String getWorktime() {
		return this.worktime;
	}

	/* �ֻ�������ʼʱ�� */
	private String nowworkbegin;

	public void setNowworkbegin(String nowworkbegin) {
		this.nowworkbegin = nowworkbegin;
	}

	public String getNowworkbegin() {
		return this.nowworkbegin;
	}

	/* �ֻ����������ʱ�� */
	private String nowworkend;

	public void setNowworkend(String nowworkend) {
		this.nowworkend = nowworkend;
	}

	public String getNowworkend() {
		return this.nowworkend;
	}

	/* �������� */
	private String worktype;

	public void setWorktype(String worktype) {
		this.worktype = worktype;
	}

	public String getWorktype() {
		return this.worktype;
	}

	/* ����ְҵ�ʸ� */
	private String otherprofessional;

	public void setOtherprofessional(String otherprofessional) {
		this.otherprofessional = otherprofessional;
	}

	public String getOtherprofessional() {
		return this.otherprofessional;
	}

	/* ����ְҵ�ʸ�֤���� */
	private String otherprofessionalid;

	public void setOtherprofessionalid(String otherprofessionalid) {
		this.otherprofessionalid = otherprofessionalid;
	}

	public String getOtherprofessionalid() {
		return this.otherprofessionalid;
	}

	/* �˴���Э��ְ */
	private String national;

	public void setNational(String national) {
		this.national = national;
	}

	public String getNational() {
		return this.national;
	}

	/* Э��ְ�� */
	private String association;

	public void setAssociation(String association) {
		this.association = association;
	}

	public String getAssociation() {
		return this.association;
	}

	/* �μ���ѵ�ۼ�ѧʱ */
	private String traintime;

	public void setTraintime(String traintime) {
		this.traintime = traintime;
	}

	public String getTraintime() {
		return this.traintime;
	}

	/* ǩ�𱨸�������ۼƣ� */
	private String reportscores;

	public void setReportscores(String reportscores) {
		this.reportscores = reportscores;
	}

	public String getReportscores() {
		return this.reportscores;
	}

	/* ��Ƭ */
	private FormFile photo;


	/* ����ǩ�� */
	private FormFile pen;

	private String emailPassword;
	public String getEmailPassword() {
		return emailPassword;
	}

	public void setEmailPassword(String emailPassword) {
		this.emailPassword = emailPassword;
	}

	private String postid;
	private String postname;
	private String deptname;
	private String organname;

	public String getPostid() {
		return postid;
	}

	public void setPostid(String postid) {
		this.postid = postid;
	}

	public String getPostname() {
		return postname;
	}

	public void setPostname(String postname) {
		this.postname = postname;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getOrganname() {
		return organname;
	}

	public void setOrganname(String organname) {
		this.organname = organname;
	}

	public FormFile getPhoto() {
		return photo;
	}

	public void setPhoto(FormFile photo) {
		this.photo = photo;
	}

	public FormFile getPen() {
		return pen;
	}

	public void setPen(FormFile pen) {
		this.pen = pen;
	}

	public String getOtherprofessionalidtime() {
		return otherprofessionalidtime;
	}

	public void setOtherprofessionalidtime(String otherprofessionalidtime) {
		this.otherprofessionalidtime = otherprofessionalidtime;
	}


	private String mainplace;
	private String blood;
	private String marry;
	private String mobile;
	private String dutydate;
	private String cardid;

	public String getMainplace() {
		return mainplace;
	}

	public void setMainplace(String mainplace) {
		this.mainplace = mainplace;
	}

	public String getBlood() {
		return blood;
	}

	public void setBlood(String blood) {
		this.blood = blood;
	}

	public String getMarry() {
		return marry;
	}

	public void setMarry(String marry) {
		this.marry = marry;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDutydate() {
		return dutydate;
	}

	public void setDutydate(String dutydate) {
		this.dutydate = dutydate;
	}

	public String getCardid() {
		return cardid;
	}

	public void setCardid(String cardid) {
		this.cardid = cardid;
	}
}
