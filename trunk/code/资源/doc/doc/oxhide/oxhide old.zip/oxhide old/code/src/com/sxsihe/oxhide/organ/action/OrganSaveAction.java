package com.sxsihe.oxhide.organ.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.organ.domain.Organ;
import com.sxsihe.oxhide.organ.form.OrganForm;
import com.sxsihe.oxhide.organ.form.OrganConditionForm;
import com.sxsihe.oxhide.organ.service.OrganService;
import com.sxsihe.utils.common.CharsetSwitch;

/**
 * <p>
 * Title:com.sxsihe.oxhide.organ.action.
 * OrganSaveAction
 * </p>
 * <p>
 * Description:���� SaveAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */

public class OrganSaveAction extends BaseSaveAction {
	/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 * 
	 * @param form
	 * @return
	 */
	protected Serializable getPersisPo(ActionForm form, String type) {
		OrganForm vForm = (OrganForm) form;
		Organ po;
		if (type.equals("add"))
			po = new Organ();
		else {
			String organid = vForm.getOrganid();
			po = (Organ) service.findObjectBykey(organid);
		}
		po.setOrganid(vForm.getOrganid());
		po.setOrganname(vForm.getOrganname());
		po.setAreaid(vForm.getAreaid());
		po.setOrgancode(vForm.getOrgancode());
		po.setOrganalias(vForm.getOrganalias());
		po.setAddress(vForm.getAddress());
		po.setTelephone(vForm.getTelephone());
		po.setFax(vForm.getFax());
		po.setIsvalidation(vForm.getIsvalidation());
		po.setRemark(vForm.getRemark());
		if (StringUtils.isNotEmpty(vForm.getOrganpid())) {
			Organ organ = new Organ();
			organ.setOrganid(vForm.getOrganpid());
			po.setPorgan(organ);
		}
		return po;
	}

	
	/**
	 * ����ǰ���õķ���
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	public void preAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * �޸�ǰ���õķ���
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	public void preUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * ���Ӻ���õķ���
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	public void nextAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable po) {
	}

	/**
	 * �޸ĺ���õķ���
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	public void nextUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable po) {
	}
	/**
	 * ������ʵ��Ĺ���ʵ��
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form, HttpServletRequest request, String type) {
	}
	
	/**
	 * ��֤po������
	 * @param po
	 * @return
	 * Administrator
	 * com.sxsihe.oxhide.organ.action
	 * OrganSaveAction.java
	 * 2012����9:29:50
	 * oxhide
	 * @see com.ite.oxhide.struts.actionEx.BaseSaveAction#checkSave(java.io.Serializable)
	 */
	protected String checkSave(Serializable po) {
		Organ organ = (Organ) po;
		String hql = "from Organ organ where (organ.organid != :organid or :organid is null)  and organ.organname = :organname";
		Map map = new HashMap();
		map.put("organid", organ.getOrganid());
		map.put("organname", organ.getOrganname());
		if (!getService().queryHql(hql, map).isEmpty()) {
			return "���������Ѿ�����";
		}
		return null;
	}

}