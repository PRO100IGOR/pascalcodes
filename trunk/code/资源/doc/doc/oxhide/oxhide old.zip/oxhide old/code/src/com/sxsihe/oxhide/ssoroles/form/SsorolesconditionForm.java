package com.sxsihe.oxhide.ssoroles.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.application.form.ApplicationConditionForm
 * </p>
 * <p>
 * Description:Ӧ��ϵͳ
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 * 
 * @modify
 * @date
 */
public class SsorolesconditionForm extends BaseForm {
	private String dvalue;
	private String dcode;

	public String getDvalue() {
		return dvalue;
	}

	public void setDvalue(String dvalue) {
		this.dvalue = dvalue;
	}

	public String getDcode() {
		return dcode;
	}

	public void setDcode(String dcode) {
		this.dcode = dcode;
	}
}
