package com.sxsihe.oxhide.server.resource;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.service.BaseServiceIface;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.utils.common.CharsetSwitch;
import com.sxsihe.utils.common.DataUtils;
import com.sxsihe.utils.common.RandomGUID;

public class ResourceServerImpl implements ResourceServer {
	private BaseServiceIface service;

	public BaseServiceIface getService() {
		return service;
	}

	public void setService(BaseServiceIface service) {
		this.service = service;
	}

	public Resources findObjectBykey(String key) {
		Object object = service.findObjectBykey(key);
		try {
			return (Resources) DataUtils.copyPoJo(object, Resources.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public List<Resources> findObjectsByCondition(ConditionBlock block, Map sortMap) {
		List list  = service.findObjectsByCondition(DataUtils.changeCode(block), sortMap);
		return DataUtils.copyPoJos(list, Resources.class);
	}

	public List<Resources> getAll() {
		List list =  service.getAll();
		return DataUtils.copyPoJos(list, Resources.class);
	}

	public void add(Resources resources){
		service.add(resources);
	}
	public List<Resources> queryHql(String hql){
		List list = service.queryHql(hql, null);
		return DataUtils.copyPoJos(list, Resources.class);
	}

	/**
	 * ���ӻ򱣴�˵�
	* @Title: ResourceServerImpl.java
	* @Package com.sxsihe.oxhide.server.resource
	* @Description: TODO
	* @author �ų���
	* @date 2011-11-3 ����05:05:54
	* @version V1.0
	 */
	public void add(String rname,String rid,String appid,String modelid,String url){
		rname = CharsetSwitch.decode(rname);
		Resources resources = null;
		if (StringUtils.isNotEmpty(rid)) {
			resources = (Resources)getService().findObjectBykey(rid);
		}else{
			rid = RandomGUID.getGUID().replaceAll("-", "");
		}
		if (resources == null) {
			resources = new Resources();
			resources.setLargeico("resource/base/theme/public/img/largeicon/001.png");
			resources.setBigico("resource/base/theme/public/img/bigicon/001.png");
			resources.setIco("resource/base/theme/public/img/icon/001.png");
			resources.setIsvalidation("1");
			resources.setMenutype(2);
			resources.setDisplay(1);
			resources.setTarget(1);
			resources.setResourceid(rid);
		}
		Application application = new Application();
		application.setAppid(appid);
		resources.setApplication(application);
		resources.setResourceurl(url);
		resources.setDisplayAppId(appid);
		Resources model = new Resources();
		model.setResourceid(modelid);
		resources.setResourcesp(model);
		resources.setDisplayPId(modelid);
		resources.setResourcename(rname);
		resources.setSimplyname(rname.length() > 4 ? rname.substring(0,4) : rname);
		resources.setTabname(rname);
		resources.setResourcecode(rname);
		getService().save(resources);
	}
	/**
	 * ɾ��
	* @Title: ResourceServerImpl.java
	* @Package com.sxsihe.oxhide.server.resource
	* @Description: TODO
	* @author �ų���
	* @date 2011-11-3 ����05:44:10
	* @version V1.0
	 */
	public void delete(String rid){
		getService().deleteByKey(rid);
	}

}
