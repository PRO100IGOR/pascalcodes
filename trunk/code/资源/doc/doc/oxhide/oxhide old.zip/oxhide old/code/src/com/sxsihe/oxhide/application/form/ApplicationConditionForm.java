package com.sxsihe.oxhide.application.form;

import com.ite.oxhide.struts.form.BaseForm;
/**
 *<p>Title:com.sxsihe.oxhide.application.form.ApplicationConditionForm</p>
 *<p>Description:Ӧ��ϵͳ</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 *
 * @modify 
 * @date
 */
public class ApplicationConditionForm extends BaseForm{
      /*ϵͳ����*/
      private String  cappname ;
      public void setCappname(String cappname){
         this.cappname=cappname;
      }
      public String getCappname(){
         return this.cappname;
      }
      /*Ĭ�ϱ���*/
      private String  capptitle ;
      public void setCapptitle(String capptitle){
         this.capptitle=capptitle;
      }
      public String getCapptitle(){
         return this.capptitle;
      }
}





