package com.sxsihe.oxhide.config.dao.hibernateImpl;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.config.domain.Sysconfig;
import com.sxsihe.oxhide.config.dao.SysconfigDAO;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.config.dao.hibernateImpl.SysconfigDAOImpl</p>
 * <p>Description:�������ݲ�ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2012-02-15
 * @modify
 * @date
 */
public class SysconfigDAOImpl extends BaseDAOImpl implements SysconfigDAO {
	/**
	 * ������룬ָ��dao��Ӧʵ����
	 */
	public Class getEntityClass() {
		return Sysconfig.class;
	}
}
	