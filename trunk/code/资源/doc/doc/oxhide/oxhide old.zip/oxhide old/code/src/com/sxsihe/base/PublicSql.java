package com.sxsihe.base;

public class PublicSql {
	// �����û�id.ϵͳid��ѯ��Դ�б�
	public static String ResByUserIdAndAppId = "select {t.*} from  resources t where RESOURCETYPE <> 3 and display = 1 and DISPLAYAPPID = :DISPLAYAPPID and (RESOURCEID "
			+ "in( select DISTINCT r.RESOURCEID  from resources r where  r.RESOURCEID " + "in (select rr.RESOURCEID from rolesresources rr where (rr.roleid in (select "
			+ "ur.roleid from usersroles ur where ur.userid  = :userid )))) or :userid = '1') order by t.DISPLAYPID,t.orderno";
	// �����û�id��ϵͳid��ѯ���а�ť��Դ����
	public static String ResBtnByUserAndAppId = "select t.resourcecode from  resources t where t.RESOURCETYPE = 3 and t.DISPLAYAPPID = :DISPLAYAPPID and t.RESOURCEPID = (select tt.RESOURCEID from resources tt where tt.DISPLAYAPPID = :DISPLAYAPPID and tt.RESOURCECODE = :resourcePcode and tt.RESOURCETYPE = 0  limit 1) and RESOURCEID "
			+ "in( select DISTINCT r.RESOURCEID  from resources r where  (r.RESOURCEID "
			+ "in (select rr.RESOURCEID from rolesresources rr where (rr.roleid in (select "
			+ "ur.roleid from usersroles ur where ur.userid  = :userid   )))or :userid = '1')) order by t.DISPLAYPID,t.orderno";
	// �����û�id��ϵͳid��ѯ�����ƶ����͵���Դ����
	public static String ResByUserAndAppIdAndType = "select {t.*} from  resources t where t.RESOURCETYPE = :rtype and t.DISPLAYAPPID = :DISPLAYAPPID and t.RESOURCEPID = (select tt.RESOURCEID from resources tt where tt.DISPLAYAPPID = :DISPLAYAPPID and tt.RESOURCECODE = :resourcePcode limit 1) and RESOURCEID "
			+ "in( select DISTINCT r.RESOURCEID  from resources r where  (r.RESOURCEID "
			+ "in (select rr.RESOURCEID from rolesresources rr where (rr.roleid in (select "
			+ "ur.roleid from usersroles ur where ur.userid  = :userid   )))or  :userid = '1')) order by t.DISPLAYPID,t.orderno";
	// �����û�id��ѯ���ص���ݲ˵�����Դ
	public static String QuickResByUserId = "select {t.*} from  resources t where RESOURCETYPE = 2 and display = 2 and RESOURCEID "
										 + "in( select DISTINCT r.RESOURCEID  from resources r where  (r.RESOURCEID "
										 + "in (select rr.RESOURCEID from rolesresources rr where (rr.roleid in (select "
										 + "ur.roleid from usersroles ur where ur.userid  = :userid   )))) or :userid = '1')"
										 +" order by t.DISPLAYPID,t.orderno";
	// �����û�id��ѯӦ��ϵͳ
	public static String AppByUserId = "select {t.*} from  application t where (appid "
									 + "in (select  DISTINCT (select r.DISPLAYAPPID from resources  r "
									 +"where r.RESOURCEID =rs.RESOURCEID and r.RESOURCETYPE = 2 and r.display = 1)"
									 +" from rolesresources rs where (rs.roleid in (select  ur.roleid  from usersroles ur"
									 +" where ur.userid  = :userid  ))) or :userid = '1') order by t.orderno";
	// �����û�id��ѯ��Ҫ��ʾ����Դ
	public static String PromtResByUserId = "select t.RESOURCEID,t.DISPLAYPID,t.DISPLAYAPPID,t.PROMPT,(select a.appurl from application a where a.appid = t.appid) appurl,(select a.appurlw from application a where a.appid = t.appid) appurlw from  resources t where RESOURCETYPE = 2 and display = 1 and PROMPT <> '' and PROMPT is not null and RESOURCEID "
			+ "in( select DISTINCT r.RESOURCEID  from resources r where  (r.RESOURCEID " + "in (select rr.RESOURCEID from rolesresources rr where (rr.roleid in (select "
			+ "ur.roleid from usersroles ur where ur.userid  = :userid   ))  ) or :userid = '1')) order by t.RESOURCEPID,t.orderno";
	// ��ѯ�������������
	public static String OrderForDept = "select nvl(max(orderno),0) + 1 nonum from deptment  where organid = :organid";

	// ��ѯԱ�����������
	public static String OrderForEmp = "select nvl(max(orderno),0) + 1 nonum from employee  where POSTID = :POSTID";

	// ��ѯ��λ���������
	public static String OrderForPost = "select nvl(max(orderno),0) + 1 nonum from posts  where deptid = :deptid";
	// ��ѯϵͳ���������
	public static String OrderForApp = "select nvl(max(orderno),0) + 1 nonum from application ";
	// ��ѯ�˵����������
	public static String OrderForResource = "select nvl(max(orderno),0) + 1 nonum from resources where DISPLAYAPPID = :DISPLAYAPPID and (RESOURCEPID = :RESOURCEPID ";
	// ����û��Ƿ���Ȩ�޷���ĳ����Դ
	public static String CheckResourceForUser = "select count(*) count from rolesresources  rr where (rr.ROLEID in "
			+"(select ur.ROLEID from usersroles ur where ur.USERID = :userid) and rr.RESOURCEID "
			+"in (select r.RESOURCEID from resources r where r.RESOURCECODE = :resourcecode and "
			+"r.DISPLAYAPPID = (select a.APPID from application a where a.APPCODE = :appcode)) or :userid = '1')";

}
