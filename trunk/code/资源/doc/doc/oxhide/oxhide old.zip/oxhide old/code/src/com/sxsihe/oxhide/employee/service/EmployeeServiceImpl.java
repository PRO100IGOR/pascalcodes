package com.sxsihe.oxhide.employee.service;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.struts.menu.MenuDataPick;
import org.apache.commons.beanutils.PropertyUtils;

import com.sxsihe.oxhide.employee.dao.EmployeeDAO;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.ite.oxhide.common.util.*;
import java.util.*;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;

/**
 * <p>
 * Title:com.sxsihe.oxhide.employee.service.
 * EmployeeServiceImpl
 * </p>
 * <p>
 * Description:Ա��Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class EmployeeServiceImpl extends BaseServiceImpl implements EmployeeService {
	/**
	 * ��ȡ��������� zcc Apr 22, 2011
	 * 
	 * @return
	 */
	public int getOrderNo(String postid) {
		return ((EmployeeDAO) this.getDao()).getOrderNo(postid);
	}

	/**
	 * �߼���ѯ����
	 * 
	 * @param condition
	 * @return Administrator
	 *         com.sxsihe.oxhide.employee
	 *         .dao.hibernateImpl
	 *         EmployeeDAOImpl.java 2012����6:54:50
	 *         oxhide
	 */
	public int getEmpAdvCount(ConditionBlock condition) {
		return ((EmployeeDAO) this.getDao()).getEmpAdvCount(condition);
	}

	/**
	 * �߼���ѯԱ��
	 * 
	 * @param block
	 * @param sortMap
	 * @param index
	 * @param count
	 * @return Administrator
	 *         com.sxsihe.oxhide.employee
	 *         .dao.hibernateImpl
	 *         EmployeeDAOImpl.java 2012����6:37:55
	 *         oxhide
	 */
	public List<Employee> getEmpAdv(ConditionBlock condition, Map sortMap, int beginNo, int pageSize) {
		return ((EmployeeDAO) this.getDao()).getEmpAdv(condition, sortMap, beginNo, pageSize);
	}
}