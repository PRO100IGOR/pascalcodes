package com.sxsihe.oxhide.tree.organ;

import com.ite.oxhide.struts.menu.MenuDataPick;

public interface OrganTreeServices extends MenuDataPick{

}
