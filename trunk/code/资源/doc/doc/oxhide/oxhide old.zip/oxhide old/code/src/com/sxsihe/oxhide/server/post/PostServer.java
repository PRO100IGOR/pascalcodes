package com.sxsihe.oxhide.server.post;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.sxsihe.oxhide.post.domain.Posts;


public abstract interface PostServer{
	/**
	 * �����б�����
	 * 
	 * @param block
	 * @param sortMap
	 * @return
	 */
	public List<Posts> findObjectsByCondition(ConditionBlock block, Map sortMap);

	/**
	 * ����������ѯ����
	 * 
	 * @param key
	 * @return
	 */
	public Posts findObjectBykey(String key) ;
	
	/**
	 * ��ѯȫ��
	 * @return
	 */
	public List<Posts> getAll();
}
