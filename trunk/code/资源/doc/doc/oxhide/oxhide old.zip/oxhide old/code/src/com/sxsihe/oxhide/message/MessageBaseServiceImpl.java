package com.sxsihe.oxhide.message;

import java.util.List;

import net.sf.json.JSONObject;

import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.ssouser.service.SsouserService;

public class MessageBaseServiceImpl implements MessageBaseService {

	private SsouserService ssouserService;

	public SsouserService getSsouserService() {
		return ssouserService;
	}

	public void setSsouserService(SsouserService ssouserService) {
		this.ssouserService = ssouserService;
	}

	private SenderManger senderManger;

	public SenderManger getSenderManger() {
		return senderManger;
	}

	public void setSenderManger(SenderManger senderManger) {
		this.senderManger = senderManger;
	}


	public List getSenders(String appcode) {
		return null;
	}

	public void delAllSender(String appcode) {

	}

	public void delSender(String id) {

	}

	public Sender getSenderById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public String sendData(JSONObject param, Application application, Resources resources, List users) {
		// TODO Auto-generated method stub
		return null;
	}

}
