package com.sxsihe.oxhide.config.service;

import com.ite.oxhide.service.BaseServiceIface;

/**
 * 
 * <p>
 * Title:com.sxsihe.oxhide.config.service.SysconfigService
 * </p>
 * <p>
 * Description:���÷���ӿ�
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Company: �ĺ�
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2012-02-15
 * @modify
 * @date
 */
public interface SysconfigService extends BaseServiceIface {

	/**
	 * ��������
	 * 
	 * @param code
	 * @return Administrator com.sxsihe.oxhide.config.service SysconfigServiceImpl.java 2012����4:08:09 oxhide
	 */
	public void saveConfig(String code, String value);
}
