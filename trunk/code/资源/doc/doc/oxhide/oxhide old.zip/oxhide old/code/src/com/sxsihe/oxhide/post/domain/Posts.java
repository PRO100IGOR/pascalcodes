package com.sxsihe.oxhide.post.domain;

import java.util.HashSet;
import java.util.Set;

import com.sxsihe.oxhide.dept.domain.Deptment;

/**
 * Posts entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Posts implements java.io.Serializable {

	// Fields

	private String postid;
	private Deptment deptment;
	private String postname;
	private String postcode;
	private Posts posts;
	private Integer orderno;
	private Integer isvalidation;
	private String remark;
	private Set employees = new HashSet(0);
	private Set postses = new HashSet(0);

	// Constructors

	public Set getPostses() {
		return postses;
	}

	public void setPostses(Set postses) {
		this.postses = postses;
	}

	/** default constructor */
	public Posts() {
	}

	/** full constructor */
	public Posts(Deptment deptment, String postname, String postcode,
			Integer orderno, Integer isvalidation, String remark, Set employees) {
		this.deptment = deptment;
		this.postname = postname;
		this.postcode = postcode;
		this.orderno = orderno;
		this.isvalidation = isvalidation;
		this.remark = remark;
		this.employees = employees;
	}

	// Property accessors

	public String getPostid() {
		return this.postid;
	}

	public void setPostid(String postid) {
		this.postid = postid;
	}

	public Deptment getDeptment() {
		return this.deptment;
	}

	public void setDeptment(Deptment deptment) {
		this.deptment = deptment;
	}

	public String getPostname() {
		return this.postname;
	}

	public void setPostname(String postname) {
		this.postname = postname;
	}

	public String getPostcode() {
		return this.postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public Integer getOrderno() {
		return this.orderno;
	}

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Set getEmployees() {
		return this.employees;
	}

	public void setEmployees(Set employees) {
		this.employees = employees;
	}

	public Posts getPosts() {
		return posts;
	}

	public void setPosts(Posts posts) {
		this.posts = posts;
	}

}