package com.sxsihe.oxhide.resource.action;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.actionEx.BaseDeleteAction;
import com.sxsihe.oxhide.helpdoc.service.HelpdocService;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.resource.service.ResourceService;

/**
 * <p>
 * Title:com.sxsihe.oxhide.resource.action.ResourceDeleteAction
 * </p>
 * <p>
 * Description:��ԴDeleteAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class ResourceDeleteAction extends BaseDeleteAction {

	/**
	 * �޸Ľ�Ҫɾ���Ķ�����Ϊ��ʾ�˵�����Դ
	 */
	public ActionForward preDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable ob) throws BaseException {
		Resources resources = (Resources) ob;
		if (resources != null) {
			ResourceService resourceService = (ResourceService) SpringContextUtil.getBean("resourceService");
			resourceService.correction(null, resources.getResourceid());
			HelpdocService helpdocService = (HelpdocService) SpringContextUtil.getBean("helpdocService");
			String hql = "from Helpdoc t where t.itemid = :itemid";
			Map map = new HashMap();
			map.put("itemid", "res"+resources.getResourceid());
			helpdocService.deleteBatch(helpdocService.queryHql(hql, map));
		}
		return null;
	}
}