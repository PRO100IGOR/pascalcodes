package com.sxsihe.oxhide.message.android;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import org.apache.mina.core.service.IoAcceptor;
import org.apache.mina.core.session.IoSession;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.textline.TextLineCodecFactory;
import org.apache.mina.filter.logging.LoggingFilter;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;

public class SenderHelper {
	private boolean isReady = false;

	private Executor executor = Executors.newCachedThreadPool();

	public boolean isReady() {
		return isReady;
	}

	public void setReady(boolean isReady) {
		this.isReady = isReady;
	}

	private int port;
	private IoAcceptor acceptor;

	public IoAcceptor getAcceptor() {
		return acceptor;
	}

	public void setAcceptor(IoAcceptor acceptor) {
		this.acceptor = acceptor;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public void startService() {
		stopService();
		acceptor = new NioSocketAcceptor();
		acceptor.getFilterChain().addLast("logger", new LoggingFilter());
		acceptor.getFilterChain().addLast("codec", new ProtocolCodecFilter(new TextLineCodecFactory(Charset.forName("UTF-8"))));
		acceptor.setHandler(new AndroidHandel());
		acceptor.setDefaultLocalAddress(new InetSocketAddress(port));
		try {
			acceptor.bind();
			isReady = true;
		} catch (IOException e) {
			isReady = false;
			e.printStackTrace();
		}
	}

	public void stopService() {
		if (acceptor != null) {
			acceptor.unbind();
			acceptor = null;
		}
	}

	public void send(String message, IoSession session) {
		AndroidThread androidThread = new AndroidThread();
		androidThread.setMessage(message);
		androidThread.setSession(session);
		executor.execute(androidThread);
	}

	public static void main(String[] args) {
		SenderHelper senderHelper = new SenderHelper();
		senderHelper.setPort(2000);
		senderHelper.startService();
	}

}
