package com.sxsihe.oxhide.message.android;

import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.core.session.IoSession;

import com.ite.oxhide.spring.SpringContextUtil;

public class AndroidHandel extends IoHandlerAdapter {
	public void sessionCreated(IoSession session) throws Exception {

	}

	public void sessionOpened(IoSession session) throws Exception {
	}

	public void sessionClosed(IoSession session) throws Exception {
		AndroidService androidService = (AndroidService) SpringContextUtil.getBean("android");
		androidService.sessionDel(session.getRemoteAddress().toString());
	}

	public void sessionIdle(IoSession session, IdleStatus status) throws Exception {
	}

	public void exceptionCaught(IoSession session, Throwable cause) throws Exception {
		AndroidService androidService = (AndroidService) SpringContextUtil.getBean("android");
		androidService.sessionDel(session.getRemoteAddress().toString());
	}

	public void messageReceived(IoSession session, Object message) throws Exception {
		AndroidService androidService = (AndroidService) SpringContextUtil.getBean("android");
		androidService.sessionLogin(message.toString(), session);
	}

	public void messageSent(IoSession session, Object message) throws Exception {
	}
}
