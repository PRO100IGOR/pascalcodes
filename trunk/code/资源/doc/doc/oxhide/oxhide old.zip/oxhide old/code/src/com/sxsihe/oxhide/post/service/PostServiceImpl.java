package com.sxsihe.oxhide.post.service;

import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.struts.menu.MenuDataPick;
import org.apache.commons.beanutils.PropertyUtils;

import com.sxsihe.oxhide.post.dao.PostsDAO;
import com.sxsihe.oxhide.post.domain.Posts;
import com.ite.oxhide.common.util.*;
import java.util.*;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;

/**
 * <p>
 * Title:com.sxsihe.oxhide.post.service.PostServiceImpl
 * </p>
 * <p>
 * Description:��λService
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class PostServiceImpl extends BaseServiceImpl implements PostService {
	/**
	 * ��ȡ��������� zcc Apr 22, 2011
	 * 
	 * @return
	 */
	public int getOrderNo(String deptid) {
		return ((PostsDAO) this.getDao()).getOrderNo(deptid);
	}
}