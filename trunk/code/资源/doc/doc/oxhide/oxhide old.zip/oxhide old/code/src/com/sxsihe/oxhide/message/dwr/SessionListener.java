package com.sxsihe.oxhide.message.dwr;

import org.directwebremoting.ScriptSession;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;
import org.directwebremoting.event.ScriptSessionEvent;
import org.directwebremoting.event.ScriptSessionListener;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.login.service.SessionHouse;

public class SessionListener implements ScriptSessionListener {

	public void sessionCreated(ScriptSessionEvent event) {
		ScriptSession scriptSession = event.getSession();
		if (scriptSession.getPage().indexOf("loginAction.do") > -1) {
			WebContext webContext = WebContextFactory.get();
			SessionHouse sessionHouse = (SessionHouse) SpringContextUtil.getBean("sessionHouse");
			sessionHouse.addScriptSession(scriptSession.getId(), webContext.getSession().getId());
		}
	}

	public void sessionDestroyed(ScriptSessionEvent event) {
		ScriptSession scriptSession = event.getSession();
		SessionHouse sessionHouse = (SessionHouse) SpringContextUtil.getBean("sessionHouse");
		sessionHouse.removeScriptSession(scriptSession.getId());
	}

}
