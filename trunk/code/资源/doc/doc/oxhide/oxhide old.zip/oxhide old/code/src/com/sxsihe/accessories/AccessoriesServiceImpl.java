package com.sxsihe.accessories;

import java.io.File;
import java.util.List;
import java.util.Map;

public class AccessoriesServiceImpl implements AccessoriesService {
	private AccessoriesDao accessDao;

	public AccessoriesDao getAccessDao() {
		return this.accessDao;
	}

	public void setAccessDao(AccessoriesDao accessDao) {
		this.accessDao = accessDao;
	}

	public void add(Accessories acc) {
		getAccessDao().add(acc);
	}

	public void delete(Accessories acc) {
		getAccessDao().delete(acc);
	}

	public void delete(String id) {
		getAccessDao().delete(id);
	}

	public Accessories getAccessories(String id) {
		return getAccessDao().getAccessories(id);
	}

	public List getAccessoriesListByItem(String itemId) {
		return getAccessDao().getAccessoriesListByItem(itemId);
	}

	public void update(Accessories acc) {
		getAccessDao().update(acc);
	}

	public void submitAccessory(String itemId) {
		List list = getAccessDao().getAccessoriesListByItem(itemId);
		for (int i = 0; i < list.size(); i++) {
			Accessories acc = (Accessories) list.get(i);
			acc.setStat(Integer.valueOf(1));
			getAccessDao().update(acc);
		}
	}

	public void deleteAccessory(String itemId) {
		List list = getAccessDao().getAccessoriesListByItem(itemId);
		for (int i = 0; i < list.size(); i++) {
			Accessories acc = (Accessories) list.get(i);
			File file = new File(acc.getRealpath());
			file.delete();
			getAccessDao().delete(acc);
		}
	}

	public List getAccessByHql(String hql, Map<String, Object> keyValue) {
		return getAccessDao().getAccessByHql(hql, keyValue);
	}
	public void save(Accessories acc){
		getAccessDao().save(acc);
	}
}