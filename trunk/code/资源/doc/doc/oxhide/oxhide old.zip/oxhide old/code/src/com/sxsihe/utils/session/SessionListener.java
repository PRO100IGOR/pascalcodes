package com.sxsihe.utils.session;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.login.service.SessionHouse;

public class SessionListener implements HttpSessionListener {

	public void sessionCreated(HttpSessionEvent event) {
	}

	public void sessionDestroyed(HttpSessionEvent event) {
		HttpSession session = event.getSession();
		String id = session.getId();
		SessionHouse sessionHouse = (SessionHouse) SpringContextUtil.getBean("sessionHouse");
		sessionHouse.removeSessionBySid(id);
	}

}
