package com.sxsihe.utils.common;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;

public class DataUtils {
	public static ConditionBlock changeCode(ConditionBlock block) {
		Map<String, Object> map = block.getMap();
		for (Iterator<String> iterator = map.keySet().iterator(); iterator.hasNext();) {
			String key = iterator.next();
			if (map.get(key) instanceof Collection)
				continue;
			if (map.get(key) instanceof Object[])
				continue;
			map.put(key, CharsetSwitch.decode(map.get(key) + ""));
		}
		block.setMap(map);
		return block;
	}
	
	public static Object changeCode(Object object,Class classType) throws Exception{
		Field[] fields = classType.getDeclaredFields();
		Object objectCopy = classType.getConstructor(new Class[0]).newInstance(new Object[0]);
		for (int i = 0; i < fields.length; ++i) {
			Field field = fields[i];
			String fieldName = field.getName();
			String firstLetter = fieldName.substring(0, 1).toUpperCase();
			String getMethodName = (((!(field.getType().getName().equals("java.lang.Boolean"))) && (!(field.getType().getName().equals("boolean")))) ? "get" : "is") + firstLetter + fieldName.substring(1);
			String setMethodName = "set" + firstLetter + fieldName.substring(1);
			try {
				Method getMethod = classType.getMethod(getMethodName, new Class[0]);
				Method setMethod = classType.getMethod(setMethodName, new Class[] { field.getType() });
				Object value = null;
				if ((field.getType().getName().equals("java.lang.String"))) {
					value = getMethod.invoke(object, new Object[0]);
					setMethod.invoke(objectCopy, new Object[] { CharsetSwitch.decode(value.toString()) });
				} else  {
					value = getMethod.invoke(object, new Object[0]);
					setMethod.invoke(objectCopy, new Object[] { value });
				}
			} catch (Exception localException) {
			}
		}
		return objectCopy;
	}
	

	public static List copyPoJos(List list, Class classType) {
		if (list == null)
			return null;
		Iterator iterator = list.iterator();
		List returnColl = new ArrayList();
		while (iterator.hasNext()) {
			Object object = iterator.next();
			try {
				returnColl.add(copyPoJo(object, classType));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return returnColl;
	}

	public static Object copyPoJo(Object object, Class classType) throws Exception {
		if (object == null)
			return null;
		Object objectCopy = classType.getConstructor(new Class[0]).newInstance(new Object[0]);
		Field[] fields = classType.getDeclaredFields();
		for (int i = 0; i < fields.length; ++i) {
			Field field = fields[i];
			String fieldName = field.getName();
			String firstLetter = fieldName.substring(0, 1).toUpperCase();
			String getMethodName = (((!(field.getType().getName().equals("java.lang.Boolean"))) && (!(field.getType().getName().equals("boolean")))) ? "get" : "is") + firstLetter + fieldName.substring(1);
			String setMethodName = "set" + firstLetter + fieldName.substring(1);
			try {
				Method getMethod = classType.getMethod(getMethodName, new Class[0]);
				Method setMethod = classType.getMethod(setMethodName, new Class[] { field.getType() });
				Object value = null;
				if ((field.getType().getName().equals("java.lang.String")) || (field.getType().getName().equals("java.lang.Boolean")) || (field.getType().getName().equals("java.lang.Long")) || (field.getType().getName().equals("java.lang.Integer"))
						|| (field.getType().getName().equals("java.lang.Double")) || (field.getType().getName().equals("java.lang.Float")) || (field.getType().getName().equals("java.math.BigInteger"))
						|| (field.getType().getName().equals("java.util.Date")) || (field.getType().getName().equals("java.sql.Date")) || (field.getType().getName().equals("int")) || (field.getType().getName().equals("long"))
						|| (field.getType().getName().equals("float")) || (field.getType().getName().equals("double")) || (field.getType().getName().equals("boolean"))) {
					value = getMethod.invoke(object, new Object[0]);
					setMethod.invoke(objectCopy, new Object[] { value });
				} else if (!field.getType().getName().equals("java.util.Set")) {
					value = getMethod.invoke(object, new Object[0]);
					setMethod.invoke(objectCopy, new Object[] { copyPoJo2(value, field.getType()) });
				}
			} catch (Exception localException) {
			}
		}
		return objectCopy;
	}

	private static Object copyPoJo2(Object object, Class classType) throws Exception {
		if (object == null)
			return null;
		Object objectCopy = classType.getConstructor(new Class[0]).newInstance(new Object[0]);
		Field[] fields = classType.getDeclaredFields();
		for (int i = 0; i < fields.length; ++i) {
			Field field = fields[i];
			String fieldName = field.getName();
			String firstLetter = fieldName.substring(0, 1).toUpperCase();
			String getMethodName = (((!(field.getType().getName().equals("java.lang.Boolean"))) && (!(field.getType().getName().equals("boolean")))) ? "get" : "is") + firstLetter + fieldName.substring(1);
			String setMethodName = "set" + firstLetter + fieldName.substring(1);
			try {
				Method getMethod = classType.getMethod(getMethodName, new Class[0]);
				Method setMethod = classType.getMethod(setMethodName, new Class[] { field.getType() });
				Object value = null;
				if ((field.getType().getName().equals("java.lang.String")) || (field.getType().getName().equals("java.lang.Boolean")) || (field.getType().getName().equals("java.lang.Long")) || (field.getType().getName().equals("java.lang.Integer"))
						|| (field.getType().getName().equals("java.lang.Double")) || (field.getType().getName().equals("java.lang.Float")) || (field.getType().getName().equals("java.math.BigInteger"))
						|| (field.getType().getName().equals("java.util.Date")) || (field.getType().getName().equals("java.sql.Date")) || (field.getType().getName().equals("int")) || (field.getType().getName().equals("long"))
						|| (field.getType().getName().equals("float")) || (field.getType().getName().equals("double")) || (field.getType().getName().equals("boolean"))) {
					value = getMethod.invoke(object, new Object[0]);
					setMethod.invoke(objectCopy, new Object[] { value });
				}
			} catch (Exception localException) {
			}
		}
		return objectCopy;
	}

}
