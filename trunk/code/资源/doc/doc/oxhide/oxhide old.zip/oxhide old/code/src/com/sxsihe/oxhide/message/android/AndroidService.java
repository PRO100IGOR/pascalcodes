package com.sxsihe.oxhide.message.android;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.mina.core.session.IoSession;

import net.sf.json.JSONObject;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.config.service.SysconfigServiceImpl;
import com.sxsihe.oxhide.message.Address;
import com.sxsihe.oxhide.message.MessageBaseServiceImpl;
import com.sxsihe.oxhide.message.Sender;
import com.sxsihe.oxhide.message.mobile.MobileHandle;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.utils.common.DateUtils;
import com.sxsihe.utils.common.RandomGUID;

public class AndroidService extends MessageBaseServiceImpl {

	private Map<String, IoSession> sessions = new HashMap<String, IoSession>(); // ��ַ��session

	private SenderHelper helper;

	public String sendData(JSONObject param, Application application, Resources resources, List users) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("info", param.getString("info"));
		jsonObject.put("appcode", application.getAppcode());
		if (param.has("map")) {
			jsonObject.put("map", param.getJSONObject("map"));
		}
		jsonObject.put("time", DateUtils.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
		String message = jsonObject.toString();
		Sender sender = null;
		int count = 0;
		for (Object o : users) {
			Ssousers ssousers = (Ssousers) o;
			boolean sended = false;

			List<Address> addresses = this.getSenderManger().getAddressByUserid(ssousers.getUserid());
			for (Address address : addresses) {
				IoSession session = sessions.get(address.getAddress());
				if (session != null) {
					helper.send(message, session);
					sended = true;
				}
			}
			if (sended) {
				count++;
			} else {
				sender = new Sender();
				sender.setAppcode(application.getAppcode());
				sender.setAppid(application.getAppid());
				sender.setDateTime(jsonObject.getString("time"));
				sender.setId(RandomGUID.getGUID().replaceAll("-", ""));
				sender.setMessage(message);
				sender.setRid(resources.getResourceid());
				sender.setUserid(ssousers.getUserid());
				this.getSenderManger().addAndroid(sender);
			}
		}
		return "�ɹ����͸�" + count + "���û���";
	}

	public List getSenders(String appcode) {
		List list = this.getSenderManger().getAndroids(appcode);
		for (int i = 0; i < list.size(); i++) {
			Sender sender = (Sender) list.get(i);
			sender.setSsousers((Ssousers) this.getSsouserService().findObjectBykey(sender.getUserid()));
		}
		return list;
	}

	public List getAddress() {
		List<Address> list = this.getSenderManger().getAddress();
		for (Address address : list) {
			address.setSsousers(((Ssousers) this.getSsouserService().findObjectBykey(address.getUserid())));
		}
		return list;
	}

	public Sender getSenderById(String id) {
		return this.getSenderManger().getAndroidById(id);
	}

	public void delSender(String id) {
		this.getSenderManger().delAndroid(id);
	}

	public void delAllSender(String appcode) {
		this.getSenderManger().delAllAndroid(appcode);
	}

	public void delAddress(String id) {
		Address address = this.getSenderManger().getAddressById(id);
		sessions.remove(address.getAddress());
		this.getSenderManger().delAddress(id);
	}

	public void start() {
		stop();
		this.helper = new SenderHelper();
		this.helper.setPort(SysconfigServiceImpl.configs.getInt("androidport"));
		this.helper.startService();
	}

	public void stop() {
		if (this.helper != null) {
			this.helper.stopService();
		}
	}

	/**
	 * �пͻ�������
	 * 
	 * @param token
	 * @param session
	 *            Administrator com.sxsihe.oxhide.message.android AndroidService.java 2012����7:17:01 oxhide
	 */
	public void sessionLogin(String userid, IoSession session) {
		Ssousers ssousers = (Ssousers)getSsouserService().findObjectBykey(userid);
		if (ssousers == null) {
			session.close();
		}
		sessions.put(session.getRemoteAddress().toString(), session);
		Address address = new Address();
		address.setAddress(session.getRemoteAddress().toString());
		address.setId(RandomGUID.getGUID().replaceAll("-", ""));
		address.setUserid(userid);
		this.getSenderManger().addAddress(address);
		List<Sender> senders = this.getSenderManger().getAndroidByUserid(userid);
		for (Sender sender : senders) {
			helper.send(sender.getMessage(), session);
		}
	}

	/**
	 * �ͻ���ʧȥ����
	 * 
	 * @param userid
	 *            Administrator com.sxsihe.oxhide.message.android AndroidService.java 2012����9:16:16 oxhide
	 */
	public void sessionDel(String address) {
		sessions.remove(address);
		this.getSenderManger().delAddressByAddress(address);
	}

	public static void main(String[] args) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("map", JSONObject.fromObject("{\"A\":\"B\"}"));
		System.out.println(jsonObject.getString("map"));
	}
}
