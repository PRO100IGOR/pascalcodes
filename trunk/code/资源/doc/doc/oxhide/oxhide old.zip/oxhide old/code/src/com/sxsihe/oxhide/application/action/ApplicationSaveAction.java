package com.sxsihe.oxhide.application.action;

import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.application.form.ApplicationForm;
import com.sxsihe.oxhide.application.service.ApplicationService;
import java.io.Serializable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class ApplicationSaveAction extends BaseSaveAction {
	protected Serializable getPersisPo(ActionForm form, String type) {
		Application po;
		ApplicationForm vForm = (ApplicationForm) form;

		if (type.equals("add")) {
			po = new Application();
		} else {
			String appid = vForm.getAppid();
			po = (Application) this.service.findObjectBykey(appid);
		}
		po.setAppid(vForm.getAppid());
		po.setAppname(vForm.getAppname());
		po.setAppurl(vForm.getAppurl());
		po.setAppindex(vForm.getAppindex());
		po.setApptitle(vForm.getApptitle());
		po.setIco(vForm.getIco());
		po.setBigico(vForm.getBigico());
		po.setAppcode(vForm.getAppcode());
		po.setLargeico(vForm.getLargeico());
		po.setSimplyname(vForm.getSimplyname());
		po.setRemark(vForm.getRemark());
		po.setAppurlw(vForm.getAppurlw());
		po.setAndroidkey(vForm.getAndroidkey());
		po.setApplekey(vForm.getApplekey());
		po.setAndroidkf(vForm.getAndroidkf());
		po.setApplekf(vForm.getApplekf());
		po.setTimer(vForm.getTimer());
		po.setTimeenable(vForm.getTimeenable());
		po.setTimes(vForm.getTimes());

		if (type.equals("add"))
			po.setOrderno(Integer.valueOf(((ApplicationService) getService()).getOrderNo()));
		else
			po.setOrderno(vForm.getOrderno());

		return po;
	}


	public ActionForward saveorder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		String[] array = request.getParameterValues("appid");
		for (int i = 0; i < array.length; ++i) {
			Application application = (Application) getService().findObjectBykey(array[i]);
			application.setOrderno(Integer.valueOf(i + 1));
			getService().update(application);
		}
		return new ActionForward("/core/success/opSuccess.jsp");
	}
	
}