package com.sxsihe.oxhide.schema.dao.hibernateImpl;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.schema.domain.TSchema;
import com.sxsihe.oxhide.schema.dao.TSchemaDAO;
/**
 *<p>Title:com.sxsihe.oxhide.schema.dao.TSchemaDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author zcc
 * @version 1.0
 * @date 2011-05-04
 *
 * @modify
 * @date
 */
public class TSchemaDAOImpl extends BaseDAOImpl implements TSchemaDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return TSchema.class;
	   }
}