package com.sxsihe.oxhide.message.dwr;

import org.directwebremoting.impl.DefaultScriptSessionManager;

public class SessionManager extends DefaultScriptSessionManager {

	public SessionManager(){
		this.addScriptSessionListener(new SessionListener());
	}

}
