package com.sxsihe.oxhide.systemlog.action;

import java.io.Serializable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseDeleteAction;

/**
 *<p>Title:com.sxsihe.oxhide.systemlog.action.LogDeleteAction</p>
 *<p>Description:DeleteAction</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author 
 * @version 1.0
 * @date 2011-07-08
 *
 * @modify
 * @date
 */
public class SystemlogDeleteAction extends BaseDeleteAction{
}