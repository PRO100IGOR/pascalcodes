package com.sxsihe.oxhide.rolesresource.dao;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOIface;

/**
 *<p>Title:com.sxsihe.oxhide.rolesresource.dao.RolesresourcesDAO</p>
 *<p>Description:DAO</p>
 *<p>Copyright: Copyright (c) 2009</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public interface RolesresourcesDAO extends BaseDAOIface{
}