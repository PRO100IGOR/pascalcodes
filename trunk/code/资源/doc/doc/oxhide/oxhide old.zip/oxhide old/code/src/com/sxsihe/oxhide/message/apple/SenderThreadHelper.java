package com.sxsihe.oxhide.message.apple;

import com.notnoop.apns.ApnsService;
import com.sxsihe.oxhide.message.Sender;

public class SenderThreadHelper extends Thread {
	private ApnsService service;
	private Sender sender;

	public SenderThreadHelper(Sender sender) {
		this.sender = sender;
	}

	public ApnsService getService() {
		return service;
	}

	public void setService(ApnsService service) {
		this.service = service;
	}

	public void run() {
		send();
	}

	public void send() {
		service.push(sender.getToken(), sender.getMessage());
	}

	public Sender getSender() {
		return sender;
	}

	public void setSender(Sender sender) {
		this.sender = sender;
	}
}
