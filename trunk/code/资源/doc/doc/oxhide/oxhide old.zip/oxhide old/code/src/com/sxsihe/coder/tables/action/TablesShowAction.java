package com.sxsihe.coder.tables.action;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import com.sxsihe.coder.columns.domain.Columns;
import com.sxsihe.coder.columns.service.ColumnsService;
import com.sxsihe.coder.dataid.domain.Dataid;
import com.sxsihe.coder.dataid.service.DataidService;
import com.sxsihe.coder.datas.domain.Datas;
import com.sxsihe.coder.datas.service.DatasService;
import com.sxsihe.coder.sels.domain.Sels;
import com.sxsihe.coder.sels.service.SelsService;
import com.sxsihe.coder.tables.domain.SimplyLeaf;
import com.sxsihe.coder.tables.domain.Tables;
import com.sxsihe.coder.tables.form.TablesConditionForm;
import com.sxsihe.coder.tables.service.TablesService;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.server.dictionary.DictionaryServer;
import com.sxsihe.oxhide.server.resource.ResourceServer;
import com.sxsihe.utils.system.SystemLogHelper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.extremecomponents.table.limit.Limit;

public class TablesShowAction extends BaseShowAction {
	private ResourceServer resourceServer;
	private ColumnsService columnsService;
	private SelsService selsService;
	private DataidService dataidService;
	private DatasService datasService;

	public ColumnsService getColumnsService() {
		return this.columnsService;
	}

	public void setColumnsService(ColumnsService columnsService) {
		this.columnsService = columnsService;
	}

	public SelsService getSelsService() {
		return this.selsService;
	}

	public void setSelsService(SelsService selsService) {
		this.selsService = selsService;
	}

	public DataidService getDataidService() {
		return this.dataidService;
	}

	public void setDataidService(DataidService dataidService) {
		this.dataidService = dataidService;
	}

	public DatasService getDatasService() {
		return this.datasService;
	}

	public void setDatasService(DatasService datasService) {
		this.datasService = datasService;
	}

	public ResourceServer getResourceServer() {
		return this.resourceServer;
	}

	public void setResourceServer(ResourceServer resourceServer) {
		this.resourceServer = resourceServer;
	}

	public ActionForward showAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		saveToken(request);
		DictionaryServer dictionaryServer = (DictionaryServer) SpringContextUtil.getBean("dictionaryClient");
		request.setAttribute("dic", dictionaryServer.getDicTypes());
		Tables tables = new Tables();
		SystemLogHelper.addLog(request, "��������ҳ��", "1", "");
		request.setAttribute("table", tables);
		request.setAttribute("tables", getService().getAll());
		return mapping.findForward("showSave");
	}

	public ActionForward showUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		saveToken(request);
		String id = request.getParameter("id");
		Tables po = (Tables) getService().findObjectBykey(id);
		request.setAttribute("columns", po.getCols());
		request.setAttribute("columnsLength", Integer.valueOf(po.getCols().size()));
		request.setAttribute("sels", po.getSels());
		request.setAttribute("selsLength", Integer.valueOf(po.getSels().size()));
		DictionaryServer dictionaryServer = (DictionaryServer) SpringContextUtil.getBean("dictionaryClient");
		request.setAttribute("dic", dictionaryServer.getDicTypes());
		Resources resources = StringUtils.isEmpty(po.getMenuid()) ? null : this.resourceServer.findObjectBykey(po.getMenuid());
		if (resources != null) {
			po.setApplication(resources.getApplication().getApptitle());
			po.setApplicationid(resources.getApplication().getAppid());
			po.setMenu(resources.getResourcename());
			po.setModel(resources.getResourcesp().getResourcename());
			po.setModelid(resources.getResourcesp().getResourceid());
		}
		if (po.getTables() != null) {
			po.setPtid(po.getTables().getTid());
		}
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("tid", "ctid", 906, po.getTid(), true));
		request.setAttribute("tables", getService().findObjectsByCondition(block, null));
		request.setAttribute("table", po);
		SystemLogHelper.addLog(request, "�����޸�ҳ��", "1", "");
		return mapping.findForward("showSave");
	}

	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	public ActionForward showView(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Tables po = (Tables) getService().findObjectBykey(id);
		nextShowUpdate(mapping, form, request, response);
		request.setAttribute("view", po);
		return mapping.findForward("showView");
	}

	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		TablesConditionForm tablesConditionForm = (TablesConditionForm) conditionForm;
		if (tablesConditionForm != null) {
			block.and(new ConditionLeaf("tname", "ctname", 907, tablesConditionForm.getCtname(), true));
			block.and(new ConditionLeaf("tcode", "ctcode", 907, tablesConditionForm.getCtcode(), true));
		}
		return getService().getTotalObjects(block);
	}

	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		TablesConditionForm tablesConditionForm = (TablesConditionForm) conditionForm;
		if (tablesConditionForm != null) {
			block.and(new ConditionLeaf("tname", "ctname", 907, tablesConditionForm.getCtname(), true));
			block.and(new ConditionLeaf("tcode", "ctcode", 907, tablesConditionForm.getCtcode(), true));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = getSortMap(limit);
		else
			sortMap = new HashMap();
		return ((limit != null) ? getService().findObjectsByCondition(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed()) : getService()
				.findObjectsByCondition(block, sortMap));
	}

	public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String tablecode = request.getParameter("table");
		Tables tables = (Tables) getService().findObjectBykey(tablecode);
		request.setAttribute("table", tables);
		request.setAttribute("tableCode", tablecode);
		request.setAttribute("values", "{}");
		Tables pTables = tables.getTables();
		if (pTables != null) {
			String mainId = pTables.getMaincol();
			if ((StringUtils.isNotEmpty(mainId)) && (this.columnsService.findObjectBykey(mainId) != null)) {
				ConditionBlock block = new ConditionBlock();
				block.and(new ConditionLeaf("columns.cid", "ccid", 905, mainId, false));
				List datas = this.datasService.findObjectsByCondition(block, null);
				request.setAttribute("datas", datas);
				request.setAttribute("pname", pTables.getTname());
			}
		}

		return mapping.findForward("showCode");
	}

	public ActionForward view(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String tablecode = request.getParameter("table");
		Tables tables = (Tables) getService().findObjectBykey(tablecode);
		String id = request.getParameter("id");
		Dataid dataid = (Dataid) this.dataidService.findObjectBykey(id);
		Tables pTables = tables.getTables();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("{");
		for (Iterator iterator = dataid.getDatas().iterator(); iterator.hasNext();) {
			Datas datas = (Datas) iterator.next();
			stringBuilder.append("\"");
			stringBuilder.append(datas.getColumns().getCname());
			stringBuilder.append("\":\"");
			stringBuilder.append(datas.getDvalue());
			stringBuilder.append("\",");
		}
		boolean hasParent = false;
		if (pTables != null) {
			String mainId = pTables.getMaincol();
			if ((StringUtils.isNotEmpty(mainId)) && (this.columnsService.findObjectBykey(mainId) != null) && (dataid.getDataid() != null)) {
				ConditionBlock block = new ConditionBlock();
				block.and(new ConditionLeaf("columns.cid", "ccid", 905, mainId, false));
				block.and(new ConditionLeaf("dataid.dtid", "cdtid", 905, dataid.getDataid().getDtid(), false));
				List datas = this.datasService.findObjectsByCondition(block, null);
				if (datas.size() > 0) {
					Datas datasParent = (Datas) datas.get(0);
					stringBuilder.append("\"");
					stringBuilder.append(pTables.getTname());
					stringBuilder.append("\":\"");
					stringBuilder.append(datasParent.getDvalue());
					stringBuilder.append("\"}");
					hasParent = true;
				}
			}

		}

		if (!(hasParent))
			request.setAttribute("values", stringBuilder.substring(0, stringBuilder.length() - 1) + "}");
		else {
			request.setAttribute("values", stringBuilder.toString());
		}

		return mapping.findForward("showCodeView");
	}

	public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String tablecode = request.getParameter("table");
		Tables tables = (Tables) getService().findObjectBykey(tablecode);
		request.setAttribute("table", tables);
		String id = request.getParameter("id");
		request.setAttribute("tableCode", tablecode);
		Dataid dataid = (Dataid) this.dataidService.findObjectBykey(id);
		Tables pTables = tables.getTables();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("{");
		if (pTables != null) {
			String mainId = pTables.getMaincol();
			if ((StringUtils.isNotEmpty(mainId)) && (this.columnsService.findObjectBykey(mainId) != null)) {
				ConditionBlock block = new ConditionBlock();
				block.and(new ConditionLeaf("columns.cid", "ccid", 905, mainId, false));
				List datas = this.datasService.findObjectsByCondition(block, null);
				if (dataid.getDataid() != null) {
					stringBuilder.append("pdataid:\"");
					stringBuilder.append(dataid.getDataid().getDtid());
					stringBuilder.append("\",");
				}
				request.setAttribute("datas", datas);
				request.setAttribute("pname", pTables.getTname());
			}
		}

		for (Iterator iterator = dataid.getDatas().iterator(); iterator.hasNext();) {
			Datas datas = (Datas) iterator.next();
			stringBuilder.append(datas.getColumns().getCcode());
			stringBuilder.append(":\"");
			stringBuilder.append(StringUtils.isEmpty(datas.getDvalue()) ? "" : datas.getDvalue());
			stringBuilder.append("\",");
		}
		stringBuilder.append("dtid:");
		stringBuilder.append("\"" + id + "\"}");
		request.setAttribute("values", stringBuilder.toString());

		return mapping.findForward("showCode");
	}

	public ActionForward list(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String tablecode = request.getParameter("table");
		String pageSizeStr = request.getParameter("pageSize");
		Tables tables = (Tables) getService().findObjectBykey(tablecode);
		if (StringUtils.isEmpty(pageSizeStr)) {
			pageSizeStr = "15";
		}
		int pageSize = new Integer(pageSizeStr).intValue();

		String pageNowStr = request.getParameter("pageNow");
		if (StringUtils.isEmpty(pageNowStr)) {
			pageNowStr = "1";
		}
		int pageNow = new Integer(pageNowStr).intValue();

		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("tables.tid", "ctid", 905, tablecode, true));
		block.and(new ConditionLeaf("isshow", "cisshow", 905, "1", true));
		Map sortMap = new HashMap();
		sortMap.put("orderno", Boolean.valueOf(true));
		List cols = this.columnsService.findObjectsByCondition(block, sortMap);

		block = new ConditionBlock();
		block.and(new ConditionLeaf("tables.tid", "ctid", 905, tablecode, true));
		List sels = this.selsService.findObjectsByCondition(block, sortMap);

		String selsValue = request.getParameter("sels");

		List listLeaf = new ArrayList();
		if (StringUtils.isNotEmpty(selsValue)) {
			JSONObject object = JSONObject.fromObject(selsValue);
			for (int i = 0; i < sels.size(); ++i) {
				Sels sel = (Sels) sels.get(i);
				listLeaf.add(new SimplyLeaf(sel.getColumns().getCcode(), sel.getCname(), sel.getSwith(), object.get(sel.getCname()).toString()));
			}
		}
		sortMap.clear();
		sortMap.put("dataid.dtid", Boolean.valueOf(false));
		block.and(new ConditionLeaf("columns.isshow", "cisshow", 905, "1", true));
		block.and(new ConditionLeaf("columns.tables.tid", "ctid", 905, tablecode, true));
		TablesService tablesService = (TablesService) getService();
		List list = tablesService.findObjectByCondition(tables.getTcode(), listLeaf, cols, pageSize, pageNow);
		int totalRow = tablesService.getCountByCondition(tables.getTcode(), listLeaf);
		int pageCount = (totalRow + pageSize - 1) / pageSize;
		request.setAttribute("sels", sels);
		request.setAttribute("totalRows", Integer.valueOf(totalRow));
		request.setAttribute("pageCount", Integer.valueOf(pageCount));
		request.setAttribute("pageSize", Integer.valueOf(pageSize));
		request.setAttribute("pageNow", Integer.valueOf(pageNow));
		request.setAttribute("list", list);
		request.setAttribute("selsValue", selsValue);
		request.setAttribute("table", tablecode);
		request.setAttribute("cols", cols);
		request.setAttribute("colsSize", Integer.valueOf(tables.getCols().size()));

		return mapping.findForward("showCodeList");
	}

	public void savePlug(HttpServletRequest request) {
		String tablecode = request.getParameter("table");
		Tables tables = null;
		if ((StringUtils.isEmpty(tablecode)) && (request.getAttribute("table") != null)) {
			Object o = request.getAttribute("table");
			if (o instanceof String) {
				tablecode = request.getAttribute("table") + "";
				if (StringUtils.isNotEmpty(tablecode)) {
					tables = (Tables) getService().findObjectBykey(tablecode);
				}
			} else {
				tables = (Tables) o;
			}
		}
		if (tables == null) {
			return;
		}
		request.setAttribute("tableCode", tables.getTid());
		request.setAttribute("table", tables);
		String id = request.getParameter("dataid");

		if ((StringUtils.isEmpty(id)) && (request.getAttribute("dataid") != null)) {
			id = request.getAttribute("dataid") + "";
		}

		Dataid dataid = null;
		if (StringUtils.isNotEmpty(id)) {
			dataid = (Dataid) this.dataidService.findObjectBykey(id);
		}

		Tables pTables = tables.getTables();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("{");
		if (pTables != null) {
			String mainId = pTables.getMaincol();
			if ((StringUtils.isNotEmpty(mainId)) && (this.columnsService.findObjectBykey(mainId) != null)) {
				ConditionBlock block = new ConditionBlock();
				block.and(new ConditionLeaf("columns.cid", "ccid", 905, mainId, false));
				List datas = this.datasService.findObjectsByCondition(block, null);
				if ((dataid != null) && (dataid.getDataid() != null)) {
					stringBuilder.append("pdataid:\"");
					stringBuilder.append(dataid.getDataid().getDtid());
					stringBuilder.append("\",");
				}
				request.setAttribute("datas", datas);
				request.setAttribute("pname", pTables.getTname());
			}
		}

		if (dataid != null) {
			for (Iterator iterator = dataid.getDatas().iterator(); iterator.hasNext();) {
				Datas datas = (Datas) iterator.next();
				stringBuilder.append(datas.getColumns().getCcode());
				stringBuilder.append(":\"");
				stringBuilder.append(StringUtils.isEmpty(datas.getDvalue()) ? "" : datas.getDvalue());
				stringBuilder.append("\",");
			}
			stringBuilder.append("dtid:");
			stringBuilder.append("\"" + id + "\"}");
		} else {
			stringBuilder.append("}");
		}
		request.setAttribute("values", stringBuilder.toString());
		
	}

	public void viewPlug(HttpServletRequest request) {
		String tablecode = request.getParameter("table");
		
		Tables tables = null;
		if ((StringUtils.isEmpty(tablecode)) && (request.getAttribute("table") != null)) {
			Object o = request.getAttribute("table");
			if (o instanceof String) {
				tablecode = request.getAttribute("table") + "";
				if (StringUtils.isNotEmpty(tablecode)) {
					tables = (Tables) getService().findObjectBykey(tablecode);
				}
			} else {
				tables = (Tables) o;
			}
		}
		if (tables == null) {
			return;
		}
		request.setAttribute("tableCode", tables.getTid());
		String id = request.getParameter("dataid");
		if ((StringUtils.isEmpty(id)) && (request.getAttribute("dataid") != null)) {
			id = request.getAttribute("dataid") + "";
		}
		if (StringUtils.isEmpty(id))
			return;
		Dataid dataid = (Dataid) this.dataidService.findObjectBykey(id);
		Tables pTables = tables.getTables();
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("{");
		for (Iterator iterator = dataid.getDatas().iterator(); iterator.hasNext();) {
			Datas datas = (Datas) iterator.next();
			stringBuilder.append("\"");
			stringBuilder.append(datas.getColumns().getCname());
			stringBuilder.append("\":\"");
			stringBuilder.append(datas.getDvalue());
			stringBuilder.append("\",");
		}
		boolean hasParent = false;
		if (pTables != null) {
			String mainId = pTables.getMaincol();
			if ((StringUtils.isNotEmpty(mainId)) && (this.columnsService.findObjectBykey(mainId) != null) && (dataid.getDataid() != null)) {
				ConditionBlock block = new ConditionBlock();
				block.and(new ConditionLeaf("columns.cid", "ccid", 905, mainId, false));
				block.and(new ConditionLeaf("dataid.dtid", "cdtid", 905, dataid.getDataid().getDtid(), false));
				List datas = this.datasService.findObjectsByCondition(block, null);
				if (datas.size() > 0) {
					Datas datasParent = (Datas) datas.get(0);
					stringBuilder.append("\"");
					stringBuilder.append(pTables.getTname());
					stringBuilder.append("\":\"");
					stringBuilder.append(StringUtils.isEmpty(datasParent.getDvalue()) ? "" : datasParent.getDvalue());
					stringBuilder.append("\"}");
					hasParent = true;
				}
			}
		}
		if (!(hasParent))
			request.setAttribute("values", stringBuilder.substring(0, stringBuilder.length() - 1) + "}");
		else
			request.setAttribute("values", stringBuilder.toString());
	}
}