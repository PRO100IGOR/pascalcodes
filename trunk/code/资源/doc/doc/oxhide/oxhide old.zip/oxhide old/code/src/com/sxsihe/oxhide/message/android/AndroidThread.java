package com.sxsihe.oxhide.message.android;

import org.apache.mina.core.session.IoSession;

public class AndroidThread extends Thread {
	private IoSession session;
	private String message;

	public IoSession getSession() {
		return session;
	}

	public void setSession(IoSession session) {
		this.session = session;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void run() {
		session.write(message);
	}
}
