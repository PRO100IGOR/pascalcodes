package com.sxsihe.oxhide.ssouser.service;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.jsp.PageContext;

import com.ite.oxhide.struts.menu.MenuDes;
import com.ite.oxhide.struts.menu.MenuNode;
import com.sxsihe.base.PublicVariable;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.oxhide.tree.organ.OrganExtandService;
import com.sxsihe.oxhide.usersroles.domain.Usersroles;
import com.sxsihe.oxhide.usersroles.service.UsersrolesService;

public class SsoUserRoleTree implements OrganExtandService{
	
	private SsouserService ssouserService;
	private UsersrolesService usersrolesService;
	
	public SsouserService getSsouserService() {
		return ssouserService;
	}

	public void setSsouserService(SsouserService ssouserService) {
		this.ssouserService = ssouserService;
	}

	public UsersrolesService getUsersrolesService() {
		return usersrolesService;
	}

	public void setUsersrolesService(UsersrolesService usersrolesService) {
		this.usersrolesService = usersrolesService;
	}

	public List<MenuDes> getMenuDes(String type) {
		List<MenuDes> list = new ArrayList<MenuDes>();
		MenuDes menuDes = new MenuDes();
		menuDes.setImg(PublicVariable.USERICON);
		menuDes.setName("�û�");
		list.add(menuDes);
		return list;
	}

	public List<MenuNode> getMenuNodeData(String type, PageContext pageContext) {
		List users = ssouserService.getAll();
		ServletRequest request = pageContext.getRequest();
		String hql = "from Usersroles t where t.ssoroles.roleid = '" + request.getParameter("roleid") + "'";
		List userRoles = usersrolesService.queryHql(hql, null);
		List<MenuNode> nodes = new ArrayList<MenuNode>();
		
		for(Object o : users){
			Ssousers ssousers = (Ssousers)o;
			MenuNode node = new MenuNode();
			node.setType("user");
			node.setId("user_" + ssousers.getUserid());
			node.setTitle(ssousers.getUsername());
			node.setIcon(PublicVariable.USERICON);
			node.setOpenIcon(PublicVariable.USERICON);
			node.setParentId("emp_"+ssousers.getEmployee().getEmployeeid());
			if(containUserId(ssousers.getUserid(),userRoles)){
				node.setSelected("true");
			}
			nodes.add(node);
		}
		return nodes;
	}

	public List<MenuNode> getMenuNodeData(String parentId, String parentType, String type, PageContext pageContext) {
		return null;
	}
	
	private boolean containUserId(String userid,List userRoles){
		for(Object o : userRoles){
			Usersroles usersroles = (Usersroles)o;
			if(usersroles.getSsousers().getUserid().equals(userid)){
				return true;
			}
		}
		return false;
	}

}
