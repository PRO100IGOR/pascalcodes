package com.sxsihe.oxhide.message.mobile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Level;

import net.sf.json.JSONObject;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.config.service.SysconfigServiceImpl;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.message.MessageBaseServiceImpl;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;

//import SMCPPAPI.

public class MobileService extends MessageBaseServiceImpl {
	private SMSThread thread;
	private MobileHandle mobileHandle;

	public MobileHandle getMobileHandle() {
		return mobileHandle;
	}

	public void setMobileHandle(MobileHandle mobileHandle) {
		this.mobileHandle = mobileHandle;
	}

	public String sendData(JSONObject param, Application application, Resources resources, List users) {
		if (this.thread == null) {
			return "����èû��׼��������";
		}

		String hql = "from Unmobile t where t.application.appid = :appid and t.employee.employeeid = :employeeid";
		Map map = new HashMap();
		List list = new ArrayList();
		int count = 0;
		for (int i = 0; i < users.size(); i++) {
			Ssousers ssousers = (Ssousers) users.get(i);
			Employee employee = ssousers.getEmployee();
			if (StringUtils.isEmpty(employee.getMobile()))
				continue;
			map.put("appid", application.getAppid());
			map.put("employeeid", employee.getEmployeeid());
			List temp = this.getSsouserService().queryHql(hql, map);
			if (!temp.isEmpty())
				continue;
			if (list.indexOf(employee.getEmployeeid()) == -1) {
				list.add(employee.getEmployeeid());
				if (thread.sendMess(
						param.getString("info") + SysconfigServiceImpl.configs.getString("smstail","").replaceAll("<title>", application.getApptitle()).replaceAll("<code>", application.getAppcode()),
						employee.getMobile())) {
					count++;
				}
			}
		}
		return count + "���û����ͳɹ���" + (users.size() - count) + "���û�ʧ��";
	}

	public void start() {
		stop();
		this.thread = new SMSThread();
		this.thread.setMobileHandle(mobileHandle);
		this.thread.setTime(SysconfigServiceImpl.configs.getInt("smstime"));
		this.thread.setCom(SysconfigServiceImpl.configs.getString("smscom"));
		this.thread.setBaud(SysconfigServiceImpl.configs.getInt("smsbaud"));
		this.thread.setDevname(SysconfigServiceImpl.configs.getString("smsdevname"));
		this.thread.setWavetype(SysconfigServiceImpl.configs.getString("smswavetype"));
		this.thread.setPin(SysconfigServiceImpl.configs.getString("smspin",""));
		this.thread.start();
	}

	public void stop() {
		if (this.thread != null) {
			this.thread.setRun(false);
			this.thread = null;
		}
	}
}
