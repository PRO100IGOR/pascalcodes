package com.sxsihe.oxhide.systemlog.dao.hibernateImpl;

import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.systemlog.domain.Systemlog;
import com.sxsihe.oxhide.systemlog.dao.SystemlogDAO;
/**
 *<p>Title:com.sxsihe.oxhide.systemlog.dao.LogDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author x.IE-IT
 * @version 1.0
 * @date 2011-07-08
 *
 * @modify
 * @date
 */
public class SystemlogDAOImpl extends BaseDAOImpl implements SystemlogDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Systemlog.class;
	   }
}