package com.sxsihe.oxhide.workhistory.service;

import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.struts.menu.MenuDataPick;
import org.apache.commons.beanutils.PropertyUtils;
import com.sxsihe.oxhide.workhistory.domain.Workhistory;
import com.ite.oxhide.common.util.*;
import java.util.*;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;

/**
 *<p>Title:com.sxsihe.oxhide.workhistory.service.WorkhistoryServiceImpl</p>
 *<p>Description:������ʷService</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-08-11
 *
 * @modify 
 * @date
 */
 public class WorkhistoryServiceImpl 
     extends BaseServiceImpl 
     implements WorkhistoryService{
}