package com.sxsihe.oxhide.dept.action;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ite.oxhide.common.util.StringUtils;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import java.io.*;

import com.ite.oxhide.persistence.*;

import org.extremecomponents.table.limit.Limit;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import org.apache.commons.beanutils.PropertyUtils;

import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.oxhide.dept.form.DeptForm;
import com.sxsihe.oxhide.dept.form.DeptConditionForm;
import com.sxsihe.oxhide.login.domain.UserSession;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dept.action.DeptShowAction
 * </p>
 * <p>
 * Description:����showAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class DeptShowAction extends BaseShowAction {
	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		// DeptForm vForm = (DeptForm) form;
		// OrganService organService = (OrganService)
		// SpringContextUtil.getBean("organService");
		// Organ organ = (Organ)
		// organService.findObjectBykey(request.getParameter("organid"));
		// if (organ != null) {
		// vForm.setOrganid(organ.getOrganid());
		// vForm.setOrganname(organ.getOrganname());
		// }
	}

	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {

	}


	/**
	 * ��ʾ�����б� zcc Apr 22, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showOrderList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		saveToken(request);
		ConditionBlock block = new ConditionBlock();
		String organid = request.getParameter("organid");
		organid = StringUtils.isEmpty(organid) ? null : organid;
		String pid = request.getParameter("pid");
		pid = StringUtils.isEmpty(pid) ? null : pid;
		block.and(new ConditionLeaf("organ.organid", "corganid", ConditionLeaf.EQ, organid, false));
		block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, pid, false));
		Map sortMap = new HashMap();
		sortMap.put("orderno", true);
		List list = getService().findObjectsByCondition(block, sortMap);
		request.setAttribute("totalRows", list.size());
		request.setAttribute("list", list);
		return mapping.findForward("showOrderList");
	}

	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof DeptForm) {
				Deptment pos = (Deptment) po;
				DeptForm vForm = (DeptForm) form;
				BeanUtils.setProperty(vForm, "deptid", PropertyUtils.getProperty(pos, "deptid"));
				BeanUtils.setProperty(vForm, "deptname", PropertyUtils.getProperty(pos, "deptname"));
				BeanUtils.setProperty(vForm, "deptcode", PropertyUtils.getProperty(pos, "deptcode"));
				BeanUtils.setProperty(vForm, "areaid", PropertyUtils.getProperty(pos, "areaid"));
				BeanUtils.setProperty(vForm, "orderno", PropertyUtils.getProperty(pos, "orderno"));
				BeanUtils.setProperty(vForm, "remark", PropertyUtils.getProperty(pos, "remark"));
				BeanUtils.setProperty(vForm, "isvalidation", PropertyUtils.getProperty(pos, "isvalidation"));
				vForm.setOrganid(pos.getOrgan().getOrganid());
				vForm.setOrganname(pos.getOrgan().getOrganname());
				if (pos.getDeptment() != null) {
					vForm.setDeptpid(pos.getDeptment().getDeptid());
					vForm.setDeptpname(pos.getDeptment().getDeptname());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		DeptConditionForm vcForm = (DeptConditionForm) conditionForm;
		if (StringUtils.isEmpty(vcForm.getCorganid())) {
			UserSession userSession = (UserSession) request.getSession().getAttribute("USERSESSION");
			vcForm.setCorganid(userSession.getOrganid());
		}
		if (vcForm != null) {
			block.and(new ConditionLeaf("deptname", "cdeptname", ConditionLeaf.LIKE, vcForm.getCdeptname(), true));
			block.and(new ConditionLeaf("organ.organid", "corganid", ConditionLeaf.EQ, vcForm.getCorganid(), true));
		}
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		DeptConditionForm vcForm = (DeptConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("deptname", "cdeptname", ConditionLeaf.LIKE, vcForm.getCdeptname(), true));
			block.and(new ConditionLeaf("organ.organid", "corganid", ConditionLeaf.EQ, vcForm.getCorganid(), true));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else {
			sortMap = new HashMap();
		}
		sortMap.put("orderno", true);
		List list = getService().findObjectsByCondition(block, sortMap);
		return list;
	}

}
