package com.sxsihe.oxhide.tree.ssoroles;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.servlet.jsp.PageContext;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.menu.MenuDes;
import com.ite.oxhide.struts.menu.MenuNode;
import com.sxsihe.base.PublicVariable;
import com.sxsihe.oxhide.server.ssoroles.SsorolesServer;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;

public class SsoroleTreeServiceImpl implements SsorolesTreeService {

	public List<MenuNode> getMenuNodeData(String type, PageContext pageContext) {
		List nodeList = new ArrayList();
		String ids = pageContext.getRequest().getParameter("ids");
		ids = StringUtils.isEmpty(ids) ? "" : ids;
		SsorolesServer ssorolesServer = (SsorolesServer)SpringContextUtil.getBean("ssorolesClient");
		List roleList = ssorolesServer.getAll();
		addNode(nodeList, roleList, ids);
		return nodeList;
	}

	public List<MenuNode> getMenuNodeData(String arg0, String arg1, String arg2, PageContext arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	private void addNode(List nodeList, Collection list, String ids) {
		Iterator iterator = list.iterator();
		while (iterator.hasNext()) {
			Ssoroles ssoroles = (Ssoroles) iterator.next();
			MenuNode node = new MenuNode();
			node.setId(ssoroles.getRoleid());
			node.setTitle(ssoroles.getRolename());
			node.setIcon(PublicVariable.ROLEICON);
			node.setOpenIcon(PublicVariable.ROLEOPENICON);
			node.setType("role");
			node.setChecked("true");
			boolean exits = ids.indexOf(ssoroles.getRoleid()) != -1;
			node.setSelected(exits + "");
			nodeList.add(node);
		}

	}

	public List<MenuDes> getMenuDes(String type) {
		// TODO Auto-generated method stub
		return null;
	}

}
