package com.sxsihe.oxhide.rolesapp.dao.hibernateImpl;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.rolesapp.domain.Rolesapp;
import com.sxsihe.oxhide.rolesapp.dao.RolesappDAO;
/**
 *<p>Title:com.sxsihe.oxhide.rolesapp.dao.RolesappDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 *
 * @modify
 * @date
 */
public class RolesappDAOImpl extends BaseDAOImpl implements RolesappDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Rolesapp.class;
	   }
}