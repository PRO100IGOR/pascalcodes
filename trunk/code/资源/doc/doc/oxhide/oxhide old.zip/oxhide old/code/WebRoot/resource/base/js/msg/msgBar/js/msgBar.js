(function ($) {
    $.msgBar = function (config) {
        var defaults, options, bar, icon, close,container;
        defaults = {
            type: '',
            title: '',
            text: '',
            lifetime: 0,
            position: 'center-center',
            closeTrigger: true
        };
        options = $.extend(defaults, config);
        container = $('.msgBar-container.' + options.position);
        if (!container.length) {
            container = $('<div>', {
                'class': 'msgBar-container ' + options.position
            }).appendTo('body')
        }
        bar = $('<div>', {
            'class': 'msgBar ' + options.type,
            'text': options.text
        });
        icon = $('<div>', {
            'class': 'icon'
        }).appendTo(bar);
        if (options.closeTrigger) {
            close = $('<div>', {
                'class': 'close',
                'text': 'x',
                'click': closeBar
            }).appendTo(bar)
        }
        if (options.lifetime > 0) {
            setTimeout(function () {
                closeBar()
            }, options.lifetime)
        }
        function closeBar() {
            bar.slideUp('medium', function () {
                $(this).remove()
            })
        }
        if (options.position.split('-')[0] == 'top' || options.position.split('-')[0] == 'center') {
            bar.prependTo(container).hide().fadeIn('slow')
        } else {
            bar.appendTo(container).hide().fadeIn('slow')
        }
        return bar
    };
    
    $.cookieMessage = function(cookie){
	    var arrStr = document.cookie.split("; ");
	    var strIn = "";
	    for (var i = 0; i < arrStr.length; i++) {
	        var temp = arrStr[i].split("=");
	        if (temp[0] == cookie) strIn = temp[1];
	    }
	    if(strIn){
			var intLen = strIn.length;
			var strOut = "";
			var strTemp;
			for(var i=0; i<intLen; i++)
			{
				strTemp = strIn.charAt(i);
				switch (strTemp)
				{
					case "~":{
						strTemp = strIn.substring(i+1, i+3);
						strTemp = parseInt(strTemp, 16);
						strTemp = String.fromCharCode(strTemp);
						strOut = strOut+strTemp;
						i += 2;
						break;
					}
					case "^":{
						strTemp = strIn.substring(i+1, i+5);
						strTemp = parseInt(strTemp,16);
						strTemp = String.fromCharCode(strTemp);
						strOut = strOut+strTemp;
						i += 4;
						break;
					}
					default:{
						strOut = strOut+strTemp;
						break;
					}
				}
		
			}
			$.msgBar ({
				type: 'success', 
				text: strOut,
				position: 'center-center', 
				lifetime: 2000
			});
			var date = new Date();
			date.setTime(date.getTime() - 20000);
			document.cookie = cookie + "=a; expires=" + date.toGMTString();
	    }
    }
    
})(jQuery);


$(window).load(function(){
	$.cookieMessage("oxhidemessage");
})