package com.sxsihe.coder.util;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.tagext.BodyTagSupport;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.coder.tables.domain.Tables;
import com.sxsihe.coder.tables.service.TablesService;

public class TablesShow extends BodyTagSupport{
	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int doStartTag() {
		TablesService tablesService = (TablesService)SpringContextUtil.getBean("tablesService");
		List list = tablesService.getAll();
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			Tables tables = (Tables)list.get(i);
			builder.append("<option value= \"");
			builder.append(tables.getTid());
			if (tables.getTid().equals(value)) {
				builder.append("\" selected=\"selected\" >");
			}else{
				builder.append("\">");
			}
			builder.append(tables.getTname());
			builder.append("</option>\n\r");
		}
		try {
			this.pageContext.getOut().print(builder.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return SKIP_PAGE;
	}
}
