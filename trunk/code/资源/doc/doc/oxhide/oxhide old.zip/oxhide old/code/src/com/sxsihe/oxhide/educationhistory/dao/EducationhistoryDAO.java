package com.sxsihe.oxhide.educationhistory.dao;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOIface;

/**
 *<p>Title:com.sxsihe.oxhide.educationhistory.dao.EducationhistoryDAO</p>
 *<p>Description:DAO</p>
 *<p>Copyright: Copyright (c) 2009</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-08-11
 *
 * @modify
 * @date
 */
public interface EducationhistoryDAO extends BaseDAOIface{
}