package com.sxsihe.oxhide.config.dao;
import com.ite.oxhide.persistence.BaseDAOIface;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.config.dao.SysconfigDAO</p>
 * <p>Description:�������ݲ�ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2012-02-15
 * @modify
 * @date
 */
 public interface SysconfigDAO extends BaseDAOIface{
 }
	