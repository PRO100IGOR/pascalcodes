package com.sxsihe.oxhide.schema.domain;

/**
 * TSchema entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class TSchema implements java.io.Serializable {

	// Fields

	private String schemaid;
	private String schemaname;
	private String folder;
	private String dialog;

	// Constructors

	public String getDialog() {
		return dialog;
	}

	public void setDialog(String dialog) {
		this.dialog = dialog;
	}

	/** default constructor */
	public TSchema() {
	}

	/** full constructor */
	public TSchema(String schemaname, String folder) {
		this.schemaname = schemaname;
		this.folder = folder;
	}

	// Property accessors

	public String getSchemaid() {
		return this.schemaid;
	}

	public void setSchemaid(String schemaid) {
		this.schemaid = schemaid;
	}

	public String getSchemaname() {
		return this.schemaname;
	}

	public void setSchemaname(String schemaname) {
		this.schemaname = schemaname;
	}

	public String getFolder() {
		return this.folder;
	}

	public void setFolder(String folder) {
		this.folder = folder;
	}

}