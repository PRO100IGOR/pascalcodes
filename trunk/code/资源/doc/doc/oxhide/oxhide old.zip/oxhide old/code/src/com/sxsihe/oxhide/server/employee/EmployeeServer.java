package com.sxsihe.oxhide.server.employee;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.sxsihe.oxhide.employee.domain.Employee;

public abstract interface EmployeeServer {
	/**
	 * �����б�����
	 * 
	 * @param block
	 * @param sortMap
	 * @return
	 */
	public List<Employee> findObjectsByCondition(ConditionBlock block, Map sortMap);

	/**
	 * ����������ѯ����
	 * 
	 * @param key
	 * @return
	 */
	public Employee findObjectBykey(String key) ;
	
	/**
	 * ��ѯȫ��
	 * @return
	 */
	public List<Employee> getAll();
}
