package com.sxsihe.coder.datas.dao.hibernateImpl;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.coder.datas.domain.Datas;
import com.sxsihe.coder.datas.dao.DatasDAO;
/**
 * 
 * <p>Title:com.sxsihe.coder.datas.dao.hibernateImpl.DatasDAOImpl</p>
 * <p>Description:datas���ݲ�ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-03
 * @modify
 * @date
 */
public class DatasDAOImpl extends BaseDAOImpl implements DatasDAO {
	/**
	 * ������룬ָ��dao��Ӧʵ����
	 */
	public Class getEntityClass() {
		return Datas.class;
	}
}
	