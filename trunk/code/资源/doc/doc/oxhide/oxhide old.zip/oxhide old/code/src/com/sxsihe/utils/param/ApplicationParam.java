package com.sxsihe.utils.param;


import javax.servlet.ServletContextEvent;

import org.springframework.web.context.ContextLoaderListener;

/**
 * ����ϵͳ����ʱ����ȫ�ֲ���
* @Title: ApplicationParam.java
* @Package com.sxsihe.utils.param
* @Description: TODO
* @author �ų���
* @date 2011-11-19 ����07:10:53
* @version V1.0
 */
public class ApplicationParam extends ContextLoaderListener {

	/**
	 * �ر�ʱ
	* override
	* @Title: ApplicationParam.java
	* @Package com.sxsihe.utils.param
	* @Description: TODO
	* @author �ų���
	* @date 2011-11-19 ����07:11:09
	* @version V1.0
	 */
	public void contextDestroyed(ServletContextEvent sce) {

	}

	/**
	 * ��ʼ��ʱ
	* override
	* @Title: ApplicationParam.java
	* @Package com.sxsihe.utils.param
	* @Description: TODO
	* @author �ų���
	* @date 2011-11-19 ����07:11:25
	* @version V1.0
	 */
	public void contextInitialized(ServletContextEvent sce){
		String webAppRootKey = sce.getServletContext().getRealPath("/");
		System.setProperty("cc.root" , webAppRootKey);
	}

}
