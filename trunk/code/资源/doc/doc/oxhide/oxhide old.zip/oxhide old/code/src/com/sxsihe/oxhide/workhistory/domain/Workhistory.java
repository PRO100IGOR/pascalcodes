package com.sxsihe.oxhide.workhistory.domain;

import com.sxsihe.oxhide.employee.domain.Employee;

/**
 * Workhistory entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Workhistory implements java.io.Serializable {

	// Fields

	private String hid;
	private Employee employee;
	private String begintime;
	private String endtime;
	private String organname;
	private String organid;
	private String dept;
	private String deptid;
	private String post;
	private String postid;
	private String remark;

	// Constructors

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	/** default constructor */
	public Workhistory() {
	}

	/** full constructor */
	public Workhistory(String employeeid, String begintime, String endtime, String organname, String organid, String dept, String deptid, String post, String postid) {
		this.begintime = begintime;
		this.endtime = endtime;
		this.organname = organname;
		this.organid = organid;
		this.dept = dept;
		this.deptid = deptid;
		this.post = post;
		this.postid = postid;
	}

	// Property accessors

	public String getHid() {
		return this.hid;
	}

	public void setHid(String hid) {
		this.hid = hid;
	}


	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public String getBegintime() {
		return this.begintime;
	}

	public void setBegintime(String begintime) {
		this.begintime = begintime;
	}

	public String getEndtime() {
		return this.endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public String getOrganname() {
		return this.organname;
	}

	public void setOrganname(String organname) {
		this.organname = organname;
	}

	public String getOrganid() {
		return this.organid;
	}

	public void setOrganid(String organid) {
		this.organid = organid;
	}

	public String getDept() {
		return this.dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getDeptid() {
		return this.deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getPost() {
		return this.post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getPostid() {
		return this.postid;
	}

	public void setPostid(String postid) {
		this.postid = postid;
	}

}