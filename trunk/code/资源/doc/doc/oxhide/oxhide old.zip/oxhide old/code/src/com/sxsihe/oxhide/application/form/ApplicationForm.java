package com.sxsihe.oxhide.application.form;

import com.ite.oxhide.struts.form.BaseForm;

public class ApplicationForm extends BaseForm {
	private String appid;
	private String ico;
	private String bigico;
	private Integer orderno;
	private String appcode;
	private String simplyname;
	private String largeico;
	private String remark;
	private String appurlw;
	private String applekey;
	private String androidkey;
	private String appname;
	private String appurl;
	private String appindex;
	private String apptitle;
	private String androidkf;
	private String applekf;
	private String timer;
	public String getTimer() {
		return timer;
	}

	public void setTimer(String timer) {
		this.timer = timer;
	}

	public String getTimeenable() {
		return timeenable;
	}

	public void setTimeenable(String timeenable) {
		this.timeenable = timeenable;
	}

	public String getTimes() {
		return times;
	}

	public void setTimes(String times) {
		this.times = times;
	}

	private String timeenable;
	private String times;
	public String getAndroidkf() {
		return androidkf;
	}

	public void setAndroidkf(String androidkf) {
		this.androidkf = androidkf;
	}

	public String getApplekf() {
		return applekf;
	}

	public void setApplekf(String applekf) {
		this.applekf = applekf;
	}

	public String getApplekey() {
		return this.applekey;
	}

	public void setApplekey(String applekey) {
		this.applekey = applekey;
	}

	public String getAndroidkey() {
		return this.androidkey;
	}

	public void setAndroidkey(String androidkey) {
		this.androidkey = androidkey;
	}

	public String getAppurlw() {
		return this.appurlw;
	}

	public void setAppurlw(String appurlw) {
		this.appurlw = appurlw;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getSimplyname() {
		return this.simplyname;
	}

	public void setSimplyname(String simplyname) {
		this.simplyname = simplyname;
	}

	public String getLargeico() {
		return this.largeico;
	}

	public void setLargeico(String largeico) {
		this.largeico = largeico;
	}

	public String getAppcode() {
		return this.appcode;
	}

	public void setAppcode(String appcode) {
		this.appcode = appcode;
	}

	public Integer getOrderno() {
		return this.orderno;
	}

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	public String getBigico() {
		return this.bigico;
	}

	public void setBigico(String bigico) {
		this.bigico = bigico;
	}

	public String getIco() {
		return this.ico;
	}

	public void setIco(String ico) {
		this.ico = ico;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getAppid() {
		return this.appid;
	}

	public void setAppname(String appname) {
		this.appname = appname;
	}

	public String getAppname() {
		return this.appname;
	}

	public void setAppurl(String appurl) {
		this.appurl = appurl;
	}

	public String getAppurl() {
		return this.appurl;
	}

	public void setAppindex(String appindex) {
		this.appindex = appindex;
	}

	public String getAppindex() {
		return this.appindex;
	}

	public void setApptitle(String apptitle) {
		this.apptitle = apptitle;
	}

	public String getApptitle() {
		return this.apptitle;
	}
}