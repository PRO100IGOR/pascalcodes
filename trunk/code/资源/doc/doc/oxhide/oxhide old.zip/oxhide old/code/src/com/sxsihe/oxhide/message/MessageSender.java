package com.sxsihe.oxhide.message;

import java.util.List;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.application.service.ApplicationService;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.resource.service.ResourceService;
import com.sxsihe.oxhide.ssouser.service.SsouserService;
import com.sxsihe.utils.common.CharsetSwitch;

import net.sf.json.JSONObject;

public class MessageSender {

	public String sendData(String data) {
		JSONObject result = new JSONObject();
		if (data.indexOf("{") < -1) {
			result.put("message", "������ʽ����");
			return result.toString();
		}
		data = data.replaceAll("&quot;", "\"");
		JSONObject param = JSONObject.fromObject(data);
		if (!param.has("appcode")) {
			result.put("message", "������ʽ����");
			return result.toString();
		}
		if (!param.has("type")) {
			result.put("message", "������ʽ����");
			return result.toString();
		}
		if (!param.has("info")) {
			result.put("message", "������ʽ����");
			return result.toString();
		}
		param.put("info", CharsetSwitch.decode(param.get("info").toString()));
		if (param.has("map") && StringUtils.isEmpty(param.getString("map"))) param.remove("map");
		if (param.has("map")) param.put("map", CharsetSwitch.decode(param.getString("map")));
		if (param.has("msgtype"))param.put("msgtype", CharsetSwitch.decode(param.get("msgtype").toString()));
		param.put("state", param.getString("state","all"));
		ConditionBlock block = new ConditionBlock();
		if (param.has("appcode")) {
			block.and(new ConditionLeaf("appcode", "cappcode", ConditionLeaf.EQ, param.getString("appcode"), false));
		} else {
			block.and(new ConditionLeaf("appid", "cappid", ConditionLeaf.EQ, param.getString("appid"), false));
		}
		ApplicationService applicationService = (ApplicationService) SpringContextUtil.getBean("applicationService");
		List list = applicationService.findObjectsByCondition(block, null);
		if (list.isEmpty()) {
			result.put("message", "ϵͳ�������");
			return result.toString();
		}
		Application application = (Application) list.get(0);
		Resources resources = null;
		if (param.has("rescode")) {
			ResourceService resourceService = (ResourceService) SpringContextUtil.getBean("resourceService");
			block = new ConditionBlock();
			block.and(new ConditionLeaf("application.appid", "cappid", ConditionLeaf.EQ, application.getAppid(), false));
			block.and(new ConditionLeaf("resourcecode", "crescode", ConditionLeaf.EQ, param.getString("rescode"), false));
			list = resourceService.findObjectsByCondition(block, null);
			if (list.isEmpty()) {
				result.put("message", "��Դ�������");
				return result.toString();
			}
			resources = (Resources) list.get(0);
		}

		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		List users = ssouserService.getMessUsers(param, application);
		if (users.isEmpty()) {
			result.put("message", "û���ҵ��û���");
			return result.toString();
		}
		String[] types = param.getString("type").split(",");
		for (int i = 0; i < types.length; i++) {
			MessageBaseService messageBaseService = (MessageBaseService) SpringContextUtil.getBean(types[i]);
			if (messageBaseService != null) {
				result.put(types[i], messageBaseService.sendData(param, application, resources, users));
			}
		}
		return result.toString();
	}

	public void unSendData(String id, String type) {
		MessageBaseService messageBaseService = (MessageBaseService) SpringContextUtil.getBean(type);
		if (messageBaseService != null) {
			messageBaseService.delSender(id);
		}
	}
}
