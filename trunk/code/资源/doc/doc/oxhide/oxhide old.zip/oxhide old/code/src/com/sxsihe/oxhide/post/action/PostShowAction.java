package com.sxsihe.oxhide.post.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ite.oxhide.common.util.StringUtils;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.menu.MenuNode;
import org.tdeccn.table.client.ActionHelper;
import java.io.*;
import com.ite.oxhide.persistence.*;

import org.extremecomponents.table.limit.Limit;
import com.ite.oxhide.common.util.*;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import org.apache.commons.beanutils.PropertyUtils;

import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.oxhide.dept.service.DeptService;
import com.sxsihe.oxhide.post.domain.Posts;
import com.sxsihe.oxhide.post.form.PostForm;
import com.sxsihe.oxhide.post.form.PostConditionForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.post.action.PostShowAction
 * </p>
 * <p>
 * Description:��λshowAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class PostShowAction extends BaseShowAction {
	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
//		DeptService deptService = (DeptService) SpringContextUtil.getBean("deptService");
//		Deptment deptment = (Deptment) deptService.findObjectBykey(request.getParameter("deptid"));
//		if (deptment != null) {
//			PostForm vForm = (PostForm) form;
//			vForm.setDeptid(deptment.getDeptid());
//			vForm.setDeptname(deptment.getDeptname());
//			vForm.setOrganid(deptment.getOrgan().getOrganid());
//			vForm.setOrganname(deptment.getOrgan().getOrganname());
//		}
	}


	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}


	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof PostForm) {
				Posts pos = (Posts) po;
				PostForm vForm = (PostForm) form;
				BeanUtils.setProperty(vForm, "postid", PropertyUtils.getProperty(pos, "postid"));
				BeanUtils.setProperty(vForm, "postname", PropertyUtils.getProperty(pos, "postname"));
				BeanUtils.setProperty(vForm, "postcode", PropertyUtils.getProperty(pos, "postcode"));
				BeanUtils.setProperty(vForm, "orderno", PropertyUtils.getProperty(pos, "orderno"));
				BeanUtils.setProperty(vForm, "isvalidation", PropertyUtils.getProperty(pos, "isvalidation"));
				BeanUtils.setProperty(vForm, "remark", PropertyUtils.getProperty(pos, "remark"));
				vForm.setDeptid(pos.getDeptment().getDeptid());
				vForm.setDeptname(pos.getDeptment().getDeptname());
				vForm.setOrganid(pos.getDeptment().getOrgan().getOrganid());
				vForm.setOrganname(pos.getDeptment().getOrgan().getOrganname());
				if (pos.getPosts() != null) {
					vForm.setPostpid(pos.getPosts().getPostid());
					vForm.setPostpname(pos.getPosts().getPostname());
				}
			}
		} catch (Exception e) {
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		PostConditionForm vcForm = (PostConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("postname", "cpostname", ConditionLeaf.LIKE, vcForm.getCpostname(), true));
			block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, vcForm.getCdeptid(), true));
			block.and(new ConditionLeaf("deptment.organ.organid", "corganid", ConditionLeaf.EQ, vcForm.getCorganid(), true));
		}
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		PostConditionForm vcForm = (PostConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("postname", "cpostname", ConditionLeaf.LIKE, vcForm.getCpostname(), true));
			block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, vcForm.getCdeptid(), true));
			block.and(new ConditionLeaf("deptment.organ.organid", "corganid", ConditionLeaf.EQ, vcForm.getCorganid(), true));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		sortMap.put("orderno", true);
		List list =  getService().findObjectsByCondition(block, sortMap);
		return list;
	}

	/**
	 * ��ʾ�����б� zcc Apr 22, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showOrderList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		saveToken(request);
		ConditionBlock block = new ConditionBlock();
		String deptid = request.getParameter("deptid");

		deptid = StringUtils.isEmpty(deptid)? null : deptid;
		String pid = request.getParameter("pid");
		pid = StringUtils.isEmpty(pid)? null : pid;
		if (deptid!=null) {
			block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, deptid, false));
		}
		block.and(new ConditionLeaf("posts.postid", "cpostid", ConditionLeaf.EQ, pid, false));
		Map sortMap = new HashMap();
		sortMap.put("orderno", true);
		List list = getService().findObjectsByCondition(block, sortMap);
		request.setAttribute("totalRows", list.size());
		request.setAttribute("list", list);
		return mapping.findForward("showOrderList");
	}

}
