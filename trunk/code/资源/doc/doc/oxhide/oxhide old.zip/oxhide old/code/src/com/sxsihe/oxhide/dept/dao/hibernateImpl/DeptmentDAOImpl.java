package com.sxsihe.oxhide.dept.dao.hibernateImpl;

import java.util.*;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;

import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.oxhide.dept.dao.DeptmentDAO;
import com.sxsihe.utils.properties.Reader;
/**
 *<p>Title:com.sxsihe.oxhide.dept.dao.DeptmentDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class DeptmentDAOImpl extends BaseDAOImpl implements DeptmentDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Deptment.class;
	   }

		/**
		 * ��ȡ���������
		 * zcc
		 * Apr 22, 2011
		 * @return
		 */
		public int getOrderNo(String organid){
			List temp = new ArrayList();
			try {
				Reader reader = new Reader("config.properties");
				Class sqlClass = Class.forName("com.sxsihe.base.sql." + reader.getProperty("sql"));
				String sql = sqlClass.getDeclaredField("OrderForDept").get(null).toString();
				SQLQuery sqlquery = this.getSession().createSQLQuery(sql);
				sqlquery.setParameter("organid", organid);
				sqlquery.addScalar("nonum", Hibernate.INTEGER);
				temp = sqlquery.list();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return temp.size() > 0 ? (new Integer(temp.get(0)+"")).intValue() : 0;
		}

}