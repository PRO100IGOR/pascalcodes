package com.sxsihe.oxhide.resource.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.resource.form.form.ResourceConditionForm
 * </p>
 * <p>
 * Description:��Դ
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 * 
 * @modify
 * @date
 */
public class ResourceConditionForm extends BaseForm {
	/* ��Դ�� */
	private String cresourcename;

	public void setCresourcename(String cresourcename) {
		this.cresourcename = cresourcename;
	}

	public String getCresourcename() {
		return this.cresourcename;
	}

	/* ��Դ���� */
	private Integer cresourcetype;

	public void setCresourcetype(Integer cresourcetype) {
		this.cresourcetype = cresourcetype;
	}

	public Integer getCresourcetype() {
		return this.cresourcetype;
	}

	private String parentrid;
	private String appid;

	public String getParentrid() {
		return parentrid;
	}

	public void setParentrid(String parentrid) {
		this.parentrid = parentrid;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}
}
