package com.sxsihe.coder.sels.service;
import com.ite.oxhide.service.BaseServiceImpl;
/**
 *
 * <p>Title:com.sxsihe.oxhide.coder.sels.service.SelsServiceImpl</p>
 * <p>Description:sels����ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-02
 * @modify
 * @date
 */
 public class SelsServiceImpl extends BaseServiceImpl implements SelsService{
 }
