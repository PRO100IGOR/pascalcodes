package com.sxsihe.oxhide.employee.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.employee.form.
 * EmployeeConditionForm
 * </p>
 * <p>
 * Description:Ա��
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class EmployeeConditionForm extends BaseForm {
	/* ���� */
	private String cemployeename;

	public void setCemployeename(String cemployeename) {
		this.cemployeename = cemployeename;
	}

	public String getCemployeename() {
		return this.cemployeename;
	}

	/* �Ա� */
	private Integer csex;

	public void setCsex(Integer csex) {
		this.csex = csex;
	}

	public Integer getCsex() {
		return this.csex;
	}

	/* ���գ��� */
	private String cbirthdaya;

	public void setCbirthdaya(String cbirthdaya) {
		this.cbirthdaya = cbirthdaya;
	}

	public String getCbirthdaya() {
		return this.cbirthdaya;
	}

	/* �� */
	private String cbirthdayb;

	public void setCbirthdayb(String cbirthdayb) {
		this.cbirthdayb = cbirthdayb;
	}

	public String getCbirthdayb() {
		return this.cbirthdayb;
	}

	private String postid;
	private String deptid;
	private String organid;

	public String getPostid() {
		return postid;
	}

	public void setPostid(String postid) {
		this.postid = postid;
	}

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getOrganid() {
		return organid;
	}

	public void setOrganid(String organid) {
		this.organid = organid;
	}
	
	private int cuserCount;

	public int getCuserCount() {
		return cuserCount;
	}

	public void setCuserCount(int cuserCount) {
		this.cuserCount = cuserCount;
	}

}
