package com.sxsihe.oxhide.message.token.dao;
import com.ite.oxhide.persistence.BaseDAOIface;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.token.dao.TokensDAO</p>
 * <p>Description:tokens���ݲ�ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-19
 * @modify
 * @date
 */
 public interface TokensDAO extends BaseDAOIface{
 }
	