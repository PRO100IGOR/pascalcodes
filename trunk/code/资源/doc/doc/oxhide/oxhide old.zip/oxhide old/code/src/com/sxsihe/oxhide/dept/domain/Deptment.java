package com.sxsihe.oxhide.dept.domain;

import java.util.HashSet;
import java.util.Set;

import com.sxsihe.oxhide.organ.domain.Organ;

/**
 * Deptment entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Deptment implements java.io.Serializable {

	// Fields

	private String deptid;
	private Organ organ;
	private String areaid;
	private String deptcode;
	private String deptname;
	private Integer orderno;
	private String remark;
	private Deptment deptment;
	private Integer isvalidation;
	private Set postses = new HashSet(0);
	private Set deptments = new HashSet(0);

	// Constructors

	/** default constructor */
	public Deptment() {
	}

	/** full constructor */
	public Deptment(Organ organ, String areaid, String deptcode, String deptname, Integer orderno, String remark, Integer isvalidation, Set postses) {
		this.organ = organ;
		this.areaid = areaid;
		this.deptcode = deptcode;
		this.deptname = deptname;
		this.orderno = orderno;
		this.remark = remark;
		this.isvalidation = isvalidation;
		this.postses = postses;
	}

	// Property accessors

	public String getDeptid() {
		return this.deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public Organ getOrgan() {
		return this.organ;
	}

	public void setOrgan(Organ organ) {
		this.organ = organ;
	}

	public String getAreaid() {
		return this.areaid;
	}

	public void setAreaid(String areaid) {
		this.areaid = areaid;
	}

	public String getDeptcode() {
		return this.deptcode;
	}

	public void setDeptcode(String deptcode) {
		this.deptcode = deptcode;
	}

	public String getDeptname() {
		return this.deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public Integer getOrderno() {
		return this.orderno;
	}

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Set getPostses() {
		return this.postses;
	}

	public void setPostses(Set postses) {
		this.postses = postses;
	}

	public Deptment getDeptment() {
		return deptment;
	}

	public void setDeptment(Deptment deptment) {
		this.deptment = deptment;
	}

	public Set getDeptments() {
		return deptments;
	}

	public void setDeptments(Set deptments) {
		this.deptments = deptments;
	}

}