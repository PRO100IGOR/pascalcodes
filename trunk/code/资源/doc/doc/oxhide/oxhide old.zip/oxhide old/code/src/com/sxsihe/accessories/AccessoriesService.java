package com.sxsihe.accessories;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public abstract interface AccessoriesService {
	public abstract void add(Accessories paramAccessories);

	public abstract void update(Accessories paramAccessories);

	public abstract void delete(Accessories paramAccessories);

	public abstract void delete(String paramString);

	public abstract Accessories getAccessories(String paramString);

	public abstract List getAccessoriesListByItem(String paramString);

	public abstract void submitAccessory(String paramString);

	public abstract void deleteAccessory(String paramString1);

	public List getAccessByHql(String hql, Map<String, Object> keyValue);
	public void save(Accessories acc);
}