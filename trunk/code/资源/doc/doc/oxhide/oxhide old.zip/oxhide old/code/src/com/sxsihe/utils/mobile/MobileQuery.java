package com.sxsihe.utils.mobile;

import java.util.ArrayList;
import java.util.List;

import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.spring.SpringContextUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

/**
 * �ƶ��˲�ѯ������
 * @author �ų���
 * TODO
 *2012����3:31:42
 */
public class MobileQuery {
	
	/**
	 * ��ȡhql
	 * @param datas
	 * {
	 * 		condition:[
	 * 			{
	 * 				name:"organAge",
	 * 				c:">"
	 * 				value:"1"
	 * 			},
	 * 			{
	 * 				name:"organAge",
	 * 				c:"<"
	 * 				value:"3"
	 * 			}
	 * 		],
	 * 		begin:0,
	 * 		count:10,
	 * 		order:{
	 * 			organname:true,
	 * 			organid:false	
	 * 		}	
	 * }
	 * @param className
	 * @return
	 * Administrator
	 * com.sxsihe.utils.mobile
	 * MobileQuery.java
	 * 2012����6:27:29
	 * oxhide
	 */
	public static String getHqlFromData(String datas, String className) {
		JSONObject data = null;
		try {
			data = JSONObject.fromObject(datas);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		String hqls = null;
		StringBuilder hql = new StringBuilder();
		hql.append("from " + className + " t where 1=1 ");
		if (data.containsKey("condition")) {
			JSONArray array = null;
			try {
				array = data.getJSONArray("condition");
				if (array.size() == 0)
					return hqls;
			} catch (Exception e) {
				e.printStackTrace();
				return hqls;
			}
			for (int i = 0; i < array.size(); i++) {
				JSONObject p = array.getJSONObject(i);
				hql.append(" and t." + p.getString("name") + " " + p.getString("c") + "'" + p.getString("value") + "'");
			}			
		}

		if (data.containsKey("order")) {
			JSONObject order = data.getJSONObject("order");
			hql.append(" order by ");
			for (Object key : order.keySet()) {
				hql.append(" " + key + " " + (order.getBoolean(key + "") ? "desc" : "false") + ",");
			}
			hqls = hql.substring(0, hql.length() - 1);
		} else {
			hqls = hql.toString();
		}
		return hqls;
	}
	
	/**
	 * ��ȡlist
	 * @param datas
	 * {
	 * 		condition:[
	 * 			{
	 * 				name:"organAge",
	 * 				c:">"
	 * 				value:"1"
	 * 			},
	 * 			{
	 * 				name:"organAge",
	 * 				c:"<"
	 * 				value:"3"
	 * 			}
	 * 		],
	 * 		begin:0,
	 * 		count:10,
	 * 		order:{
	 * 			organname:true,
	 * 			organid:false	
	 * 		}	
	 * }
	 * @param className
	 * @param serviceName
	 * @return
	 * Administrator
	 * com.sxsihe.utils.mobile
	 * MobileQuery.java
	 * 2012����6:27:18
	 * oxhide
	 */
	public static List queryListByData(String datas, String className, String serviceName) {
		String hqls = getHqlFromData(datas, className);
		JSONObject data = null;
		try {
			data = JSONObject.fromObject(datas);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		List list = new ArrayList();
		BaseServiceIface serviceIface = (BaseServiceIface) SpringContextUtil.getBean(serviceName);
		if (data.containsKey("begin")) {
			list = serviceIface.queryHql(hqls, null, data.getInt("begin"), data.getInt("count"));
		} else {
			list = serviceIface.queryHql(hqls, null);
		}
		return list;
	}

	/**
	 * ��ѯ����
	 * 
	 * @param datas
	 * {
	 * 		condition:[
	 * 			{
	 * 				name:"organAge",
	 * 				c:">"
	 * 				value:"1"
	 * 			},
	 * 			{
	 * 				name:"organAge",
	 * 				c:"<"
	 * 				value:"3"
	 * 			}
	 * 		],
	 * 		begin:0,
	 * 		count:10,
	 * 		order:{
	 * 			organname:true,
	 * 			organid:false	
	 * 		}	
	 * }
	 * @param className
	 * @param serviceName
	 * @param config
	 * @return Administrator
	 *         com.sxsihe.utils.mobile
	 *         MobileQuery.java 2012����6:21:40
	 *         oxhide
	 */
	public static String queryByJsonData(String datas, String className, String serviceName, JsonConfig config) {
		List list = queryListByData(datas, className, serviceName);
		if (list == null) {
			return null;
		} else {
			JSONArray jsonArray = config == null ? JSONArray.fromObject(list) : JSONArray.fromObject(list, config);
			return jsonArray.toString();
		}
	}
}
