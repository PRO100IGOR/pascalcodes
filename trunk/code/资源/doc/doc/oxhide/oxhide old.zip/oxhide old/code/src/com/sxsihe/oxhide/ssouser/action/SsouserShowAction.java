package com.sxsihe.oxhide.ssouser.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.ite.oxhide.spring.SpringContextUtil;
import java.io.*;
import com.ite.oxhide.persistence.*;

import org.extremecomponents.table.limit.Limit;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import org.apache.commons.beanutils.PropertyUtils;

import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.employee.service.EmployeeService;
import com.sxsihe.oxhide.login.service.SessionHouse;
import com.sxsihe.oxhide.schema.service.SchemaService;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.oxhide.ssouser.form.SsouserForm;
import com.sxsihe.oxhide.ssouser.form.SsouserconditionForm;
import com.sxsihe.oxhide.usersroles.domain.Usersroles;
import com.sxsihe.oxhide.usersroles.service.UsersrolesService;
import com.sxsihe.utils.common.CharsetSwitch;
import com.sxsihe.utils.common.RandomGUID;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssouser.action.
 * SsouserShowAction
 * </p>
 * <p>
 * Description:�û�showAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class SsouserShowAction extends BaseShowAction {

	/**
	 * ��ʾ��Դ�� zcc Apr 25, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showTree(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Ssousers po = (Ssousers) getService().findObjectBykey(id);
		if (po.getUsersroleses() != null) {
			Iterator ite = po.getUsersroleses().iterator();
			StringBuilder stringBuilder = new StringBuilder();
			while (ite.hasNext()) {
				Usersroles usersroles = (Usersroles) ite.next();
				stringBuilder.append(usersroles.getSsoroles().getRoleid() + ",");
			}
			request.setAttribute("ids", stringBuilder.toString());
		}
		request.setAttribute("id", id);
		return mapping.findForward("showTree");
	}

	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String eid = request.getParameter("eid");
		SsouserForm vForm = (SsouserForm) form;
		if (StringUtils.isNotEmpty(eid)) {
			EmployeeService employeeService = (EmployeeService) SpringContextUtil.getBean("employeeService");
			Employee employee = (Employee) employeeService.findObjectBykey(eid);
			vForm.setEmployeeid(eid);
			vForm.setEmployeename(employee.getEmployeename());
		}
		vForm.setUserid(RandomGUID.getGUID().replace("-", ""));
		addschemaList(request);
	}

	/**
	 * ��ѯ��ʽ
	 * 
	 * @param request
	 */
	private void addschemaList(HttpServletRequest request) {
		SchemaService schemaService = (SchemaService) SpringContextUtil.getBean("schemaService");
		request.setAttribute("list", schemaService.getAll());
	}

	/**
	 * ��������
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showOnline(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		SessionHouse sessionHouse = (SessionHouse) SpringContextUtil.getBean("sessionHouse");
		List list = sessionHouse.getAllSession();
		request.setAttribute("list", list);
		request.setAttribute("totalRows", list.size());
		return mapping.findForward("showOnline");
	}

	/**
	 * �߳�ϵͳ����
	 * 
	 * @param sessionid
	 */
	public ActionForward tipUser(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String sessionid = request.getParameter("id");
		SessionHouse sessionHouse = (SessionHouse) SpringContextUtil.getBean("sessionHouse");
		sessionHouse.removeSessionBySid(sessionid);
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("�����ɹ���"));
		response.addCookie(cookie);
		return new ActionForward("/ssouserShowAction.do?action=showOnline");
	}

	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable po) throws BaseException {
		addschemaList(request);
		Ssousers pos = (Ssousers) po;
		JSONArray arrayId = new JSONArray();
		JSONArray arrayName = new JSONArray();
		for (Iterator iterator = pos.getUsersroleses().iterator(); iterator.hasNext();) {
			Usersroles usersroles = (Usersroles) iterator.next();
			arrayId.add(usersroles.getSsoroles().getRoleid());
			arrayName.add(usersroles.getSsoroles().getRolename());
		}
		request.setAttribute("ids", arrayId.join(",", true));
		request.setAttribute("names", arrayName.join(",", true));
	}


	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof SsouserForm) {
				Ssousers pos = (Ssousers) po;
				SsouserForm vForm = (SsouserForm) form;
				BeanUtils.setProperty(vForm, "userid", PropertyUtils.getProperty(pos, "userid"));
				BeanUtils.setProperty(vForm, "username", PropertyUtils.getProperty(pos, "username"));
				BeanUtils.setProperty(vForm, "password", PropertyUtils.getProperty(pos, "password"));
				BeanUtils.setProperty(vForm, "isvalidation", PropertyUtils.getProperty(pos, "isvalidation"));
				BeanUtils.setProperty(vForm, "facestyle", PropertyUtils.getProperty(pos, "facestyle"));
				BeanUtils.setProperty(vForm, "apple", PropertyUtils.getProperty(pos, "apple"));
				BeanUtils.setProperty(vForm, "issingel", PropertyUtils.getProperty(pos, "issingel"));
				BeanUtils.setProperty(vForm, "android", PropertyUtils.getProperty(pos, "android"));
				vForm.setEmployeeid(pos.getEmployee().getEmployeeid());
				vForm.setEmployeename(pos.getEmployee().getEmployeename());
			}
		} catch (Exception e) {
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		SsouserconditionForm ssouserconditionForm = (SsouserconditionForm) conditionForm;
		if (ssouserconditionForm != null) {
			block.and(new ConditionLeaf("username", "cusername", ConditionLeaf.LIKE, ssouserconditionForm.getUsername(), true));
			block.and(new ConditionLeaf("issingel", "cissingel", ConditionLeaf.EQ, ssouserconditionForm.getIssingle(), true));
			block.and(new ConditionLeaf("employee.employeename", "cemployeename", ConditionLeaf.LIKE, ssouserconditionForm.getEname(), true));
			block.and(new ConditionLeaf("employee.posts.deptment.deptid", "cdeptid", ConditionLeaf.EQ, ssouserconditionForm.getDeptId(), true));
			block.and(new ConditionLeaf("employee.posts.postid", "cpostid", ConditionLeaf.EQ, ssouserconditionForm.getPostId(), true));
			block.and(new ConditionLeaf("employee.posts.deptment.organ.organid", "corganid", ConditionLeaf.EQ, ssouserconditionForm.getOrganId(), true));
			if (StringUtils.isNotEmpty(request.getParameter("ee"))) {
				block.and(new ConditionLeaf("employee.employeeid", "cemployeeid", ConditionLeaf.EQ, ssouserconditionForm.getEid(), true));
			}
		}
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		SsouserconditionForm ssouserconditionForm = (SsouserconditionForm) conditionForm;
		if (ssouserconditionForm != null) {
			block.and(new ConditionLeaf("username", "cusername", ConditionLeaf.LIKE, ssouserconditionForm.getUsername(), true));
			block.and(new ConditionLeaf("issingel", "cissingel", ConditionLeaf.EQ, ssouserconditionForm.getIssingle(), true));
			block.and(new ConditionLeaf("employee.employeename", "cemployeename", ConditionLeaf.LIKE, ssouserconditionForm.getEname(), true));
			block.and(new ConditionLeaf("employee.posts.deptment.deptid", "cdeptid", ConditionLeaf.EQ, ssouserconditionForm.getDeptId(), true));
			block.and(new ConditionLeaf("employee.posts.postid", "cpostid", ConditionLeaf.EQ, ssouserconditionForm.getPostId(), true));
			block.and(new ConditionLeaf("employee.posts.deptment.organ.organid", "corganid", ConditionLeaf.EQ, ssouserconditionForm.getOrganId(), true));
			if (StringUtils.isNotEmpty(request.getParameter("ee"))) {
				block.and(new ConditionLeaf("employee.employeeid", "cemployeeid", ConditionLeaf.EQ, ssouserconditionForm.getEid(), true));
			}
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		sortMap.put("username", true);
		List list = null;
		if (limit != null)
			list = getService().findObjectsByCondition(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed());
		else
			list = getService().findObjectsByCondition(block, sortMap);
		return list;
	}

}
