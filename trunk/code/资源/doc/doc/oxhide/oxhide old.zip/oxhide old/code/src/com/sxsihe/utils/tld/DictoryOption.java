package com.sxsihe.utils.tld;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.dictionarycontent.domain.Dictionarycontent;
import com.sxsihe.oxhide.server.dictionary.DictionaryServer;
/**
 * ����ָ���������ֵ��������select��ǩ��option���ԣ���ѡ��match���������
 * @author �ų���
 *
 */
public class DictoryOption extends BodyTagSupport {
	private String dic;
	private String match;

	public String getMatch() {
		return match;
	}

	public void setMatch(String match) {
		this.match = match;
	}

	public String getDic() {
		return dic;
	}

	public void setDic(String dic) {
		this.dic = dic;
	}

	public int doStartTag() throws JspException {
		DictionaryServer dictionaryServer = (DictionaryServer) SpringContextUtil.getBean("dictionaryClient");
		List list = dictionaryServer.getDicAsList(dic);
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < list.size(); i++) {
			Dictionarycontent dictionarycontent = (Dictionarycontent)list.get(i);
			if (dictionarycontent.getDcode().equals(match)) {
				builder.append("<option selected=\"selected\" value=\""+dictionarycontent.getDcode()+"\">"+dictionarycontent.getDcvalue()+"</option>\n\r");
			}else{
				builder.append("<option  value=\""+dictionarycontent.getDcode()+"\">"+dictionarycontent.getDcvalue()+"</option>\n\r");
			}
		}
		try {
			this.pageContext.getOut().print(builder.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return SKIP_PAGE;
	}
}
