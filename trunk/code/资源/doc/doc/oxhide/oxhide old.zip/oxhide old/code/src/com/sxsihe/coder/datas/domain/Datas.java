package com.sxsihe.coder.datas.domain;

import com.sxsihe.coder.columns.domain.Columns;
import com.sxsihe.coder.dataid.domain.Dataid;

/**
 * Datas entity. @author MyEclipse Persistence Tools
 */

public class Datas implements java.io.Serializable {

	// Fields

	private String did;
	private String dvalue;
	private Dataid dataid;
	private Columns columns;

	// Constructors

	public Dataid getDataid() {
		return dataid;
	}

	public void setDataid(Dataid dataid) {
		this.dataid = dataid;
	}

	public Columns getColumns() {
		return columns;
	}

	public void setColumns(Columns columns) {
		this.columns = columns;
	}

	/** default constructor */
	public Datas() {
	}

	/** full constructor */
	public Datas(String cid, String dtid, String dvalue) {
		this.dvalue = dvalue;
	}

	// Property accessors

	public String getDid() {
		return this.did;
	}

	public void setDid(String did) {
		this.did = did;
	}


	public String getDvalue() {
		return this.dvalue;
	}

	public void setDvalue(String dvalue) {
		this.dvalue = dvalue;
	}

}