package com.sxsihe.oxhide.server.resource;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.sxsihe.oxhide.resource.domain.Resources;


public abstract interface ResourceServer {
	/**
	 * �����б�����
	 *
	 * @param block
	 * @param sortMap
	 * @return
	 */
	public List<Resources> findObjectsByCondition(ConditionBlock block, Map sortMap);

	/**
	 * ����������ѯ����
	 *
	 * @param key
	 * @return
	 */
	public Resources findObjectBykey(String key) ;

	/**
	 * ��ѯȫ��
	 * @return
	 */
	public List<Resources> getAll();

	public void add(Resources resources);

	public List<Resources> queryHql(String hql);

	/**
	 * ���ӻ򱣴�˵�
	* @Title: ResourceServerImpl.java
	* @Package com.sxsihe.oxhide.server.resource
	* @Description: TODO
	* @author �ų���
	* @date 2011-11-3 ����05:05:54
	* @version V1.0
	 */
	public void add(String rname,String rid,String appid,String modelid,String url);

	/**
	 * ɾ��
	* @Title: ResourceServerImpl.java
	* @Package com.sxsihe.oxhide.server.resource
	* @Description: TODO
	* @author �ų���
	* @date 2011-11-3 ����05:44:10
	* @version V1.0
	 */
	public void delete(String rid);
}
