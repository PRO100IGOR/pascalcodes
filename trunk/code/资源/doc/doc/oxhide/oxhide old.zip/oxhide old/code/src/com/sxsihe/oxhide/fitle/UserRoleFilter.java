package com.sxsihe.oxhide.fitle;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.login.domain.UserSession;
import com.sxsihe.oxhide.server.loginsession.LoginSessionService;

public class UserRoleFilter implements Filter {

	private boolean forceEncoding = true;
	private String noEncodingUrls = "";
	private String encoding = "GBK";
	private String noFilterUrls = "";
	private String noFilterUris = "";

	public void destroy() {
		// TODO Auto-generated method stub

	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		String basepath = req.getContextPath();
		res.setHeader("P3P", "CP=CAO PSA OUR");
		String uri = req.getRequestURI().toString();
		String sessionid = req.getParameter("SESSIONID");
		LoginSessionService uumService = (LoginSessionService) SpringContextUtil.getBean("loginServiceClient");
		/* ����Ҫǿ��ת��ʱ������Ҫת�������urls */
		if ((this.forceEncoding) || (request.getCharacterEncoding() == null)) {
			String[] noEncodings = this.noEncodingUrls.split(",");
			boolean is = true;
			if (StringUtils.isNotEmpty(this.noEncodingUrls)) {
				for (int i = 0; i < noEncodings.length; i++) {
					if (uri.indexOf(noEncodings[i]) >= 0) {
						is = false;
						break;
					}
				}
			}

			if (is)
				request.setCharacterEncoding(this.encoding);
		}
		/* �����session��urls */
		String[] noFilters = this.noFilterUrls.split(",");
		boolean is = false;
		for (int i = 0; i < noFilters.length; i++) {
			if (uri.indexOf(noFilters[i]) >= 0) {
				is = true;
				break;
			}
		}
		if (is) {
			try {
				filterChain.doFilter(request, response);
			} catch (Exception e) {

			}
			return;
		}

		noFilters = this.noFilterUris.split(",");
		is = false;
		for (int i = 0; i < noFilters.length; i++) {
			if (uri.equals(noFilters[i])) {
				is = true;
				break;
			}
		}
		if (is) {
			try {
				filterChain.doFilter(request, response);
			} catch (Exception e) {

			}
			return;
		}

		// if (url.endsWith("getAllLanguage.do"))
		// {
		// String path =
		// getClass().getResource("/").getPath();
		// path =
		// path.replaceAll("WEB-INF/classes", "");
		// Properties prop = new Properties();
		// prop.load(new FileInputStream(path +
		// "/resource/language/lang.properties"));
		// Iterator iterator =
		// prop.keySet().iterator();
		// String express = "{";
		// boolean first = true;
		// while (iterator.hasNext()) {
		// String key = (String) iterator.next();
		// if (!first)
		// express = express + ",\n";
		// express = express + "\"" + key +
		// "\":\"" + prop.getProperty(key) + "\"";
		// first = false;
		// }
		// express = express + "};\n";
		// res.setCharacterEncoding("GBK");
		// PrintWriter outStream =
		// res.getWriter();
		// outStream.println(express);
		// return;
		// }

		UserSession token = StringUtils.isEmpty(sessionid) ? (UserSession) req.getSession().getAttribute("USERSESSION") : uumService.getSession(sessionid, null);
		if (token == null) {
			clearSession(req.getSession());
			if(StringUtils.isEmpty(req.getParameter("mobile"))){
				res.sendRedirect(basepath + "/core/exception/sessionTimeOut.jsp");
			}else{
				String callback = req.getParameter("callback");
				res.setCharacterEncoding("utf-8");
				try {
					if (StringUtils.isNotEmpty(callback)) {
						JSONObject jsonObject = new JSONObject();
						jsonObject.put("error", "���ĻỰ�ѹ���,�����µ�¼��");
						res.getWriter().write(callback + "(" + jsonObject + ")");
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return;
		} else {
			req.getSession().setAttribute("USERSESSION", token);
			req.getSession().setAttribute("faceStyle", token.getFacestyle());
			req.getSession().setAttribute("dialog", token.getDialog());
		}
		filterChain.doFilter(request, response);
	}

	public void init(FilterConfig config) throws ServletException {
		setEncoding(config.getInitParameter("encoding"));
		setForceEncoding(Boolean.valueOf(config.getInitParameter("forceEncoding")).booleanValue());
		setNoEncodingUrls(config.getInitParameter("noEncodingUrls"));
		setNoFilterUrls(config.getInitParameter("noFilterUrls"));
		setNoFilterUris(config.getInitParameter("noFilterUris"));
	}

	private void clearSession(HttpSession session) {
		Enumeration enums = session.getAttributeNames();
		while (enums.hasMoreElements()) {
			String name = (String) enums.nextElement();
			session.removeAttribute(name);
		}
	}

	public boolean isForceEncoding() {
		return forceEncoding;
	}

	public void setForceEncoding(boolean forceEncoding) {
		this.forceEncoding = forceEncoding;
	}

	public String getNoEncodingUrls() {
		return noEncodingUrls;
	}

	public void setNoEncodingUrls(String noEncodingUrls) {
		this.noEncodingUrls = noEncodingUrls;
	}

	public String getEncoding() {
		return encoding;
	}

	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	public String getNoFilterUrls() {
		return noFilterUrls;
	}

	public void setNoFilterUrls(String noFilterUrls) {
		this.noFilterUrls = noFilterUrls;
	}

	public String getNoFilterUris() {
		return noFilterUris;
	}

	public void setNoFilterUris(String noFilterUris) {
		this.noFilterUris = noFilterUris;
	}

}
