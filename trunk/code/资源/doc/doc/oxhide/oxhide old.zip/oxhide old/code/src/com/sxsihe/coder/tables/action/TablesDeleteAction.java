package com.sxsihe.coder.tables.action;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseDeleteAction;
import com.sxsihe.coder.dataid.service.DataidService;
import com.sxsihe.coder.tables.domain.Tables;
import com.sxsihe.coder.tables.service.TablesService;
import com.sxsihe.oxhide.server.resource.ResourceServer;
import com.sxsihe.utils.common.CharsetSwitch;
import com.sxsihe.utils.system.SystemLogHelper;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class TablesDeleteAction extends BaseDeleteAction {
	private ResourceServer resourceServer;
	private DataidService dataidService;

	public ResourceServer getResourceServer() {
		return this.resourceServer;
	}

	public void setResourceServer(ResourceServer resourceServer) {
		this.resourceServer = resourceServer;
	}

	public DataidService getDataidService() {
		return this.dataidService;
	}

	public void setDataidService(DataidService dataidService) {
		this.dataidService = dataidService;
	}

	public ActionForward preDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable ob) throws BaseException {
		Tables tables = (Tables) ob;
		if (StringUtils.isNotEmpty(tables.getMenuid())) {
			this.resourceServer.delete(tables.getMenuid());
		}
		((TablesService) getService()).execSql("drop view " + tables.getTcode() + "_view");
		return null;
	}

	public ActionForward deleteCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		boolean is = repeatSubmit(mapping, form, request);
		if (is)
			new ActionForward(request.getContextPath() + "/core/success/opSuccess.jsp");
		String id = request.getParameter("id");
		Serializable po = (Serializable) this.dataidService.findObjectBykey(id);
		if (po != null) {
			this.dataidService.delete(po);
			SystemLogHelper.addLog(request, "ɾ��һ����¼", "1", "");
			Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("ɾ���ɹ���"));
			response.addCookie(cookie);
		}
		return new ActionForward("/tablesLoadAction.do?action=list&table=" + request.getParameter("table"));
	}

	public ActionForward batchDeleteCode(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String[] ids = request.getParameterValues("itemlist");
		Serializable po = null;
		List list = new ArrayList();
		for (int i = 0; i < ids.length; ++i) {
			po = (Serializable) this.dataidService.findObjectBykey(ids[i]);
			if (po != null) {
				list.add(po);
			}
		}
		if (!(list.isEmpty())) {
			this.dataidService.deleteBatch(list);
			SystemLogHelper.addLog(request, "ɾ��" + list.size() + "����¼", "1", "");
			Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("ɾ��" + list.size() + "����¼"));
			response.addCookie(cookie);
		}
		return new ActionForward("/tablesLoadAction.do?action=list&table=" + request.getParameter("table"));
	}
}