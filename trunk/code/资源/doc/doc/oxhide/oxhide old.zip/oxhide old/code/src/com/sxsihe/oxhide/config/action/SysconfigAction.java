package com.sxsihe.oxhide.config.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.action.AbstractAction;
import com.sxsihe.oxhide.config.service.SysconfigService;
import com.sxsihe.oxhide.config.service.SysconfigServiceImpl;
import com.sxsihe.oxhide.message.android.AndroidService;
import com.sxsihe.oxhide.message.mobile.MobileService;

/**
 * 
 * <p>
 * Title:com.sxsihe.oxhide.config.action.SysconfigShowAction
 * </p>
 * <p>
 * Description:������ʾaction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Company: �ĺ�
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2012-02-15
 * @modify
 * @date
 */
public class SysconfigAction extends AbstractAction {

	/**
	 * ��ʾ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 *             Administrator com.sxsihe.oxhide.config.action SysconfigAction.java 2012����9:25:53 oxhide
	 */
	public ActionForward show(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		request.setAttribute("configs", SysconfigServiceImpl.configs);
		return mapping.findForward("config");
	}

	/**
	 * ���棡
	 * 
	 * @param action
	 * @param data
	 * @return Administrator com.sxsihe.oxhide.config.action SysconfigAction.java 2012����4:06:59 oxhide
	 */
	public void saveConfig(String action, String data) {
		SysconfigService sysconfigService = (SysconfigService) getService();
		JSONObject v = JSONObject.fromObject(data);
		if ("base".equals(action)) {
			sysconfigService.saveConfig("baselogin", v.getString("baselogin"));
			sysconfigService.saveConfig("basesession", v.getString("basesession"));
		} else if ("sms".equals(action)) {
			MobileService mobile = (MobileService) SpringContextUtil.getBean("mobile");
			sysconfigService.saveConfig("smsopen", v.getString("smsopen"));
			sysconfigService.saveConfig("smstime", v.getString("smstime"));
			sysconfigService.saveConfig("smscom", v.getString("smscom"));
			sysconfigService.saveConfig("smsbaud", v.getString("smsbaud"));
			sysconfigService.saveConfig("smsdevname", v.getString("smsdevname"));
			sysconfigService.saveConfig("smswavetype", v.getString("smswavetype"));
			sysconfigService.saveConfig("smspin", v.getString("smspin",""));
			sysconfigService.saveConfig("smstail", v.getString("smstail",""));
			if ("1".equals(v.getString("smsopen"))) {
				mobile.start();
			} else {
				mobile.stop();
			}
		} else if ("android".equals(action)) {
			AndroidService androidService = (AndroidService) SpringContextUtil.getBean("android");
			sysconfigService.saveConfig("androidopen", v.getString("androidopen"));
			sysconfigService.saveConfig("androidport", v.getString("androidport"));
			if ("1".equals(v.getString("androidopen"))) {
				androidService.start();
			} else {
				androidService.stop();
			}
		}
	}
}
