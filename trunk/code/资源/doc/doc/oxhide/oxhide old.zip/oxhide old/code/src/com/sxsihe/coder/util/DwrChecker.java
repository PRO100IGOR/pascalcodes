package com.sxsihe.coder.util;

import java.util.HashMap;
import java.util.Map;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.coder.tables.service.TablesService;

public class DwrChecker {

	/**
	 * ��֤�����Ƿ��ظ�
	 * @param tid
	 * @param tname
	 * @return
	 */
	public boolean checkTableName(String tid,String tcode){
		TablesService tablesService = (TablesService)SpringContextUtil.getBean("tablesService");
		String hql = "from Tables tables where tables.tid != :tid  and tables.tcode = :tcode";
		Map map = new HashMap();
		map.put("tid", tid);
		map.put("tcode", tcode);
		return tablesService.queryHql(hql, map).isEmpty();
	}

}
