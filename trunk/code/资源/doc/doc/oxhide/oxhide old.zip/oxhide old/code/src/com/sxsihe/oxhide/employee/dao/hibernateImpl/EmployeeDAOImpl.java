package com.sxsihe.oxhide.employee.dao.hibernateImpl;

import java.util.*;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;

import com.ite.oxhide.persistence.BaseDAOImpl;
import com.ite.oxhide.persistence.ConditionBlock;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.employee.dao.EmployeeDAO;
import com.sxsihe.utils.properties.Reader;

/**
 * <p>
 * Title:com.sxsihe.oxhide.employee.dao.
 * EmployeeDAOImpl
 * </p>
 * <p>
 * Description:DAOImpl
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class EmployeeDAOImpl extends BaseDAOImpl implements EmployeeDAO {
	/**
	 * (non-Javadoc)
	 * 
	 * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	 */
	public Class getEntityClass() {
		// TODO Auto-generated method stub
		return Employee.class;
	}

	/**
	 * ��ȡ��������� zcc Apr 22, 2011
	 * 
	 * @return
	 */
	public int getOrderNo(String postid) {
		List temp = new ArrayList();
		try {
			Reader reader = new Reader("config.properties");
			Class sqlClass = Class.forName("com.sxsihe.base.sql." + reader.getProperty("sql"));
			String sql = sqlClass.getDeclaredField("OrderForEmp").get(null).toString();
			SQLQuery sqlquery = this.getSession().createSQLQuery(sql);
			sqlquery.setParameter("POSTID", postid);
			sqlquery.addScalar("nonum", Hibernate.INTEGER);
			temp = sqlquery.list();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return temp.size() > 0 ? (new Integer(temp.get(0) + "")).intValue() : 0;
	}

	/**
	 * �߼���ѯ����
	 * 
	 * @param condition
	 * @return Administrator
	 *         com.sxsihe.oxhide.employee
	 *         .dao.hibernateImpl
	 *         EmployeeDAOImpl.java 2012����6:54:50
	 *         oxhide
	 */
	public int getEmpAdvCount(ConditionBlock condition) {
		String sql = "select count(*) cc from (SELECT e.*,(select count(*) from ssousers u where u.EMPLOYEEID = e.EMPLOYEEID) userCount from employee e) table0_1 where 1=1 ";
		String where = condition == null ? "" : (" and " + condition.getHQL());
		sql = sql + where;
		SQLQuery query = this.getSession().createSQLQuery(sql);
		if (condition != null) {
			Map map = condition.getMap();
			if (map.size() != 0) {
				Set set = map.keySet();
				Iterator iterator = set.iterator();
				while (iterator.hasNext()) {
					String key = (String) iterator.next();
					try {
						if (map.get(key) instanceof Collection)
							query.setParameterList(key, (Collection) (Collection) map.get(key));
						if (map.get(key) instanceof Object[])
							query.setParameterList(key, (Object[]) map.get(key));
						query.setParameter(key, map.get(key));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		query.addScalar("cc", Hibernate.INTEGER);
		List list = query.list();
		if (list.isEmpty()) {
			return 0;
		} else {
			return (Integer) list.get(0);
		}
	}

	/**
	 * �߼���ѯԱ��
	 * 
	 * @param block
	 * @param sortMap
	 * @param index
	 * @param count
	 * @return Administrator
	 *         com.sxsihe.oxhide.employee
	 *         .dao.hibernateImpl
	 *         EmployeeDAOImpl.java 2012����6:37:55
	 *         oxhide
	 */
	public List<Employee> getEmpAdv(ConditionBlock condition, Map sortMap, int beginNo, int pageSize) {
		String sql = "select {table0_1.*}, userCount users from (SELECT e.*,(select count(*) from ssousers u where u.EMPLOYEEID = e.EMPLOYEEID) userCount from employee e) table0_1 where 1=1 ";
		String where = condition == null ? "" : (" and " + condition.getHQL());
		StringBuilder order = new StringBuilder();
		boolean hasOrder = false;
		for (Iterator iterator = sortMap.keySet().iterator(); iterator.hasNext();) {
			String o = (String) iterator.next();
			boolean t = (Boolean) sortMap.get(o);
			order.append(o + (t ? " desc " : " asc "));
			hasOrder = true;
		}
		if (hasOrder) {
			order.insert(0, " order by ");
		}
		sql = sql + where + order;
		SQLQuery query = this.getSession().createSQLQuery(sql);
		if (condition != null) {
			Map map = condition.getMap();
			if (map.size() != 0) {
				Set set = map.keySet();
				Iterator iterator = set.iterator();
				while (iterator.hasNext()) {
					String key = (String) iterator.next();
					try {
						if (map.get(key) instanceof Collection)
							query.setParameterList(key, (Collection) (Collection) map.get(key));
						if (map.get(key) instanceof Object[])
							query.setParameterList(key, (Object[]) map.get(key));
						query.setParameter(key, map.get(key));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		query.addEntity("table0_1", Employee.class);
		query.addScalar("users", Hibernate.INTEGER);
		if (beginNo > -1) {
			query.setFirstResult(beginNo);
			query.setMaxResults(pageSize);
		}
		List<Object[]> list  = query.list();
		List<Employee> result = new ArrayList<Employee>();
		for(Object[] o : list){
			Employee employee = (Employee)o[1];
			employee.setUserCount((Integer)o[0]);
			result.add(employee);
		}
		return result;
	}
}