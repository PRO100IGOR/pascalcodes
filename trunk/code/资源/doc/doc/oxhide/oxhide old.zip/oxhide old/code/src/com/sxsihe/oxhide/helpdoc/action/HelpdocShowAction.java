package com.sxsihe.oxhide.helpdoc.action;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import java.io.Serializable;
import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.persistence.ConditionBlock;
import org.apache.commons.beanutils.PropertyUtils;
import org.extremecomponents.table.limit.Limit;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import com.sxsihe.oxhide.helpdoc.domain.Helpdoc;
import com.sxsihe.oxhide.helpdoc.form.HelpdocForm;

/**
 * 
 * <p>
 * Title:com.sxsihe.oxhide.helpdoc.action.HelpdocShowAction
 * </p>
 * <p>
 * Description:helpdoc��ʾaction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Company: �ĺ�
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-09-28
 * @modify
 * @date
 */
public class HelpdocShowAction extends BaseShowAction {

	/**
	 * ά������
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showHelp(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String itemId = request.getParameter("itemId");
		String hql = "from Helpdoc t where t.itemid = :itemid";
		Map map = new HashMap();
		map.put("itemid", itemId);
		List list = getService().queryHql(hql, map);
		HelpdocForm vForm = (HelpdocForm) form;
		if (list.isEmpty()) {
			vForm.setItemid(itemId);
			request.setAttribute("form", vForm);
			request.setAttribute("action", "add");
		} else {
			Helpdoc po = (Helpdoc) list.get(0);
			getForm(po, vForm);
			request.setAttribute("form", vForm);
			request.setAttribute("action", "update");
		}
		return mapping.findForward("showAdd");
	}

	/**
	 * �ж�FORM �Ƿ�Ϊ��
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected boolean judgeFormIsNull(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		HelpdocForm vForm = (HelpdocForm) form;
		if (StringUtils.isNotEmpty(vForm.getHid()))
			return false;
		else
			return true;
	}

	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * ת��ʵ����Ϊform����
	 * 
	 * @param po
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof HelpdocForm) {
				Helpdoc pos = (Helpdoc) po;
				HelpdocForm vForm = (HelpdocForm) form;
				BeanUtils.setProperty(vForm, "hid", PropertyUtils.getProperty(pos, "hid"));
				BeanUtils.setProperty(vForm, "hcontent", PropertyUtils.getProperty(pos, "hcontent"));
				BeanUtils.setProperty(vForm, "itemid", PropertyUtils.getProperty(pos, "itemid"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return form;
	}

	/**
	 * ��ʾ�鿴ҳ��
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showView(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String itemId = request.getParameter("itemId");
		String hql = "from Helpdoc t where t.itemid = :itemid";
		Map map = new HashMap();
		map.put("itemid", itemId);
		List list = getService().queryHql(hql, map);
		HelpdocForm vForm = (HelpdocForm) form;
		if (!list.isEmpty()) {
			request.setAttribute("view", list.get(0));
		}
		return mapping.findForward("showView");
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		return limit != null ? getService().findObjectsByCondition(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed()) : getService()
				.findObjectsByCondition(block, sortMap);
	}
}
