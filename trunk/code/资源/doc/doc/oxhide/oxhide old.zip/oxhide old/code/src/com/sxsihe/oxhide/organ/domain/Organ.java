package com.sxsihe.oxhide.organ.domain;

import java.util.HashSet;
import java.util.Set;

/**
 * Organ entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Organ implements java.io.Serializable {

	// Fields

	private String organid;
	private String organname;
	private String areaid;
	private String organcode;
	private String organalias;
	private String postcode;
	private String address;
	private String telephone;
	private String fax;
	private String remark;
	private Integer isvalidation;
	private Set deptments = new HashSet(0);
	private Organ porgan;
	private Set organs = new HashSet(0);

	// Constructors

	public Organ getPorgan() {
		return porgan;
	}

	public void setPorgan(Organ porgan) {
		this.porgan = porgan;
	}

	public Set getOrgans() {
		return organs;
	}

	public void setOrgans(Set organs) {
		this.organs = organs;
	}

	/** default constructor */
	public Organ() {
	}

	/** full constructor */
	public Organ(String organname, String areaid, String organcode, String organalias, String postcode, String address, String telephone, String fax, String remark, Integer isvalidation, Set deptments) {
		this.organname = organname;
		this.areaid = areaid;
		this.organcode = organcode;
		this.organalias = organalias;
		this.postcode = postcode;
		this.address = address;
		this.telephone = telephone;
		this.fax = fax;
		this.remark = remark;
		this.isvalidation = isvalidation;
		this.deptments = deptments;
	}

	// Property accessors

	public String getOrganid() {
		return this.organid;
	}

	public void setOrganid(String organid) {
		this.organid = organid;
	}

	public String getOrganname() {
		return this.organname;
	}

	public void setOrganname(String organname) {
		this.organname = organname;
	}

	public String getAreaid() {
		return this.areaid;
	}

	public void setAreaid(String areaid) {
		this.areaid = areaid;
	}

	public String getOrgancode() {
		return this.organcode;
	}

	public void setOrgancode(String organcode) {
		this.organcode = organcode;
	}

	public String getOrganalias() {
		return this.organalias;
	}

	public void setOrganalias(String organalias) {
		this.organalias = organalias;
	}

	public String getPostcode() {
		return this.postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Set getDeptments() {
		return this.deptments;
	}

	public void setDeptments(Set deptments) {
		this.deptments = deptments;
	}

}