package com.sxsihe.oxhide.resource.domain;

import java.util.ArrayList;
import java.util.List;

import com.sxsihe.oxhide.application.domain.Application;

public class ResourceSimply {
	private String resourcecode;
	private String resourcename;
	private String resourceid;
	private String resourcepid;
	private String displayPId;
	private String mobileico;
	private String remark;
	private String mobileurl;
	private String resourceurl;
	private String prompt;
	private Integer target;
	
	private String ico;
	private String bigico;
	private String selfclick;
	private String tabname;
	private Integer display;
	private Integer menutype;
	private String simplyname;
	private String largeico;
	private Application application;
	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}


	public String getDisplayAppId() {
		return displayAppId;
	}

	public void setDisplayAppId(String displayAppId) {
		this.displayAppId = displayAppId;
	}
	private String displayAppId;
	public String getLargeico() {
		return largeico;
	}

	public void setLargeico(String largeico) {
		this.largeico = largeico;
	}

	public Integer getDisplay() {
		return display;
	}

	public void setDisplay(Integer display) {
		this.display = display;
	}

	public Integer getMenutype() {
		return menutype;
	}

	public void setMenutype(Integer menutype) {
		this.menutype = menutype;
	}

	public String getSimplyname() {
		return simplyname;
	}

	public void setSimplyname(String simplyname) {
		this.simplyname = simplyname;
	}

	public String getIco() {
		return ico;
	}

	public void setIco(String ico) {
		this.ico = ico;
	}

	public String getBigico() {
		return bigico;
	}

	public void setBigico(String bigico) {
		this.bigico = bigico;
	}

	public String getSelfclick() {
		return selfclick;
	}

	public void setSelfclick(String selfclick) {
		this.selfclick = selfclick;
	}

	public String getTabname() {
		return tabname;
	}

	public void setTabname(String tabname) {
		this.tabname = tabname;
	}

	public ResourceSimply(){

	}
	
	public ResourceSimply(ResourceSimply simply){
		this.resourcecode = simply.getResourcecode();
		this.resourcename = simply.getResourcename();
		this.resourceid = simply.getResourceid();
		this.resourcepid = simply.getResourcepid();
		this.displayPId = simply.getDisplayPId();
		this.mobileico = simply.getMobileico();
		this.remark = simply.getRemark();
		this.mobileurl = simply.getMobileurl();
		this.resourceurl = simply.getResourceurl();
		this.prompt = simply.getPrompt();
		this.target = simply.getTarget();
		this.ico = simply.getIco();
		this.bigico = simply.getBigico();
		this.selfclick = simply.getSelfclick();
		this.tabname = simply.getTabname();
		this.display = simply.getDisplay();
		this.menutype = simply.getMenutype();
		this.simplyname = simply.getSimplyname();
		this.largeico = simply.getLargeico();
		this.displayAppId = simply.getDisplayAppId();
		this.application = simply.getApplication();
	}
	
	public Integer getTarget() {
		return target;
	}

	public void setTarget(Integer target) {
		this.target = target;
	}

	public String getPrompt() {
		return prompt;
	}
	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}
	public String getResourceurl() {
		return resourceurl;
	}
	public void setResourceurl(String resourceurl) {
		this.resourceurl = resourceurl;
	}
	public String getMobileurl() {
		return mobileurl;
	}
	public void setMobileurl(String mobileurl) {
		this.mobileurl = mobileurl;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getMobileico() {
		return mobileico;
	}
	public void setMobileico(String mobileico) {
		this.mobileico = mobileico;
	}
	public String getDisplayPId() {
		return displayPId;
	}
	public void setDisplayPId(String displayPId) {
		this.displayPId = displayPId;
	}
	public List<ResourceSimply> getResource() {
		return resource;
	}
	public void setResource(List<ResourceSimply> resource) {
		this.resource = resource;
	}
	private List<ResourceSimply> resource = new ArrayList<ResourceSimply>();
	public String getResourcepid() {
		return resourcepid;
	}
	public void setResourcepid(String resourcepid) {
		this.resourcepid = resourcepid;
	}
	public String getResourceid() {
		return resourceid;
	}
	public void setResourceid(String resourceid) {
		this.resourceid = resourceid;
	}
	public String getResourcecode() {
		return resourcecode;
	}
	public void setResourcecode(String resourcecode) {
		this.resourcecode = resourcecode;
	}
	public String getResourcename() {
		return resourcename;
	}
	public void setResourcename(String resourcename) {
		this.resourcename = resourcename;
	}
}
