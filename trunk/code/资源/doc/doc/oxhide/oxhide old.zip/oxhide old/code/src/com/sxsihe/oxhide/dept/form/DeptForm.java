package com.sxsihe.oxhide.dept.form;

import com.ite.oxhide.struts.form.BaseForm;
import com.sxsihe.oxhide.organ.domain.Organ;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dept.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:����
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class DeptForm extends BaseForm {
	/* deptid */
	private String deptid;

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getDeptid() {
		return this.deptid;
	}
	private String deptpid;
	private String deptpname;
	/* �������� */
	private String deptname;

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getDeptname() {
		return this.deptname;
	}

	/* ���ű��� */
	private String deptcode;

	public void setDeptcode(String deptcode) {
		this.deptcode = deptcode;
	}

	public String getDeptcode() {
		return this.deptcode;
	}

	/* ������ */
	private String areaid;

	public void setAreaid(String areaid) {
		this.areaid = areaid;
	}

	public String getAreaid() {
		return this.areaid;
	}

	/* ����� */
	private Integer orderno;

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	public Integer getOrderno() {
		return this.orderno;
	}

	/* remark */
	private String remark;

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRemark() {
		return this.remark;
	}

	/* isvalidation */
	private Integer isvalidation;

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	private String organid;
	private String organname;

	public String getOrganid() {
		return organid;
	}

	public void setOrganid(String organid) {
		this.organid = organid;
	}

	public String getOrganname() {
		return organname;
	}

	public void setOrganname(String organname) {
		this.organname = organname;
	}

	public String getDeptpid() {
		return deptpid;
	}

	public void setDeptpid(String deptpid) {
		this.deptpid = deptpid;
	}

	public String getDeptpname() {
		return deptpname;
	}

	public void setDeptpname(String deptpname) {
		this.deptpname = deptpname;
	}

}
