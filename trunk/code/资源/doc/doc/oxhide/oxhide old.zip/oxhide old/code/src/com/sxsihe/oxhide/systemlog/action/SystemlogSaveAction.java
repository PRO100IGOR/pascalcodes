package com.sxsihe.oxhide.systemlog.action;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.systemlog.domain.Systemlog;
import com.sxsihe.oxhide.systemlog.form.SystemlogForm;

/**
 *<p>Title:com.sxsihe.oxhide.systemlog.action.LogSaveAction</p>
 *<p>Description:SaveAction</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author 
 * @version 1.0
 * @date 2011-07-08
 *
 * @modify 
 * @date
 */
 
public class SystemlogSaveAction extends BaseSaveAction{
/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 * @param form
	 * @return
	 */	
	protected Serializable getPersisPo(ActionForm form,String type){
		HashMap map=new HashMap();
	    SystemlogForm vForm =(SystemlogForm)form;
	    Systemlog po ;
	    if(type.equals("add"))
	       po=new Systemlog();
	    else{
       String sid=vForm.getSid();
	       po=(Systemlog)service.findObjectBykey(sid);
	    }
	    po.setSid(vForm.getSid());
	    po.setOperateTime(vForm.getOperateTime());
	    po.setOperateIp(vForm.getOperateIp());
	    po.setOperatePerson(vForm.getOperatePerson());
	    po.setOperateEmp(vForm.getOperateEmp());
	    po.setOperateSys(vForm.getOperateSys());
	    po.setOperateContent(vForm.getOperateContent());
	    po.setRemark(vForm.getRemark());
	    po.setOperateModel(vForm.getOperateModel());
	    po.setOperateType(vForm.getOperateType());
     return po;
	}

/**
	 * ������ʵ��Ĺ���ʵ��
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form,
			HttpServletRequest request, String type) {
		HashMap map=new HashMap();
		Set list=new HashSet();
	}
	
}