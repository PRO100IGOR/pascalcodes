package com.sxsihe.utils.common;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import org.apache.commons.lang.StringUtils;

public class StrTool {
	public static String formatDate(Date date, String formatstr) {
		if ((date == null) || (formatstr == null))
			return null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(formatstr);
		return dateFormat.format(date);
	}

	public static String formatDate(Date date) {
		return formatDate(date, "yyyy-MM-dd");
	}

	public static String formatDateByNow() {
		return formatDate(new Date());
	}

	public static String formatTime(Date date) {
		return formatDate(date, "HH:mm:ss");
	}

	public static String formatDateTime(Date date) {
		return formatDate(date, "yyyy-MM-dd HH:mm");
	}

	public static Date parseDateTime(String strdate) throws ParseException {
		return parseDateTimeByFormatstr(strdate, "yyyy-MM-dd HH:mm");
	}

	public static Date parseDate(String strdate) throws ParseException {
		return parseDateTimeByFormatstr(strdate, "yyyy-MM-dd");
	}

	public static Date parseDateTimeByFormatstr(String strdate, String formatstr) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat(formatstr);
		return dateFormat.parse(strdate);
	}

	public static String formatNumber(double f, String pattern) {
		DecimalFormat num = new DecimalFormat(pattern);
		return num.format(f);
	}

	public static String formatMoney(double money) {
		return formatNumber(money, "#,##0.00");
	}

	public static String indexUpStr(String str) {
		if ((str == null) || (str.length() < 1)) {
			return str;
		}
		String tmstr = "";
		tmstr = str.substring(0, 1);
		tmstr = tmstr.toUpperCase();
		tmstr = tmstr + str.substring(1);
		return tmstr;
	}

	public static int[] toIntsByRegex(String str, String regex) {
		if ((str == null) || ("".equals(str.trim())))
			return null;
		String[] tms = str.split(regex);
		int[] tmi = new int[tms.length];
		for (int i = 0; i < tms.length; i++) {
			tmi[i] = Integer.parseInt(tms[i]);
		}
		return tmi;
	}

	public static int[] toInts(String str) {
		return toIntsByRegex(str, ",");
	}

	public static String parseFormattedNumber(String formattedNumber) {
		DecimalFormat num = new DecimalFormat();

		String parseString = "";
		try {
			parseString = formatNumber(Double.parseDouble(num.parse(formattedNumber).toString()), "#0.00");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return parseString;
	}

	public static String convertArrayToString(String[] arrayString) {
		String returnString = "";

		if (arrayString != null) {
			for (int i = 0; i < arrayString.length; i++) {
				if (StringUtils.isEmpty(returnString))
					returnString = returnString + arrayString[i];
				else {
					returnString = returnString + "," + arrayString[i];
				}
			}
		}
		return returnString;
	}

	public static String getFileExt(String filename) {
		String fileext = "";
		String tmfilename = filename;
		if (tmfilename != null) {
			int l = tmfilename.indexOf(".") + 1;
			if (l == 0) {
				return "";
			}
			int tml = l;
			while (tml != 0) {
				try {
					l = tml;
					tml = tmfilename.indexOf(".", tml) + 1;
				} catch (Exception e) {
					tml = 0;
				}
			}
			int length = tmfilename.length();
			if ((l <= length) && (l != 1))
				fileext = tmfilename.substring(l);
			else {
				fileext = "";
			}
		}
		return fileext;
	}

	public static String fillStrLength(String str, int length, String repair) {
		for (int i = str.length(); i < length; i++) {
			str = repair + str;
		}
		return str;
	}

	public static int strComp(String str1, String str2) {
		if ((str1 == null) || (str2 == null)) {
			return 0;
		}
		int str1Length = str1.length();
		int str2Length = str2.length();
		if (str2Length > str1Length)
			str1 = fillStrLength(str1, str2Length, "0");
		else if (str2Length < str1Length) {
			str1 = fillStrLength(str2, str1Length, "0");
		}
		int result = str1.compareTo(str2);
		if (result >= 1)
			result = 1;
		if (result <= -1)
			result = -1;
		return result;
	}

	public static long getMillis(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c.getTimeInMillis();
	}

	public static Date subDate(Date date, int day) {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(getMillis(date) - day * 24L * 3600L * 1000L);
		return c.getTime();
	}

	public static int getIntervalOfDate(String date1, String date2) throws ParseException {
		int interval = 0;

		Date dt1 = parseDate(date1);
		Date dt2 = parseDate(date2);

		interval = (int) (Math.abs(dt1.getTime() - dt2.getTime()) / 1000L / 60L / 60L / 24L);
		return interval;
	}

	public static int getDaysOfYear(int year) {
		int days = 0;

		Calendar c = new GregorianCalendar();
		c.set(1, year);
		for (int i = 0; i < 12; i++) {
			c.set(2, i);
			days += c.getActualMaximum(5);
		}

		return days;
	}

	public static int getWeeksOfYear(int year) {
		int weeks = 0;

		Calendar c = new GregorianCalendar();
		c.set(1, year);
		weeks = c.getActualMaximum(3);

		return weeks;
	}

	public static int getWeekIndexOfYear(String date) throws ParseException {
		int index = -1;

		Calendar cal = Calendar.getInstance();
		cal.setTime(parseDate(date));

		index = cal.get(3);

		return index;
	}

	public static String getWeekDay(String date) throws ParseException {
		String[] days = { "����һ", "���ڶ�", "������", "������", "������", "������", "������" };
		Calendar cal = Calendar.getInstance();
		cal.setTime(parseDate(date));
		int index = cal.get(7);
		return days[(index - 1)];
	}

	public static String[] getFirstEndDayOfDate(String date) throws ParseException {
		Calendar cal = Calendar.getInstance();
		Date curdate = parseDate(date);
		cal.setTime(curdate);
		int index = cal.get(7);
		Date startdate = subDate(curdate, index - 1);
		Date enddate = addDate(curdate, 7 - index);
		String[] dates = new String[2];
		dates[0] = formatDate(startdate);
		dates[1] = formatDate(enddate);
		return dates;
	}

	public static Date addDate(Date date, int day) {
		Calendar c = Calendar.getInstance();
		c.setTimeInMillis(getMillis(date) + day * 24L * 3600L * 1000L);
		return c.getTime();
	}
}