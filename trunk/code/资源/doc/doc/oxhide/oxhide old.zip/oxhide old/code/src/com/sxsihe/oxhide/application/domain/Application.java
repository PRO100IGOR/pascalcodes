package com.sxsihe.oxhide.application.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Application implements Serializable {
	private String appid;
	private String appname;
	private String appurl;
	private String appindex;
	private String apptitle;
	private Set resources = new HashSet(0);
	private Set rolesapp = new HashSet(0);
	private Set unmobiles = new HashSet(0);
	private String ico;
	private String bigico;
	private Integer orderno;
	private String simplyname;
	private String largeico;
	private String remark;
	private String appurlw;
	private String applekey;
	private String androidkf;
	private String applekf;
	private String timer;
	private String timeenable;
	private String times;
	public String getTimer() {
		return timer;
	}

	public void setTimer(String timer) {
		this.timer = timer;
	}

	public String getTimeenable() {
		return timeenable;
	}

	public void setTimeenable(String timeenable) {
		this.timeenable = timeenable;
	}

	public String getTimes() {
		return times;
	}

	public void setTimes(String times) {
		this.times = times;
	}

	public String getAndroidkf() {
		return androidkf;
	}

	public void setAndroidkf(String androidkf) {
		this.androidkf = androidkf;
	}

	public String getApplekf() {
		return applekf;
	}

	public void setApplekf(String applekf) {
		this.applekf = applekf;
	}

	private String androidkey;
	private Set tokens = new HashSet(0);
	private String appcode;

	public String getApplekey() {
		return this.applekey;
	}

	public void setApplekey(String applekey) {
		this.applekey = applekey;
	}

	public String getAndroidkey() {
		return this.androidkey;
	}

	public void setAndroidkey(String androidkey) {
		this.androidkey = androidkey;
	}

	public Set getTokens() {
		return this.tokens;
	}

	public void setTokens(Set tokens) {
		this.tokens = tokens;
	}

	public String getAppcode() {
		return this.appcode;
	}

	public void setAppcode(String appcode) {
		this.appcode = appcode;
	}

	public Integer getOrderno() {
		return this.orderno;
	}

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	public String getBigico() {
		return this.bigico;
	}

	public void setBigico(String bigico) {
		this.bigico = bigico;
	}

	public String getIco() {
		return this.ico;
	}

	public void setIco(String ico) {
		this.ico = ico;
	}

	public Set getRolesapp() {
		return this.rolesapp;
	}

	public void setRolesapp(Set rolesapp) {
		this.rolesapp = rolesapp;
	}

	public Application() {
	}

	public Application(String appname, String appurl, String appindex, String apptitle) {
		this.appname = appname;
		this.appurl = appurl;
		this.appindex = appindex;
		this.apptitle = apptitle;
	}

	public String getAppid() {
		return this.appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getAppname() {
		return this.appname;
	}

	public void setAppname(String appname) {
		this.appname = appname;
	}

	public String getAppurl() {
		return this.appurl;
	}

	public void setAppurl(String appurl) {
		this.appurl = appurl;
	}

	public String getAppindex() {
		return this.appindex;
	}

	public void setAppindex(String appindex) {
		this.appindex = appindex;
	}

	public String getApptitle() {
		return this.apptitle;
	}

	public void setApptitle(String apptitle) {
		this.apptitle = apptitle;
	}

	public Set getResources() {
		return this.resources;
	}

	public void setResources(Set resources) {
		this.resources = resources;
	}

	public String getSimplyname() {
		return this.simplyname;
	}

	public void setSimplyname(String simplyname) {
		this.simplyname = simplyname;
	}

	public String getLargeico() {
		return this.largeico;
	}

	public void setLargeico(String largeico) {
		this.largeico = largeico;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAppurlw() {
		return this.appurlw;
	}

	public void setAppurlw(String appurlw) {
		this.appurlw = appurlw;
	}

	public Set getUnmobiles() {
		return unmobiles;
	}

	public void setUnmobiles(Set unmobiles) {
		this.unmobiles = unmobiles;
	}
}