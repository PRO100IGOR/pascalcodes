package com.sxsihe.coder.dataid.dao;
import com.ite.oxhide.persistence.BaseDAOIface;
/**
 *
 * <p>Title:com.sxsihe.coder.dataid.dao.DataidDAO</p>
 * <p>Description:dataid���ݲ�ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-03
 * @modify
 * @date
 */
 public interface DataidDAO extends BaseDAOIface{
 }
