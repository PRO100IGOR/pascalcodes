package com.sxsihe.oxhide.server.post;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.service.BaseServiceIface;
import com.sxsihe.oxhide.post.domain.Posts;
import com.sxsihe.utils.common.DataUtils;

public class PostServerImpl implements PostServer {
	private BaseServiceIface service;

	public BaseServiceIface getService() {
		return service;
	}

	public void setService(BaseServiceIface service) {
		this.service = service;
	}

	public Posts findObjectBykey(String key) {
		Object object = service.findObjectBykey(key);
		try {
			return (Posts) DataUtils.copyPoJo(object, Posts.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public List<Posts> findObjectsByCondition(ConditionBlock block, Map sortMap) {
		List list  = service.findObjectsByCondition(DataUtils.changeCode(block), sortMap);
		return DataUtils.copyPoJos(list, Posts.class);
	}

	public List<Posts> getAll() {
		List list =  service.getAll();
		return DataUtils.copyPoJos(list, Posts.class);
	}

}
