package com.sxsihe.oxhide.server.systemlog;
import com.sxsihe.oxhide.systemlog.domain.*;
public abstract interface SystemlogServer {
	/**
	 * ��־���ͣ�id
	 * @param type
	 * @param id
	 * @return
	 */
	public void add(Systemlog log) ;
	
}
