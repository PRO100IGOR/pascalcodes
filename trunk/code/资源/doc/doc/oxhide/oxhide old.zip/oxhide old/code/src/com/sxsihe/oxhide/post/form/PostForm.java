package com.sxsihe.oxhide.post.form;

import com.ite.oxhide.struts.form.BaseForm;
import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.oxhide.organ.domain.Organ;

/**
 * <p>
 * Title:com.sxsihe.oxhide.post.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:��λ
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class PostForm extends BaseForm {
	private String postpid;
	private String postpname;
	
	/* postid */
	private String postid;

	public void setPostid(String postid) {
		this.postid = postid;
	}

	public String getPostid() {
		return this.postid;
	}

	/* ��λ���� */
	private String postname;

	public void setPostname(String postname) {
		this.postname = postname;
	}

	public String getPostname() {
		return this.postname;
	}

	/* ��λ���� */
	private String postcode;

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getPostcode() {
		return this.postcode;
	}

	/* ����� */
	private Integer orderno;

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	public Integer getOrderno() {
		return this.orderno;
	}

	/* isvalidation */
	private Integer isvalidation;

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	/* ��ע */
	private String remark;

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRemark() {
		return this.remark;
	}

	private String deptid;
	private String organid;
	private String organname;
	private String deptname;

	public String getDeptid() {
		return deptid;
	}

	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}

	public String getOrganid() {
		return organid;
	}

	public void setOrganid(String organid) {
		this.organid = organid;
	}

	public String getOrganname() {
		return organname;
	}

	public void setOrganname(String organname) {
		this.organname = organname;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getPostpid() {
		return postpid;
	}

	public void setPostpid(String postpid) {
		this.postpid = postpid;
	}

	public String getPostpname() {
		return postpname;
	}

	public void setPostpname(String postpname) {
		this.postpname = postpname;
	}

}
