package com.sxsihe.oxhide.workhistory.dao.hibernateImpl;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.workhistory.domain.Workhistory;
import com.sxsihe.oxhide.workhistory.dao.WorkhistoryDAO;
/**
 *<p>Title:com.sxsihe.oxhide.workhistory.dao.WorkhistoryDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-08-11
 *
 * @modify
 * @date
 */
public class WorkhistoryDAOImpl extends BaseDAOImpl implements WorkhistoryDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Workhistory.class;
	   }
	
}