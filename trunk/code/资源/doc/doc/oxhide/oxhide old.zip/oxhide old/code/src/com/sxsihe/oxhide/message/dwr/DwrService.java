package com.sxsihe.oxhide.message.dwr;

import java.util.Date;
import java.util.List;

import org.directwebremoting.Browser;

import net.sf.json.JSONObject;

import com.ite.oxhide.common.util.StringUtils;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.login.service.SessionHouse;
import com.sxsihe.oxhide.message.MessageBaseServiceImpl;
import com.sxsihe.oxhide.message.Sender;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.utils.common.DateUtils;
import com.sxsihe.utils.common.RandomGUID;

public class DwrService extends MessageBaseServiceImpl {

	private SessionHouse sessionHouse;

	public SessionHouse getSessionHouse() {
		return sessionHouse;
	}

	public void setSessionHouse(SessionHouse sessionHouse) {
		this.sessionHouse = sessionHouse;
	}

	// Ĭ���أ�����
	public String sendData(JSONObject param, Application application, Resources resources, List users) {
		int count = 0;
		int max = users.size();
		for (int i = 0; i < users.size(); i++) {
			Ssousers ssousers = (Ssousers) users.get(i);
			Sender sender = new Sender();
			sender.setId(RandomGUID.getGUID().replaceAll("-", ""));
			sender.setAppcode(application.getAppcode());
			sender.setHref(param.getString("href", ""));
			if (param.has("map")) {
				JSONObject map = param.getJSONObject("map");
				if (sender.getHref().indexOf("?") == -1)
					sender.setHref(sender.getHref() + "?1=1");
				for (Object o : map.keySet()) {
					sender.setHref(sender.getHref() + "&" + o + "=" + map.getString(o + ""));
				}
			}
			sender.setMessage(param.getString("info"));
			sender.setDateTime(DateUtils.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
			sender.setUserid(ssousers.getUserid());
			sender.setAppid(application.getAppid());
			sender.setBtn(param.getString("btn", "true"));
			sender.setIsnote(param.getString("isnote", "no"));
			sender.setTypes(param.getString("msgtype","ϵͳ��Ϣ"));
			if (resources != null)
				sender.setRid(resources.getResourceid());
			sender.setTarget(param.getString("target", "1"));
			if(!param.getString("state").equals("off")){
				this.getSenderManger().addDwr(sender);
			}else{
				max --;
			}
			List<String> list = sessionHouse.getScriptSessionByUserId(ssousers.getUserid());
			if (!list.isEmpty()) {
				JSONObject object = new JSONObject();
				count++;
				object.put("message", param.get("info"));
				object.put("href", sender.getHref());
				object.put("btn", sender.getBtn());
				object.put("time", sender.getDateTime());
				object.put("appid", application.getAppid());
				object.put("id", sender.getId());
				object.put("isnote", sender.getIsnote());
				object.put("type", sender.getTypes());
				if (resources != null)
					object.put("rid", resources.getResourceid());
				object.put("target", sender.getTarget());
				for (String id : list) {
					Browser.withSession(id, new DwrMethodHandel("messTool.add", new Object[] { object }));
				}
			}
		}
		return count + "���û����ͳɹ���" + (max - count) + "���û�����";
	}

	public void sendDataForPerson(String userid) {
		List senders = this.getSenderManger().getDwrsByUserId(userid);
		List<String> list = sessionHouse.getScriptSessionByUserId(userid);
		if (list.isEmpty())
			return;
		for (int i = 0; i < senders.size(); i++) {
			Sender sender = (Sender) senders.get(i);
			JSONObject object = new JSONObject();
			object.put("message", sender.getMessage());
			object.put("href", sender.getHref());
			object.put("time", sender.getDateTime());
			object.put("appid", sender.getAppid());
			object.put("id", sender.getId());
			object.put("rid", sender.getRid());
			object.put("target", sender.getTarget());
			object.put("isnote", sender.getIsnote());
			object.put("btn", sender.getBtn());
			object.put("type", sender.getTypes());
			for (String id : list) {
				Browser.withSession(id, new DwrMethodHandel("messTool.add", new Object[] { object }));
			}
		}
	}

	public List getSenders(String appcode) {
		List senders = this.getSenderManger().getDwrsByAppcode(appcode);
		for (int i = 0; i < senders.size(); i++) {
			Sender sender = (Sender) senders.get(i);
			sender.setSsousers((Ssousers) this.getSsouserService().findObjectBykey(sender.getUserid()));
		}
		return senders;
	}

	public Sender getSenderById(String id) {
		return this.getSenderManger().getDwrById(id);
	}

	public void delSender(String id) {
		this.getSenderManger().delDwr(id);
	}

	public void delAllSender(String appcode) {
		this.getSenderManger().delAllDwr(appcode);
	}

	public void delSenderByUserId(String userid) {
		this.getSenderManger().delDwrByUserId(userid);
	}

}
