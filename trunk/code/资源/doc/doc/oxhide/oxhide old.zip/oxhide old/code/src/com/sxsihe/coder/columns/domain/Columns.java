package com.sxsihe.coder.columns.domain;

import java.util.HashSet;
import java.util.Set;

import com.sxsihe.coder.tables.domain.Tables;


public class Columns implements java.io.Serializable {

	// Fields

	private String cid;
	private String cname;
	private String rule;
	private String showtype;
	private String orderno;
	private String isshow;
	private String width;
	private String ccode;
	private String data;
	private String getdata;
	private String ismust;
	private String ismain;
	public String getIsmain() {
		return ismain;
	}

	public void setIsmain(String ismain) {
		this.ismain = ismain;
	}

	public String getIsmust() {
		return ismust;
	}

	public void setIsmust(String ismust) {
		this.ismust = ismust;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getGetdata() {
		return getdata;
	}

	public void setGetdata(String getdata) {
		this.getdata = getdata;
	}

	private Set sels = new HashSet(0);
	private Set datas = new HashSet(0);
	private Tables tables;
	private String timer;

	public String getTimer() {
		return timer;
	}

	public void setTimer(String timer) {
		this.timer = timer;
	}

	public Set getDatas() {
		return datas;
	}

	public void setDatas(Set datas) {
		this.datas = datas;
	}


	// Constructors

	public Set getSels() {
		return sels;
	}

	public void setSels(Set sels) {
		this.sels = sels;
	}

	public Tables getTables() {
		return tables;
	}

	public void setTables(Tables tables) {
		this.tables = tables;
	}

	/** default constructor */
	public Columns() {
	}

	// Property accessors

	public String getCid() {
		return this.cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getRule() {
		return this.rule;
	}

	public void setRule(String rule) {
		this.rule = rule;
	}


	public String getShowtype() {
		return this.showtype;
	}

	public void setShowtype(String showtype) {
		this.showtype = showtype;
	}

	public String getOrderno() {
		return this.orderno;
	}

	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}

	public String getIsshow() {
		return this.isshow;
	}

	public void setIsshow(String isshow) {
		this.isshow = isshow;
	}

	public String getWidth() {
		return this.width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getCcode() {
		return this.ccode;
	}

	public void setCcode(String ccode) {
		this.ccode = ccode;
	}

}