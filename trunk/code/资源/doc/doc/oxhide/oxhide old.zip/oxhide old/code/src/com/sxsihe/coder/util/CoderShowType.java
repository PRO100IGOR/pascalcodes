package com.sxsihe.coder.util;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.tagext.BodyTagSupport;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.dictionarycontent.domain.Dictionarycontent;
import com.sxsihe.oxhide.server.dictionary.DictionaryServer;

/**
 * �ؼ���ʾtld
 *
 * @author Administrator
 *
 */
public class CoderShowType extends BodyTagSupport {
	private int type;
	private String value;
	private String id;
	private String timer;
	private String data;
	private int getdata;
	private boolean iscontrol = true;
	public boolean isIscontrol() {
		return iscontrol;
	}

	public void setIscontrol(boolean iscontrol) {
		this.iscontrol = iscontrol;
	}

	public boolean isNeedCom() {
		return needCom;
	}

	public void setNeedCom(boolean needCom) {
		this.needCom = needCom;
	}

	private boolean needCom = true;
	public int getGetdata() {
		return getdata;
	}

	public void setGetdata(int getdata) {
		this.getdata = getdata;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}


	public String getTimer() {
		return timer;
	}

	public void setTimer(String timer) {
		this.timer = timer;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int doStartTag() {
		try {
			if (iscontrol) {
				switch (type) {
				case 1:
					this.pageContext.getOut().print("<input c='form' type='text' size='28' maxlength='200' value='" + value + "' id='" + id + "' name='" + id + "' />");
					break;
				case 3:
					this.pageContext.getOut().print(
							needCom ?
							("<input readonly='readonly' c='form' onclick='WdatePicker({dateFmt:\\\"" + timer + "\\\"})'  type='text' size='28' maxlength='32' value='" + value + "' id='" + id + "' name='" + id + "' />"):
							("<input readonly='readonly' c='form' onclick='WdatePicker({dateFmt:\"" + timer + "\"})'  type='text' size='28' maxlength='32' value='" + value + "' id='" + id + "' name='" + id + "' />")
					);
					break;
				case 2:
					StringBuilder builder = new StringBuilder();
					builder.append("<select c='form' value='" + value + "' id='" + id + "' name='" + id + "' >");
					switch (getdata) {
					case 2:
						DictionaryServer dictionaryServer = (DictionaryServer) SpringContextUtil.getBean("dictionaryClient");
						List list = dictionaryServer.getDicAsList(data);
						builder.append("<option>��ѡ��</option>");
						for (int i = 0; i < list.size(); i++) {
							Dictionarycontent dictionarycontent = (Dictionarycontent) list.get(i);
							builder.append("<option  value='" + dictionarycontent.getDcode() + "'>" + dictionarycontent.getDcvalue() + "</option>");
						}
						break;
					case 3:
						String[] opts = data.split("#");
						String[] keys = opts[0].split(",");
						String[] values = opts[1].split(",");
						builder.append("<option>��ѡ��</option>");
						for (int i = 0; i < values.length; i++) {
							builder.append("<option  value='" + keys[i] + "'>" + values[i] + "</option>");
						}
						break;
					}
					builder.append("</select>");
					this.pageContext.getOut().print(builder.toString());
					break;
				}
			}else{

				switch (type) {
				case 1:
					this.pageContext.getOut().print(value);
					break;
				case 3:
					this.pageContext.getOut().print(value);
					break;
				case 2:
					switch (getdata) {
					case 2:
						this.pageContext.getOut().print(value);
						break;
					case 3:
						String[] opts = data.split("#");
						String[] keys = opts[0].split(",");
						String[] values = opts[1].split(",");
						for (int i = 0; i < values.length; i++) {
							if (value.equals(keys[i])) {
								this.pageContext.getOut().print(values[i]);
								break;
							}
						}
						break;
					}
					break;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return SKIP_PAGE;
	}
}
