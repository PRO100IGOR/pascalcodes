package com.sxsihe.oxhide.systemlog.dao;

import com.ite.oxhide.persistence.BaseDAOIface;

/**
 *<p>Title:com.sxsihe.oxhide.systemlog.dao.LogDAO</p>
 *<p>Description:DAO</p>
 *<p>Copyright: Copyright (c) 2009</p>
 *<p>Company: ITE</p>
 * @author x.IE-IT
 * @version 1.0
 * @date 2011-07-08
 *
 * @modify
 * @date
 */
public interface SystemlogDAO extends BaseDAOIface{
}