package com.sxsihe.oxhide.dept.action;

import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.*;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.oxhide.dept.form.DeptForm;
import com.sxsihe.oxhide.dept.service.DeptService;
import com.sxsihe.oxhide.organ.domain.Organ;
import com.sxsihe.utils.system.SystemLogHelper;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dept.action.DeptSaveAction
 * </p>
 * <p>
 * Description:����SaveAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */

public class DeptSaveAction extends BaseSaveAction {
	/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 * 
	 * @param form
	 * @return
	 */
	protected Serializable getPersisPo(ActionForm form, String type) {
		HashMap map = new HashMap();
		DeptForm vForm = (DeptForm) form;
		Deptment po;
		if (type.equals("add"))
			po = new Deptment();
		else {
			String deptid = vForm.getDeptid();
			po = (Deptment) service.findObjectBykey(deptid);
		}
		po.setDeptid(vForm.getDeptid());
		po.setDeptname(vForm.getDeptname());
		po.setDeptcode(vForm.getDeptcode());
		po.setAreaid(vForm.getAreaid());
		po.setRemark(vForm.getRemark());
		Organ organ = new Organ();
		organ.setOrganid(vForm.getOrganid());
		po.setOrgan(organ);
		po.setIsvalidation(vForm.getIsvalidation());
		if (type.equals("add")) {
			po.setOrderno(((DeptService) this.getService()).getOrderNo(po.getOrgan().getOrganid()));
		} else {
			po.setOrderno(vForm.getOrderno());
		}
		if (StringUtils.isNotEmpty(vForm.getDeptpid())) {
			Deptment deptment = new Deptment();
			deptment.setDeptid(vForm.getDeptpid());
			po.setDeptment(deptment);
		}
		return po;
	}

	/**
	 * ������ʵ��Ĺ���ʵ��
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form, HttpServletRequest request, String type) {
		HashMap map = new HashMap();
		Set list = new HashSet();
	}

	/**
	 * �������� zcc Apr 22, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward saveOrder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		String[] array = request.getParameterValues("deptid");
		for (int i = 0; i < array.length; i++) {
			Deptment deptment = (Deptment) this.getService().findObjectBykey(array[i]);
			deptment.setOrderno(i + 1);
			this.getService().update(deptment);
		}
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	    boolean is = repeatSubmit(mapping, form, request);
	    if (is) {
	      return mapping.findForward("showAdd");
	    }
	    Serializable po = getPersisPo(form, "add");
	    setPersistAssociatePo(po, form, request, "add");
	    getService().add(po);
	    String submit = request.getParameter("isSaveAndAdd");
	    request.setAttribute("isSaveAndAdd", Boolean.valueOf(true));
	    SystemLogHelper.addLog(request, "����һ����¼", "1", "");
		DeptForm vForm = (DeptForm) form;
	    if ("true".equals(submit))
	    {
	      saveToken(request);
	      String uri = request.getRequestURI();
			uri = uri.replaceAll("Save", "Show").replaceAll(request.getContextPath(), "") + "?action=showAdd&organid=" + vForm.getOrganid();

	      return new ActionForward(uri);
	    }
	    return new ActionForward("/core/success/opSuccess.jsp");
	}
}