package com.sxsihe.oxhide.systemlog.action;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.extremecomponents.table.limit.Limit;

import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import com.sxsihe.oxhide.systemlog.domain.Systemlog;
import com.sxsihe.oxhide.systemlog.form.SystemlogConditionForm;
import com.sxsihe.oxhide.systemlog.form.SystemlogForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.systemlog.action.LogShowAction
 * </p>
 * <p>
 * Description:showAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author
 * @version 1.0
 * @date 2011-07-08
 * 
 * @modify
 * @date
 */
public class SystemlogShowAction extends BaseShowAction {
	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}


	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}


	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof SystemlogForm) {
				Systemlog pos = (Systemlog) po;
				SystemlogForm vForm = (SystemlogForm) form;
				BeanUtils.setProperty(vForm, "sid", PropertyUtils.getProperty(pos, "sid"));
				BeanUtils.setProperty(vForm, "operateTime", PropertyUtils.getProperty(pos, "operateTime"));
				BeanUtils.setProperty(vForm, "operateIp", PropertyUtils.getProperty(pos, "operateIp"));
				BeanUtils.setProperty(vForm, "operatePerson", PropertyUtils.getProperty(pos, "operatePerson"));
				BeanUtils.setProperty(vForm, "operateEmp", PropertyUtils.getProperty(pos, "operateEmp"));
				BeanUtils.setProperty(vForm, "operateSys", PropertyUtils.getProperty(pos, "operateSys"));
				BeanUtils.setProperty(vForm, "operateContent", PropertyUtils.getProperty(pos, "operateContent"));
				BeanUtils.setProperty(vForm, "remark", PropertyUtils.getProperty(pos, "remark"));
				BeanUtils.setProperty(vForm, "operateModel", PropertyUtils.getProperty(pos, "operateModel"));
				BeanUtils.setProperty(vForm, "operateType", PropertyUtils.getProperty(pos, "operateType"));
			}
		} catch (Exception e) {
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		SystemlogConditionForm vcForm = (SystemlogConditionForm) conditionForm;
		// ��֤�������Ĳ�����Ϊ��
		block.and(new ConditionLeaf("operatePerson", "coperatePerson", ConditionLeaf.LIKE, vcForm.getOperatePerson(), true));
		block.and(new ConditionLeaf("operateTime", "operateTimea", ConditionLeaf.GE, vcForm.getOperateTimea(), true));
		block.and(new ConditionLeaf("operateTime", "operateTimeb", ConditionLeaf.LE, vcForm.getOperateTimeb(), true));
		block.and(new ConditionLeaf("operateIp", "coperateIp", ConditionLeaf.LIKE, vcForm.getOperateIp(), true));
		block.and(new ConditionLeaf("operateEmp", "coperateEmp", ConditionLeaf.LIKE, vcForm.getOperateEmp(), true));
		block.and(new ConditionLeaf("operateSys", "coperateSys", ConditionLeaf.LIKE, vcForm.getOperateSys(), true));
		block.and(new ConditionLeaf("operateContent", "coperateContent", ConditionLeaf.LIKE, vcForm.getOperateContent(), true));
		block.and(new ConditionLeaf("operateModel", "coperateModel", ConditionLeaf.LIKE, vcForm.getOperateModel(), true));
		block.and(new ConditionLeaf("operateType", "coperateType", ConditionLeaf.EQ, vcForm.getOperateModel(), true));
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {

		// ConditionBlock�൱��HQL���
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		// ���еı�����������ConditionForm���
		SystemlogConditionForm vcForm = (SystemlogConditionForm) conditionForm;
		// and�ж��Ƿ�Ϊ�յķ���
		block.and(new ConditionLeaf("operatePerson", "coperatePerson", ConditionLeaf.LIKE, vcForm.getOperatePerson(), true));
		block.and(new ConditionLeaf("operateTime", "operateTimea", ConditionLeaf.GE, vcForm.getOperateTimea(), true));
		block.and(new ConditionLeaf("operateTime", "operateTimeb", ConditionLeaf.LE, vcForm.getOperateTimeb(), true));
		block.and(new ConditionLeaf("operateIp", "coperateIp", ConditionLeaf.LIKE, vcForm.getOperateIp(), true));
		block.and(new ConditionLeaf("operateEmp", "coperateEmp", ConditionLeaf.LIKE, vcForm.getOperateEmp(), true));
		block.and(new ConditionLeaf("operateSys", "coperateSys", ConditionLeaf.LIKE, vcForm.getOperateSys(), true));
		block.and(new ConditionLeaf("operateContent", "coperateContent", ConditionLeaf.LIKE, vcForm.getOperateContent(), true));
		block.and(new ConditionLeaf("operateModel", "coperateModel", ConditionLeaf.LIKE, vcForm.getOperateModel(), true));
		block.and(new ConditionLeaf("operateType", "coperateType", ConditionLeaf.EQ, vcForm.getOperateModel(), true));
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		sortMap.put("operateTime", false);
		sortMap.put("operateSys", true);
		List list = null;
		if (limit != null)
			list = getService().findObjectsByCondition(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed());
		else
			list = getService().findObjectsByCondition(block, sortMap);
		return list;
	}

}
