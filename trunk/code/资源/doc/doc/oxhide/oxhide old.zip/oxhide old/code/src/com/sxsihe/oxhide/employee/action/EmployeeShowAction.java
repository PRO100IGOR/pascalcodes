package com.sxsihe.oxhide.employee.action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ite.oxhide.common.util.StringUtils;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.menu.MenuNode;

import org.springframework.util.FileCopyUtils;
import org.tdeccn.table.client.ActionHelper;
import java.io.*;

import com.ite.oxhide.persistence.*;

import org.extremecomponents.table.context.Context;
import org.extremecomponents.table.context.HttpServletRequestContext;
import org.extremecomponents.table.limit.Limit;
import org.extremecomponents.table.limit.LimitFactory;
import org.extremecomponents.table.limit.TableLimit;
import org.extremecomponents.table.limit.TableLimitFactory;

import com.ite.oxhide.common.util.*;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import org.apache.commons.beanutils.PropertyUtils;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.employee.form.EmployeeForm;
import com.sxsihe.oxhide.employee.form.EmployeeConditionForm;
import com.sxsihe.oxhide.employee.service.EmployeeService;
import com.sxsihe.oxhide.organ.service.OrganService;
import com.sxsihe.oxhide.schema.service.SchemaService;
import com.sxsihe.utils.common.DateUtils;
import com.sxsihe.utils.system.SystemLogHelper;

/**
 * <p>
 * Title:com.sxsihe.oxhide.employee.action.
 * EmployeeShowAction
 * </p>
 * <p>
 * Description:Ա��showAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class EmployeeShowAction extends BaseShowAction {
	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		request.setAttribute("hasPhoto", false);
		request.setAttribute("hasPen", false);
	}

	/**
	 * ��ʾ�����б� zcc Apr 22, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showOrderList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		saveToken(request);
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("posts.postid", "cpostid", ConditionLeaf.EQ, request.getParameter("postid"), false));
		Map sortMap = new HashMap();
		sortMap.put("orderno", true);
		List list = getService().findObjectsByCondition(block, sortMap);
		request.setAttribute("totalRows", list.size());
		request.setAttribute("list", list);
		return mapping.findForward("showOrderList");
	}

	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		EmployeeForm vForm = (EmployeeForm) form;
		Employee po = (Employee) getService().findObjectBykey(vForm.getEmployeeid());
		request.setAttribute("educationhistory", po.getEducationhistory());
		request.setAttribute("workhistory", po.getWorkhistory());
		request.setAttribute("hasPhoto", po.getPhoto() != null);
		request.setAttribute("hasPen", po.getPen() != null);
	}


	protected void nextShowView(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable po) throws BaseException {
		Employee epo = (Employee) po;
		if (StringUtils.isNotEmpty(epo.getBirthday())) {
			request.setAttribute("age", DateUtils.betweenYear(DateUtils.getCurDate(), epo.getBirthday()));
		}
		request.setAttribute("count", epo.getWorkhistory().size());
		request.setAttribute("hasPhoto", epo.getPhoto() != null);
		request.setAttribute("hasPen", epo.getPen() != null);
	}

	/**
	 * ��ʾ���ҳ��
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showReview(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Employee po = (Employee) getService().findObjectBykey(id);
		request.setAttribute("view", po);
		if (StringUtils.isNotEmpty(po.getBirthday())) {
			request.setAttribute("age", DateUtils.betweenYear(DateUtils.getCurDate(), po.getBirthday()));
		}
		request.setAttribute("count", po.getWorkhistory().size());
		request.setAttribute("hasPhoto", po.getPhoto() != null);
		request.setAttribute("hasPen", po.getPen() != null);
		return mapping.findForward("showReview");
	}

	// /**
	// * ��������
	// * @param mapping
	// * @param form
	// * @param request
	// * @param response
	// * @return
	// * @throws BaseException
	// */
	// public ActionForward
	// showWorkChange(ActionMapping mapping,
	// ActionForm
	// form, HttpServletRequest request,
	// HttpServletResponse response) throws
	// BaseException {
	// String id = request.getParameter("id");
	// Employee po = (Employee)
	// getService().findObjectBykey(id);
	// request.setAttribute("view", po);
	// return
	// mapping.findForward("showWorkChange");
	// }
	/**
	 * ��ʾ��Ƭ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showPhoto(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Employee po = (Employee) getService().findObjectBykey(id);
		if (po != null && po.getPhoto() != null) {
			ByteArrayInputStream is = null;
			try {
				is = new java.io.ByteArrayInputStream(po.getPhoto().getBytes(1, (int) po.getPhoto().length()));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (is != null) {
				try {
					FileCopyUtils.copy(is, response.getOutputStream());
				} catch (IOException e) {
					// TODO Auto-generated catch
					// block
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	/**
	 * ��ʾ����ǩ��
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showPen(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Employee po = (Employee) getService().findObjectBykey(id);
		if (po != null && po.getPen() != null) {
			ByteArrayInputStream is = null;
			try {
				is = new java.io.ByteArrayInputStream(po.getPen().getBytes(1, (int) po.getPen().length()));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (is != null) {
				try {
					FileCopyUtils.copy(is, response.getOutputStream());
				} catch (IOException e) {
					// TODO Auto-generated catch
					// block
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof EmployeeForm) {
				Employee pos = (Employee) po;
				EmployeeForm vForm = (EmployeeForm) form;
				BeanUtils.setProperty(vForm, "employeeid", PropertyUtils.getProperty(pos, "employeeid"));
				BeanUtils.setProperty(vForm, "employeecode", PropertyUtils.getProperty(pos, "employeecode"));
				BeanUtils.setProperty(vForm, "employeename", PropertyUtils.getProperty(pos, "employeename"));
				BeanUtils.setProperty(vForm, "sex", PropertyUtils.getProperty(pos, "sex"));
				BeanUtils.setProperty(vForm, "birthday", PropertyUtils.getProperty(pos, "birthday"));
				BeanUtils.setProperty(vForm, "isvalidation", PropertyUtils.getProperty(pos, "isvalidation"));
				BeanUtils.setProperty(vForm, "remark", PropertyUtils.getProperty(pos, "remark"));
				BeanUtils.setProperty(vForm, "orderno", PropertyUtils.getProperty(pos, "orderno"));
				BeanUtils.setProperty(vForm, "nation", PropertyUtils.getProperty(pos, "nation"));
				BeanUtils.setProperty(vForm, "workstarttime", PropertyUtils.getProperty(pos, "workstarttime"));
				BeanUtils.setProperty(vForm, "outlook", PropertyUtils.getProperty(pos, "outlook"));
				BeanUtils.setProperty(vForm, "origin", PropertyUtils.getProperty(pos, "origin"));
				BeanUtils.setProperty(vForm, "title", PropertyUtils.getProperty(pos, "title"));
				BeanUtils.setProperty(vForm, "education", PropertyUtils.getProperty(pos, "education"));
				BeanUtils.setProperty(vForm, "professional", PropertyUtils.getProperty(pos, "professional"));
				BeanUtils.setProperty(vForm, "titleid", PropertyUtils.getProperty(pos, "titleid"));
				BeanUtils.setProperty(vForm, "accounttype", PropertyUtils.getProperty(pos, "accounttype"));
				BeanUtils.setProperty(vForm, "account", PropertyUtils.getProperty(pos, "account"));
				BeanUtils.setProperty(vForm, "identity", PropertyUtils.getProperty(pos, "identity"));
				BeanUtils.setProperty(vForm, "identityplace", PropertyUtils.getProperty(pos, "identityplace"));
				BeanUtils.setProperty(vForm, "email", PropertyUtils.getProperty(pos, "email"));
				BeanUtils.setProperty(vForm, "phone", PropertyUtils.getProperty(pos, "phone"));
				BeanUtils.setProperty(vForm, "professionallife", PropertyUtils.getProperty(pos, "professionallife"));
				BeanUtils.setProperty(vForm, "professionaltype", PropertyUtils.getProperty(pos, "professionaltype"));
				BeanUtils.setProperty(vForm, "worktime", PropertyUtils.getProperty(pos, "worktime"));
				BeanUtils.setProperty(vForm, "nowworkbegin", PropertyUtils.getProperty(pos, "nowworkbegin"));
				BeanUtils.setProperty(vForm, "nowworkend", PropertyUtils.getProperty(pos, "nowworkend"));
				BeanUtils.setProperty(vForm, "worktype", PropertyUtils.getProperty(pos, "worktype"));
				BeanUtils.setProperty(vForm, "otherprofessional", PropertyUtils.getProperty(pos, "otherprofessional"));
				BeanUtils.setProperty(vForm, "otherprofessionalid", PropertyUtils.getProperty(pos, "otherprofessionalid"));
				BeanUtils.setProperty(vForm, "national", PropertyUtils.getProperty(pos, "national"));
				BeanUtils.setProperty(vForm, "association", PropertyUtils.getProperty(pos, "association"));
				BeanUtils.setProperty(vForm, "traintime", PropertyUtils.getProperty(pos, "traintime"));
				BeanUtils.setProperty(vForm, "reportscores", PropertyUtils.getProperty(pos, "reportscores"));
				BeanUtils.setProperty(vForm, "orderno", PropertyUtils.getProperty(pos, "orderno"));
				BeanUtils.setProperty(vForm, "otherprofessionalidtime", PropertyUtils.getProperty(pos, "otherprofessionalidtime"));
				BeanUtils.setProperty(vForm, "mainplace", PropertyUtils.getProperty(pos, "mainplace"));
				BeanUtils.setProperty(vForm, "blood", PropertyUtils.getProperty(pos, "blood"));
				BeanUtils.setProperty(vForm, "marry", PropertyUtils.getProperty(pos, "marry"));
				BeanUtils.setProperty(vForm, "mobile", PropertyUtils.getProperty(pos, "mobile"));
				BeanUtils.setProperty(vForm, "dutydate", PropertyUtils.getProperty(pos, "dutydate"));
				BeanUtils.setProperty(vForm, "cardid", PropertyUtils.getProperty(pos, "cardid"));
				BeanUtils.setProperty(vForm, "emailPassword", PropertyUtils.getProperty(pos, "emailPassword"));
				if (pos.getPosts() != null) {
					vForm.setPostid(pos.getPosts().getPostid());
					vForm.setPostname(pos.getPosts().getPostname());
					vForm.setOrganname(pos.getPosts().getDeptment().getOrgan().getOrganname());
					vForm.setDeptname(pos.getPosts().getDeptment().getDeptname());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		EmployeeConditionForm vcForm = (EmployeeConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("employeename", "cemployeename", ConditionLeaf.LIKE, vcForm.getCemployeename(), true));
			if (vcForm.getCsex() != null && vcForm.getCsex() != -1) {
				block.and(new ConditionLeaf("sex", "csex", ConditionLeaf.EQ, vcForm.getCsex(), false));
			}
			block.and(new ConditionLeaf("birthday", "cbirthdaya", ConditionLeaf.GE, vcForm.getCbirthdaya(), true));
			block.and(new ConditionLeaf("birthday", "cbirthdayb", ConditionLeaf.LE, vcForm.getCbirthdayb(), true));
			block.and(new ConditionLeaf("posts.postid", "cpostid", ConditionLeaf.EQ, vcForm.getPostid(), true));
			block.and(new ConditionLeaf("posts.deptment.deptid", "cdeptid", ConditionLeaf.EQ, vcForm.getDeptid(), true));
			block.and(new ConditionLeaf("posts.deptment.organ.organid", "corganid", ConditionLeaf.EQ, vcForm.getOrganid(), true));
		}
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		EmployeeConditionForm vcForm = (EmployeeConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("employeename", "cemployeename", ConditionLeaf.LIKE, vcForm.getCemployeename(), true));
			if (vcForm.getCsex() != null && vcForm.getCsex() != -1) {
				block.and(new ConditionLeaf("sex", "csex", ConditionLeaf.EQ, vcForm.getCsex(), false));
			}
			block.and(new ConditionLeaf("birthday", "cbirthdaya", ConditionLeaf.GE, vcForm.getCbirthdaya(), true));
			block.and(new ConditionLeaf("birthday", "cbirthdayb", ConditionLeaf.LE, vcForm.getCbirthdayb(), true));
			block.and(new ConditionLeaf("posts.postid", "cpostid", ConditionLeaf.EQ, vcForm.getPostid(), true));
			block.and(new ConditionLeaf("posts.deptment.deptid", "cdeptid", ConditionLeaf.EQ, vcForm.getDeptid(), true));
			block.and(new ConditionLeaf("posts.deptment.organ.organid", "corganid", ConditionLeaf.EQ, vcForm.getOrganid(), true));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		List list = null;
		if (limit != null)
			list = getService().findObjectsByCondition(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed());
		else
			list = getService().findObjectsByCondition(block, sortMap);

		return list;
	}

	/**
	 * �߼���ѯ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 *             Administrator
	 *             com.sxsihe.oxhide.
	 *             employee.action
	 *             EmployeeShowAction.java
	 *             2012����7:06:55 oxhide
	 */
	public ActionForward showAdvList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		saveToken(request);
		Context context = new HttpServletRequestContext(request);
		LimitFactory limitFactory = new TableLimitFactory(context);
		Limit limit = new TableLimit(limitFactory);
		EmployeeService employeeService = (EmployeeService) this.getService();
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		EmployeeConditionForm vcForm = (EmployeeConditionForm) form;
		if (vcForm != null) {
			if (StringUtils.isNotEmpty(request.getParameter("adv"))) {
				vcForm.setCuserCount(1);
			}
			block.and(new ConditionLeaf("postid", "cpostid", ConditionLeaf.EQ, vcForm.getPostid(), true));
			block.and(new ConditionLeaf("userCount", "cuserCount", ConditionLeaf.LT, vcForm.getCuserCount(), true));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		sortMap.put("employeename", true);
		try {
			int totalRows;
			Object tmpObject = request.getAttribute("totalRows");
			if (tmpObject != null) {
				totalRows = ((Integer) tmpObject).intValue();
			} else {
				totalRows = employeeService.getEmpAdvCount(block);
				request.setAttribute("totalRows", totalRows);
			}
			limit.setRowAttributes(totalRows, getRowSize());
			List list = employeeService.getEmpAdv(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed());
			request.setAttribute("list", list);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mapping.findForward("showList");
	}

}
