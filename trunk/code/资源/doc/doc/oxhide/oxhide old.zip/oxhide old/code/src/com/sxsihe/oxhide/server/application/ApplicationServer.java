package com.sxsihe.oxhide.server.application;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.sxsihe.oxhide.application.domain.Application;

public abstract interface ApplicationServer {
	/**
	 * �����б�����
	 * 
	 * @param block
	 * @param sortMap
	 * @return
	 */
	public List<Application> findObjectsByCondition(ConditionBlock block, Map sortMap);

	/**
	 * ����������ѯ����
	 * 
	 * @param key
	 * @return
	 */
	public Application findObjectBykey(String key);

	/**
	 * ��ѯȫ��
	 * 
	 * @return
	 */
	public List<Application> getAll();
}
