package com.sxsihe.oxhide.employee.domain;

import java.sql.Blob;
import java.util.HashSet;
import java.util.Set;

import com.sxsihe.oxhide.post.domain.Posts;

/**
 * Employee entity.
 *
 * @author MyEclipse Persistence Tools
 */

public class Employee implements java.io.Serializable {

	// Fields

	private String employeeid;
	private Posts posts;
	private String employeecode;
	private String employeename;
	private Integer sex;
	private String birthday;
	private Integer isvalidation;
	private String remark;
	private Integer orderno;
	private String nation;
	private String workstarttime;
	private String outlook;
	private String origin;
	private String title;
	private String education;
	private String professional;
	private String titleid;
	private String accounttype;
	private String account;
	private String identity;
	private String identityplace;
	private String email;
	private String phone;
	private String professionallife;
	private String professionaltype;
	private String worktime;
	private String nowworkbegin;
	private String nowworkend;
	private String worktype;
	private String otherprofessional;
	private String otherprofessionalid;
	private String national;
	private String association;
	private String traintime;
	private String reportscores;
	private String otherprofessionalidtime;
	private String emailPassword;
	private String mainplace;
	private String blood;
	private String marry;
	private String mobile;
	private String dutydate;
	private String cardid;
	private int userCount;
	private boolean hasPhoto;
	private boolean hasPen;
	private Blob photo;
	private Blob pen;
	public boolean isHasPhoto() {
		return hasPhoto;
	}

	public void setHasPhoto(boolean hasPhoto) {
		this.hasPhoto = hasPhoto;
	}

	public boolean isHasPen() {
		return hasPen;
	}

	public void setHasPen(boolean hasPen) {
		this.hasPen = hasPen;
	}

	private Set educationhistory = new HashSet(0);
	private Set workhistory = new HashSet(0);
	private Set ssouserses = new HashSet(0);
	private Set unmobiles = new HashSet(0);
	// Constructors
	public String getEmailPassword() {
		return emailPassword;
	}

	public void setEmailPassword(String emailPassword) {
		this.emailPassword = emailPassword;
	}
	public int getUserCount() {
		return userCount;
	}

	public void setUserCount(int userCount) {
		this.userCount = userCount;
	}

	public String getMainplace() {
		return mainplace;
	}

	public void setMainplace(String mainplace) {
		this.mainplace = mainplace;
	}

	public String getBlood() {
		return blood;
	}

	public void setBlood(String blood) {
		this.blood = blood;
	}

	public String getMarry() {
		return marry;
	}

	public void setMarry(String marry) {
		this.marry = marry;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getDutydate() {
		return dutydate;
	}

	public void setDutydate(String dutydate) {
		this.dutydate = dutydate;
	}

	public String getCardid() {
		return cardid;
	}

	public void setCardid(String cardid) {
		this.cardid = cardid;
	}




	public Set getUnmobiles() {
		return unmobiles;
	}

	public void setUnmobiles(Set unmobiles) {
		this.unmobiles = unmobiles;
	}

	/** default constructor */
	public Employee() {
	}

	/** full constructor */
	public Employee(String postid, String employeecode, String employeename, Integer sex, String birthday, Integer isvalidation, String remark, Integer orderno, String nation, String workstarttime,
			String outlook, String origin, String title, String education, String professional, String titleid, String accounttype, String account, String identity, String identityplace,
			String email, String phone, String professionallife, String professionaltype, String worktime, String nowworkbegin, String nowworkend, String worktype, String otherprofessional,
			String otherprofessionalid, String national, String association, String traintime, String reportscores, Blob photo, Blob pen) {
		this.employeecode = employeecode;
		this.employeename = employeename;
		this.sex = sex;
		this.birthday = birthday;
		this.isvalidation = isvalidation;
		this.remark = remark;
		this.orderno = orderno;
		this.nation = nation;
		this.workstarttime = workstarttime;
		this.outlook = outlook;
		this.origin = origin;
		this.title = title;
		this.education = education;
		this.professional = professional;
		this.titleid = titleid;
		this.accounttype = accounttype;
		this.account = account;
		this.identity = identity;
		this.identityplace = identityplace;
		this.email = email;
		this.phone = phone;
		this.professionallife = professionallife;
		this.professionaltype = professionaltype;
		this.worktime = worktime;
		this.nowworkbegin = nowworkbegin;
		this.nowworkend = nowworkend;
		this.worktype = worktype;
		this.otherprofessional = otherprofessional;
		this.otherprofessionalid = otherprofessionalid;
		this.national = national;
		this.association = association;
		this.traintime = traintime;
		this.reportscores = reportscores;
		this.photo = photo;
		this.pen = pen;
	}

	// Property accessors

	public String getEmployeeid() {
		return this.employeeid;
	}

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}

	public Posts getPosts() {
		return posts;
	}

	public void setPosts(Posts posts) {
		this.posts = posts;
	}

	public String getEmployeecode() {
		return this.employeecode;
	}

	public void setEmployeecode(String employeecode) {
		this.employeecode = employeecode;
	}

	public String getEmployeename() {
		return this.employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public Integer getSex() {
		return this.sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public String getBirthday() {
		return this.birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getOrderno() {
		return this.orderno;
	}

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}

	public String getNation() {
		return this.nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getWorkstarttime() {
		return this.workstarttime;
	}

	public void setWorkstarttime(String workstarttime) {
		this.workstarttime = workstarttime;
	}

	public String getOutlook() {
		return this.outlook;
	}

	public void setOutlook(String outlook) {
		this.outlook = outlook;
	}

	public String getOrigin() {
		return this.origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEducation() {
		return this.education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getProfessional() {
		return this.professional;
	}

	public void setProfessional(String professional) {
		this.professional = professional;
	}

	public String getTitleid() {
		return this.titleid;
	}

	public void setTitleid(String titleid) {
		this.titleid = titleid;
	}

	public String getAccounttype() {
		return this.accounttype;
	}

	public void setAccounttype(String accounttype) {
		this.accounttype = accounttype;
	}

	public String getAccount() {
		return this.account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getIdentity() {
		return this.identity;
	}

	public void setIdentity(String identity) {
		this.identity = identity;
	}

	public String getIdentityplace() {
		return this.identityplace;
	}

	public void setIdentityplace(String identityplace) {
		this.identityplace = identityplace;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getProfessionallife() {
		return this.professionallife;
	}

	public void setProfessionallife(String professionallife) {
		this.professionallife = professionallife;
	}

	public String getProfessionaltype() {
		return this.professionaltype;
	}

	public void setProfessionaltype(String professionaltype) {
		this.professionaltype = professionaltype;
	}

	public String getWorktime() {
		return this.worktime;
	}

	public void setWorktime(String worktime) {
		this.worktime = worktime;
	}

	public String getNowworkbegin() {
		return this.nowworkbegin;
	}

	public void setNowworkbegin(String nowworkbegin) {
		this.nowworkbegin = nowworkbegin;
	}

	public String getNowworkend() {
		return this.nowworkend;
	}

	public void setNowworkend(String nowworkend) {
		this.nowworkend = nowworkend;
	}

	public String getWorktype() {
		return this.worktype;
	}

	public void setWorktype(String worktype) {
		this.worktype = worktype;
	}

	public String getOtherprofessional() {
		return this.otherprofessional;
	}

	public void setOtherprofessional(String otherprofessional) {
		this.otherprofessional = otherprofessional;
	}

	public String getOtherprofessionalid() {
		return this.otherprofessionalid;
	}

	public void setOtherprofessionalid(String otherprofessionalid) {
		this.otherprofessionalid = otherprofessionalid;
	}

	public String getNational() {
		return this.national;
	}

	public void setNational(String national) {
		this.national = national;
	}

	public String getAssociation() {
		return this.association;
	}

	public void setAssociation(String association) {
		this.association = association;
	}

	public String getTraintime() {
		return this.traintime;
	}

	public void setTraintime(String traintime) {
		this.traintime = traintime;
	}

	public String getReportscores() {
		return this.reportscores;
	}

	public void setReportscores(String reportscores) {
		this.reportscores = reportscores;
	}


	public Blob getPhoto() {
		return photo;
	}

	public void setPhoto(Blob photo) {
		this.hasPhoto = photo != null;
		this.photo = photo;
	}

	public Blob getPen() {
		return pen;
	}

	public void setPen(Blob pen) {
		this.hasPen = pen != null;
		this.pen = pen;
	}

	public Set getEducationhistory() {
		return educationhistory;
	}

	public void setEducationhistory(Set educationhistory) {
		this.educationhistory = educationhistory;
	}

	public Set getWorkhistory() {
		return workhistory;
	}

	public void setWorkhistory(Set workhistory) {
		this.workhistory = workhistory;
	}

	public Set getSsouserses() {
		return ssouserses;
	}

	public void setSsouserses(Set ssouserses) {
		this.ssouserses = ssouserses;
	}

	public String getOtherprofessionalidtime() {
		return otherprofessionalidtime;
	}

	public void setOtherprofessionalidtime(String otherprofessionalidtime) {
		this.otherprofessionalidtime = otherprofessionalidtime;
	}

}