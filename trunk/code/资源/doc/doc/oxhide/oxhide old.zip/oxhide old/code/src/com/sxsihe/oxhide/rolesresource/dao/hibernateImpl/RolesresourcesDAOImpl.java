package com.sxsihe.oxhide.rolesresource.dao.hibernateImpl;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.rolesresource.domain.Rolesresources;
import com.sxsihe.oxhide.rolesresource.dao.RolesresourcesDAO;
/**
 *<p>Title:com.sxsihe.oxhide.rolesresource.dao.RolesresourcesDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class RolesresourcesDAOImpl extends BaseDAOImpl implements RolesresourcesDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Rolesresources.class;
	   }
}