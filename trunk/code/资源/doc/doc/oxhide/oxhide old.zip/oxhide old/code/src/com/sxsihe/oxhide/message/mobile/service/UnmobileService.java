package com.sxsihe.oxhide.message.mobile.service;
import com.ite.oxhide.service.BaseServiceIface;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.message.mobile.service.UnmobileService</p>
 * <p>Description:unmobile����ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-12-26
 * @modify
 * @date
 */
 public interface UnmobileService extends BaseServiceIface{
 }
	