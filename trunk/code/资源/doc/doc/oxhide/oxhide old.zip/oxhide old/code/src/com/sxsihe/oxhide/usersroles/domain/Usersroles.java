package com.sxsihe.oxhide.usersroles.domain;

import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;

/**
 * Usersroles entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Usersroles implements java.io.Serializable {

	// Fields

	private String userroleid;
	private Ssousers ssousers;
	private Ssoroles ssoroles;

	// Constructors

	/** default constructor */
	public Usersroles() {
	}

	/** full constructor */
	public Usersroles(Ssousers ssousers, Ssoroles ssoroles) {
		this.ssousers = ssousers;
		this.ssoroles = ssoroles;
	}

	// Property accessors

	public String getUserroleid() {
		return this.userroleid;
	}

	public void setUserroleid(String userroleid) {
		this.userroleid = userroleid;
	}

	public Ssousers getSsousers() {
		return this.ssousers;
	}

	public void setSsousers(Ssousers ssousers) {
		this.ssousers = ssousers;
	}

	public Ssoroles getSsoroles() {
		return this.ssoroles;
	}

	public void setSsoroles(Ssoroles ssoroles) {
		this.ssoroles = ssoroles;
	}

}