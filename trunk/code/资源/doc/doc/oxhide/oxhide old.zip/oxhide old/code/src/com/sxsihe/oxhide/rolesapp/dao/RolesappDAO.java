package com.sxsihe.oxhide.rolesapp.dao;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOIface;

/**
 *<p>Title:com.sxsihe.oxhide.rolesapp.dao.RolesappDAO</p>
 *<p>Description:DAO</p>
 *<p>Copyright: Copyright (c) 2009</p>
 *<p>Company: ITE</p>
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 *
 * @modify
 * @date
 */
public interface RolesappDAO extends BaseDAOIface{
}