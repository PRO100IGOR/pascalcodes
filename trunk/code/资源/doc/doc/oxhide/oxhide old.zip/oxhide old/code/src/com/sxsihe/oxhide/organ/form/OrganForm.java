package com.sxsihe.oxhide.organ.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.organ.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:����
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class OrganForm extends BaseForm {
	/* organid */
	private String organid;

	public void setOrganid(String organid) {
		this.organid = organid;
	}

	public String getOrganid() {
		return this.organid;
	}

	/* �������� */
	private String organname;

	public void setOrganname(String organname) {
		this.organname = organname;
	}

	public String getOrganname() {
		return this.organname;
	}

	/* ������� */
	private String areaid;

	public void setAreaid(String areaid) {
		this.areaid = areaid;
	}

	public String getAreaid() {
		return this.areaid;
	}

	/* �������� */
	private String organcode;

	public void setOrgancode(String organcode) {
		this.organcode = organcode;
	}

	public String getOrgancode() {
		return this.organcode;
	}

	/* ���� */
	private String organalias;

	public void setOrganalias(String organalias) {
		this.organalias = organalias;
	}

	public String getOrganalias() {
		return this.organalias;
	}

	/* ��ַ */
	private String address;

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddress() {
		return this.address;
	}

	/* �绰 */
	private String telephone;

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getTelephone() {
		return this.telephone;
	}

	/* ���� */
	private String fax;

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getFax() {
		return this.fax;
	}

	/* isvalidation */
	private Integer isvalidation;

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	/* ��ע */
	private String remark;

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRemark() {
		return this.remark;
	}

	private String organpid;
	private String organpname;

	public String getOrganpid() {
		return organpid;
	}

	public void setOrganpid(String organpid) {
		this.organpid = organpid;
	}

	public String getOrganpname() {
		return organpname;
	}

	public void setOrganpname(String organpname) {
		this.organpname = organpname;
	}
}
