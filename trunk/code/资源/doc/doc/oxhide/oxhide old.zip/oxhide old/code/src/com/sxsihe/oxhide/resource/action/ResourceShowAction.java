package com.sxsihe.oxhide.resource.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ite.oxhide.common.util.StringUtils;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.ite.oxhide.struts.menu.MenuNode;
import org.tdeccn.table.client.ActionHelper;
import java.io.*;
import com.ite.oxhide.persistence.*;

import org.extremecomponents.table.limit.Limit;
import com.ite.oxhide.common.util.*;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import org.apache.commons.beanutils.PropertyUtils;

import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.application.service.ApplicationService;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.resource.form.ResourceForm;
import com.sxsihe.oxhide.resource.form.ResourceConditionForm;
import com.sxsihe.oxhide.rolesresource.domain.Rolesresources;

/**
 * <p>
 * Title:com.sxsihe.oxhide.resource.form.action.ResourceShowAction
 * </p>
 * <p>
 * Description:��ԴshowAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 * 
 * @modify
 * @date
 */
public class ResourceShowAction extends BaseShowAction {
	private ApplicationService applicationService;

	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}


	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof ResourceForm) {
				Resources pos = (Resources) po;
				ResourceForm vForm = (ResourceForm) form;
				BeanUtils.setProperty(vForm, "resourceid", PropertyUtils.getProperty(pos, "resourceid"));
				BeanUtils.setProperty(vForm, "resourcename", PropertyUtils.getProperty(pos, "resourcename"));
				BeanUtils.setProperty(vForm, "resourceurl", PropertyUtils.getProperty(pos, "resourceurl"));
				BeanUtils.setProperty(vForm, "isvalidation", PropertyUtils.getProperty(pos, "isvalidation"));
				BeanUtils.setProperty(vForm, "resourcecode", PropertyUtils.getProperty(pos, "resourcecode"));
				BeanUtils.setProperty(vForm, "ico", PropertyUtils.getProperty(pos, "ico"));
				BeanUtils.setProperty(vForm, "bigico", PropertyUtils.getProperty(pos, "bigico"));
				BeanUtils.setProperty(vForm, "selfclick", PropertyUtils.getProperty(pos, "selfclick"));
				BeanUtils.setProperty(vForm, "tabname", PropertyUtils.getProperty(pos, "tabname"));
				BeanUtils.setProperty(vForm, "orderno", PropertyUtils.getProperty(pos, "orderno"));
				BeanUtils.setProperty(vForm, "display", PropertyUtils.getProperty(pos, "display"));
				BeanUtils.setProperty(vForm, "target", PropertyUtils.getProperty(pos, "target"));
				BeanUtils.setProperty(vForm, "menutype", PropertyUtils.getProperty(pos, "menutype"));
				BeanUtils.setProperty(vForm, "largeico", PropertyUtils.getProperty(pos, "largeico"));
				BeanUtils.setProperty(vForm, "simplyname", PropertyUtils.getProperty(pos, "simplyname"));
				BeanUtils.setProperty(vForm, "remark", PropertyUtils.getProperty(pos, "remark"));
				BeanUtils.setProperty(vForm, "prompt", PropertyUtils.getProperty(pos, "prompt"));
				BeanUtils.setProperty(vForm, "mobileico", PropertyUtils.getProperty(pos, "mobileico"));
				BeanUtils.setProperty(vForm, "mobileurl", PropertyUtils.getProperty(pos, "mobileurl"));
				if (pos.getApplication() != null) {
					vForm.setAppid(pos.getApplication().getAppid());
					vForm.setAppname(pos.getApplication().getAppname());
				}
				if (pos.getResourcesp() != null) {
					vForm.setResourcepid(pos.getResourcesp().getResourceid());
					vForm.setResourcepname(pos.getResourcesp().getResourcename());
				}
				if (StringUtils.isNotEmpty(pos.getDisplayAppId())) {
					vForm.setDisplayAppId(pos.getDisplayAppId());
					vForm.setDisplayAppName(((Application) (applicationService.findObjectBykey(pos.getDisplayAppId()))).getAppname());
				}
				if (StringUtils.isNotEmpty(pos.getDisplayPId())) {
					vForm.setDisplayPId(pos.getDisplayPId());
					vForm.setDisplayPName(((Resources) (getService().findObjectBykey(pos.getDisplayPId()))).getResourcename());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		ResourceConditionForm vcForm = (ResourceConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("resourcename", "cresourcename", ConditionLeaf.LIKE, vcForm.getCresourcename(), true));
			if (vcForm.getCresourcetype() != null && vcForm.getCresourcetype() != -1) {
				block.and(new ConditionLeaf("resourcetype", "cresourcetype", ConditionLeaf.EQ, vcForm.getCresourcetype(), false));
			}
			block.and(new ConditionLeaf("resourcesp.resourceid", "cresourceid", ConditionLeaf.EQ, vcForm.getParentrid(), true));
			block.and(new ConditionLeaf("application.appid", "cappid", ConditionLeaf.EQ, vcForm.getAppid(), false));
		}
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		ResourceConditionForm vcForm = (ResourceConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("resourcename", "cresourcename", ConditionLeaf.LIKE, vcForm.getCresourcename(), true));
			if (vcForm.getCresourcetype() != null && vcForm.getCresourcetype() != -1) {
				block.and(new ConditionLeaf("resourcetype", "cresourcetype", ConditionLeaf.EQ, vcForm.getCresourcetype(), false));
			}
			block.and(new ConditionLeaf("resourcesp.resourceid", "cresourceid", ConditionLeaf.EQ, vcForm.getParentrid(), true));
			block.and(new ConditionLeaf("application.appid", "cappid", ConditionLeaf.EQ, vcForm.getAppid(), false));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		sortMap.put("orderno", true);
		List list = getService().findObjectsByCondition(block, sortMap);
		return list;
	}

	/**
	 * ��ʾ�����б� zcc Apr 22, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showOrderList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		saveToken(request);
		ConditionBlock block = new ConditionBlock();
		Map sortMap = new HashMap();
		sortMap.put("orderno", true);
		if (StringUtils.isEmpty(request.getParameter("parentrid"))) {
			ConditionBlock blockor = new ConditionBlock();
			blockor.or(new ConditionLeaf("displayPId", "cresourceid1", ConditionLeaf.EQ, null, false));
			blockor.or(new ConditionLeaf("displayPId", "cresourceid1", ConditionLeaf.EQ, "", false));
			block.and(blockor);
		} else {
			block.and(new ConditionLeaf("displayPId", "cresourceid", ConditionLeaf.EQ, request.getParameter("parentrid"), false));
		}

		block.and(new ConditionLeaf("displayAppId", "cappid", ConditionLeaf.EQ, request.getParameter("appid"), false));
		List list = getService().findObjectsByCondition(block, sortMap);
		request.setAttribute("totalRows", list.size());
		request.setAttribute("list", list);
		return mapping.findForward("showOrderList");
	}

	public ApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(ApplicationService applicationService) {
		this.applicationService = applicationService;
	}

}
