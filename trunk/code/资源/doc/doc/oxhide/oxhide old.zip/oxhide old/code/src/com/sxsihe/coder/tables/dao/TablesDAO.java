package com.sxsihe.coder.tables.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;

import com.ite.oxhide.persistence.BaseDAOIface;
import com.sxsihe.coder.columns.domain.Columns;
import com.sxsihe.coder.tables.domain.SimplyLeaf;

/**
 * 
 * <p>
 * Title:com.sxsihe.oxhide.coder.tables.dao.TablesDAO
 * </p>
 * <p>
 * Description:tables���ݲ�ӿ�
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Company: �ĺ�
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-10-30
 * @modify
 * @date
 */
public interface TablesDAO extends BaseDAOIface {
	/**
	 * ��֤�����Ƿ��Ѿ�������������ͼռ��
	 * 
	 * @Title: TablesDAOImpl.java
	 * @Package com.sxsihe.coder.tables.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-5 ����10:53:51
	 * @version V1.0
	 */
	public boolean checkTableName(String tableName);

	/**
	 * ִ�з��ݵȵ�sql���
	 * 
	 * @Title: TablesDAOImpl.java
	 * @Package com.sxsihe.coder.tables.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-5 ����11:39:25
	 * @version V1.0
	 */
	public void execSql(String sql);

	/**
	 * ��ѯ��¼����
	 * 
	 * @Title: TablesDAOImpl.java
	 * @Package com.sxsihe.coder.tables.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-5 ����03:46:23
	 * @version V1.0
	 */
	public int getCountByCondition(String tableCode, List<SimplyLeaf> leafs);

	/**
	 * ��ҳ��ѯ����
	 * 
	 * @Title: TablesDAOImpl.java
	 * @Package com.sxsihe.coder.tables.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-5 ����03:46:44
	 * @version V1.0
	 */
	public List<Map> findObjectByCondition(String tableCode, List<SimplyLeaf> leafs, List<Columns> cols, int pageSize, int pageNow);

	public JSONObject getDataById(String tid, String dtid);
}
