package com.sxsihe.oxhide.login.action;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSON;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.spring.SpringContextUtil;

import com.sxsihe.accessories.Accessories;
import com.sxsihe.accessories.AccessoriesService;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.employee.service.EmployeeService;
import com.sxsihe.oxhide.login.domain.UserSession;
import com.sxsihe.oxhide.login.service.SessionHouse;
import com.sxsihe.oxhide.message.dwr.DwrService;

import com.sxsihe.oxhide.schema.domain.TSchema;
import com.sxsihe.oxhide.schema.service.SchemaService;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.oxhide.ssouser.service.SsouserService;
import com.sxsihe.utils.aes.AES;
import com.sxsihe.utils.system.NetUnit;
import com.sxsihe.utils.system.SystemLogHelper;
import com.sxsihe.utils.common.DateUtils;

public class LoginAction extends DispatchAction {


	/**
	 * ��ȡ��¼����
	 * 
	 * @return Administrator
	 *         com.sxsihe.oxhide.login.action
	 *         LoginAction.java 2012����9:03:37
	 *         oxhide
	 */
	public static String getLoginSize() {
		Properties prop = new Properties();
		try {
			String path = LoginAction.class.getResource("/config.properties").getPath().replaceAll("%20", " ");
			FileInputStream fis = new FileInputStream(path);
			prop.load(fis);
			String size = prop.getProperty("config.login.size");
			if (size == null)
				size = "1";
			return size;
		} catch (Exception e) {
		}
		return "0";
	}

	private EmployeeService employeeService;

	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	private SsouserService ssouserService;

	public SsouserService getSsouserService() {
		return ssouserService;
	}

	public void setSsouserService(SsouserService ssouserService) {
		this.ssouserService = ssouserService;
	}

	private AccessoriesService accessService;
	private SessionHouse sessionHouse;

	public SessionHouse getSessionHouse() {
		return sessionHouse;
	}

	public void setSessionHouse(SessionHouse sessionHouse) {
		this.sessionHouse = sessionHouse;
	}

	/**
	 * ����֤�û���¼
	 * 
	 * @param userName
	 * @param passWord
	 * @return
	 */
	public boolean checkUser(String userName, String passWord) {
		JSONObject object = new JSONObject();
		object.put("username", userName);
		object.put("password", passWord);
		boolean result = false;
		try {
			result = !ssouserService.login(object.toString(),null).containsKey("message");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * �ƶ���¼
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 *             Administrator
	 *             com.sxsihe.oxhide.login.action
	 *             LoginAction.java 2012����9:04:03
	 *             oxhide
	 */
	private ActionForward loginMobile(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			String data = request.getParameter("data");
			String callback = request.getParameter("callback");
			if (StringUtils.isEmpty(data)) {
				return null;
			}
			response.setCharacterEncoding("utf-8");
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("ip", NetUnit.getIpAddr(request));
			jsonObject.put("id", request.getSession().getId());
			jsonObject.put("time", request.getSession().getCreationTime());
			data = ssouserService.login(data,jsonObject).toString();
			if (StringUtils.isNotEmpty(callback)) {
				response.getWriter().write(callback + "(" + data + ")");
			}else{
				response.getWriter().write(data);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
	
	/**
	 * IP��ȡ����
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 * Administrator
	 * com.sxsihe.oxhide.login.action
	 * LoginAction.java
	 * 2012����4:22:14
	 * oxhide
	 */
	public ActionForward url(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String callback = request.getParameter("callback");
		response.setCharacterEncoding("utf-8");
		if (StringUtils.isNotEmpty(callback)) {
			response.getWriter().write(callback + "(" + NetUnit.getIpAddr(request) + ")");
		}else{
			response.getWriter().write(NetUnit.getIpAddr(request));
		}
		return null;
	}
	
	/**
	 * ��ʾ�����ҷ�����Ϣ
	 * 
	 * @Title: LoginAction.java
	 * @Package com.sxsihe.oxhide.login.action
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-12-18 ����12:05:40
	 * @version V1.0
	 */
	public ActionForward showDes(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		UserSession userSession = (UserSession) request.getSession().getAttribute("USERSESSION");
		if (userSession == null) {
			return new ActionForward("/core/exception/sessionTimeOut.jsp");
		}
		DwrService dwrService = (DwrService) SpringContextUtil.getBean("dwr");
		dwrService.sendDataForPerson(userSession.getUserid());
		JSONArray list = ssouserService.getDesRes(userSession.getUserid(), userSession.getIp());
		request.setAttribute("res", list);
		return mapping.findForward("showDes");
	}

	/**
	 * ��½
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward login(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		if (StringUtils.isNotEmpty(request.getParameter("mobile"))) {
			return loginMobile(mapping, form, request, response);
		}
		try {
			/*��ȡ�û���Ϣ��ʼ*/
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			String ip = NetUnit.getIpAddr(request);
			List<Ssousers> ssouserArr = new ArrayList<Ssousers>();
			HttpSession session = request.getSession();
			UserSession userSession = "nopass".equals(request.getParameter("logintype")) ? ssouserService.getUserByNameNotPass(username, ssouserArr) : ssouserService.getUserByName(username, password,ssouserArr);
			if (userSession == null) {
				request.setAttribute("error", "�û������������!");
				return new ActionForward("/core/exception/baseException.jsp");
			}
			/*��ȡ�û���Ϣ����*/
			
			
			/* �ǵ����¼��ָ��ϵͳid */
			String appid = request.getParameter("appid");
			String appcode = request.getParameter("appcode");
			/* �ǵ����¼��ָ��ϵͳid */
			
			/* ��ȡϵͳ��ʼ */
			JSONArray apps = ssouserService.getApps(userSession.getUserid(), ip, appid, appcode);
			if (apps.size() == 0) {
				request.setAttribute("error", "�����ʵ�ϵͳ������!");
				return new ActionForward("/core/exception/baseException.jsp");
			}
			/* ��ȡϵͳ����*/
			
			
			/* ��ȡ��һ��ϵͳ����Դ��ʼ */
			JSONArray res = ssouserService.getResourcesByUserAndApp(apps.getJSONObject(0).getString("appid"), userSession.getUserid(), ip);
			if (res.isEmpty()) {
				request.setAttribute("error", "���û�û�з���ϵͳ���κ�Ȩ��!");
				return mapping.findForward("loginError");
			}
			/* ��ȡ��һ��ϵͳ����Դ����  */
			
			
			/* ��ȡ��ݲ˵���ʼ */
			JSONArray quick = ssouserService.getQuickResourcesByUser(userSession.getUserid(), ip);
			/* ��ȡ��ݲ˵�����  */
			
			
			/* �û���Ϣ���俪ʼ  */
			String id = session.getId();
			userSession.setId(id);
			userSession.setCreateTime(session.getCreationTime());
			userSession.setLoginTime(DateUtils.getCurDate());
			userSession.setIp(ip);
			if (userSession.getIssingel()) {
				UserSession temp = sessionHouse.getUserSessionByUserid(userSession.getUserid());
				if (temp != null) {
					if (!temp.getIp().equals(userSession.getIp())) {
						request.setAttribute("error", "�����˺��Ѿ������������ϵ�¼!");
						clearSession(session);
						return mapping.findForward("error");
					} else {
						sessionHouse.removeSessionBySid(temp.getId());
					}
				}
			}
			/* �û���Ϣ�������  */
			/* �û��л���ʽ ���濪ʼ*/
			if (StringUtils.isNotEmpty(request.getParameter("faceStyle"))) {
				userSession.setFacestyle(request.getParameter("faceStyle"));
				if (!"1".equals(userSession.getUserid())) {
					Ssousers ssouser = (Ssousers) this.ssouserService.findObjectBykey(userSession.getUserid());
					ssouser.setFacestyle(request.getParameter("faceStyle"));
					ssouserService.update(ssouser);
				}
			}
			/* �û��л���ʽ �������*/

			
			
			
			/*���»Ự����¼��¼��־��ʼ*/
			UserSession temp = sessionHouse.getUserSessionBySid(id);
			if (temp == null) {
				SystemLogHelper.addLog(request, "��½ϵͳ", "1", "");
			}else{
				sessionHouse.removeSessionBySid(id);
			}
			/*���»Ự����¼��¼��־����*/
			
			
			/* ���session */
			userSession.setLogintype("��ҳ�ͻ���");
			sessionHouse.addSession(userSession);
			
			/*��ѯ��Ƥ����Ӧ��dialog��Ϣ��ʼ*/
			SchemaService schemaService = (SchemaService) SpringContextUtil.getBean("schemaService");
			ConditionBlock block = new ConditionBlock();
			block.and(new ConditionLeaf("folder", "cschemaname", ConditionLeaf.EQ, userSession.getFacestyle(), false));
			List schemas = schemaService.findObjectsByCondition(block, null);
			TSchema schema = schemas.isEmpty() ? (TSchema) schemaService.getAll().get(0) : (TSchema) schemas.get(0);
			userSession.setDialog(schema.getDialog());
			/*��ѯ��Ƥ����Ӧ��dialog��Ϣ����*/

			/* �û���Ϣ */
			request.getSession().setAttribute("USERSESSION", userSession);
			/* ��ʽ */
			request.getSession().setAttribute("faceStyle", userSession.getFacestyle());
			/* ����ϵͳ */
			request.setAttribute("apps", apps);
			/* ���п�ݲ��� */
			request.setAttribute("quick", quick);
			/* ��ǰʱ�� */
			request.setAttribute("datetime", DateUtils.formatToDate(new Date()));
			/* sessionid */
			request.setAttribute("sessionid", session.getId());
			/* ��ʷ�������� */
			request.setAttribute("onlineAll", getLoginSize());
			/* �������� */
			request.setAttribute("online", sessionHouse.getSessionCounts());
			/*��Դ*/
			request.setAttribute("res", res);
			/* ��ʾ����Դ */
			request.setAttribute("prompt", ssouserService.getReourcePromt(userSession.getUserid(), ip));
			/* ip */
			request.setAttribute("ip", ip);
			/* ��Ƭ */
			Employee po = (Employee) employeeService.findObjectBykey(userSession.getEmployeeid());
			request.setAttribute("hasPhoto", po != null && po.getPhoto() != null);
			/* logo */
			List logos = accessService.getAccessoriesListByItem(apps.getJSONObject(0).getString("appid") + "_" + userSession.getFacestyle());
			if (logos.isEmpty()) {
				request.setAttribute("logo", "/resource/logo/" + userSession.getFacestyle() + "/default.gif");
			} else {
				Accessories accessories = (Accessories) logos.get(0);
				request.setAttribute("logo", accessories.getPath());
			}
//			return new ActionForward("/ui/" + userSession.getFacestyle() + "/index.jsp");
			return new ActionForward("/index.jsp");
			
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "��¼�����쳣" + e.getMessage() + "����ϵ����Ա!");
			return mapping.findForward("loginError");
		}
	}

	/**
	 * ��ʾ��ʽ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showSchema(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		SchemaService schemaService = (SchemaService) SpringContextUtil.getBean("schemaService");
		List styles = schemaService.getAll();
		request.setAttribute("styles", styles);
		return mapping.findForward("changeSchema");
	}

	/**
	 * ��ʾ�û�������Ϣ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showPassword(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		UserSession token = (UserSession) request.getSession().getAttribute("USERSESSION");
		Ssousers user = (Ssousers) ssouserService.findObjectBykey(token.getUserid());
		if (user == null) {
			request.setAttribute("login_error", "��˵�е��û�!");
			return mapping.findForward("loginError");
		}
		String strKey = "1234567890abcdef";
		try {
			user.setPassword(AES.Decrypt(user.getPassword(), strKey));
		} catch (Exception e) {
		}
		request.setAttribute("user", user);
		return mapping.findForward("password");
	}

	/**
	 * �޸�����ȸ�����Ϣ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward updateInfo(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		Ssousers user = (Ssousers) ssouserService.findObjectBykey(request.getParameter("userid"));
		String strKey = "1234567890abcdef";
		try {
			user.setPassword(AES.Encrypt(request.getParameter("newpassword"), strKey));
		} catch (Exception e) {
			e.getMessage();
		}
		ssouserService.update(user);
		EmployeeService employeeService = (EmployeeService) SpringContextUtil.getBean("employeeService");
		user.getEmployee().setEmployeename(request.getParameter("employeename"));
		user.getEmployee().setSex(Integer.valueOf(request.getParameter("sex")));
		user.getEmployee().setBirthday(request.getParameter("birthday"));
		user.getEmployee().setEmail(request.getParameter("email"));
		user.getEmployee().setEmailPassword(request.getParameter("emailPassword"));
		employeeService.update(user.getEmployee());
		request.setAttribute("user", user);
		request.setAttribute("isSaveAndAdd", Boolean.valueOf(true));
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	/**
	 * ����ʽ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward changeSchema(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String username = request.getParameter("username");
		request.setAttribute("syspath", request.getContextPath() + "/loginAction.do?action=login");
		request.setAttribute("username", username);
		request.setAttribute("faceStyleself", request.getParameter("faceStyle"));
		request.setAttribute("logintype", "nopass");
		return mapping.findForward("loginpre");
	}

	
	/**
	 * ���session
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward clearSessionSelf(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getSession().getId();
		sessionHouse.removeSessionBySid(id);
		if (StringUtils.isNotEmpty(request.getParameter("returnpage")) && request.getParameter("returnpage").indexOf("changeSchema") == -1) {
			SystemLogHelper.addLog(request, "�˳�ϵͳ", "1", "");
		}
		sessionHouse.removeSessionBySid(id);
		clearSession(request.getSession());
		String url = request.getParameter("returnpage").replaceAll(",", "&");
		url += url.indexOf("&") == -1 ? "?outoxhide" : "&outoxhide";
		try {
			response.sendRedirect(url);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * ���session����Ϣ
	 * 
	 * @param session
	 */
	private void clearSession(HttpSession session) {
		System.out.println("clear session....");
		Enumeration enums = session.getAttributeNames();
		while (enums.hasMoreElements()) {
			String name = (String) enums.nextElement();
			session.removeAttribute(name);
		}
		session.invalidate();
		session = null;
	}


	/**
	 * �����û�id��ϵͳid��ȡ�˵�
	 * 
	 * @param appid
	 *            ϵͳid
	 * @param userid
	 *            �û�id
	 * @return
	 */
	public String getResourceByAppidAndUserId(String appid, String userid, String ip) {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("appid", appid);
		jsonObject.put("res",  ssouserService.getResourcesByUserAndApp(appid, userid, ip));
		return jsonObject.toString();
	}

	public AccessoriesService getAccessService() {
		return accessService;
	}

	public void setAccessService(AccessoriesService accessService) {
		this.accessService = accessService;
	}

}
