package com.sxsihe.oxhide.message.mobile.dao;
import com.ite.oxhide.persistence.BaseDAOIface;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.message.mobile.dao.UnmobileDAO</p>
 * <p>Description:unmobile���ݲ�ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-12-26
 * @modify
 * @date
 */
 public interface UnmobileDAO extends BaseDAOIface{
 }
	