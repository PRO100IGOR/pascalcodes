package com.sxsihe.utils.tld;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.server.dictionary.DictionaryServer;

/**
 * ����ָ���������ֵ�����ȡ�������ֵ����ݲ�����ͨ�ı���ʽ��ʾ
 * 
 * @author �ų���
 * 
 */
public class DicValue extends BodyTagSupport {
	private String dicType;
	private String dicCode;
	private String defaultValue = "";

	public String getDicType() {
		return dicType;
	}

	public void setDicType(String dicType) {
		this.dicType = dicType;
	}

	public String getDicCode() {
		return dicCode;
	}

	public void setDicCode(String dicCode) {
		this.dicCode = dicCode;
	}

	public int doStartTag() throws JspException {
		DictionaryServer dictionaryServer = (DictionaryServer) SpringContextUtil.getBean("dictionaryClient");
		try {
			String value = dictionaryServer.getDicValue(dicType, dicCode);
			this.pageContext.getOut().print(StringUtils.isNotEmpty(value) ? value : defaultValue);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return SKIP_PAGE;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
}
