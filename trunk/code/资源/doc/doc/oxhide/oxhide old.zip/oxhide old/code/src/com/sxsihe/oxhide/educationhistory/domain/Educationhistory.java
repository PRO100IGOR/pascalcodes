package com.sxsihe.oxhide.educationhistory.domain;

import com.sxsihe.oxhide.employee.domain.Employee;

/**
 * Educationhistory entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Educationhistory implements java.io.Serializable {

	// Fields

	private String eid;
	private Employee employee;
	private String education;
	private String schoolname;
	private String professional;
	private String graduation;
	private String certificate;
	private String edutype;

	// Constructors

	/** default constructor */
	public Educationhistory() {
	}

	/** full constructor */
	public Educationhistory(String employeeid, String education, String schoolname, String professional, String graduation, String certificate, String edutype) {
		this.education = education;
		this.schoolname = schoolname;
		this.professional = professional;
		this.graduation = graduation;
		this.certificate = certificate;
		this.edutype = edutype;
	}

	// Property accessors

	public String getEid() {
		return this.eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}


	public String getEducation() {
		return this.education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getSchoolname() {
		return this.schoolname;
	}

	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}

	public String getProfessional() {
		return this.professional;
	}

	public void setProfessional(String professional) {
		this.professional = professional;
	}

	public String getGraduation() {
		return this.graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation = graduation;
	}

	public String getCertificate() {
		return this.certificate;
	}

	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}

	public String getEdutype() {
		return this.edutype;
	}

	public void setEdutype(String edutype) {
		this.edutype = edutype;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}