package com.sxsihe.coder.columns.dao;
import com.ite.oxhide.persistence.BaseDAOIface;
/**
 *
 * <p>Title:com.sxsihe.oxhide.coder.columns.dao.ColumnsDAO</p>
 * <p>Description:columns���ݲ�ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-02
 * @modify
 * @date
 */
 public interface ColumnsDAO extends BaseDAOIface{
 }
