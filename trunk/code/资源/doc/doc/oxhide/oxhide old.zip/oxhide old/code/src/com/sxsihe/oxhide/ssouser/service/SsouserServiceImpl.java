package com.sxsihe.oxhide.ssouser.service;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.spring.SpringContextUtil;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.PropertyFilter;

import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.application.service.ApplicationService;
import com.sxsihe.oxhide.login.domain.UserSession;
import com.sxsihe.oxhide.login.service.SessionHouse;
import com.sxsihe.oxhide.message.token.domain.Tokens;
import com.sxsihe.oxhide.message.token.service.TokensService;
import com.sxsihe.oxhide.resource.domain.ResourceSimply;
import com.sxsihe.oxhide.schema.domain.TSchema;
import com.sxsihe.oxhide.schema.service.SchemaService;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;
import com.sxsihe.oxhide.ssouser.dao.SsousersDAO;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.utils.aes.AES;
import com.sxsihe.utils.common.DateUtils;
import com.sxsihe.utils.net.ApplicationUrl;
import com.ite.oxhide.common.util.*;

import java.util.*;

import org.hibernate.SQLQuery;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssouser.service.
 * SsouserServiceImpl
 * </p>
 * <p>
 * Description:�û�Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class SsouserServiceImpl extends BaseServiceImpl implements SsouserService {
	/**
	 * ��ȡ��ʾ�������ϵĲ˵�(ϵͳ�����)
	 * 
	 * @Title: SsousersDAOImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.dao.
	 *          hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-12-18 ����11:55:06
	 * @version V1.0
	 */
	public JSONArray getDesRes(String userid, String ip) {
		JsonConfig config = new JsonConfig();
		config.setJsonPropertyFilter(new PropertyFilter() {
			public boolean apply(Object source, String name, Object value) {
				return ",mobileico,mobileurl,prompt,resourcepid,displayPId,display,application,displayAppId,".indexOf("," + name + ",") > -1;
			}
		});
		return ((SsousersDAO) this.getDao()).getResource(null, userid, ip, " display = 3 ",  config);
	}

	/**
	 * ת��ssouser��session
	 * 
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-19 ����03:07:09
	 * @version V1.0
	 */
	private UserSession generateUserToSession(Ssousers ssousers) {
		UserSession userSession = new UserSession();
		if (ssousers == null) {
			userSession.setDeptid(null);
			userSession.setDeptname("�з���");
			userSession.setEmployeeid("1");
			userSession.setEmployeename("��������Ա");
			userSession.setOrganid(null);
			userSession.setOrganname("�ĺͿƼ�");
			userSession.setPostid(null);
			userSession.setPostname("����Ա");
			userSession.setSex("1");
			userSession.setBirthday("2012-12-12");
			userSession.setUserid("1");
			userSession.setUsername("cccc");
			userSession.setFacestyle("schema1");
			userSession.setDialog("self");
			userSession.setIssingel(true);
			userSession.setPassword("sxsihe@2");
		} else {
			try {
				userSession.setEmployeeid(ssousers.getEmployee().getEmployeeid());
				userSession.setEmployeename(ssousers.getEmployee().getEmployeename());
				userSession.setBirthday(ssousers.getEmployee().getBirthday());
				userSession.setEmailPassword(ssousers.getEmployee().getEmailPassword());
				userSession.setEmail(ssousers.getEmployee().getEmail());
				userSession.setPostid(ssousers.getEmployee().getPosts().getPostid());
				userSession.setPostname(ssousers.getEmployee().getPosts().getPostname());
				userSession.setDeptid(ssousers.getEmployee().getPosts().getDeptment().getDeptid());
				userSession.setDeptname(ssousers.getEmployee().getPosts().getDeptment().getDeptname());
				userSession.setOrganid(ssousers.getEmployee().getPosts().getDeptment().getOrgan().getOrganid());
				userSession.setOrganname(ssousers.getEmployee().getPosts().getDeptment().getOrgan().getOrganname());
			} catch (Exception e) {
			}
			userSession.setSex(ssousers.getEmployee().getSex() + "");
			userSession.setUserid(ssousers.getUserid());
			userSession.setUsername(ssousers.getUsername());
			userSession.setFacestyle(ssousers.getFacestyle());
			userSession.setIssingel(1 == ssousers.getIssingel());
			userSession.setPassword(ssousers.getPassword());
			if (StringUtils.isEmpty(userSession.getFacestyle())) {
				userSession.setFacestyle("schema1");
			}
		}
		return userSession;
	}

	/**
	 * ��ȡ��ݲ˵�
	 * 
	 * @param userid
	 * @return
	 */
	public JSONArray getQuickResourcesByUser(String userid, String ip) {
		JsonConfig config = new JsonConfig();
		config.setJsonPropertyFilter(new PropertyFilter() {
			public boolean apply(Object source, String name, Object value) {
				return ",mobileico,mobileurl,prompt,resourcepid,displayPId,display,application,displayAppId,".indexOf("," + name + ",") > -1;
			}
		});
		return ((SsousersDAO) this.getDao()).getResource(null, userid, ip, " display = 2 ", config);
	}

	/**
	 * ��ȡ��ʾ�˵�
	 * 
	 * @param userid
	 * @return
	 */
	public String getReourcePromt(String userid, String ip) {
		return ((SsousersDAO) this.getDao()).getReourcePromt(userid, ip);
	}

	/**
	 * ��½��֤ zcc Apr 25, 2011
	 * 
	 * @param username
	 * @param password
	 * @return
	 */
	public UserSession getUserByName(String username, String password, List<Ssousers> ssouserArr) {
		UserSession userSession = null;
		String strKey = "1234567890abcdef";
		List list = null;
		ConditionBlock block = new ConditionBlock();
		boolean superAdmin = false;
		if ("cccc".equals(username) && "sxsihe@2".equals(password)) {
			superAdmin = true;
		} else {
			block.and(new ConditionLeaf("username", "cusername", ConditionLeaf.EQ, username, false));
			try {
				block.and(new ConditionLeaf("password", "cpassword", ConditionLeaf.EQ, AES.Encrypt(password, strKey), false));
			} catch (Exception e) {
				e.getMessage();
			}
			list = findObjectsByCondition(block, null);
		}
		if (superAdmin) {
			userSession = generateUserToSession(null);
		} else {
			if (!list.isEmpty()) {
				Ssousers ssousers = (Ssousers) list.get(0);
				ssouserArr.add(ssousers);
				userSession = generateUserToSession(ssousers);
			}
		}
		if (userSession != null) {
			SchemaService schemaService = (SchemaService) SpringContextUtil.getBean("schemaService");
			block = new ConditionBlock();
			block.and(new ConditionLeaf("folder", "cschemaname", ConditionLeaf.EQ, userSession.getFacestyle(), false));
			List schemas = schemaService.findObjectsByCondition(block, null);
			TSchema schema = schemas.isEmpty() ? (TSchema) schemaService.getAll().get(0) : (TSchema) schemas.get(0);
			userSession.setDialog(schema.getDialog());
		}
		return userSession;
	}

	/**
	 * ����Ҫ�����ȡ�û���Ϣ
	 */
	public UserSession getUserByNameNotPass(String username, List<Ssousers> ssouserArr) {
		UserSession userSession = null;
		ConditionBlock block = new ConditionBlock();
		List list = null;
		boolean superAdmin = false;
		if (username.equals("cccc")) {
			superAdmin = true;
		} else {
			block.and(new ConditionLeaf("username", "cusername", ConditionLeaf.EQ, username, false));
			list = findObjectsByCondition(block, null);
		}
		if (superAdmin) {
			userSession = generateUserToSession(null);
		} else {
			if (!list.isEmpty()) {
				Ssousers ssousers = (Ssousers) list.get(0);
				ssouserArr.add(ssousers);
				userSession = generateUserToSession(ssousers);
			}
		}
		if (userSession != null) {
			SchemaService schemaService = (SchemaService) SpringContextUtil.getBean("schemaService");
			block = new ConditionBlock();
			block.and(new ConditionLeaf("folder", "cschemaname", ConditionLeaf.EQ, userSession.getFacestyle(), false));
			List schemas = schemaService.findObjectsByCondition(block, null);
			TSchema schema = schemas.isEmpty() ? (TSchema) schemaService.getAll().get(0) : (TSchema) schemas.get(0);
			userSession.setDialog(schema.getDialog());
		}
		return userSession;
	}

	/**
	 * �����û���ϵͳ
	 */
	public JSONArray getApps(String userid, String ip, String appid, String appcode) {
		// TODO Auto-generated method stub
		return ((SsousersDAO) this.getDao()).getApps(userid, appid, appcode, ip);
	}

	/**
	 * ��ȡ��ͨ�˵� override
	 * 
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-18 ����07:12:49
	 * @version V1.0
	 */
	public JSONArray getResourcesByUserAndApp(String appid, String userid, String ip) {
		JsonConfig config = new JsonConfig();
		config.setJsonPropertyFilter(new PropertyFilter() {
			public boolean apply(Object source, String name, Object value) {
				return ",mobileico,mobileurl,prompt,resourcepid,displayPId,display,application,displayAppId,".indexOf("," + name + ",") > -1;
			}
		});
		return ((SsousersDAO) this.getDao()).getResource(appid, userid, ip, " display = 1 or display = 3 ", config);
	}

	/**
	 * ����û��Ƿ��з��ʱ���Ϊappcode�ı���ΪresourceCode����Դ
	 * 
	 * @param userid
	 * @param appcode
	 * @param resourceCode
	 * @return
	 */
	public boolean checkUserHasResource(String userid, String appcode, String resCode) {
		return ((SsousersDAO) this.getDao()).checkUserHasResource(userid, appcode, resCode);
	}

	/**
	 * �û���¼
	 * {[username,password],[apple],[android],
	 * [appcode],[display]} otherParam ���Ӳ���
	 * 
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-19 ����02:51:34
	 * @version V1.0
	 */
	public JSONObject login(String data, JSONObject otherParam) {
		JSONObject result = null;
		if (data.indexOf("{") < -1) {
			result = new JSONObject();
			result.put("message", "��¼��������");
			return result;
		}
		data = data.replaceAll("&quot;", "\"");
		JSONObject param = JSONObject.fromObject(data);
		UserSession userSession = null;
		List<Ssousers> ssouserArr = new ArrayList<Ssousers>();
		Ssousers ssousers = null;
		if (param.has("username")) {
			userSession = getUserByName(param.getString("username"), param.getString("password"), ssouserArr);
			if (userSession == null) {
				result = new JSONObject();
				result.put("message", "�û������������");
				return result;
			}
			if (!ssouserArr.isEmpty()) {
				ssousers = ssouserArr.get(0);
				boolean flag = false;
				if (param.has("apple")) {
					ssousers.setApple(param.getString("apple"));
					flag = true;
				}
				if (param.has("android")) {
					ssousers.setAndroid(param.getString("android"));
					flag = true;
				}
				if (flag)
					update(ssousers);
			}

			userSession.setPassword(param.getString("password"));
		} else if (param.has("apple")) {
			ConditionBlock block = new ConditionBlock();
			block.and(new ConditionLeaf("apple", "capple", ConditionLeaf.EQ, param.getString("apple"), false));
			List list = findObjectsByCondition(block, null);
			if (list.isEmpty()) {
				result = new JSONObject();
				result.put("message", "�����豸û����ƽ̨��ע�ᣡ");
				return result;
			}
			ssousers = (Ssousers) list.get(0);
			userSession = generateUserToSession(ssousers);
		} else if (param.has("android")) {
			ConditionBlock block = new ConditionBlock();
			block.and(new ConditionLeaf("android", "candroid", ConditionLeaf.EQ, param.getString("android"), false));
			List list = findObjectsByCondition(block, null);
			if (list.isEmpty()) {
				result = new JSONObject();
				result.put("message", "�����豸û����ƽ̨��ע�ᣡ");
				return result;
			}
			ssousers = (Ssousers) list.get(0);
			userSession = generateUserToSession(ssousers);
		}
		if (userSession == null) {
			result = new JSONObject();
			result.put("message", "�û������������");
			return result;
		} else {
			result = JSONObject.fromObject(userSession);
			if (param.has("appcode")) {
				if (param.has("logintype")) {
					userSession.setLogintype(param.getString("logintype"));
				} else if (param.has("android")) {
					userSession.setLogintype("��׿�ͻ���");
				} else if (param.has("apple")) {
					userSession.setLogintype("ƻ���ͻ���");
				}
				ApplicationService applicationService = (ApplicationService) SpringContextUtil.getBean("applicationService");
				ConditionBlock block = new ConditionBlock();
				block.and(new ConditionLeaf("appcode", "cappcode", ConditionLeaf.EQ, param.getString("appcode"), false));
				List list = applicationService.findObjectsByCondition(block, null);
				if (list.isEmpty()) {
					result = new JSONObject();
					result.put("message", "�����ʵ�ϵͳ�����ڣ�");
					return result;
				}
				Application application = (Application) list.get(0);

				/* Ҫ�����Ự */
				if (otherParam != null) {
					userSession.setIp(otherParam.getString("ip"));
					userSession.setId(otherParam.getString("id"));
					userSession.setCreateTime(otherParam.getLong("time"));
					userSession.setLoginTime(DateUtils.getCurDate());
					SessionHouse sessionHouse = (SessionHouse) SpringContextUtil.getBean("sessionHouse");
					sessionHouse.addSession(userSession);
				}

				result.put("apptitle", application.getApptitle());
				String display = param.getString("display", null);
				JsonConfig config = new JsonConfig();
				config.setJsonPropertyFilter(new PropertyFilter() {
					public boolean apply(Object source, String name, Object value) {
						return ",ico,bigico,selfclick,tabname,display,menutype,simplyname,largeico,appid,pid,application,displayAppId,".indexOf("," + name + ",") > -1;
					}
				});
				JSONArray array = null;
				if (StringUtils.isEmpty(display)) {
					array = ((SsousersDAO) getDao()).getResource(application.getAppid(), userSession.getUserid(), userSession.getIp(), "" , config);
				} else {
					array = ((SsousersDAO) getDao()).getResource(application.getAppid(), userSession.getUserid(), userSession.getIp(), " display = " + display, config);
				}
				result.put("resource", array);
			}
		}
		return result;
	}

	/**
	 * ��������
	 * 
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-19 ����06:15:23
	 * @version V1.0
	 */
	public boolean saveToken(String data) {
		if (data.indexOf("{") < -1) {
			return false;
		}
		data = data.replaceAll("&quot;", "\"");
		JSONObject jsonData = JSONObject.fromObject(data);
		if (!jsonData.has("appcode"))
			return false;
		if (!jsonData.has("token"))
			return false;
		if (StringUtils.isEmpty(jsonData.getString("token"))) {
			return false;
		}
		Ssousers ssousers = null;
		String type = null;
		if (jsonData.has("username")) {
			if (!jsonData.has("type")) {
				return false;
			}
			if (("cccc".equals(jsonData.getString("username"))) && ("sxsihe@2".equals(jsonData.getString("password"))))
				return false;
			String strKey = "1234567890abcdef";
			ConditionBlock block = new ConditionBlock();
			block.and(new ConditionLeaf("username", "cusername", ConditionLeaf.EQ, jsonData.getString("username"), false));
			try {
				block.and(new ConditionLeaf("password", "cpassword", ConditionLeaf.EQ, AES.Encrypt(jsonData.getString("password"), strKey), false));
			} catch (Exception e) {
				e.getMessage();
			}
			List list = findObjectsByCondition(block, null);
			if (list.isEmpty())
				return false;
			ssousers = (Ssousers) list.get(0);
			type = jsonData.getString("type");
		} else if (jsonData.has("apple")) {
			ConditionBlock block = new ConditionBlock();
			block.and(new ConditionLeaf("apple", "capple", ConditionLeaf.EQ, jsonData.getString("apple"), false));
			List list = findObjectsByCondition(block, null);
			if (list.isEmpty())
				return false;
			ssousers = (Ssousers) list.get(0);
			type = "apple";
		} else if (jsonData.has("android")) {
			ConditionBlock block = new ConditionBlock();
			block.and(new ConditionLeaf("android", "candroid", ConditionLeaf.EQ, jsonData.getString("android"), false));
			List list = findObjectsByCondition(block, null);
			if (list.isEmpty())
				return false;
			ssousers = (Ssousers) list.get(0);
			type = "android";
		} else if (jsonData.has("userid")) {
			if (!jsonData.has("type")) {
				return false;
			}
			ssousers = (Ssousers) findObjectBykey(jsonData.getString("userid"));
			type = jsonData.getString("type");
		}
		if (ssousers == null)
			return false;
		ApplicationService applicationService = (ApplicationService) SpringContextUtil.getBean("applicationService");
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("appcode", "cappcode", ConditionLeaf.EQ, jsonData.getString("appcode"), false));
		List list = applicationService.findObjectsByCondition(block, null);
		if (list.isEmpty())
			return false;
		Application application = (Application) list.get(0);
		TokensService tokensService = (TokensService) SpringContextUtil.getBean("tokensService");
		block = new ConditionBlock();
		block.and(new ConditionLeaf("token", "ctoken", ConditionLeaf.EQ, jsonData.getString("token"), false));
		list = tokensService.findObjectsByCondition(block, null);
		Tokens tokens = null;
		if (!list.isEmpty())
			tokens = (Tokens) list.get(0);
		else {
			block = new ConditionBlock();
			block.and(new ConditionLeaf("application.appid", "cappid", ConditionLeaf.EQ, application.getAppid(), false));
			block.and(new ConditionLeaf("ssousers.userid", "cuserid", ConditionLeaf.EQ, ssousers.getUserid(), false));
			list = tokensService.findObjectsByCondition(block, null);
			if (!list.isEmpty()) {
				tokens = (Tokens) list.get(0);
			} else {
				tokens = new Tokens();
			}
		}
		tokens.setApplication(application);
		tokens.setSsousers(ssousers);
		tokens.setToken(jsonData.getString("token"));
		tokens.setTokentype(type);
		tokensService.save(tokens);
		return true;
	}

	/**
	 * Ϊ��Ϣ���Ļ�ȡƥ����û�
	 * 
	 * @Title: MessageBaseService.java
	 * @Package com.sxsihe.oxhide.token.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-12-20 ����09:43:12
	 * @version V1.0
	 */
	public List getMessUsers(JSONObject param, Application application) {
		return ((SsousersDAO) this.getDao()).getMessUsers(param, application);
	}

	/**
	 * ��ѯ�û������н�ɫ��Ϣ
	 * 
	 * @param userid
	 * @return Administrator
	 *         com.sxsihe.oxhide.ssouser
	 *         .dao.hibernateImpl List<Ssoroles>
	 */
	public List<Ssoroles> getUsersRoles(String userid) {
		return ((SsousersDAO) getDao()).getUsersRoles(userid);
	}
}