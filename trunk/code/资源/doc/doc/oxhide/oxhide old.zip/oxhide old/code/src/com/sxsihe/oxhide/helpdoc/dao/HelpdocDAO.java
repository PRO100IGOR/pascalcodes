package com.sxsihe.oxhide.helpdoc.dao;
import com.ite.oxhide.persistence.BaseDAOIface;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.helpdoc.dao.HelpdocDAO</p>
 * <p>Description:helpdoc���ݲ�ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-09-28
 * @modify
 * @date
 */
 public interface HelpdocDAO extends BaseDAOIface{
 }
	