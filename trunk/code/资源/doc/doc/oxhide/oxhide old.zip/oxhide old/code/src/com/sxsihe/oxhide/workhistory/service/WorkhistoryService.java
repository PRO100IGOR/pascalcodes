package com.sxsihe.oxhide.workhistory.service;

import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.struts.menu.MenuDataPick;
import java.util.*;
/**
 *<p>Title:com.sxsihe.oxhide.workhistory.service.WorkhistoryService</p>
 *<p>Description:������ʷService</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-08-11
 *
 * @modify 
 * @date
 */
 public interface WorkhistoryService extends BaseServiceIface{
 }