package com.sxsihe.oxhide.systemlog.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.systemlog.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author
 * @version 1.0
 * @date 2011-07-08
 * 
 * @modify
 * @date
 */
public class SystemlogForm extends BaseForm {
	private String operateType;
	/* sid */
	private String operateModel;
	private String sid;

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getSid() {
		return this.sid;
	}

	/* operateTime */
	private String operateTime;

	public void setOperateTime(String operateTime) {
		this.operateTime = operateTime;
	}

	public String getOperateTime() {
		return this.operateTime;
	}

	/* operateIp */
	private String operateIp;

	public void setOperateIp(String operateIp) {
		this.operateIp = operateIp;
	}

	public String getOperateIp() {
		return this.operateIp;
	}

	/* operatePerson */
	private String operatePerson;

	public void setOperatePerson(String operatePerson) {
		this.operatePerson = operatePerson;
	}

	public String getOperatePerson() {
		return this.operatePerson;
	}

	/* operateEmp */
	private String operateEmp;

	public void setOperateEmp(String operateEmp) {
		this.operateEmp = operateEmp;
	}

	public String getOperateEmp() {
		return this.operateEmp;
	}

	/* operateSys */
	private String operateSys;

	public void setOperateSys(String operateSys) {
		this.operateSys = operateSys;
	}

	public String getOperateSys() {
		return this.operateSys;
	}

	/* operateContent */
	private String operateContent;

	public void setOperateContent(String operateContent) {
		this.operateContent = operateContent;
	}

	public String getOperateContent() {
		return this.operateContent;
	}

	/* remark */
	private String remark;

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRemark() {
		return this.remark;
	}

	public String getOperateModel() {
		return operateModel;
	}

	public void setOperateModel(String operateModel) {
		this.operateModel = operateModel;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}
}
