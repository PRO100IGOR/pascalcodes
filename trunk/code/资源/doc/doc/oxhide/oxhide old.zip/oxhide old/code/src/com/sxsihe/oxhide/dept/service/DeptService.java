package com.sxsihe.oxhide.dept.service;

import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.struts.menu.MenuDataPick;
import java.util.*;
/**
 *<p>Title:com.sxsihe.oxhide.dept.service.DeptService</p>
 *<p>Description:����Service</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify 
 * @date
 */
 public interface DeptService extends BaseServiceIface{
		/**
		 * ��ȡ���������
		 * zcc
		 * Apr 22, 2011
		 * @return
		 */
		public int getOrderNo(String organid);
 }