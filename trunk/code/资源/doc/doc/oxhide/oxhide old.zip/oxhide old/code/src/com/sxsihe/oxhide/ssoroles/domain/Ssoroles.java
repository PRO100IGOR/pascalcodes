package com.sxsihe.oxhide.ssoroles.domain;

import java.util.HashSet;
import java.util.Set;

/**
 * Ssoroles entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Ssoroles implements java.io.Serializable {

	// Fields

	private String roleid;
	private String rolename;
	private String rolecode;
	private String remark;
	private Integer isvalidation;
	private Set usersroleses = new HashSet(0);
	private Set rolesresourceses = new HashSet(0);
	private Set rolesapp = new HashSet(0);

	// Constructors

	public Set getRolesapp() {
		return rolesapp;
	}

	public void setRolesapp(Set rolesapp) {
		this.rolesapp = rolesapp;
	}

	/** default constructor */
	public Ssoroles() {
	}

	/** full constructor */
	public Ssoroles(String rolename, String rolecode, String remark,
			Integer isvalidation, Set usersroleses, Set rolesresourceses) {
		this.rolename = rolename;
		this.rolecode = rolecode;
		this.remark = remark;
		this.isvalidation = isvalidation;
		this.usersroleses = usersroleses;
		this.rolesresourceses = rolesresourceses;
	}

	// Property accessors

	public String getRoleid() {
		return this.roleid;
	}

	public void setRoleid(String roleid) {
		this.roleid = roleid;
	}

	public String getRolename() {
		return this.rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public String getRolecode() {
		return this.rolecode;
	}

	public void setRolecode(String rolecode) {
		this.rolecode = rolecode;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Set getUsersroleses() {
		return this.usersroleses;
	}

	public void setUsersroleses(Set usersroleses) {
		this.usersroleses = usersroleses;
	}

	public Set getRolesresourceses() {
		return this.rolesresourceses;
	}

	public void setRolesresourceses(Set rolesresourceses) {
		this.rolesresourceses = rolesresourceses;
	}

}