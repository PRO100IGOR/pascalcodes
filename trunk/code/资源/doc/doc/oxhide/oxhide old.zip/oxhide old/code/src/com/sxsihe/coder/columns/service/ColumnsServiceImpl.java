package com.sxsihe.coder.columns.service;
import com.ite.oxhide.service.BaseServiceImpl;
/**
 *
 * <p>Title:com.sxsihe.oxhide.coder.columns.service.ColumnsServiceImpl</p>
 * <p>Description:columns����ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-02
 * @modify
 * @date
 */
 public class ColumnsServiceImpl extends BaseServiceImpl implements ColumnsService{
 }
