package com.sxsihe.oxhide.organ.mobile;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JsonConfig;
import net.sf.json.util.PropertyFilter;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import com.sxsihe.utils.mobile.MobileQuery;

public class OrganAction extends BaseShowAction {

	/**
	 * �б�action
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 *             Administrator
	 *             com.sxsihe.oxhide.organ.mobile
	 *             OrganAction.java 2012����5:18:41
	 *             oxhide
	 * @see com.ite.oxhide.struts.actionEx.BaseShowAction#showList(org.apache.struts.action.ActionMapping,
	 *      org.apache.struts.action.ActionForm,
	 *      javax.servlet.http.HttpServletRequest,
	 *      javax.servlet.http.HttpServletResponse)
	 */
	public ActionForward showList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String data = request.getParameter("data");
		if (StringUtils.isEmpty(data)) {
			return null;
		}
		JsonConfig config = new JsonConfig();
		config.setJsonPropertyFilter(new PropertyFilter() {
			public boolean apply(Object source, String name, Object value) {
				return "deptments".equals(name) || "porgan".equals(name) || "organs".equals(name);
			}
		});
		data = MobileQuery.queryByJsonData(data, "Organ", "organService", config);
		response.setCharacterEncoding("utf-8");
		try {
			response.getWriter().write("oxhide(" + data + ")");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
