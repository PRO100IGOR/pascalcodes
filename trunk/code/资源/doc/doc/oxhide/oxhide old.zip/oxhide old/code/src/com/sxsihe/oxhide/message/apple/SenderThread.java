package com.sxsihe.oxhide.message.apple;

import java.util.List;

import com.notnoop.apns.ApnsService;
import com.sxsihe.oxhide.message.Sender;
import com.sxsihe.oxhide.message.SenderManger;
import com.sxsihe.oxhide.message.apple.AppleService;

public class SenderThread extends Thread {
	private String appcode;
	private ApnsService service;

	public ApnsService getService() {
		return service;
	}

	public void setService(ApnsService service) {
		this.service = service;
	}

	private int time;
	private SenderManger senderManger;

	public SenderManger getSenderManger() {
		return senderManger;
	}

	public void setSenderManger(SenderManger senderManger) {
		this.senderManger = senderManger;
	}

	public String getAppcode() {
		return appcode;
	}

	public void setAppcode(String appcode) {
		this.appcode = appcode;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public void run() {
		while (true) {
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			getData();
		}
	}

	private void getData() {
		List list = senderManger.getApples(appcode);
		for (int i = 0; i < list.size(); i++) {
			Sender sender = (Sender) list.get(i);
			SenderThreadHelper senderThreadHelper = new SenderThreadHelper(sender);
			senderThreadHelper.setService(service);
			AppleService.executor.execute(senderThreadHelper);
			if (sender.getTimestotal() != 0 && sender.getTimes() + 1 == sender.getTimestotal()) {
				senderManger.delApple(sender.getId());
			} else {
				senderManger.addAppleTimes(sender.getId());
			}
		}
	}

}
