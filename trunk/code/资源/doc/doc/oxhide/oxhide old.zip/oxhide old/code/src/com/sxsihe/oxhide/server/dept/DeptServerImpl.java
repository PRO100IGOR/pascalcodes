package com.sxsihe.oxhide.server.dept;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.service.BaseServiceIface;
import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.utils.common.DataUtils;

public class DeptServerImpl implements DeptServer {
	private BaseServiceIface service;

	public BaseServiceIface getService() {
		return service;
	}

	public void setService(BaseServiceIface service) {
		this.service = service;
	}

	public Deptment findObjectBykey(String key) {
		Object object = service.findObjectBykey(key);
		try {
			return (Deptment) DataUtils.copyPoJo(object, Deptment.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public List<Deptment> findObjectsByCondition(ConditionBlock block, Map sortMap) {
		List list = service.findObjectsByCondition(DataUtils.changeCode(block), sortMap);
		return DataUtils.copyPoJos(list, Deptment.class);
	}

	public List<Deptment> getAll() {
		List list = service.getAll();
		return DataUtils.copyPoJos(list, Deptment.class);
	}
}
