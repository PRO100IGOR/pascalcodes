package com.sxsihe.oxhide.usersroles.dao.hibernateImpl;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.usersroles.domain.Usersroles;
import com.sxsihe.oxhide.usersroles.dao.UsersrolesDAO;
/**
 *<p>Title:com.sxsihe.oxhide.usersroles.dao.UsersrolesDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class UsersrolesDAOImpl extends BaseDAOImpl implements UsersrolesDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Usersroles.class;
	   }
}