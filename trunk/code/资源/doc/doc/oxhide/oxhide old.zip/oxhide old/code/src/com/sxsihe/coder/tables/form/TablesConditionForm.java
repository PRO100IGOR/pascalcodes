package com.sxsihe.coder.tables.form;
import com.ite.oxhide.struts.form.BaseForm;
/**
 *
 * <p>Title:com.sxsihe.oxhide.coder.tables.form.TablesConditionForm</p>
 * <p>Description:tables��ѯ����form</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-10-30
 * @modify
 * @date
 */
 public class TablesConditionForm extends BaseForm {
	private String ctname;
	public void setCtname(String ctname) {
		this.ctname = ctname;
	}
	public String getCtname() {
		return this.ctname;
	}
	private String ctcode;
	public void setCtcode(String ctcode) {
		this.ctcode = ctcode;
	}
	public String getCtcode() {
		return this.ctcode;
	}
	}
