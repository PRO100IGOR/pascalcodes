package com.sxsihe.oxhide.message.mobile;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.smslib.ICallNotification;
import org.smslib.IInboundMessageNotification;
import org.smslib.InboundMessage;
import org.smslib.OutboundMessage;
import org.smslib.Service;
import org.smslib.Message.MessageEncodings;
import org.smslib.Message.MessageTypes;
import org.smslib.Settings;
import org.smslib.modem.SerialModemGateway;

import com.ite.oxhide.common.util.StringUtils;

public class SMSThread extends Thread {
	private SerialModemGateway gateway;
	private int time;
	private String com;
	private int baud;
	private String devname;
	private String wavetype;
	private String pin;
	private Service srv;
	private MobileHandle mobileHandle;
	private boolean isReady;
	private boolean isRun = false;
	public void start(){
		super.start();
		this.isRun = true;
	}
	
	
	
	public SerialModemGateway getGateway() {
		return gateway;
	}

	public void setGateway(SerialModemGateway gateway) {
		this.gateway = gateway;
	}

	public boolean isRun() {
		return isRun;
	}

	public void setRun(boolean isRun) {
		this.isRun = isRun;
	}

	public List<OutboundMessage> getList() {
		return list;
	}

	public void setList(List<OutboundMessage> list) {
		this.list = list;
	}

	private List<OutboundMessage> list = new ArrayList<OutboundMessage>();

	public Service getSrv() {
		return srv;
	}

	public void setSrv(Service srv) {
		this.srv = srv;
	}

	public MobileHandle getMobileHandle() {
		return mobileHandle;
	}

	public void setMobileHandle(MobileHandle mobileHandle) {
		this.mobileHandle = mobileHandle;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public String getCom() {
		return com;
	}

	public void setCom(String com) {
		this.com = com;
	}

	public int getBaud() {
		return baud;
	}

	public void setBaud(int baud) {
		this.baud = baud;
	}

	public String getWavetype() {
		return wavetype;
	}

	public void setWavetype(String wavetype) {
		this.wavetype = wavetype;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getDevname() {
		return devname;
	}

	public void setDevname(String devname) {
		this.devname = devname;
	}

	public void init() {
		gateway = new SerialModemGateway(devname, com, baud, wavetype, pin);
		InboundNotification inboundNotification = new InboundNotification();
		inboundNotification.setMobileHandle(mobileHandle);
		inboundNotification.setThread(this);
		gateway.setInbound(true);
		gateway.setOutbound(true);
		gateway.setSimPin(StringUtils.isEmpty(pin) ? "0000" : pin);
		gateway.setInboundNotification(inboundNotification);
		srv = new Service();
		srv.addGateway(gateway);
		try {
			srv.startService();
			isReady = true;
			System.out.println("����è��ʼ����ϣ���ַ" + com);
		} catch (Exception e) {
			e.printStackTrace();
			isReady = false;
			System.out.println("����è��ʼ������");
		}

	}

	public void run() {
		while (isRun) {
			try {
				if (isReady) {
					List<OutboundMessage> newList = new ArrayList<OutboundMessage>();
					for (OutboundMessage msg : list) {
						if (srv.sendMessage(msg)) {
							newList.add(msg);
						} else {
							System.out.println("���ʹ���");
						}
					}
					list.removeAll(newList);
				}else{
					this.init();
				}
				Thread.sleep(time);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public boolean sendMess(String mess, String phone) {
		OutboundMessage msg = new OutboundMessage(phone, mess);
		msg.setEncoding(MessageEncodings.ENCUCS2);
		list.add(msg);
		return true;
	}

	// ����Ϣ������
	public class InboundNotification implements IInboundMessageNotification {
		private MobileHandle mobileHandle;
		private SMSThread thread;

		public SMSThread getThread() {
			return thread;
		}

		public void setThread(SMSThread thread) {
			this.thread = thread;
		}

		public MobileHandle getMobileHandle() {
			return mobileHandle;
		}

		public void setMobileHandle(MobileHandle mobileHandle) {
			this.mobileHandle = mobileHandle;
		}

		public void process(String gatewayId, MessageTypes msgType, InboundMessage msg) {
			String phone = msg.getOriginator().substring(2);
			if (msgType == MessageTypes.INBOUND) // ��Ϣ
				thread.sendMess(mobileHandle.handelMsg(msg.getText(), phone), phone);
			else if (msgType == MessageTypes.STATUSREPORT) {// ״̬����

			}
			try {
				srv.deleteMessage(msg);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	// ���紦����
	public class CallNotification implements ICallNotification {
		public void process(String gatewayId, String callerId) {

		}
	}

	public boolean isReady() {
		return isReady;
	}

	public void setReady(boolean isReady) {
		this.isReady = isReady;
	}

}
