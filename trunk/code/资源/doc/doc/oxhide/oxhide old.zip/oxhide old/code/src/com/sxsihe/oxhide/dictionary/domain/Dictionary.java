package com.sxsihe.oxhide.dictionary.domain;

import java.util.HashSet;
import java.util.Set;

/**
 * Dictionary entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Dictionary implements java.io.Serializable {

	// Fields

	private String did;
	private String dname;
	private String dcode;
	private String remark;
	private Set dictionarycontents = new HashSet(0);

	// Constructors

	/** default constructor */
	public Dictionary() {
	}

	/** full constructor */
	public Dictionary(String dname, Set dictionarycontents) {
		this.dname = dname;
		this.dictionarycontents = dictionarycontents;
	}

	// Property accessors

	public String getDid() {
		return this.did;
	}

	public void setDid(String did) {
		this.did = did;
	}

	public String getDname() {
		return this.dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public Set getDictionarycontents() {
		return this.dictionarycontents;
	}

	public void setDictionarycontents(Set dictionarycontents) {
		this.dictionarycontents = dictionarycontents;
	}

	public String getDcode() {
		return dcode;
	}

	public void setDcode(String dcode) {
		this.dcode = dcode;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}