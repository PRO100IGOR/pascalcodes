package com.sxsihe.oxhide.schema.service;

import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.struts.menu.MenuDataPick;
import java.util.*;
/**
 *<p>Title:com.sxsihe.oxhide.schema.service.SchemaService</p>
 *<p>Description:��ʽ����Service</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-05-04
 *
 * @modify 
 * @date
 */
 public interface SchemaService extends BaseServiceIface{
 }