package com.sxsihe.oxhide.post.service;

import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.struts.menu.MenuDataPick;
import java.util.*;

/**
 * <p>
 * Title:com.sxsihe.oxhide.post.service.PostService
 * </p>
 * <p>
 * Description:��λService
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public interface PostService extends BaseServiceIface {
	/**
	 * ��ȡ��������� zcc Apr 22, 2011
	 * 
	 * @return
	 */
	public int getOrderNo(String deptid);
}