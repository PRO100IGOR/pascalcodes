package com.sxsihe.oxhide.dept.service;

import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.menu.MenuDataPick;
import org.apache.commons.beanutils.PropertyUtils;

import com.sxsihe.oxhide.dept.dao.DeptmentDAO;
import com.sxsihe.oxhide.dept.domain.Deptment;
import com.ite.oxhide.common.util.*;
import java.util.*;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dept.service.DeptServiceImpl
 * </p>
 * <p>
 * Description:����Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class DeptServiceImpl extends BaseServiceImpl implements DeptService {
	
	/**
	 * ��ȡ���������
	 * zcc
	 * Apr 22, 2011
	 * @return
	 */
	public int getOrderNo(String organid){
		return ((DeptmentDAO)this.getDao()).getOrderNo(organid);
	}
}