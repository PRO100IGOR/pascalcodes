package com.sxsihe.oxhide.ssouser.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.login.service.SessionHouse;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.oxhide.ssouser.form.SsouserForm;
import com.sxsihe.oxhide.ssouser.service.SsouserService;
import com.sxsihe.oxhide.usersroles.domain.Usersroles;
import com.sxsihe.oxhide.usersroles.service.UsersrolesService;
import com.sxsihe.utils.aes.AES;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssouser.action.
 * SsouserSaveAction
 * </p>
 * <p>
 * Description:�û�SaveAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */

public class SsouserSaveAction extends BaseSaveAction {
	/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 * 
	 * @param form
	 * @return
	 */
	protected Serializable getPersisPo(ActionForm form, String type) {
		SsouserForm vForm = (SsouserForm) form;
		Ssousers po;
		if (type.equals("add")) {
			po = new Ssousers();

		} else {
			String userid = vForm.getUserid();
			po = (Ssousers) service.findObjectBykey(userid);
		}
		po.setIssingel(vForm.getIssingel());
		po.setUserid(vForm.getUserid());
		po.setUsername(vForm.getUsername());
		po.setFacestyle(vForm.getFacestyle());
		po.setIsvalidation(vForm.getIsvalidation());
		if (StringUtils.isNotEmpty(vForm.getEmployeeid())) {
			Employee employee = new Employee();
			employee.setEmployeeid(vForm.getEmployeeid());
			po.setEmployee(employee);
		}
		if (type.equals("add")) {
			try {
				po.setPassword(AES.Encrypt("888888", "1234567890abcdef"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		po.setApple(vForm.getApple());
		po.setAndroid(vForm.getAndroid());
		return po;
	}

	/**
	 * ���Ӻ���õķ���
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	public void nextAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable po) {
		saveRoles(false, (Ssousers) po, request);
	}

	/**
	 * �޸ĺ���õķ���
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	public void nextUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable po) {
		saveRoles(false, (Ssousers) po, request);
	}

	private void saveRoles(boolean isAdd, Ssousers po, HttpServletRequest request) {
		if (!isAdd) {
			String hql = "from Usersroles u where u.ssousers.userid = '" + po.getUserid() + "'";
			getService().deleteBatch(getService().queryHql(hql, null));
		}
		String ids = request.getParameter("ids");
		if (StringUtils.isNotEmpty(ids)) {
			String[] idArr = ids.split(",");
			List addArr = new ArrayList();
			for (String id : idArr) {
				if (StringUtils.isNotEmpty(id)) {
					Usersroles usersroles = new Usersroles();
					Ssoroles ssoroles = new Ssoroles();
					ssoroles.setRoleid(id);
					usersroles.setSsoroles(ssoroles);
					usersroles.setSsousers(po);
					addArr.add(usersroles);
				}
			}
			UsersrolesService usersrolesService = (UsersrolesService) SpringContextUtil.getBean("usersrolesService");
			usersrolesService.saveBatch(addArr);
		}
	}

	/**
	 * ������ʵ��Ĺ���ʵ��
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form, HttpServletRequest request, String type) {
		HashMap map = new HashMap();
		Set list = new HashSet();
	}

	/**
	 * ��������
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward reset(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Ssousers po = (Ssousers) getService().findObjectBykey(id);
		po.setPassword("be5f1c15b1d51d6f4be84eb34cb965c3");
		return new ActionForward("/ssouserLoadAction.do?action=showList");
	}
}