package com.sxsihe.coder.sels.dao;
import com.ite.oxhide.persistence.BaseDAOIface;
/**
 *
 * <p>Title:com.sxsihe.oxhide.coder.sels.dao.SelsDAO</p>
 * <p>Description:sels���ݲ�ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-02
 * @modify
 * @date
 */
 public interface SelsDAO extends BaseDAOIface{
 }
