package com.sxsihe.utils.tld;

public class StringUtils {
	/**
	 * �滻ȫ��
	 * @param src
	 * @param p
	 * @param r
	 * @return
	 */
	public static String replaceAll(String src,String p,String r){
		String  a = src.replaceAll(p, r);
		return a;
	}
}
