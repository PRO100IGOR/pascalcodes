package com.sxsihe.oxhide.organ.form;

import com.ite.oxhide.struts.form.BaseForm;
/**
 *<p>Title:com.sxsihe.oxhide.organ.form.OrganConditionForm</p>
 *<p>Description:���� </p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author zcc
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify 
 * @date
 */
public class OrganConditionForm extends BaseForm{
      /*��������*/
      private String  corganname ;
      public void setCorganname(String corganname){
         this.corganname=corganname;
      }
      public String getCorganname(){
         return this.corganname;
      }
      /*��������*/
      private String  corgancode ;
      public void setCorgancode(String corgancode){
         this.corgancode=corgancode;
      }
      public String getCorgancode(){
         return this.corgancode;
      }
      
}





