package com.sxsihe.oxhide.schema.action;

import java.util.*;
import java.io.Serializable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseDeleteAction;
import com.sxsihe.oxhide.schema.form.SchemaForm;

/**
 *<p>Title:com.sxsihe.oxhide.schema.action.SchemaDeleteAction</p>
 *<p>Description:��ʽ����DeleteAction</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-05-04
 *
 * @modify
 * @date
 */
public class SchemaDeleteAction extends BaseDeleteAction{
}