package com.sxsihe.coder.dataid.service;
import com.ite.oxhide.service.BaseServiceIface;
/**
 * 
 * <p>Title:com.sxsihe.coder.dataid.service.DataidService</p>
 * <p>Description:dataid����ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-03
 * @modify
 * @date
 */
 public interface DataidService extends BaseServiceIface{
 }
	