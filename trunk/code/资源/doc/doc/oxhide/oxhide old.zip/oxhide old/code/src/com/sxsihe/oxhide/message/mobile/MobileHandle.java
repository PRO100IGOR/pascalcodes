package com.sxsihe.oxhide.message.mobile;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.application.service.ApplicationService;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.employee.service.EmployeeService;
import com.sxsihe.oxhide.message.mobile.domain.Unmobile;
import com.sxsihe.oxhide.message.mobile.service.UnmobileService;
import com.sxsihe.utils.common.DateUtils;

public class MobileHandle {
	private ApplicationService applicationService;
	private EmployeeService employeeService;
	private UnmobileService unmobileService;

	public ApplicationService getApplicationService() {
		return applicationService;
	}

	public void setApplicationService(ApplicationService applicationService) {
		this.applicationService = applicationService;
	}

	public EmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}

	public UnmobileService getUnmobileService() {
		return unmobileService;
	}

	public void setUnmobileService(UnmobileService unmobileService) {
		this.unmobileService = unmobileService;
	}

	
	public String handelMsg(String msg, String port) {
		msg = msg.toUpperCase().trim();
		int index = msg.indexOf("QX");
		String code = index == -1 ? msg : msg.substring(2);
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("appcode", "cappcode", ConditionLeaf.EQ, code, false));
		List list = applicationService.findObjectsByCondition(block, null);
		if (list.isEmpty())
			return "��Ϣ��ʽ����,�뷢��QX+����";
		Application application = (Application) list.get(0);
		block = new ConditionBlock();
		block.and(new ConditionLeaf("mobile", "cmobile", ConditionLeaf.EQ, port, false));
		list = employeeService.findObjectsByCondition(block, null);
		if (list.isEmpty())
			return "�����ֻ�û����ϵͳ��ע�ᣡ";
		Employee employee = (Employee) list.get(0);
		if (index > -1) {
			Unmobile unmobile = new Unmobile();
			unmobile.setApplication(application);
			unmobile.setEmployee(employee);
			unmobile.setUdate(DateUtils.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
			unmobileService.add(unmobile);
			return "ȡ���ɹ�����ҪԤ�����뷢��" + code;
		} else {
			String hql = "from Unmobile t where t.application.appid = :appid and t.employee.employeeid = :employeeid";
			Map map = new HashMap();
			map.put("appid", application.getAppid());
			map.put("employeeid", employee.getEmployeeid());
			list = this.unmobileService.queryHql(hql, map);
			this.unmobileService.deleteBatch(list);
			return "ע��ɹ�!��Ҫȡ�����뷢��QX" + code;
		}
	}
}
