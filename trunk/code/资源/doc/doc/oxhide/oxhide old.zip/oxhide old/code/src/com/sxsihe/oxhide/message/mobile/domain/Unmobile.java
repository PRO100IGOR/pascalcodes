package com.sxsihe.oxhide.message.mobile.domain;

import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.employee.domain.Employee;

/**
 * Unmobile entity.
 *
 * @author MyEclipse Persistence Tools
 */

public class Unmobile implements java.io.Serializable {

	// Fields

	private String unid;
	private Employee employee;
	private Application application;
	private String udate;

	// Constructors

	/** default constructor */
	public Unmobile() {
	}

	// Property accessors


	public String getUdate() {
		return this.udate;
	}

	public String getUnid() {
		return unid;
	}

	public void setUnid(String unid) {
		this.unid = unid;
	}

	public void setUdate(String udate) {
		this.udate = udate;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}