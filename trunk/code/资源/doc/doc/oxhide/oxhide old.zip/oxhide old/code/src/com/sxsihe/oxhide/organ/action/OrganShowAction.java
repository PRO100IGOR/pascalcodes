package com.sxsihe.oxhide.organ.action;

import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.PropertyFilter;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import java.io.*;

import com.ite.oxhide.persistence.*;
import org.extremecomponents.table.limit.Limit;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import org.apache.commons.beanutils.PropertyUtils;
import com.sxsihe.oxhide.organ.domain.Organ;
import com.sxsihe.oxhide.organ.form.OrganForm;
import com.sxsihe.oxhide.organ.form.OrganConditionForm;
import com.sxsihe.utils.mobile.MobileQuery;

/**
 * <p>
 * Title:com.sxsihe.oxhide.organ.action.
 * OrganShowAction
 * </p>
 * <p>
 * Description:���� showAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class OrganShowAction extends BaseShowAction {
	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * ��֯������
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showMap(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Serializable po = (Serializable) getService().findObjectBykey(id);
		nextShowUpdate(mapping, form, request, response);
		request.setAttribute("view", po);
		return mapping.findForward("showMap");
	}

	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof OrganForm) {
				Organ pos = (Organ) po;
				OrganForm vForm = (OrganForm) form;
				BeanUtils.setProperty(vForm, "organid", PropertyUtils.getProperty(pos, "organid"));
				BeanUtils.setProperty(vForm, "organname", PropertyUtils.getProperty(pos, "organname"));
				BeanUtils.setProperty(vForm, "areaid", PropertyUtils.getProperty(pos, "areaid"));
				BeanUtils.setProperty(vForm, "organcode", PropertyUtils.getProperty(pos, "organcode"));
				BeanUtils.setProperty(vForm, "organalias", PropertyUtils.getProperty(pos, "organalias"));
				BeanUtils.setProperty(vForm, "address", PropertyUtils.getProperty(pos, "address"));
				BeanUtils.setProperty(vForm, "telephone", PropertyUtils.getProperty(pos, "telephone"));
				BeanUtils.setProperty(vForm, "fax", PropertyUtils.getProperty(pos, "fax"));
				BeanUtils.setProperty(vForm, "isvalidation", PropertyUtils.getProperty(pos, "isvalidation"));
				BeanUtils.setProperty(vForm, "remark", PropertyUtils.getProperty(pos, "remark"));
				if (pos.getPorgan() != null) {
					vForm.setOrganpid(pos.getPorgan().getOrganid());
					vForm.setOrganpname(pos.getPorgan().getOrganname());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		OrganConditionForm vcForm = (OrganConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("organname", "corganname", ConditionLeaf.LIKE, vcForm.getCorganname(), true));
			block.and(new ConditionLeaf("organcode", "corgancode", ConditionLeaf.EQ, vcForm.getCorgancode(), true));
		}
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		OrganConditionForm vcForm = (OrganConditionForm) conditionForm;
		if (vcForm != null) {
			block.and(new ConditionLeaf("organname", "corganname", ConditionLeaf.LIKE, vcForm.getCorganname(), true));
			block.and(new ConditionLeaf("organcode", "corgancode", ConditionLeaf.EQ, vcForm.getCorgancode(), true));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		List list = getService().findObjectsByCondition(block, sortMap);
		return list;
	}

	
}
