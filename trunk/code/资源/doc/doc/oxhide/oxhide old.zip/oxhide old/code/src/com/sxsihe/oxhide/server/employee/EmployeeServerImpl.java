package com.sxsihe.oxhide.server.employee;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.service.BaseServiceIface;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.utils.common.DataUtils;

public class EmployeeServerImpl implements EmployeeServer {
	private BaseServiceIface service;

	public BaseServiceIface getService() {
		return service;
	}

	public void setService(BaseServiceIface service) {
		this.service = service;
	}

	public Employee findObjectBykey(String key) {
		Object object = service.findObjectBykey(key);
		try {
			return (Employee) DataUtils.copyPoJo(object, Employee.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public List<Employee> findObjectsByCondition(ConditionBlock block, Map sortMap) {
		List list = service.findObjectsByCondition(DataUtils.changeCode(block), sortMap);
		return DataUtils.copyPoJos(list, Employee.class);
	}

	public List<Employee> getAll() {
		List list =  service.getAll();
		return DataUtils.copyPoJos(list, Employee.class);
	}

}
