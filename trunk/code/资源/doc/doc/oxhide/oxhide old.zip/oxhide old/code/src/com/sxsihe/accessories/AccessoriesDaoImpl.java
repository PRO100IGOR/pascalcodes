package com.sxsihe.accessories;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class AccessoriesDaoImpl extends HibernateDaoSupport implements AccessoriesDao {
	public void add(Accessories acc) {
		getHibernateTemplate().save(acc);
	}
	public void save(Accessories acc){
		getHibernateTemplate().saveOrUpdate(acc);
	}
	public void delete(Accessories acc) {
		getHibernateTemplate().delete(acc);
	}

	public void delete(String id) {
		getHibernateTemplate().delete(getAccessories(id));
	}

	public Accessories getAccessories(String id) {
		return (Accessories) getHibernateTemplate().load(Accessories.class, id);
	}

	public List getAccessoriesListByItem(String itemId) {
		return getHibernateTemplate().find("from Accessories acc where acc.itemId = '" + itemId + "' order by acc.uploadDate");
	}

	public List getAccessoriesNoSubmit() {
		return getHibernateTemplate().find("from Accessories acc where acc.stat = 0");
	}

	public void update(Accessories acc) {
		getHibernateTemplate().update(acc);
	}

	public List getAccessByHql(String hql, Map<String, Object> keyValue) {
		hql = "from Accessories " + hql;
		Query query = getHibernateTemplate().getSessionFactory().getCurrentSession().createQuery(hql);
		if ((keyValue != null) && (keyValue.size() != 0)) {
			Iterator iterator = keyValue.keySet().iterator();
			while (iterator.hasNext()) {
				String key = (String) iterator.next();
				try {
					Object value = keyValue.get(key);
					if (value instanceof Collection) {
						query.setParameterList(key, (Collection) value);
					} else if (value instanceof Object[]) {
						query.setParameterList(key, (Object[]) value);
					} else {
						query.setParameter(key, value);
					}

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return query.list();
	}
}