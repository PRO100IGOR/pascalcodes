package com.sxsihe.utils.net;

import com.ite.oxhide.common.util.StringUtils;
import com.sxsihe.oxhide.application.domain.Application;

/**
 * ���ݷ�����Ip��������������������IP
 * 
 * @Title: ApplicationUrl.java
 * @Package com.sxsihe.utils.net
 * @Description: TODO
 * @author �ų���
 * @date 2011-11-18 ����06:27:50
 * @version V1.0
 */
public class ApplicationUrl {
	/**
	 * �����û��ķ���ip�ж�������������
	 * 
	 * @param application
	 * @param url
	 * @return
	 */
	public static String getUrl(Application application, String ip) {
		if(StringUtils.isEmpty(ip)){
			return null;
		}
		String urln = application.getAppurl();
		if (urln.indexOf("//") == -1) {
			return urln;
		}
		if (StringUtils.isEmpty(application.getAppurlw())) {
			return urln;
		}
		urln = urln.substring(urln.indexOf("//") + 2, urln.length());
		urln = urln.substring(0, urln.indexOf(":"));
		String[] urls = urln.split("\\.");
		if (urls.length > 0) {
			urln = urls[0] + "." + urls[1];
		}
		urls = ip.split("\\.");
		if (urls.length > 0) {
			ip = urls[0] + "." + urls[1];
		}
		if (ip.equals(urln)) {
			return application.getAppurl();
		} else {
			return application.getAppurlw();
		}
	}

	/**
	 * �����û��ķ���ip�ж�������������
	 * 
	 * @param urln
	 * @param urlw
	 * @param ip
	 * @return
	 */
	public static String getUrl(Object urlno, Object urlwo, String ip) {
		if(StringUtils.isEmpty(ip)){
			return null;
		}
		String urlw = urlwo == null ? "" : urlwo.toString();
		String urln = urlno == null ? "" : urlno.toString();
		if (StringUtils.isEmpty(urlw)) {
			return urln;
		}
		if (urln.indexOf("//") > -1) {
			urln = urln.substring(urln.indexOf("//") + 2, urln.length());
		}
		if (urln.indexOf(":") > -1) {
			urln = urln.substring(0, urln.indexOf(":"));
		}
		String[] urls = urln.split("\\.");
		if (urls.length > 0) {
			urln = urls[0] + "." + urls[1];
		}
		urls = ip.split("\\.");
		if (urls.length > 0) {
			ip = urls[0] + "." + urls[1];
		}
		if (ip.equals(urln)) {
			return urlno.toString();
		} else {
			return urlwo.toString();
		}
	}
	
}
