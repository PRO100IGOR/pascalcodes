package com.sxsihe.utils.properties;

import java.io.InputStream;
import java.util.Properties;

public class Reader extends Properties {
	private String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Reader(String fileName) {
		this.setFileName(fileName);
		InputStream is = getClass().getResourceAsStream("/"+fileName);
		try {
			load(is);
			is.close();
		} catch (Exception e) {
		}
	}
}
