package com.sxsihe.oxhide.tree.organ;

import java.util.List;

import javax.servlet.jsp.PageContext;

import com.ite.oxhide.struts.menu.MenuDes;
import com.ite.oxhide.struts.menu.MenuNode;

/**
 * ��������չ
 * @author �ų���
 * TODO
 *2012����11:16:17
 */
public interface OrganExtandService {
	
	/**
	 * ����ͼ��ʾ��
	 * @param type
	 * @return
	 * Administrator
	 * com.sxsihe.oxhide.tree.organ
	 * List<MenuDes>
	 */
	public List<MenuDes> getMenuDes(String type);
	
	/**
	 * һ���Լ����������ؽڵ�
	 * @param type
	 * @param pageContext
	 * @return
	 * Administrator
	 * com.sxsihe.oxhide.tree.organ
	 * List<MenuNode>
	 */
	public List<MenuNode> getMenuNodeData(String type, PageContext pageContext); 
	
	
	/**
	 * �ֻ�������
	 * @param parentId
	 * @param parentType
	 * @param type
	 * @param pageContext
	 * @return
	 * Administrator
	 * com.sxsihe.oxhide.tree.organ
	 * List<MenuNode>
	 */
	public List<MenuNode> getMenuNodeData(String parentId, String parentType, String type, PageContext pageContext);
}
