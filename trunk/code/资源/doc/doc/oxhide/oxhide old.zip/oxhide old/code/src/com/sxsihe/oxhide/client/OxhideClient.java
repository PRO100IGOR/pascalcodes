package com.sxsihe.oxhide.client;

import java.lang.reflect.Proxy;

import org.codehaus.xfire.client.Client;
import org.codehaus.xfire.client.XFireProxy;
import org.codehaus.xfire.client.XFireProxyFactory;
import org.codehaus.xfire.service.Service;
import org.codehaus.xfire.service.binding.ObjectServiceFactory;
import org.springframework.beans.factory.FactoryBean;


public class OxhideClient implements FactoryBean {
	private String serviceInterface;
	private String wsdlDocumentUrl;
	private String serviceName;

	public String getServiceInterface() {
		return serviceInterface;
	}

	public void setServiceInterface(String serviceInterface) {
		this.serviceInterface = serviceInterface;
	}

	public String getWsdlDocumentUrl() {
		return wsdlDocumentUrl;
	}

	public void setWsdlDocumentUrl(String wsdlDocumentUrl) {
		this.wsdlDocumentUrl = wsdlDocumentUrl;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Object getObject() throws Exception {
		Service serviceModel = new ObjectServiceFactory().create(getObjectType());
		String url = this.wsdlDocumentUrl + "/" + this.serviceName;
		XFireProxyFactory factory = new XFireProxyFactory();
		Object service = factory.create(serviceModel, url);
		Client client = ((XFireProxy) Proxy.getInvocationHandler(service)).getClient();
		client.addOutHandler(new ClientHandel());
		return service;
	}

	public Class getObjectType() {
		// TODO Auto-generated method stub
		try {
			return Class.forName(this.serviceInterface);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean isSingleton() {
		// TODO Auto-generated method stub
		return false;
	}

}
