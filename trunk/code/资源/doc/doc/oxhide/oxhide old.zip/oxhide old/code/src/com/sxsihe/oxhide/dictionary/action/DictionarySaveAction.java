package com.sxsihe.oxhide.dictionary.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.dictionary.domain.Dictionary;
import com.sxsihe.oxhide.dictionary.form.DictionaryForm;
import com.sxsihe.oxhide.dictionary.service.DictionaryService;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dictionary.action.DictionarySaveAction
 * </p>
 * <p>
 * Description:�����ֵ�����SaveAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */

public class DictionarySaveAction extends BaseSaveAction {
	/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 * 
	 * @param form
	 * @return
	 */
	protected Serializable getPersisPo(ActionForm form, String type) {
		HashMap map = new HashMap();
		DictionaryForm vForm = (DictionaryForm) form;
		Dictionary po;
		if (type.equals("add"))
			po = new Dictionary();
		else {
			String did = vForm.getDid();
			po = (Dictionary) service.findObjectBykey(did);
		}

		po.setDid(vForm.getDid());
		po.setDname(vForm.getDname());
		po.setDcode(vForm.getDcode());
		po.setRemark(vForm.getRemark());
		return po;
	}

	/**
	 * ������ʵ��Ĺ���ʵ��
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form, HttpServletRequest request, String type) {
		HashMap map = new HashMap();
		Set list = new HashSet();
	}
}