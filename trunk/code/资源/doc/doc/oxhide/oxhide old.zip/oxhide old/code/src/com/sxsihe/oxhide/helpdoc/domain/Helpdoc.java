package com.sxsihe.oxhide.helpdoc.domain;

/**
 * Helpdoc entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Helpdoc implements java.io.Serializable {

	// Fields

	private String hid;
	private String hcontent;
	private String itemid;

	// Constructors

	/** default constructor */
	public Helpdoc() {
	}

	/** full constructor */
	public Helpdoc(String hcontent, String itemid) {
		this.hcontent = hcontent;
		this.itemid = itemid;
	}

	// Property accessors

	public String getHid() {
		return this.hid;
	}

	public void setHid(String hid) {
		this.hid = hid;
	}

	public String getHcontent() {
		return this.hcontent;
	}

	public void setHcontent(String hcontent) {
		this.hcontent = hcontent;
	}

	public String getItemid() {
		return this.itemid;
	}

	public void setItemid(String itemid) {
		this.itemid = itemid;
	}

}