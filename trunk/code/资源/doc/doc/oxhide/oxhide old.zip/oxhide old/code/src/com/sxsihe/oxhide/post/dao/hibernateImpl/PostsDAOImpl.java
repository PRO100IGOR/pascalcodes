package com.sxsihe.oxhide.post.dao.hibernateImpl;

import java.util.*;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;

import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.post.domain.Posts;
import com.sxsihe.oxhide.post.dao.PostsDAO;
import com.sxsihe.utils.properties.Reader;
/**
 *<p>Title:com.sxsihe.oxhide.post.dao.PostsDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class PostsDAOImpl extends BaseDAOImpl implements PostsDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Posts.class;
	   }

		/**
		 * ��ȡ���������
		 * zcc
		 * Apr 22, 2011
		 * @return
		 */
		public int getOrderNo(String deptid){

			List temp = new ArrayList();
			try {
				Reader reader = new Reader("config.properties");
				Class sqlClass = Class.forName("com.sxsihe.base.sql." + reader.getProperty("sql"));
				String sql = sqlClass.getDeclaredField("OrderForPost").get(null).toString();
				SQLQuery sqlquery = this.getSession().createSQLQuery(sql);
				sqlquery.setParameter("deptid", deptid);
				sqlquery.addScalar("nonum", Hibernate.INTEGER);
				temp = sqlquery.list();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return temp.size() > 0 ? (new Integer(temp.get(0)+"")).intValue() : 0;
		}

}