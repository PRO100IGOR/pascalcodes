package com.sxsihe.oxhide.server.users;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.message.MessageSender;
import com.sxsihe.oxhide.ssouser.service.SsouserService;

public class UserServerImpl implements UserServer {

	/**
	 * ����û��Ƿ��з���ϵͳ����Ϊappcode����Դ����ΪresourceCode����Դ override
	 *
	 * @Title: UserServerImpl.java
	 * @Package com.sxsihe.oxhide.server.users
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-19 ����02:45:35
	 * @version V1.0
	 */
	public boolean hasRescource(String userid, String appcode, String resCode) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		return ssouserService.checkUserHasResource(userid, appcode, resCode);
	}

	/**
	 * ��֤�û���¼��򵥷�ʽ
	 *
	 * @Title: UserServerImpl.java
	 * @Package com.sxsihe.oxhide.server.users
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-18 ����07:47:08
	 * @version V1.0
	 */
	public boolean loginCheck(String data) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		return !ssouserService.login(data,null).containsKey("message");
	}

	/**
	 * �û��������ն˵�¼
	 *
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-19 ����02:51:34
	 * @version V1.0
	 */
	public String login(String data) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		return ssouserService.login(data,null).toString();
	}

	/**
	 * ��������
	 *
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-19 ����06:15:23
	 * @version V1.0
	 */
	public boolean saveToken(String data) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		return ssouserService.saveToken(data);
	}

	/**
	 * �������ݣ�
	 *
	 * @Title: UserServerImpl.java
	 * @Package com.sxsihe.oxhide.server.users
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-20 ����02:55:26
	 * @version V1.0
	 */
	public String sendTokenData(String data) {
		MessageSender messageSender = (MessageSender) SpringContextUtil.getBean("messageSender");
		return messageSender.sendData(data);
	}

	/**
	 * ����������
	 *
	 * @param id
	 */
	public void unSendData(String id, String type) {
		MessageSender messageSender = (MessageSender) SpringContextUtil.getBean("messageSender");
		messageSender.unSendData(id, type);
	}
}
