var ECCNList = {};
var ECCNConstants = {};

var ECCN = function(formid) {

	var Me = this;

	ECCNList[formid] = Me;

	this.id = formid;
	this.doPrep = true;
	this.isDebug = false;
	this.doPrepPrev = true;

	this.prepState = {
		next : 0,
		prev : 0
	};
	this.prepPage = {
		next : 0,
		prev : 0
	};
	this.prepareaName = {};
	this.pageFieldName = this.id + "_p";

	this.totalPagesFieldName = this.id + "_totalpages";
	this.totalRowsFieldName = this.id + "_totalrows";

	this.prepareaName['next'] = this.id + "_ec_preparea_n";

	this.prepareaName['prev'] = this.id + "_ec_preparea_p";

	Me.buildPrepArea = function() {
		var ta = document.createElement("textarea");
		ta.id = this.prepareaName['next'];
		ta.disabled = true;
		ta.style.display = "none";
		document.body.appendChild(ta);

		var tb = document.createElement("textarea");
		tb.id = this.prepareaName['prev'];
		tb.disabled = true;
		tb.style.display = "none";
		document.body.appendChild(tb);

		/* for Debug */
		if (Me.isDebug) {
			ta.disabled = false;
			ta.style.display = "inline";
			ta.rows = 10;
			ta.cols = 50;
			tb.disabled = false;
			tb.style.display = "inline";
			tb.rows = 10;
			tb.cols = 50;
		}

	};

	Me.goPage = function() {
		var newPageNO = (document.getElementById(Me.pageFieldName) || document.getelementsByName(Me.pageFieldName)[0]).value;

		var key = null;

		if (newPageNO == Me.prepPage['next'] && Me.prepState['next'] == 2) {
			key = 'next';
		} else if (newPageNO == Me.prepPage['prev']
				&& Me.prepState['prev'] == 2 && Me.doPrepPrev) {
			key = 'prev';
		}

		if (key != null) {
			try {
			
				var newhtml = (document.getElementById(Me.prepareaName[key]) || document.getelementsByName(Me.prepareaName[key])[0]).value;
				if (newhtml == "") {
					(document.getElementById(Me.id) || document.getelementsByName(Me.id)[0]).submit();
					return;
				}
				(document.getElementById(Me.id) || document.getelementsByName(Me.id)[0]).innerHTML = newhtml;
				Me.prepState[key] = 0;
				window.setTimeout(Me.ajaxPrepSubmit, 10);
			} catch (ex) {
				(document.getElementById(Me.pageFieldName) || document.getelementsByName(Me.pageFieldName)[0]).value = newPageNO;
				Me.ajaxSubmit();
				// $(Me.id).submit();
			}
		} else {
			// $(Me.id).submit();
			Me.ajaxSubmit();
		}

	};

	Me.dealResponse = {
		'next' : function(originalRequest) {
			(document.getElementById(Me.prepareaName['next']) || document.getelementsByName(Me.prepareaName['next'])[0]).value = Me
					.cutText(originalRequest.responseText);
			Me.prepState['next'] = 2;
			Me.doingAjaxSubmit = false;
		},
		'prev' : function(originalRequest) {
			(document.getElementById(Me.prepareaName['prev']) || document.getelementsByName(Me.prepareaName['prev'])[0]).value = Me
					.cutText(originalRequest.responseText);
			Me.prepState['prev'] = 2;
			Me.doingAjaxSubmit = false;
		}
	};

	Me.cutText = function(text) {
		eval("var rex= /<" + "fo" + "rm" + ".+id=\"?" + Me.id
				+ "\"?[^>]*>/im ;");
		var mtext = text.match(rex);
		if (mtext == null) {
			return "";
		}
		text = text.substr(mtext.index + mtext[0].length);
		var end = text.indexOf("</form>");
		return text.substring(0, end);
	};

	Me.ajaxPrepSubmit = function() {
		if (!Me.doPrep) {
			return;
		}
		try {
			Me.ajaxPrep(1);
			Me.ajaxPrep(-1);
		} catch (e) {
		}
	};

	Me.ajaxPrep = function(which) {

		var key;
		if (which == 1) {
			key = 'next';
		} else if (which == -1 && Me.doPrepPrev) {
			key = 'prev';
		} else {
			return;
		}
		Me.prepState[key] = 1;


		Me.prepPage[key] =(document.getElementById(Me.pageFieldName) || document.getelementsByName(Me.pageFieldName)[0]).value / 1 + which;
		if (Me.prepPage[key] < 1
				|| Me.prepPage[key] > 		(document.getElementById(Me.totalPagesFieldName) || document.getelementsByName(Me.totalPagesFieldName)[0]).value / 1)
			return;

				(document.getElementById(Me.pageFieldName) || document.getelementsByName(Me.pageFieldName)[0]).value = Me.prepPage[key];

		Me.ajaxSubmit(Me.dealResponse[key], true);

		(document.getElementById(Me.pageFieldName) || document.getelementsByName(Me.pageFieldName)[0]).value = Me.prepPage[key] - which;
	};

	Me.init = function() {
		Me.buildPrepArea();
		Me.ajaxPrepSubmit();
	};

	Me.doingAjaxSubmit = false;
	Me.ajaxSubmit = function(resfunc, asy) {
		if ($("ajaxWaitng")) {
			$("ajaxWaitng").style.visibility = "visible";
		}

		if (!asy) {
			asy = false;
		}
		if (!resfunc) {
			resfunc = Me.fillForm;
		}
		if (!asy && Me.doingAjaxSubmit) {
			// alert("前一锟斤拷锟结交锟斤拷锟斤拷锟斤拷未锟斤拷桑锟斤拷锟斤拷院锟斤拷锟斤拷浴锟�1�??);
			// return;
		}
		Me.doingAjaxSubmit = true;

		Ajax.formSubmit(Me.id, resfunc, "post", asy);

	};
	Me.fillForm = function(originalRequest) {
		var newhtml = Me.cutText(originalRequest.responseText);

		if (newhtml == "") {
			return;
		}
				(document.getElementById(Me.id) || document.getelementsByName(Me.id)[0]).innerHTML = newhtml;
		Me.init();
		Me.doingAjaxSubmit = false;

		if ($("ajaxWaitng")) {
			$("ajaxWaitng").style.visibility = "hidden";
		}

	};
};

var EccnUtil = {};

EccnUtil.hideOrShowCol = function(obj) {
	var id = obj.id + "_c";
	col = document.getElementById(id) || document.getelementsByName(id)[0]; 
	if (col.style.display == "none") {
		col.style.display = "table-cell";
		col.setAttribute("width", obj.getAttribute("ow"));
	} else {
		col.style.display = "none";
		obj.setAttribute("ow", col.getAttribute("width"));
		col.setAttribute("width", "0");
	}

}

// EccnUtil.noExport("form锟斤拷id");

EccnUtil.noExport = function(formid, etiid) {
	if (!etiid) {
		etiid = "eti";
	}
	var form = document.getElementById(formid);
	try {
		form[etiid].value = "";
	} catch (e) {
	}

}

EccnUtil.refresh = function(formid) {
	var form = document.getElementById(formid);
	try {
		form[formid + "_totalrows"].value = "";
	} catch (e) {
	}
}

EccnUtil.gotoPage = function(formid, action, method, pageid, etiid, pageno) {
	var form = document.getElementById(formid);
	form.setAttribute('action', action);
	form.setAttribute('method', method);
	form[pageid].value = pageno;
	EccnUtil.noExport(formid, etiid);
	XqTipOpen("ҳ�������,���Ժ�");
	try {
		if (ECCNList[formid].doPrep) {
			ECCNList[formid].goPage();
		} else {
			ECCNList[formid].ajaxSubmit();
		}
	} catch (e) {
		try {
			ECCNList[formid].ajaxSubmit();
		} catch (e2) {
			form.submit();
		}
	}
}

EccnUtil.gotoPageByInput = function(formid, action, method, pageid, etiid,
		inputid) {

	var form = document.getElementById(formid);
	var pageno = form[inputid].value / 1;
	var totalpages = form[formid + "_totalpages"].value / 1;
	if (!isFinite(pageno) || (pageno + "").indexOf(".") != -1 || pageno < 1
			|| pageno > totalpages) {
		form[inputid].focus();
		form[inputid].select();
		return;
	}
	if (pageno < 1) {
		pageno = 1;
	}

	EccnUtil.gotoPage(formid, action, method, pageid, etiid, pageno);

}

EccnUtil.doExportList = function(formid, fileName) {
	var action = document.getElementById(formid).getAttribute('action');
	var method = "post";
	var etiid = "eti";
	var type = "xls";
	EccnUtil.doExport(formid, action, method, etiid, type, fileName)
}

// EccnUtil.doExport('list1','/ec/query.do?actionMethod=query2','post','eti','xls','1锟斤拷test.xls')
EccnUtil.doExport = function(formid, action, method, etiid, type, fileName) {
	var form = document.getElementById(formid);
	form[formid + "_ev"].value = type;
	form[formid + "_efn"].value = fileName;
	form[etiid].value = formid;
	form.setAttribute('action', action);
	form.setAttribute('method', method);
	form.submit();
	EccnUtil.noExport(formid, etiid);
};

EccnUtil.changeRowsDisplayed = function(formid, action, method, pageid, etiid,
		selectObj) {
	var form =document.getElementById(formid) || document.getelementsByName(formid)[0]; 
	form[formid + "_crd"].value = selectObj.options[selectObj.selectedIndex].value;
	form[pageid].value = '1';
	form.setAttribute('action', action);
	form.setAttribute('method', method);
	EccnUtil.noExport(formid, etiid);
	try {
		ECCNList[formid].ajaxSubmit();
	} catch (e2) {
		form.submit();
	}
};
EccnUtil.checkAll = function(formid, checkboxname, checkcontrol) {
	var form =document.getElementById(formid) || document.getelementsByName(formid)[0]; 
	
	if (form.elements[checkboxname] != undefined)
		if (form.elements[checkboxname].length)
			for (i = 0; i < form.elements[checkboxname].length; i++) {
				if (form.elements[checkboxname].item(i).disabled == false)
					form.elements[checkboxname].item(i).checked = form.elements[checkcontrol].checked;
			}
		else {
			if (form.elements[checkboxname].disabled == false)
				form.elements[checkboxname].checked = form.elements[checkcontrol].checked;
		}
};

function synData(obj) {
	document.forms.ec.elements[obj.name].value = obj.value;
}
function initAdvenceSelect() {
	function getNext(obj) {
		var result = obj.nextSibling;
		while (!result.tagName) {
			result = result.nextSibling;
		}
		return result;
	}

	function getChild(obj) {
		for (var i = 0; i < obj.childNodes.length; i++) {
			if (obj.childNodes[i].tagName == "INPUT") {
				return obj.childNodes[i];
			}
		}
	}

	if (document.getElementById("ec_EC_FITER_TABLE2")) {
		var tr = document.getElementById("ec_EC_FITER_TABLE2");
		var tr2 = getNext(tr);
		var table = "<table class=\"list-tables\" style='width:400px;' cellspacing=0  cellpadding=0>";
		var h = 0;
		for (var i = 0; i < tr.cells.length; i++) {
			var temp = getChild(tr.cells[i]);
			if (temp) {
				table += "<tr>";
				table += "<td align=\"right\" class=\"list-lhead\">";
				table +=  tr2.cells[i].innerHTML + "��";
				table += "</td>";
				h += 30;
				table += "<td align=\"left\">";
				table += "<input type=\"text\"  onfocus=\"this.className='list-textclick'\" onblur=\"this.className='list-text'\"  class=\"list-text\" size=40 name=\"" + temp.name
						+ "\" value= \"" + temp.value
						+ "\"   onchange= \"synData(this)\"  /> ";
				table += "</td>";
				table += "</tr>";
			}
		}
		table += "</table>";
		window.advce = table;
		if (h > 0) {
			var b = document.getElementById("cxbutton");
			if(b)b = b.parentNode;
			else{
				return;
			}
			var btn = document.createElement("input");
			btn.type = "button";
			btn.className = "cx-button";
			btn.setAttribute("onmouseover", "this.className='cx-button-over'");
			btn.setAttribute("onmouseout", "this.className='cx-button'");
			btn.value = "�߼���ѯ";
			btn.onclick = function() {
				var temp = htmlWin({
							html : window.advce,
							title : "�߼���ѯ",
							cover : "yes",
							width : 450,
							height:300,
							canelBtnTxt : "�ر�",
							fns : [{
								name : "���",
								fn : function() {
									temp.cancel();
									XqTipOpen('ҳ�������,���Ժ�');
									document.getElementById("ecClear").click();
								}
							}, {
								name : "ȷ��",
								fn : function() {
									temp.cancel();
									XqTipOpen('ҳ�������,���Ժ�');
									document.getElementById("ecFilter").click();
								}
							}]
						});
			};
			b.appendChild(btn);

		}

	}
}
if (!-[1,])
	window.attachEvent("onload", initAdvenceSelect);
else
	window.addEventListener("load", initAdvenceSelect, false);
