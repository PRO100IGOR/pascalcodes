package com.sxsihe.coder.tables.action;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.coder.columns.domain.Columns;
import com.sxsihe.coder.columns.service.ColumnsService;
import com.sxsihe.coder.dataid.domain.Dataid;
import com.sxsihe.coder.dataid.service.DataidService;
import com.sxsihe.coder.datas.domain.Datas;
import com.sxsihe.coder.datas.service.DatasService;
import com.sxsihe.coder.sels.domain.Sels;
import com.sxsihe.coder.sels.service.SelsService;
import com.sxsihe.coder.tables.domain.Tables;
import com.sxsihe.coder.tables.service.TablesService;
import com.sxsihe.coder.util.ColumnSort;
import com.sxsihe.oxhide.server.resource.ResourceServer;
import com.sxsihe.utils.common.CharsetSwitch;
import com.sxsihe.utils.common.RandomGUID;
import com.sxsihe.utils.system.SystemLogHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class TablesSaveAction extends BaseSaveAction {
	private SelsService selsService;
	private ColumnsService columnsService;
	private ResourceServer resourceServer;
	private DataidService dataidService;
	private DatasService datasService;

	public DatasService getDatasService() {
		return this.datasService;
	}

	public void setDatasService(DatasService datasService) {
		this.datasService = datasService;
	}

	public DataidService getDataidService() {
		return this.dataidService;
	}

	public void setDataidService(DataidService dataidService) {
		this.dataidService = dataidService;
	}

	public ResourceServer getResourceServer() {
		return this.resourceServer;
	}

	public void setResourceServer(ResourceServer resourceServer) {
		this.resourceServer = resourceServer;
	}

	public SelsService getSelsService() {
		return this.selsService;
	}

	public void setSelsService(SelsService selsService) {
		this.selsService = selsService;
	}

	public ColumnsService getColumnsService() {
		return this.columnsService;
	}

	public void setColumnsService(ColumnsService columnsService) {
		this.columnsService = columnsService;
	}

	public ActionForward saveCoder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		boolean is = repeatSubmit(mapping, form, request);
		if (is) {
			return mapping.findForward("showSave");
		}
		SystemLogHelper.addLog(request, "�޸Ļ�����һ����¼", "1", "");
		JSONObject json = JSONObject.fromObject(request.getParameter("values"));
		String tablecode = request.getParameter("table");
		Tables tables = (Tables) getService().findObjectBykey(tablecode);
		List list = new ArrayList();
		String dtid = json.getString("dtid");
		Dataid dataid = (Dataid) this.dataidService.findObjectBykey(dtid);
		if (dataid == null) {
			dataid = new Dataid();
			dataid.setDtid(json.getString("dtid"));
			dataid.setTables(tables);
		} else {
			String hql = "from Datas d where d.dataid.dtid = '" + dtid + "'";
			this.datasService.deleteBatch(this.datasService.queryHql(hql, null));
		}
		if (json.has("pdataid")) {
			Dataid dataidParent = new Dataid();
			dataidParent.setDtid(json.getString("pdataid"));
			dataid.setDataid(dataidParent);
		}
		this.datasService.save(dataid);
		for (Iterator iterator = tables.getCols().iterator(); iterator.hasNext();) {
			Columns columns = (Columns) iterator.next();
			Datas datas = new Datas();
			datas.setColumns(columns);
			datas.setDataid(dataid);
			datas.setDvalue(json.getString(columns.getCcode()));
			list.add(datas);
		}

		this.datasService.saveBatch(list);

		String submit = json.getString("isSaveAndAdd");
		if ("true".equals(submit)) {
			saveToken(request);
			String uri = request.getRequestURI();
			uri = uri.replaceAll("Save", "Show").replaceAll(request.getContextPath(), "") + "?action=add&table=" + tablecode;
			Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("����ɹ���"));
			response.addCookie(cookie);
			return new ActionForward(uri);
		}
		request.setAttribute("isSaveAndAdd", Boolean.valueOf(true));
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	public String savePlug(HttpServletRequest request) {
		JSONObject json = JSONObject.fromObject(request.getParameter("values"));

		String tablecode = request.getParameter("table");
		if ((StringUtils.isEmpty(tablecode)) && (request.getAttribute("table") != null)) {
			tablecode = request.getAttribute("table") + "";
		}

		if (StringUtils.isEmpty(tablecode))
			return null;

		Tables tables = (Tables) getService().findObjectBykey(tablecode);
		if (tables == null) {
			return null;
		}
		List list = new ArrayList();
		String dtid = json.getString("dtid");
		Dataid dataid = (Dataid) this.dataidService.findObjectBykey(dtid);
		if (dataid == null) {
			dataid = new Dataid();
			dataid.setDtid(json.getString("dtid"));
			dataid.setTables(tables);
		} else {
			String hql = "from Datas d where d.dataid.dtid = '" + dtid + "'";
			this.datasService.deleteBatch(this.datasService.queryHql(hql, null));
		}
		if (json.has("pdataid")) {
			Dataid dataidParent = new Dataid();
			dataidParent.setDtid(json.getString("pdataid"));
			dataid.setDataid(dataidParent);
		}
		String hql = "from Columns c where c.tables.tid = '" + tables.getTid() + "' order by c.orderno asc";
		List listColumns = this.columnsService.queryHql(hql, null);
		for (Iterator iterator = listColumns.iterator(); iterator.hasNext();) {
			Columns columns = (Columns) iterator.next();
			Datas datas = new Datas();
			datas.setColumns(columns);
			datas.setDataid(dataid);
			datas.setDvalue(json.getString(columns.getCcode()));
			list.add(datas);
		}
		this.datasService.save(dataid);
		this.datasService.saveBatch(list);
		return dtid;
	}

	public ActionForward save(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		boolean is = repeatSubmit(mapping, form, request);
		if (is) {
			return mapping.findForward("showSave");
		}
		SystemLogHelper.addLog(request, "�޸Ļ�����һ����¼", "1", "");
		JSONObject json = JSONObject.fromObject(request.getParameter("main"));
		Tables tables = (Tables) JSONObject.toBean(json, Tables.class);
		getService().deleteByKey(tables.getTid());
		if (StringUtils.isNotEmpty(tables.getPtid())) {
			Tables parentTables = new Tables();
			parentTables.setTid(tables.getPtid());
			tables.setTables(parentTables);
		}
		if (StringUtils.isNotEmpty(tables.getMenu())) {
			if (StringUtils.isEmpty(tables.getMenuid())) {
				tables.setMenuid(RandomGUID.getGUID().replaceAll("-", ""));
			}
			if (StringUtils.isNotEmpty(tables.getApplication())) {
				this.resourceServer.add(CharsetSwitch.encode(tables.getMenu()), tables.getMenuid(), tables.getApplicationid(), tables.getModelid(), "/tablesLoadAction.do?action=list&table=" + tables.getTid());
			}
		}
		getService().save(tables);
		
		JSONArray jsonArray = JSONArray.fromObject(request.getParameter("cols"));
		List cols = JSONArray.toList(jsonArray, Columns.class);
		List list = new ArrayList();
		Collections.sort(cols, new ColumnSort());
		jsonArray = JSONArray.fromObject(request.getParameter("sels"));
		List sels = JSONArray.toList(jsonArray, Sels.class);
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("create or replace view ");
		stringBuilder.append(tables.getTcode() + "_view as ");
		stringBuilder.append("select ");
		for (int i = 0; i < cols.size(); ++i) {
			Columns columns = (Columns) cols.get(i);
			if (columns.getCid().equals(tables.getMaincol()))
				columns.setIsmain("1");
			else {
				columns.setIsmain("0");
			}
			if ((StringUtils.isEmpty(columns.getRule())) || (columns.getRule().indexOf("must") == -1))
				columns.setIsmust("0");
			else {
				columns.setIsmust("1");
			}
			columns.setTables(tables);
			if (columns.getIsshow().equals("1")) {
				stringBuilder.append("(select da.dvalue from datas da where da.dtid = di.dtid and da.cid = '");
				stringBuilder.append(columns.getCid());
				stringBuilder.append("') as ");
				stringBuilder.append(columns.getCcode());
				stringBuilder.append(",");
			}
			list.add(columns);
		}
		stringBuilder.append(" di.dtid ");
		stringBuilder.append("from dataid  di where di.tid = '");
		stringBuilder.append(tables.getTid());
		stringBuilder.append("'");

		this.columnsService.saveBatch(list);

		list = new ArrayList();
		for (int i = 0; i < sels.size(); i++) {
			Sels selsone = (Sels) sels.get(i);
			selsone.setTables(tables);
			Columns columns = new Columns();
			columns.setCid(selsone.getCid());
			selsone.setColumns(columns);
			list.add(selsone);
		}
		this.selsService.saveBatch(list);
		request.setAttribute("isSaveAndAdd", Boolean.valueOf(true));
		try {
			((TablesService) getService()).execSql(stringBuilder.toString());
		} catch (Exception localException) {
		}

		return new ActionForward("/core/success/opSuccess.jsp");
	}
}