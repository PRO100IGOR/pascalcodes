package com.sxsihe.utils.tld;

import javax.servlet.jsp.tagext.BodyTagSupport;
import com.sxsihe.oxhide.server.users.UserServer;
import com.ite.oxhide.spring.SpringContextUtil;

/**
 * ��ѯ��¼���Ƿ���Ȩ�޷���ĳ����ť
 * @author �ų���
 *
 */
public class Resource extends BodyTagSupport {
	private String resCode;
	private String appCode;
	private String userid;


	public String getResCode() {
		return resCode;
	}

	public void setResCode(String resCode) {
		this.resCode = resCode;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}


	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public int doStartTag() {
		UserServer userServer = (UserServer) SpringContextUtil.getBean("userClient");
		boolean has = false;
		has = userServer.hasRescource(userid, appCode, resCode);
		if (has) {
			return EVAL_BODY_INCLUDE;
		} else {
			return SKIP_PAGE;
		}
	}
}
