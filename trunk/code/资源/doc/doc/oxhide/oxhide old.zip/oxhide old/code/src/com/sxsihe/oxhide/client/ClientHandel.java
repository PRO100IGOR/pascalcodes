package com.sxsihe.oxhide.client;
import org.codehaus.xfire.MessageContext;
import org.codehaus.xfire.handler.AbstractHandler;
import org.jdom.Element;
import org.jdom.Namespace;

public class ClientHandel extends AbstractHandler {
	public void invoke(MessageContext messageContext) throws Exception {
		Namespace ns = Namespace.getNamespace("iteflatfrom", "http://www.ite.com.cn");
		Element el = new Element("header", ns);
		Element auth = new Element("AuthenticationToken", ns);
		Element username_el = new Element("Username", ns);
		username_el.addContent("ssowbauthenticname");
		Element password_el = new Element("Password", ns);
		password_el.addContent("swk19790228");
		auth.addContent(username_el);
		auth.addContent(password_el);
		el.addContent(auth);
		messageContext.getCurrentMessage().setHeader(el);
	}
}
