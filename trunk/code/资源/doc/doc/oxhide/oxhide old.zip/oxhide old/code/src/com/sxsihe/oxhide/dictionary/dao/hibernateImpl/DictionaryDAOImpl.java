package com.sxsihe.oxhide.dictionary.dao.hibernateImpl;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.dictionary.domain.Dictionary;
import com.sxsihe.oxhide.dictionary.dao.DictionaryDAO;
/**
 *<p>Title:com.sxsihe.oxhide.dictionary.dao.DictionaryDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class DictionaryDAOImpl extends BaseDAOImpl implements DictionaryDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Dictionary.class;
	   }
}