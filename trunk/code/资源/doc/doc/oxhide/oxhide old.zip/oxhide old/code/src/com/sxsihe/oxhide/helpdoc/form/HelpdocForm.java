package com.sxsihe.oxhide.helpdoc.form;
import com.ite.oxhide.struts.form.BaseForm;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.helpdoc.form.HelpdocForm</p>
 * <p>Description:helpdoc����form</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-09-28
 * @modify
 * @date
 */
 public class HelpdocForm extends BaseForm {
	private String hid;
	public void setHid(String hid) {
		this.hid = hid;
	}
	public String getHid() {
		return this.hid;
	}
	private String hcontent;
	public void setHcontent(String hcontent) {
		this.hcontent = hcontent;
	}
	public String getHcontent() {
		return this.hcontent;
	}
	private String itemid;
	public void setItemid(String itemid) {
		this.itemid = itemid;
	}
	public String getItemid() {
		return this.itemid;
	}
	}
	