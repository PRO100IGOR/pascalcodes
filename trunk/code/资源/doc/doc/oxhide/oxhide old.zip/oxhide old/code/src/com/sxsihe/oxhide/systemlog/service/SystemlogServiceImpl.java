package com.sxsihe.oxhide.systemlog.service;

import com.ite.oxhide.service.BaseServiceImpl;

/**
 * <p>
 * Title:com.sxsihe.oxhide.systemlog.service.LogServiceImpl
 * </p>
 * <p>
 * Description:Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author
 * @version 1.0
 * @date 2011-07-08
 * 
 * @modify
 * @date
 */
public class SystemlogServiceImpl extends BaseServiceImpl implements SystemlogService {

}