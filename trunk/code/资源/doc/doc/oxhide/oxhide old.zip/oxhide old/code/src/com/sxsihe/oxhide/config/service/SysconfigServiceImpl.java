package com.sxsihe.oxhide.config.service;

import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import com.ite.oxhide.persistence.BaseDAOIface;
import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.config.domain.Sysconfig;
import com.sxsihe.oxhide.message.android.AndroidService;
import com.sxsihe.oxhide.message.mobile.MobileService;

/**
 * 
 * <p>
 * Title:com.sxsihe.oxhide.config.service.SysconfigServiceImpl
 * </p>
 * <p>
 * Description:���÷���ʵ��
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Company: �ĺ�
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2012-02-15
 * @modify
 * @date
 */
public class SysconfigServiceImpl extends BaseServiceImpl implements SysconfigService {
	public static JSONObject configs;
	private MobileService mobile;
	private AndroidService android;

	public static JSONObject getConfigs() {
		return configs;
	}

	public static void setConfigs(JSONObject configs) {
		SysconfigServiceImpl.configs = configs;
	}

	public MobileService getMobile() {
		return mobile;
	}

	public void setMobile(MobileService mobile) {
		this.mobile = mobile;
	}

	public AndroidService getAndroid() {
		return android;
	}

	public void setAndroid(AndroidService android) {
		this.android = android;
	}

	public void setDao(BaseDAOIface dao) {
		super.setDao(dao);
		initData();
		init();
	}

	/**
	 * ��������
	 * 
	 * @param code
	 * @return Administrator com.sxsihe.oxhide.config.service SysconfigServiceImpl.java 2012����4:08:09 oxhide
	 */
	public void saveConfig(String code, String value) {
		this.save(new Sysconfig(code, value));
		configs.put(code, value);
	}

	/**
	 * ��ʼ�����ݲ���
	 * 
	 * Administrator com.sxsihe.oxhide.config.service SysconfigServiceImpl.java 2012����10:49:36 oxhide
	 */
	public void initData() {
		List list = this.getAll();
		if (list.size() == 0) {
			list.add(new Sysconfig("baselogin", "/login/login.jsp"));
			list.add(new Sysconfig("basesession", "120"));
			list.add(new Sysconfig("smsopen", "0"));
			list.add(new Sysconfig("smstime", "30000"));
			list.add(new Sysconfig("smscom", "COM3"));
			list.add(new Sysconfig("smsbaud", "9600"));
			list.add(new Sysconfig("smsdevname", "modem.com1"));
			list.add(new Sysconfig("smswavetype", "wavecom"));
			list.add(new Sysconfig("smspin", ""));
			list.add(new Sysconfig("smstail", "����Ϣ����<title>,����ȡ�����ģ���ظ�QX<code>"));
			list.add(new Sysconfig("androidopen", "0"));
			list.add(new Sysconfig("androidport", "5186"));
			this.saveBatch(list);
		}
		configs = JSONObject.fromArray(Sysconfig.class, list, "scode", "svalue", false);
	}
 
	/**
	 * ��ʼ����Ҫ�߳�
	 * 
	 * Administrator com.sxsihe.oxhide.config.service SysconfigServiceImpl.java 2012����11:32:44 oxhide
	 */
	public void init() {
		// ����è��
		if ("1".equals(configs.get("smsopen"))) {
			mobile.start();
		}
		// ��׿������
		if ("1".equals(configs.get("androidopen"))) {
			android.start();
		}
	}

}
