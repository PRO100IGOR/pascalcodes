package com.sxsihe.oxhide.post.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.post.form.PostConditionForm
 * </p>
 * <p>
 * Description:��λ
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class PostConditionForm extends BaseForm {
	/* ��λ���� */
	private String cpostname;

	public void setCpostname(String cpostname) {
		this.cpostname = cpostname;
	}

	public String getCpostname() {
		return this.cpostname;
	}

	private String cdeptid;

	public String getCdeptid() {
		return cdeptid;
	}

	public void setCdeptid(String cdeptid) {
		this.cdeptid = cdeptid;
	}
	
	private String corganid;

	public String getCorganid() {
		return corganid;
	}

	public void setCorganid(String corganid) {
		this.corganid = corganid;
	}

}
