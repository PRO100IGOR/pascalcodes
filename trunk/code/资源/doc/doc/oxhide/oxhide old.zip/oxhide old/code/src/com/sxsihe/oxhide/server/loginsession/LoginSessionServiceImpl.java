package com.sxsihe.oxhide.server.loginsession;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.login.domain.UserSession;
import com.sxsihe.oxhide.login.service.SessionHouse;

public class LoginSessionServiceImpl implements LoginSessionService {

	public UserSession getSession(String sessionid, String userid) {
		// TODO Auto-generated method stub
		SessionHouse sessionHouse = (SessionHouse) SpringContextUtil.getBean("sessionHouse");
		UserSession userSession = sessionHouse.getUserSessionByUserid(userid);
		if (userSession == null)
			userSession = sessionHouse.getUserSessionBySid(sessionid);
		return userSession;
	}

}
