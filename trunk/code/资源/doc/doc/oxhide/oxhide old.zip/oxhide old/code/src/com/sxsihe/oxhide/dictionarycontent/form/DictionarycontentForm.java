package com.sxsihe.oxhide.dictionarycontent.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dictionarycontent.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:�����ֵ�
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class DictionarycontentForm extends BaseForm {
	/* dcid */
	private String dcid;
	private String dcode;
	private String remark;
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public void setDcid(String dcid) {
		this.dcid = dcid;
	}

	public String getDcid() {
		return this.dcid;
	}

	/* ���� */
	private String dcvalue;

	public void setDcvalue(String dcvalue) {
		this.dcvalue = dcvalue;
	}

	public String getDcvalue() {
		return this.dcvalue;
	}

	private String did;

	public String getDcode() {
		return dcode;
	}

	public void setDcode(String dcode) {
		this.dcode = dcode;
	}

	public String getDid() {
		return did;
	}

	public void setDid(String did) {
		this.did = did;
	}

}
