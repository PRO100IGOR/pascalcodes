package com.sxsihe.oxhide.message.apple;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import net.sf.json.JSONObject;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.spring.SpringContextUtil;
import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsService;
import com.notnoop.apns.PayloadBuilder;
import com.sxsihe.accessories.Accessories;
import com.sxsihe.accessories.AccessoriesService;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.message.MessageBaseServiceImpl;
import com.sxsihe.oxhide.message.Sender;
import com.sxsihe.oxhide.message.token.domain.Tokens;

import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.utils.common.DateUtils;
import com.sxsihe.utils.common.RandomGUID;

public class AppleService extends MessageBaseServiceImpl {
	private static Map<String, SenderThread> sendThreads = new HashMap<String, SenderThread>();
	private static Map<String, ApnsService> apnServices = new HashMap<String, ApnsService>();
	public static Executor executor = Executors.newCachedThreadPool();

	public String sendData(JSONObject param, Application application, Resources resources, List users) {
		AccessoriesService accessService = (AccessoriesService) SpringContextUtil.getBean("accessService");
		List list = accessService.getAccessoriesListByItem(application.getAppid() + "_apple");
		if (list.isEmpty()) {
			return "�������ϵͳû��֤�飡";
		}
		Accessories accessories = (Accessories) list.get(0);
		String path = System.getProperty("cc.root") + accessories.getPath();
		File cert = new File(path);
		if (!cert.exists()) {
			return "�������ϵͳ��֤���Ѿ���ɾ����";
		}
		PayloadBuilder payloadBuilder = null;
		String payload = null;
		if (param.has("map")) {
			Map<String, ?> map = (Map) JSONObject.toBean(param.getJSONObject("map"), Map.class);
			payloadBuilder = APNS.newPayload().badge(1).alertBody(param.getString("info")).actionKey("�鿴").sound("Voicemail.caf").customFields(map);
		} else {
			payloadBuilder = APNS.newPayload().badge(1).alertBody(param.getString("info")).actionKey("�鿴").sound("Voicemail.caf");
		}

		if (application.getTimeenable().equals("1")) {
			SenderThread senderThread = sendThreads.get(application.getAppcode());
			if (senderThread == null) {
				senderThread = new SenderThread();
				senderThread.setSenderManger(this.getSenderManger());
				senderThread.setTime(Integer.valueOf(application.getTimer()) * 60 * 1000);
				senderThread.setAppcode(application.getAppcode());
				ApnsService service = apnServices.get(application.getAppcode());
				if (service == null) {
					if (application.getApplekf().equals("1")) {
						service = APNS.newService().withCert(path, application.getApplekey()).withSandboxDestination().build();
					} else {
						service = APNS.newService().withCert(path, application.getApplekey()).withProductionDestination().build();
					}
					apnServices.put(application.getAppcode(), service);
				}
				senderThread.setService(service);
				sendThreads.put(application.getAppcode(), senderThread);
				senderThread.start();
			} else if (StringUtils.isEmpty(senderThread.getAppcode())) {
				senderThread.setAppcode(application.getAppcode());
			}
		}
		String hql = "from Tokens t where t.application.appid = :appid and t.ssousers.userid = :userid and t.tokentype = 'apple'";
		Map map = new HashMap();
		int count = 0;
		for (int i = 0; i < users.size(); i++) {
			Ssousers ssousers = (Ssousers) list.get(i);
			map.put("appid", application.getAppid());
			map.put("userid", ssousers.getUserid());
			List temp = this.getSsouserService().queryHql(hql, map);
			if (!temp.isEmpty()) {
				count++;
				Tokens tokensTemp = (Tokens) temp.get(0);
				Sender sender = new Sender();
				sender.setAppcode(application.getAppcode());
				sender.setId(RandomGUID.getGUID().replaceAll("-", ""));
				sender.setIskf(Integer.valueOf(application.getApplekf()));
				sender.setTimes(0);
				sender.setTimestotal(Integer.valueOf(application.getTimes()));
				sender.setToken(tokensTemp.getToken());
				sender.setUserid(tokensTemp.getSsousers().getUserid());
				sender.setDateTime(DateUtils.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
				sender.setAppid(application.getAppid());
				if (resources != null)
					sender.setRid(resources.getResourceid());
				sender.setTarget(param.getString("target", ""));
				payloadBuilder.customField("id", sender.getId());
				payload = payloadBuilder.build();
				sender.setMessage(payload);
				this.getSenderManger().addApple(sender);
				SenderThreadHelper senderThreadHelper = new SenderThreadHelper(sender);
				ApnsService service = apnServices.get(application.getAppcode());
				if (service == null) {
					if (application.getApplekf().equals("1")) {
						service = APNS.newService().withCert(path, application.getApplekey()).withSandboxDestination().build();
					} else {
						service = APNS.newService().withCert(path, application.getApplekey()).withProductionDestination().build();
					}
					apnServices.put(application.getAppcode(), service);
				}
				senderThreadHelper.setService(service);
				executor.execute(senderThreadHelper);
			}
		}
		return count + "���û����ͳɹ���" + (users.size() - count) + "���û�ʧ��";
	}

	public List getSenders(String appcode) {
		List list = this.getSenderManger().getApples(appcode);
		for (int i = 0; i < list.size(); i++) {
			Sender sender = (Sender) list.get(i);
			sender.setSsousers((Ssousers) this.getSsouserService().findObjectBykey(sender.getUserid()));
		}
		return list;
	}

	public Sender getSenderById(String id) {
		return this.getSenderManger().getAppleById(id);
	}

	public void delSender(String id) {
		this.getSenderManger().delApple(id);
	}

	public void delAllSender(String appcode) {
		this.getSenderManger().delAllApple(appcode);
	}

}
