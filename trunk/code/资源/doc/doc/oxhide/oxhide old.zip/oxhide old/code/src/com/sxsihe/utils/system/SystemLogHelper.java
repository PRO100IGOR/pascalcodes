package com.sxsihe.utils.system;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.login.domain.UserSession;
import com.sxsihe.oxhide.server.systemlog.SystemlogServer;
import com.sxsihe.oxhide.systemlog.domain.Systemlog;
import com.sxsihe.utils.common.CharsetSwitch;
import com.sxsihe.utils.common.DateUtils;

public class SystemLogHelper {
	/**
	 * ������־
	 * 
	 * @param request
	 * @param context
	 */
	public static void addLog(HttpServletRequest request, String context, String type, String remark) {
		try {
			Systemlog systemlog = new Systemlog();
			String path = request.getRequestURI();
			if (path.indexOf("/") != -1) {
				path = path.substring(path.lastIndexOf("/"), path.length() > 1 ? path.length() : 0);
			}
			systemlog.setOperateTime(DateUtils.formatDate(new Date(), "yyyy-MM-dd HH:mm:ss"));
			systemlog.setOperateSys(path);
			systemlog.setOperateType(type);
			UserSession userSession = (UserSession) request.getSession().getAttribute("USERSESSION");
			if (userSession != null) {
				systemlog.setOperatePerson(CharsetSwitch.encode(userSession.getUsername()));
				systemlog.setOperateEmp(CharsetSwitch.encode(userSession.getEmployeename()));
			}
			systemlog.setOperateContent(CharsetSwitch.encode(context));
			systemlog.setRemark(CharsetSwitch.encode(remark));
			SystemlogServer systemlogServer = (SystemlogServer) SpringContextUtil.getBean("systemlogClient");
			systemlog.setOperateIp(NetUnit.getIpAddr(request));
			systemlogServer.add(systemlog);
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("��־д��ʧ�ܣ�");
		}

	}
}
