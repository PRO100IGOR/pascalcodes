package com.sxsihe.coder.tables.domain;

import java.util.HashSet;
import java.util.Set;

/**
 * Tables entity. @author MyEclipse Persistence Tools
 */

public class Tables implements java.io.Serializable {

	// Fields

	private String tid;
	private String ptid;
	private String tcode;
	private String tname;
	private String remark;
	private String maincol;
	private Tables tables;
	private String menuid;
	private String menu;
	private String modelid;
	private String applicationid;
	private String tpid;
	private String model;
	private String application;
	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getTpid() {
		return tpid;
	}

	public void setTpid(String tpid) {
		this.tpid = tpid;
	}

	public String getMenu() {
		return menu;
	}

	public void setMenu(String menu) {
		this.menu = menu;
	}

	public String getModelid() {
		return modelid;
	}

	public void setModelid(String modelid) {
		this.modelid = modelid;
	}

	public String getApplicationid() {
		return applicationid;
	}

	public void setApplicationid(String applicationid) {
		this.applicationid = applicationid;
	}

	public String getMenuid() {
		return menuid;
	}

	public void setMenuid(String menuid) {
		this.menuid = menuid;
	}

	private Set tablees = new HashSet(0);
	private Set dataids = new HashSet(0);
	private Set sels = new HashSet(0);
	private Set cols = new HashSet(0);
	// Constructors

	public Set getSels() {
		return sels;
	}

	public void setSels(Set sels) {
		this.sels = sels;
	}

	public Set getCols() {
		return cols;
	}

	public void setCols(Set cols) {
		this.cols = cols;
	}

	public Set getDataids() {
		return dataids;
	}

	public void setDataids(Set dataids) {
		this.dataids = dataids;
	}

	public Tables getTables() {
		return tables;
	}

	public void setTables(Tables tables) {
		this.tables = tables;
	}

	public Set getTablees() {
		return tablees;
	}

	public void setTablees(Set tablees) {
		this.tablees = tablees;
	}

	/** default constructor */
	public Tables() {
	}

	/** full constructor */
	public Tables(String ptid, String tcode, String tname, String remark, String maincol) {
		this.ptid = ptid;
		this.tcode = tcode;
		this.tname = tname;
		this.remark = remark;
		this.maincol = maincol;
	}

	// Property accessors

	public String getTid() {
		return this.tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}

	public String getPtid() {
		return this.ptid;
	}

	public void setPtid(String ptid) {
		this.ptid = ptid;
	}

	public String getTcode() {
		return this.tcode;
	}

	public void setTcode(String tcode) {
		this.tcode = tcode;
	}

	public String getTname() {
		return this.tname;
	}

	public void setTname(String tname) {
		this.tname = tname;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}


	public String getMaincol() {
		return this.maincol;
	}

	public void setMaincol(String maincol) {
		this.maincol = maincol;
	}

}