package com.sxsihe.oxhide.dictionarycontent.service;

import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.struts.menu.MenuDataPick;
import org.apache.commons.beanutils.PropertyUtils;
import com.sxsihe.oxhide.dictionarycontent.domain.Dictionarycontent;
import com.ite.oxhide.common.util.*;
import java.util.*;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dictionarycontent.service.DictionarycontentServiceImpl
 * </p>
 * <p>
 * Description:�����ֵ�Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class DictionarycontentServiceImpl extends BaseServiceImpl implements DictionarycontentService {
	
}