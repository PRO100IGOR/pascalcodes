package com.sxsihe.oxhide.login.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sxsihe.oxhide.login.domain.UserSession;

public class SessionHouse {
	private Connection connection;

	public SessionHouse() {
		PreparedStatement preparedStatement = null;
		try {
			Class.forName("org.hsqldb.jdbc.JDBCDriver");
			this.connection = DriverManager.getConnection("jdbc:hsqldb:mem:aname", "sa", "");
			String sql = "create table usersessions (id varchar(100),userid varchar(32)," + "username varchar(32),organid varchar(32),organname varchar(32),"
					+ "deptname varchar(32), deptid varchar(32), postid  varchar(32), " + "postname varchar(32),employeename varchar(32), employeeid varchar(32),"
					+ "sex varchar(2),birthday varchar(32),facestyle varchar(32),ip varchar(32)," + "createTime varchar(32),password varchar(32),"
					+ "emailPassword varchar(32),email varchar(32),logintype varchar(32),dialog varchar(10),loginTime varchar(19))";
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			sql = "create table scriptsessions (uid varchar(32),scriptid varchar(100),sid varchar(100))";
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void addSession(UserSession userSession) {
		String sql = "insert into usersessions values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, userSession.getId());
			preparedStatement.setString(2, userSession.getUserid());
			preparedStatement.setString(3, userSession.getUsername());
			preparedStatement.setString(4, userSession.getOrganid());
			preparedStatement.setString(5, userSession.getOrganname());
			preparedStatement.setString(6, userSession.getDeptname());
			preparedStatement.setString(7, userSession.getDeptid());
			preparedStatement.setString(8, userSession.getPostid());
			preparedStatement.setString(9, userSession.getPostname());
			preparedStatement.setString(10, userSession.getEmployeename());
			preparedStatement.setString(11, userSession.getEmployeeid());
			preparedStatement.setString(12, userSession.getSex());
			preparedStatement.setString(13, userSession.getBirthday());
			preparedStatement.setString(14, userSession.getFacestyle());
			preparedStatement.setString(15, userSession.getIp());
			preparedStatement.setLong(16, userSession.getCreateTime());
			preparedStatement.setString(17, userSession.getPassword());
			preparedStatement.setString(18, userSession.getEmailPassword());
			preparedStatement.setString(19, userSession.getEmail());
			preparedStatement.setString(20, userSession.getLogintype());
			preparedStatement.setString(21, userSession.getDialog());
			preparedStatement.setString(22, userSession.getLoginTime());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public UserSession getUserSessionByUserid(String uid) {
		String sql = "select * from usersessions where userid = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		UserSession userSession = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, uid);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				userSession = new UserSession();
				userSession.setId(rs.getString(1));
				userSession.setUserid(rs.getString(2));
				userSession.setUsername(rs.getString(3));
				userSession.setOrganid(rs.getString(4));
				userSession.setOrganname(rs.getString(5));
				userSession.setDeptname(rs.getString(6));
				userSession.setDeptid(rs.getString(7));
				userSession.setPostid(rs.getString(8));
				userSession.setPostname(rs.getString(9));
				userSession.setEmployeename(rs.getString(10));
				userSession.setEmployeeid(rs.getString(11));
				userSession.setSex(rs.getString(12));
				userSession.setBirthday(rs.getString(13));
				userSession.setFacestyle(rs.getString(14));
				userSession.setIp(rs.getString(15));
				userSession.setCreateTime(rs.getLong(16));
				userSession.setPassword(rs.getString(17));
				userSession.setEmailPassword(rs.getString(18));
				userSession.setEmail(rs.getString(19));
				userSession.setLogintype(rs.getString(20));
				userSession.setDialog(rs.getString(21));
				userSession.setLoginTime(rs.getString(22));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userSession;
	}

	public UserSession getUserSessionBySid(String sid) {
		String sql = "select * from usersessions where id = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		UserSession userSession = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, sid);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				userSession = new UserSession();
				userSession.setId(rs.getString(1));
				userSession.setUserid(rs.getString(2));
				userSession.setUsername(rs.getString(3));
				userSession.setOrganid(rs.getString(4));
				userSession.setOrganname(rs.getString(5));
				userSession.setDeptname(rs.getString(6));
				userSession.setDeptid(rs.getString(7));
				userSession.setPostid(rs.getString(8));
				userSession.setPostname(rs.getString(9));
				userSession.setEmployeename(rs.getString(10));
				userSession.setEmployeeid(rs.getString(11));
				userSession.setSex(rs.getString(12));
				userSession.setBirthday(rs.getString(13));
				userSession.setFacestyle(rs.getString(14));
				userSession.setIp(rs.getString(15));
				userSession.setCreateTime(rs.getLong(16));
				userSession.setPassword(rs.getString(17));
				userSession.setEmailPassword(rs.getString(18));
				userSession.setEmail(rs.getString(19));
				userSession.setLogintype(rs.getString(20));
				userSession.setDialog(rs.getString(21));
				userSession.setLoginTime(rs.getString(22));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return userSession;
	}
	
	public List<UserSession> getAllSession(){
		String sql = "select * from usersessions";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		UserSession userSession = null;
		List<UserSession> list = new ArrayList<UserSession>();
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				userSession = new UserSession();
				userSession.setId(rs.getString(1));
				userSession.setUserid(rs.getString(2));
				userSession.setUsername(rs.getString(3));
				userSession.setOrganid(rs.getString(4));
				userSession.setOrganname(rs.getString(5));
				userSession.setDeptname(rs.getString(6));
				userSession.setDeptid(rs.getString(7));
				userSession.setPostid(rs.getString(8));
				userSession.setPostname(rs.getString(9));
				userSession.setEmployeename(rs.getString(10));
				userSession.setEmployeeid(rs.getString(11));
				userSession.setSex(rs.getString(12));
				userSession.setBirthday(rs.getString(13));
				userSession.setFacestyle(rs.getString(14));
				userSession.setIp(rs.getString(15));
				userSession.setCreateTime(rs.getLong(16));
				userSession.setPassword(rs.getString(17));
				userSession.setEmailPassword(rs.getString(18));
				userSession.setEmail(rs.getString(19));
				userSession.setLogintype(rs.getString(20));
				userSession.setDialog(rs.getString(21));
				userSession.setLoginTime(rs.getString(22));
				list.add(userSession);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public void addScriptSession(String scriptid, String sid) {
		UserSession userSession = getUserSessionBySid(sid);
		if (userSession != null) {
			String sql = "insert into scriptsessions values(?,?,?)";
			PreparedStatement preparedStatement = null;
			try {
				preparedStatement = this.connection.prepareStatement(sql);
				preparedStatement.setString(1, userSession.getUserid());
				preparedStatement.setString(2, scriptid);
				preparedStatement.setString(3, sid);
				preparedStatement.executeUpdate();
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void removeScriptSession(String scriptid) {
		String sql = "delete from scriptsessions where scriptid = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, scriptid);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void removeSessionBySid(String id) {
		String sql = "delete from usersessions where id = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			sql = "delete from scriptsessions where sid = ?";
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void removeSessionByUserid(String userid) {
		String sql = "delete from usersessions where userid = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, userid);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			sql = "delete from scriptsessions where uid = ?";
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, userid);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List<String> getScriptSessionByUserId(String uid) {
		String sql = "select scriptid from scriptsessions where uid = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		List<String> list = new ArrayList<String>();
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, uid);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				list.add(rs.getString(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public int getSessionCounts(){
		String sql = "select count(id) from usersessions";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		int count = 0;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return count;
	}

}