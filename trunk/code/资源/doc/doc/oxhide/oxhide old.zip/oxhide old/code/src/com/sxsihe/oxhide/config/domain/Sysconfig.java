package com.sxsihe.oxhide.config.domain;

/**
 * Sysconfig entity. @author MyEclipse Persistence Tools
 */

public class Sysconfig implements java.io.Serializable {

	// Fields

	private String scode;
	private String svalue;

	// Constructors

	/** default constructor */
	public Sysconfig() {
	}

	/** minimal constructor */
	public Sysconfig(String scode) {
		this.scode = scode;
	}

	/** full constructor */
	public Sysconfig(String scode, String svalue) {
		this.scode = scode;
		this.svalue = svalue;
	}

	// Property accessors

	public String getScode() {
		return this.scode;
	}

	public void setScode(String scode) {
		this.scode = scode;
	}

	public String getSvalue() {
		return this.svalue;
	}

	public void setSvalue(String svalue) {
		this.svalue = svalue;
	}

}