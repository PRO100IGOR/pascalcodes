package com.sxsihe.oxhide.server.ssoroles;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;
import com.sxsihe.oxhide.ssouser.service.SsouserService;
import com.sxsihe.utils.common.DataUtils;

public class SsorolesServerImpl implements SsorolesServer {
	private BaseServiceIface service;

	public BaseServiceIface getService() {
		return service;
	}

	public void setService(BaseServiceIface service) {
		this.service = service;
	}

	public Ssoroles findObjectBykey(String key) {
		Object object = service.findObjectBykey(key);
		try {
			return (Ssoroles) DataUtils.copyPoJo(object, Ssoroles.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public List<Ssoroles> findObjectsByCondition(ConditionBlock block, Map sortMap) {
		List list  = service.findObjectsByCondition(DataUtils.changeCode(block), sortMap);
		return DataUtils.copyPoJos(list, Ssoroles.class);
	}

	public List<Ssoroles> getAll() {
		List list =  service.getAll();
		return DataUtils.copyPoJos(list, Ssoroles.class);
	}
	
	public List<Ssoroles> getUsersRoles(String userid){
		SsouserService ssouserService = (SsouserService)SpringContextUtil.getBean("ssouserService");
		return DataUtils.copyPoJos(ssouserService.getUsersRoles(userid), Ssoroles.class);
	}
	
}
