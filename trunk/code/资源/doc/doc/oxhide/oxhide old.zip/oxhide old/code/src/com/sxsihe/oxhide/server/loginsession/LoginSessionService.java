package com.sxsihe.oxhide.server.loginsession;

import com.sxsihe.oxhide.login.domain.UserSession;

public abstract interface LoginSessionService {
	public  UserSession getSession(String sessionid,String userid);
}
