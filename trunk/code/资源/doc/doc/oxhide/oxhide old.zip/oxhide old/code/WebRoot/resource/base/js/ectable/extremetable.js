
//鍚屾鍔犺浇JS
function importJs(url){
	var async = true;
	var caller = this.caller;
	if(typeof(callback) != 'function'){
	   async = false;
	}
	var xmlhttp = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject('Msxml2.XMLHTTP');
	xmlhttp.open("POST", url, false);
	xmlhttp.onreadystatechange = function(){
	   if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
	   	    eval(xmlhttp.responseText);
	   }
	}
	xmlhttp.send();
}
//鑾峰緱搴旂敤鍚�1�??�????
function getContextPath() {
  var contextPath = document.location.pathname; 
  var index =contextPath.substr(1).indexOf("/"); 
  contextPath = contextPath.substr(0,index+1); 
  delete index; 
  return contextPath; 
}


//鑾峰緱搴旂敤鍚�1�??�????
function getContextPath() { 
  var contextPath = document.location.pathname; 
  var index =contextPath.substr(1).indexOf("/"); 
  contextPath = contextPath.substr(0,index+1); 
  delete index; 
  return contextPath; 
}

/**
 * ================ ExtremeTable================
 * author:tanchang
 * date:2006-7-25
 * 瀵笶xtremetable鐨勫鎴风鐨勫皝锟�????�????
 * =============================================
 */
function ExtremeTable(id){

	this._id=id;
	ExtremeTable.tables.push(this);	
}



/**
ExtremeTable鐩�??叧閰嶇疆灞烇�??
 */
var extremeTableConfig = {
	checkboxName        : "itemlist",
	chkIdPrefix   		: "chk_",
	selectedRowClass    : "selectRow"	//琚�??涓殑琛�??殑鏍凤拷?
};






//鐢熸垚鐨則able闆嗗�??
ExtremeTable.tables=new Array();




_p=ExtremeTable.prototype;

_p.getId=function(){
	return this._id;
}
_p.setId=function(id){
	this._id=id;
}
_p.getForm=function(){
	var oForm=null;
	if(this.getId()!=null && this.getId()!=""){
		oForm=document.forms[this.getId()];	
	}else{
		oForm=document.forms['ec']
	}
	return oForm;
}
_p.setAction=function(action){
	var oForm=this.getForm();
	oForm.action=action;
}
_p.getAction=function(action){
	var oForm=this.getForm();
	return oForm.action;
}
/**
 * 鏍规嵁绱㈠紩鍊煎彇寰桬xtremeTable瀵硅�??
 */
ExtremeTable.getTableByIndex=function(index){
	return ExtremeTable.tables[index];
}
/**
 * 鏍规嵁缂栧彿寰楀埌ExtremeTable瀵硅�??
 */
ExtremeTable.getTableById=function(id){
	var oResult=null;
	for(var i=0;i<ExtremeTable.tables.length;i++){
		var oTable=ExtremeTable.tables[i];
		if(oTable!=null && oTable.getId()==id ){
			oResult=oTable;
			break;
		}	
	}
	return oResult;
}



/**
 * 鍒ゆ柇锟�????�????锟斤拷锟�????�????锟斤拷閫夋嫨锟�1�??�????锟斤拷鎿嶄綔瀵癸�??
 */
_p.atleaseOneCheck=function(){
	var bResult=false;
	try{
	    var items = document.getElementsByName(extremeTableConfig.checkboxName);
	    if(items.length==undefined){
	    	if (items.checked == true){
		            bResult=true;
		    }
	    }else{
		    for (var i = 0; i < items.length; i++){
		        if (items[i].checked == true){
		            bResult=true;
		            break;
		        }
		    }
	    }
	    
    }catch(ex){

    }
    return bResult;
}


/**
 * 鍒锋柊Table涓暟锟�????�????
 */
_p.refresh=function(){
	window.document.forms[this.getId()].submit();
}
/**
 * 鍙栧緱绗竴鏉hecked鐨処tem
 */
_p.getTheFirstCheckedItem=function(){
	var bResult=null;
	try{
		var items=null;
		if(this.getId()!=null && this.getId()!=""){
			items=document.forms[this.getId()].elements[extremeTableConfig.checkboxName];
		}else{
		    items = document.forms['ec'].elements[extremeTableConfig.checkboxName];
		}
	    if(items.length==undefined){
	    	if (items.checked == true){
		            bResult=items;
		    }
	    }else{
		    for (var i = 0; i < items.length; i++){
		        if (items[i].checked == true){
		            bResult=items[i];
		            break;
		        }
		    }	    
	    }
    }catch(ex){

    }
    return bResult;
}
/**
*鍙栧緱琚拷?涓殑绗竴涓狪tem鐨処d
*/
_p.getTheFirstCheckedItemId=function(){
	var itemId="";
	var oChkItem=this.getTheFirstCheckedItem();
	if(oChkItem!=null){
		itemId=oChkItem.value;
		itemId=itemId.substring(extremeTableConfig.chkIdPrefix.length);
	}	
	return itemId;
}
/**
 * 寰楀埌琛ㄦ牸涓殑锟�????�????锟斤拷椤癸拷?
 */
_p.getAllItems=function(){
	var bResult=new Array();
	try{
		var items=null;
		if(this.getId()!=null && this.getId()!=""){
			items=document.forms[this.getId()].elements[extremeTableConfig.checkboxName];
		}else{
		    items = document.forms['ec'].elements[extremeTableConfig.checkboxName];
		}
	    if(items.length==undefined){
            bResult.push(items);
	    }else{
		    for (var i = 0; i < items.length; i++){
	            bResult.push(items[i]);		           
		    }	    
	    }
    }catch(ex){

    }
    return bResult;
}
/**
 * 鍙栧緱绗竴鏉¤锟�1�??�????
 */
_p.getTheFirstItem=function(){
	var bResult=null;
	try{
		var items=null;
		if(this.getId()!=null && this.getId()!=""){
			items=document.forms[this.getId()].elements[extremeTableConfig.checkboxName];
		}else{
		    items = document.forms['ec'].elements[extremeTableConfig.checkboxName];
		}
		

	    if(items.length==undefined){
            bResult=items;
	    }else{
	    	bResult=items[0];
	    }
    }catch(ex){

    }
    return bResult;
}
/**
 * 鍙栧緱绗竴鏉tem鐨処D
 * 浠ワ�??锛岋�??鍒嗭�??
 */
_p.getTheFirstItemId=function(){
	var idList="";
	var item=this.getTheFirstItem();
	if(item!=null){
		idList=item.value.substring(extremeTableConfig.chkIdPrefix.length);		
	}
	return idList;
}
/**
 * 鍙栧緱锟�????�????锟斤拷item鐨処D鐨勫垪锟�????�????
 * 浠ワ�??锛岋�??鍒嗭�??
 */
_p.getAllItemIdList=function(){
	var idList="";
	var oChkItems=this.getAllItems();
	
	for(var i=0;i<oChkItems.length;i++){
		var oItem=oChkItems[i];
		var id=oItem.value.substring(extremeTableConfig.chkIdPrefix.length);
		idList+=id+",";
	}
	return idList;
}
/**
 * 鍙栧緱锟�????�????锟斤拷鐨凜hecked鐨処tem
 */
_p.getAllCheckedItems=function(){
	
	var bResult=new Array();
	try{
		var items=null;
		if(this.getId()!=null && this.getId()!=""){
			items=document.forms[this.getId()].elements[extremeTableConfig.checkboxName];
		}else{
		    items = document.forms['ec'].elements[extremeTableConfig.checkboxName];
		}
		

	    if(items.length==undefined){
	    	if (items.checked == true){
		            bResult.push(items);
		    }
	    }else{
		    for (var i = 0; i < items.length; i++){
		        if (items[i].checked == true){
		            bResult.push(items[i]);		           
		        }
		    }	    
	    }
    }catch(ex){

    }
    return bResult;
}
/**
 * 鍙栧緱锟�????�????锟斤拷琚拷?涓殑Item鐨処d鐨勫垪锟�????�????
 * 浠ワ�??鈥濆垎锟�????�????
 */
_p.getCheckedItemIdList=function(){
	var idList="";
	var oChkItems=this.getAllCheckedItems();
	
	for(var i=0;i<oChkItems.length;i++){
		var oItem=oChkItems[i];
		var id=oItem.value;
		idList+=id+",";
	}
	return idList;
}
/**
*閫変腑锟�????�????锟斤拷鐨刢heckbox
*/
_p.checkAllChk=function(event){
	event = event||window.event;
	var obj = event.srcElement||event.target;
	var flag=obj.checked;	
	var items = document.forms[this.getId()].elements[extremeTableConfig.checkboxName];
	
	if(items.length==undefined){
		items.checked=flag;
	}else{
		for (var i = 0; i < items.length; i++){
	        items[i].checked=flag;
	    }
	}
}


_p.oCurSelectRow=null;				//褰撳墠閫変腑鐨勮�??�硅�??
_p.oldRowClass="";					//鍘焤ow瀵硅薄鐨勬牱锟�1�??�????
_p.oldOnMonuseOut="";
_p.oldOnMonuseOver="";


/**
 * 閫変腑褰撳墠鎸囧畾鐨勮
 */
_p.selectRow=function(oRow,event){
	var evt = event || window.event;
	var EventObject=evt.srcElement;
	if(this.oCurSelectRow!=null){
		//this.oCurSelectRow.className=this.oldRowClass;
		if(this.oCurSelectRow.rowIndex%2==0)
		   this.oCurSelectRow.className="even";
		else
		   this.oCurSelectRow.className="odd";
		this.oCurSelectRow.onmouseout=this.oldOnMonuseOut;
		this.oCurSelectRow.onmouseover=this.oldOnMonuseOver;
	}
	this.oldRowClass=oRow.className;
	oRow.className=extremeTableConfig.selectedRowClass;
	this.oldOnMonuseOut=oRow.onmouseout;
	this.oldOnMonuseOver=oRow.onmouseover;
	oRow.onmouseout="";
	oRow.onmouseover="";
	this.oCurSelectRow=oRow;

	
}
/**
 * 鍙栧緱褰撳墠閫夋嫨鐨勮瀵硅�??
 */
_p.getSelectRow=function(){
	return this.oCurSelectRow;
}
/**
 * 鍙栧緱褰撳墠閫夋嫨鐨勮瀵硅薄鐨勭紪锟�1�??�????
 */
_p.getSelectRowId=function(){
	var id="";
	if(this.oCurSelectRow!=null)
		id=this.oCurSelectRow.id;
	return id;
}
_p.getNext = function(obj){
		var result = obj.nextSibling;
		var temp ;
		while (!result.tagName) {
			temp =  result.nextSibling;
			if(temp==null)return result;
			else result = temp;
		}
		return result;
}
_p.getPre = function(obj){
		var result = obj.previousSibling;
		var temp ;
		while (!result.tagName) {
			temp =  result.previousSibling;
			if(temp==null)return result;
			else result = temp;
		}
		return result;
}
_p.moveRowN=function(cRow,n){
    if(n==0) return;
    var oldRow=cRow;
    var oRowhtml=oldRow.outerHTML;
    var crowLast;
    if(n>0){
       for(i=0;i<n;i++){
          cRow=this.getNext(cRow);
         
           if(i==0&&((cRow==null||cRow.tagName!="TR")))return oldRow;
		   if(cRow==null||cRow.tagName!="TR"){
		     cRow = crowLast;
             break;
           }else{
           	 crowLast = cRow;
           }
       }
    }
    if(n<0){
       for(i=0;i<-n;i++){
          cRow=this.getPre(cRow);
          if(i==0&&((cRow==null||cRow.tagName!="TR")))return oldRow;
		   if(cRow==null||cRow.tagName!="TR"){
		     cRow = crowLast;
             break;
           }else{
           	 crowLast = cRow;
           }
       }
    }
    var tr=document.createElement("tr");
    for(i=0;i<oldRow.cells.length;i++){
       var td=document.createElement("td");
       //var text=document.createTextNode(oldRow.cells[i].innerHTML);
       td.innerHTML=oldRow.cells[i].innerHTML;
       tr.className=oldRow.className;
       if(oldRow.onclick)
       tr.onclick=oldRow.onclick;
       if(oldRow.onmouseover)
       tr.onmouseover=oldRow.onmouseover;
       if(oldRow.onmouseout)
       tr.onmouseout=oldRow.onmouseout;
       if(oldRow.id)
       tr.id=oldRow.id;
       tr.setAttribute("style",oldRow.getAttribute("style"));
       tr.appendChild(td);
    }
    if(n>0)
      cRow.parentNode.insertBefore(tr,cRow.nextSibling);
    else
      cRow.parentNode.insertBefore(tr,cRow);
    oldRow.parentNode.deleteRow(oldRow.rowIndex-1);
    this.oCurSelectRow=tr;
    return tr;
}

_p.moveRowTop=function(cRow){
    var tr=document.createElement("tr");
    for(i=0;i<cRow.cells.length;i++){
       var td=document.createElement("td");
       //var text=document.createTextNode(oldRow.cells[i].innerHTML);
       td.innerHTML=cRow.cells[i].innerHTML;
       tr.className=cRow.className;
       if(cRow.onclick)
       tr.onclick=cRow.onclick;
       if(cRow.onmouseover)
       tr.onmouseover=cRow.onmouseover;
       if(cRow.onmouseout)
       tr.onmouseout=cRow.onmouseout;
       if(cRow.id)
       tr.id=cRow.id;
       tr.setAttribute("style",cRow.getAttribute("style"));
       tr.appendChild(td);
    }
    cRow.parentNode.insertBefore(tr,cRow.parentNode.childNodes[0]);
    cRow.parentNode.deleteRow(cRow.rowIndex-1);
    this.oCurSelectRow=tr;
    return tr;
}

_p.moveRowBottom=function(cRow){
    var tr=document.createElement("tr");
    for(i=0;i<cRow.cells.length;i++){
       var td=document.createElement("td");
       //var text=document.createTextNode(oldRow.cells[i].innerHTML);
       td.innerHTML=cRow.cells[i].innerHTML;
       tr.className=cRow.className;
       if(cRow.onclick)
       tr.onclick=cRow.onclick;
       if(cRow.onmouseover)
       tr.onmouseover=cRow.onmouseover;
       if(cRow.onmouseout)
       tr.onmouseout=cRow.onmouseout;
       if(cRow.id)
       tr.id=cRow.id;
       tr.setAttribute("style",cRow.getAttribute("style"));
       tr.appendChild(td);
    }
    cRow.parentNode.appendChild(tr);
    cRow.parentNode.deleteRow(cRow.rowIndex-1);
    this.oCurSelectRow=tr;
    return tr;
}

function openOrCloseTreeNodeRow(trs,oper,blank,tableid){
   var oTable = trs.parentNode.parentNode;
   var oRows=oTable.rows;
   var cRow=oTable.rows[trs.rowIndex];
   var cpid=cRow.id;
   var cdepth=cRow.depth;
   if(cdepth==null||cdepth=="")
       cdepth=0;
   var childed=false;
   if(oper.nodeName=='#text'){
       oper=oper.nextSibling;
   }
   for(var i=trs.rowIndex+1;i<oRows.length;i++){
       var oRow=oRows[i];
       if(oper.style.backgroundImage.indexOf("plus")>0){
       	  if(oRow.getAttribute('parentId')==cpid){
       	  	 openTreeNodeRow(oRow);
       	  	 childed=true;
       	  }
       }else{
       	  if(oRow.getAttribute('parentId')==cpid){
       	  	 closeTreeNodeRow(oRow);
       	  }
       }
   }
   var cells=cRow.cells;
   var tabletreenumber="";
   for(var x=0;x<cells.length;x++){
   	   if(cells[x].tabletreenumber=="true")
   	      tabletreenumber=cells[x].innerText;
   }
   if(oper.style.backgroundImage.indexOf("plus")>0&&!childed){
   	  var url=window.location.href;
   	  url+="&paretNode$_blank="+blank+"&parentNodeId="+cpid+
   	  "&tabletreenumber="+tabletreenumber;
   	  if(!is_tabletree_load){
   	    var is_tabletree_load=true;
   	    var form=document.getElementById(tableid);
   	    var para="";
   	    for(var i=0;i<form.length;i++){
   	    	para+="&"+form[i].name+"="+encode(form[i].value);
   	    }
   	    send_tabletree_grade_request(para,url,oTable,cRow,oper);
   	  }
   }
   if(oper.style.backgroundImage.indexOf("plus")>0){
       	  oper.style.backgroundImage=oper.style.backgroundImage.replace("plus.gif","minus.gif");
       	  oper.style.backgroundImage=oper.style.backgroundImage.replace("plusbottom.gif","minusbottom.gif");
       	  var obj=oper.nextSibling;
       	  while(obj.nodeName=='#text'){
       	  	obj=obj.nextSibling;
       	  }
       	  obj = obj.childNodes[0];
       	  obj.src=obj.src.replace("folder.gif","folderopen.gif");
       	  trs.open=true;
    }else{
       	  oper.style.backgroundImage=oper.style.backgroundImage.replace("minus.gif","plus.gif");
       	  oper.style.backgroundImage=oper.style.backgroundImage.replace("minusbottom.gif","plusbottom.gif");
       	  var obj=oper.nextSibling;
       	  while(obj.nodeName=='#text'){
       	  	obj=obj.nextSibling;
       	  }
       	  obj = obj.childNodes[0];
       	  obj.src=obj.src.replace("folderopen.gif","folder.gif");
       	  trs.open=false;
    }
}
function openTreeNodeRow(trs){
   trs.style.display="table-row";
   var oTable = trs.parentNode.parentNode;
   var oRows=oTable.rows;
   var cRow=oTable.rows[trs.rowIndex];
   var cpid=cRow.id;
   //if(cRow.open)
   for(var i=trs.rowIndex+1;i<oRows.length;i++){
      var oRow=oRows[i];
      if(oRow.getAttribute('parentId')==cpid){
       	  	openTreeNodeRow(oRow);
       	}
   }
}
function closeTreeNodeRow(trs){
   trs.style.display="none";
   var oTable = trs.parentNode.parentNode;
   var oRows=oTable.rows;
   var cRow=oTable.rows[trs.rowIndex];
   var cpid=cRow.id;
   //if(cRow.open)
   for(var i=trs.rowIndex+1;i<oRows.length;i++){
       var oRow=oRows[i];
       if(oRow.getAttribute('parentId')==cpid){
       	  	closeTreeNodeRow(oRow);
       }
   }
}


function initTableFix(oTable,trs,tds){
   var oRows=oTable.rows;
   for(i=0;i<oRows.length;i++){
       if(trs.indexOf(oRows[i].rowIndex)>=0){
           oRows[i].className="fixedHeaderTr";
       }else{
           oRows[i].className="relativeTag";
       }
       var oCells=oRows[i].cells;
       for(j=0;j<oCells.length;j++){
           if(tds.indexOf(oCells[j].cellIndex)>=0){
             oCells[j].style="word-break:break-all;"
                            +"background-color:#46a1da;"
                            +"position:relative;left:expression(this.parentNode.offsetParent.scrollLeft);";
           }
       }
   }
}




//======================================================================================




