package com.sxsihe.oxhide.server.ssoroles;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;


public abstract interface SsorolesServer {
	/**
	 * �����б�����
	 * 
	 * @param block
	 * @param sortMap
	 * @return
	 */
	public List<Ssoroles> findObjectsByCondition(ConditionBlock block, Map sortMap);

	/**
	 * ����������ѯ����
	 * 
	 * @param key
	 * @return
	 */
	public Ssoroles findObjectBykey(String key) ;
	
	/**
	 * ��ѯȫ��
	 * @return
	 */
	public List<Ssoroles> getAll();
	
	/**
	 * ��ѯ�û���ȫ����ɫ
	 * @param userid
	 * @return
	 * Administrator
	 * com.sxsihe.oxhide.server.ssoroles
	 * List<Ssoroles>
	 */
	public List<Ssoroles> getUsersRoles(String userid);
}
