package com.sxsihe.oxhide.server.systemlog;

import com.ite.oxhide.common.util.StringUtils;
import com.sxsihe.oxhide.resource.service.ResourceService;
import com.sxsihe.oxhide.systemlog.domain.*;
import com.sxsihe.oxhide.systemlog.service.SystemlogService;
import com.sxsihe.utils.common.CharsetSwitch;

public class SystemlogServerImpl implements SystemlogServer {
	private SystemlogService systemlogService;
	private ResourceService resourceService;

	public SystemlogService getSystemlogService() {
		return systemlogService;
	}

	public void setSystemlogService(SystemlogService systemlogService) {
		this.systemlogService = systemlogService;
	}

	public ResourceService getResourceService() {
		return resourceService;
	}

	public void setResourceService(ResourceService resourceService) {
		this.resourceService = resourceService;
	}

	public void add(Systemlog log) {
		String[] appTitleAndResourceTitle = resourceService.getResourceNameByPath(log.getOperateSys()).split("#");
		String temp = log.getOperateSys();
		log.setOperateSys(appTitleAndResourceTitle[1]);
		log.setOperateModel(appTitleAndResourceTitle[0]);
		if (StringUtils.isEmpty(log.getOperateSys().trim())) {
			log.setOperateSys("δ֪");
			log.setOperateModel(temp);
		}
		log.setOperateContent(CharsetSwitch.decode(log.getOperateContent()));
		log.setOperateEmp(CharsetSwitch.decode(log.getOperateEmp()));
		log.setOperatePerson(CharsetSwitch.decode(log.getOperatePerson()));
		log.setRemark(CharsetSwitch.decode(log.getRemark()));
		systemlogService.add(log);
	}

}
