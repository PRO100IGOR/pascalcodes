package com.sxsihe.oxhide.server.dept;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.sxsihe.oxhide.dept.domain.Deptment;

public abstract interface DeptServer  {
	/**
	 * �����б�����
	 * 
	 * @param block
	 * @param sortMap
	 * @return
	 */
	public List<Deptment> findObjectsByCondition(ConditionBlock block, Map sortMap);

	/**
	 * ����������ѯ����
	 * 
	 * @param key
	 * @return
	 */
	public Deptment findObjectBykey(String key) ;
	
	/**
	 * ��ѯȫ��
	 * @return
	 */
	public List<Deptment> getAll();
}
