package com.sxsihe.oxhide.resource.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.resource.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:��Դ
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 *
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class ResourceForm extends BaseForm {
	/* resourceid */
	private String resourceid;
	private String ico;
	private String bigico;
	private String selfclick;
	private String tabname;	// Constructors
	private Integer orderno;
	private Integer target;
	private Integer display;
	private Integer menutype;
	private String simplyname;
	private String largeico;
	private String remark;
	private String prompt;
	private String displayPId;
	private String displayPName;
	private String displayAppName;
	private String displayAppId;
	private String mobileico;
	private String mobileurl;
	public String getMobileurl() {
		return mobileurl;
	}

	public void setMobileurl(String mobileurl) {
		this.mobileurl = mobileurl;
	}

	public String getMobileico() {
		return mobileico;
	}

	public void setMobileico(String mobileico) {
		this.mobileico = mobileico;
	}

	public boolean isChangeDisplay() {
		return changeDisplay;
	}

	public void setChangeDisplay(boolean changeDisplay) {
		this.changeDisplay = changeDisplay;
	}

	private boolean changeDisplay = false;
	public String getDisplayPId() {
		return displayPId;
	}

	public void setDisplayPId(String displayPId) {
		this.displayPId = displayPId;
	}

	public String getDisplayAppId() {
		return displayAppId;
	}

	public void setDisplayAppId(String displayAppId) {
		this.displayAppId = displayAppId;
	}

	public String getPrompt() {
		return prompt;
	}

	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getSimplyname() {
		return simplyname;
	}

	public void setSimplyname(String simplyname) {
		this.simplyname = simplyname;
	}

	public String getLargeico() {
		return largeico;
	}

	public void setLargeico(String largeico) {
		this.largeico = largeico;
	}

	public Integer getMenutype() {
		return menutype;
	}

	public void setMenutype(Integer menutype) {
		this.menutype = menutype;
	}

	public Integer getDisplay() {
		return display;
	}

	public void setDisplay(Integer display) {
		this.display = display;
	}

	public Integer getOrderno() {
		return orderno;
	}

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}
	public String getSelfclick() {
		return selfclick;
	}

	public void setSelfclick(String selfclick) {
		this.selfclick = selfclick;
	}
	public String getBigico() {
		return bigico;
	}

	public void setBigico(String bigico) {
		this.bigico = bigico;
	}

	public String getIco() {
		return ico;
	}

	public void setIco(String ico) {
		this.ico = ico;
	}

	public void setResourceid(String resourceid) {
		this.resourceid = resourceid;
	}

	public String getResourceid() {
		return this.resourceid;
	}

	/* ���� */
	private String resourcename;

	public void setResourcename(String resourcename) {
		this.resourcename = resourcename;
	}

	public String getResourcename() {
		return this.resourcename;
	}

	/* ��ַ */
	private String resourceurl;

	public void setResourceurl(String resourceurl) {
		this.resourceurl = resourceurl;
	}

	public String getResourceurl() {
		return this.resourceurl;
	}

	/* isvalidation */
	private String isvalidation;

	public void setIsvalidation(String isvalidation) {
		this.isvalidation = isvalidation;
	}

	public String getIsvalidation() {
		return this.isvalidation;
	}

	/* ���� */
	private String resourcecode;

	public void setResourcecode(String resourcecode) {
		this.resourcecode = resourcecode;
	}

	public String getResourcecode() {
		return this.resourcecode;
	}


	private String resourcepid;
	private String resourcepname;
	private String appid;
	private String appname;

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getAppname() {
		return appname;
	}

	public void setAppname(String appname) {
		this.appname = appname;
	}

	public String getResourcepid() {
		return resourcepid;
	}

	public void setResourcepid(String resourcepid) {
		this.resourcepid = resourcepid;
	}

	public String getResourcepname() {
		return resourcepname;
	}

	public void setResourcepname(String resourcepname) {
		this.resourcepname = resourcepname;
	}

	public String getTabname() {
		return tabname;
	}

	public void setTabname(String tabname) {
		this.tabname = tabname;
	}

	public Integer getTarget() {
		return target;
	}

	public void setTarget(Integer target) {
		this.target = target;
	}

	public String getDisplayPName() {
		return displayPName;
	}

	public void setDisplayPName(String displayPName) {
		this.displayPName = displayPName;
	}

	public String getDisplayAppName() {
		return displayAppName;
	}

	public void setDisplayAppName(String displayAppName) {
		this.displayAppName = displayAppName;
	}
}
