package com.sxsihe.oxhide.application.service;

import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.struts.menu.MenuDataPick;
import org.apache.commons.beanutils.PropertyUtils;

import com.sxsihe.oxhide.application.dao.ApplicationDAO;
import com.sxsihe.oxhide.application.domain.Application;
import com.ite.oxhide.common.util.*;
import java.util.*;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;

/**
 * <p>
 * Title:com.sxsihe.oxhide.application.service.ApplicationServiceImpl
 * </p>
 * <p>
 * Description:Ӧ��ϵͳService
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 * 
 * @modify
 * @date
 */
public class ApplicationServiceImpl extends BaseServiceImpl implements ApplicationService {
	/**
	 * ��ȡ���������
	 * zcc
	 * Apr 22, 2011
	 * @return
	 */
	public int getOrderNo(){
		return ((ApplicationDAO)this.getDao()).getOrderNo();
	}
}