package com.sxsihe.oxhide.helpdoc.service;
import com.ite.oxhide.service.BaseServiceIface;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.helpdoc.service.HelpdocService</p>
 * <p>Description:helpdoc����ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-09-28
 * @modify
 * @date
 */
 public interface HelpdocService extends BaseServiceIface{
 }
	