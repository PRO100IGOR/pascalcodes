package com.sxsihe.coder.sels.dao.hibernateImpl;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.coder.sels.domain.Sels;
import com.sxsihe.coder.sels.dao.SelsDAO;
/**
 *
 * <p>Title:com.sxsihe.oxhide.coder.sels.dao.hibernateImpl.SelsDAOImpl</p>
 * <p>Description:sels���ݲ�ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-02
 * @modify
 * @date
 */
public class SelsDAOImpl extends BaseDAOImpl implements SelsDAO {
	/**
	 * ������룬ָ��dao��Ӧʵ����
	 */
	public Class getEntityClass() {
		return Sels.class;
	}
}
