package com.sxsihe.oxhide.application.action;

import java.util.*;
import java.io.Serializable;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.actionEx.BaseDeleteAction;
import com.sxsihe.accessories.AccessoriesService;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.helpdoc.service.HelpdocService;
import com.sxsihe.oxhide.message.SenderManger;
import com.sxsihe.oxhide.message.android.AndroidService;
import com.sxsihe.oxhide.message.mobile.service.UnmobileService;
import com.sxsihe.oxhide.message.token.domain.Tokens;
import com.sxsihe.oxhide.message.token.service.TokensService;
import com.sxsihe.oxhide.resource.service.ResourceService;
import com.sxsihe.oxhide.schema.domain.TSchema;
import com.sxsihe.oxhide.schema.service.SchemaService;

import com.sxsihe.utils.common.CharsetSwitch;
import com.sxsihe.utils.system.SystemLogHelper;

/**
 * <p>
 * Title:com.sxsihe.oxhide.application.action.ApplicationDeleteAction
 * </p>
 * <p>
 * Description:Ӧ��ϵͳDeleteAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 * 
 * @modify
 * @date
 */
public class ApplicationDeleteAction extends BaseDeleteAction {
	/**
	 * ɾ������
	 */
	public ActionForward preDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Serializable ob) throws BaseException {
		if (ob != null) {
			Application application = (Application) ob;
			AccessoriesService accessService = (AccessoriesService) SpringContextUtil.getBean("accessService");
			SchemaService schemaService = (SchemaService) SpringContextUtil.getBean("schemaService");
			List list = schemaService.getAll();
			for (int i = 0; i < list.size(); i++) {
				TSchema schema = (TSchema) list.get(i);
				accessService.deleteAccessory(application.getAppid() + "_" + schema.getFolder());
			}
			ResourceService resourceService = (ResourceService) SpringContextUtil.getBean("resourceService");
			resourceService.correction(application.getAppid(), null);
			HelpdocService helpdocService = (HelpdocService) SpringContextUtil.getBean("helpdocService");
			String hql = "from Helpdoc t where t.itemid = :itemid";
			Map map = new HashMap();
			map.put("itemid", "app" + application.getAppid());
			helpdocService.deleteBatch(helpdocService.queryHql(hql, map));
		}
		return null;
	}

	/**
	 * ɾ��dwr
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward delDwr(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
		senderManger.delDwr(id);
		SystemLogHelper.addLog(request, "ɾ��һ����¼", "1", "");
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("ȡ�����ͳɹ���"));
		response.addCookie(cookie);
		return new ActionForward("/applicationLoadAction.do?action=showDwr&id=" + request.getParameter("appid"));
	}

	/**
	 * ɾ��ȫ��dwr
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward delAllDwr(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
		Application application = (Application) getService().findObjectBykey(request.getParameter("appid"));
		senderManger.delAllDwr(application.getAppcode());
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("ȡ�����ͳɹ���"));
		response.addCookie(cookie);
		return new ActionForward("/applicationLoadAction.do?action=showDwr&id=" + request.getParameter("appid"));
	}

	/**
	 * ɾ����ע����Ϣ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward delUn(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		UnmobileService unmobileService = (UnmobileService) SpringContextUtil.getBean("unmobileService");
		unmobileService.deleteByKey(id);
		SystemLogHelper.addLog(request, "ɾ��һ����¼", "1", "");
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("�ָ��ɹ������û����ڿ����յ�������Ϣ�ˣ�"));
		response.addCookie(cookie);
		return new ActionForward("/applicationLoadAction.do?action=showUnMobile&id=" + request.getParameter("appid"));
	}

	/**
	 * ɾ��ȫ����ע����Ϣ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward delAllUn(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		UnmobileService unmobileService = (UnmobileService) SpringContextUtil.getBean("unmobileService");
		Application application = (Application) getService().findObjectBykey(request.getParameter("appid"));
		int count = application.getUnmobiles().size();
		unmobileService.deleteBatchEx(application.getUnmobiles());
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("�ָ���" + count + "����¼��"));
		response.addCookie(cookie);
		return new ActionForward("/applicationLoadAction.do?action=showUnMobile&id=" + request.getParameter("appid"));
	}

	/**
	 * ɾ��ȫ��ƻ����׿����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward delAllToken(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Application application = (Application) getService().findObjectBykey(request.getParameter("appid"));
		TokensService tokensService = (TokensService) SpringContextUtil.getBean("tokensService");
		String hql = "from Tokens t where t.application.appid = :appid  and t.tokentype = :ttype";
		Map map = new HashMap();
		String type = request.getParameter("type");
		map.put("appid", application.getAppid());
		map.put("ttype", type);
		List list = getService().queryHql(hql, map);
		tokensService.deleteBatch(list);
		SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
		if (type.equals("apple")) {
			senderManger.delAllApple(application.getAppcode());
		} else {
			senderManger.delAllAndroid(application.getAppcode());
		}
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("ɾ��" + list.size() + "������"));
		response.addCookie(cookie);
		return new ActionForward("/applicationLoadAction.do?action=showToken&type=" + type + "&id=" + request.getParameter("appid"));
	}

	/**
	 * ɾ��ƻ����׿����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward delToken(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		TokensService tokensService = (TokensService) SpringContextUtil.getBean("tokensService");
		Tokens tokens = (Tokens) tokensService.findObjectBykey(id);
		String type = request.getParameter("type");
		if (tokens != null) {
			tokensService.delete(tokens);
			SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
			if (type.equals("apple")) {
				senderManger.delAppleByToken(tokens.getToken());
			}
			SystemLogHelper.addLog(request, "ɾ��һ������", "1", "");
			Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("ɾ��һ����¼������䷢��״̬"));
			response.addCookie(cookie);
		}
		return new ActionForward("/applicationLoadAction.do?action=showToken&type=" + type + "&id=" + request.getParameter("appid"));
	}

	public ActionForward delSender(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
		String type = request.getParameter("type");
		if (type.equals("apple")) {
			senderManger.delApple(id);
		} else {
			senderManger.delAndroid(id);
		}
		SystemLogHelper.addLog(request, "ɾ��һ����¼", "1", "");
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("ȡ�����ͳɹ���"));
		response.addCookie(cookie);
		return new ActionForward("/applicationLoadAction.do?action=showSender&type=" + type + "&id=" + request.getParameter("appid"));
	}

	public ActionForward delAllSender(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
		String type = request.getParameter("type");
		Application application = (Application) getService().findObjectBykey(request.getParameter("appid"));
		if (type.equals("apple")) {
			senderManger.delAllApple(application.getAppcode());
		} else {
			senderManger.delAllAndroid(application.getAppcode());
		}
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("ȡ�����ͳɹ���"));
		response.addCookie(cookie);
		return new ActionForward("/applicationLoadAction.do?action=showSender&type=" + type + "&id=" + request.getParameter("appid"));
	}

	public ActionForward delAddress(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		AndroidService androidService = (AndroidService)SpringContextUtil.getBean("android");
		androidService.delAddress(id);
		SystemLogHelper.addLog(request, "ɾ��һ����¼", "1", "");
		Cookie cookie = new Cookie("oxhidemessage", CharsetSwitch.encode("�ɹ��Ͽ���"));
		response.addCookie(cookie);
		return new ActionForward("/applicationLoadAction.do?action=showAddress");
	}
}