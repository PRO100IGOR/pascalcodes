package com.sxsihe.oxhide.server.utils;

import com.sxsihe.utils.aes.AES;

public class SiheUtilImpl implements SiheUtil {
	/**
	 * AES����,��Կ 1234567890abcdef
	 * 
	 * @return
	 */
	public String AESEncrypt(String str) {
		try {
			return AES.Encrypt(str, "1234567890abcdef");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	/**
	 * AES����,��Կ 1234567890abcdef
	 * 
	 * @param str
	 * @return
	 */
	public String AESDecrypt(String str) {
		try {
			return AES.Decrypt(str, "1234567890abcdef");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
}
