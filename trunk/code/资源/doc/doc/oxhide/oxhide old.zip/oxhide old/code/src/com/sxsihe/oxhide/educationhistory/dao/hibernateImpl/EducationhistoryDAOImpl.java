package com.sxsihe.oxhide.educationhistory.dao.hibernateImpl;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.educationhistory.domain.Educationhistory;
import com.sxsihe.oxhide.educationhistory.dao.EducationhistoryDAO;
/**
 *<p>Title:com.sxsihe.oxhide.educationhistory.dao.EducationhistoryDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-08-11
 *
 * @modify
 * @date
 */
public class EducationhistoryDAOImpl extends BaseDAOImpl implements EducationhistoryDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Educationhistory.class;
	   }
}