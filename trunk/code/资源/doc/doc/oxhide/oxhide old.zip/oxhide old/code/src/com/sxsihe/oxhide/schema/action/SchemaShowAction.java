package com.sxsihe.oxhide.schema.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.ite.oxhide.common.util.StringUtils;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import com.ite.oxhide.struts.menu.MenuNode;
import org.tdeccn.table.client.ActionHelper;
import java.io.*;
import com.ite.oxhide.persistence.*;
import org.extremecomponents.table.limit.Limit;
import com.ite.oxhide.common.util.*;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import org.apache.commons.beanutils.PropertyUtils;
import com.sxsihe.oxhide.schema.domain.TSchema;
import com.sxsihe.oxhide.schema.form.SchemaForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.schema.action.SchemaShowAction
 * </p>
 * <p>
 * Description:��ʽ����showAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-05-04
 * 
 * @modify
 * @date
 */
public class SchemaShowAction extends BaseShowAction {
	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}


	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}


	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof SchemaForm) {
				TSchema pos = (TSchema) po;
				SchemaForm vForm = (SchemaForm) form;
				BeanUtils.setProperty(vForm, "schemaid", PropertyUtils.getProperty(pos, "schemaid"));
				BeanUtils.setProperty(vForm, "schemaname", PropertyUtils.getProperty(pos, "schemaname"));
				BeanUtils.setProperty(vForm, "folder", PropertyUtils.getProperty(pos, "folder"));
				BeanUtils.setProperty(vForm, "dialog", PropertyUtils.getProperty(pos, "dialog"));
			}
		} catch (Exception e) {
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		List list = null;
		if (limit != null)
			list = getService().findObjectsByCondition(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed());
		else
			list = getService().findObjectsByCondition(block, sortMap);
		return list;
	}

}
