package com.sxsihe.oxhide.ssoroles.form;

import com.ite.oxhide.struts.form.BaseForm;
/**
 *<p>Title:com.sxsihe.oxhide.ssoroles.form.${variable.getOneUpper($variable.name)}Form</p>
 *<p>Description:��ɫ</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify 
 * @date
 */
public class SsorolesForm extends BaseForm{
      /*roleid*/
      private String  roleid ;
      public void setRoleid(String roleid){
         this.roleid=roleid;
      }
      public String getRoleid(){
         return this.roleid;
      }
      /*��ɫ��*/
      private String  rolename ;
      public void setRolename(String rolename){
         this.rolename=rolename;
      }
      public String getRolename(){
         return this.rolename;
      }
      /*��ɫ����*/
      private String  rolecode ;
      public void setRolecode(String rolecode){
         this.rolecode=rolecode;
      }
      public String getRolecode(){
         return this.rolecode;
      }
      /*��ע*/
      private String  remark ;
      public void setRemark(String remark){
         this.remark=remark;
      }
      public String getRemark(){
         return this.remark;
      }
      /*isvalidation*/
      private Integer  isvalidation ;
      public void setIsvalidation(Integer isvalidation){
         this.isvalidation=isvalidation;
      }
      public Integer getIsvalidation(){
         return this.isvalidation;
      }
}





