package com.sxsihe.oxhide.ssouser.dao;

import java.util.*;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;

import com.ite.oxhide.persistence.BaseDAOIface;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssouser.dao.SsousersDAO
 * </p>
 * <p>
 * Description:DAO
 * </p>
 * <p>
 * Copyright: Copyright (c) 2009
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public interface SsousersDAO extends BaseDAOIface {

	/**��ȡ��Դ
	 * @param appid
	 * @param userid
	 * @param ip
	 * @param display
	 * @param eq
	 *            �ȽϹ�ϵ
	 * @return Administrator
	 *         com.sxsihe.oxhide.ssouser
	 *         .dao.hibernateImpl
	 *         SsousersDAOImpl.java 2012����10:42:54
	 *         oxhide
	 */
	public JSONArray getResource(String appid, String userid, String ip, String display, JsonConfig config) ;

	/**
	 * �����û���ϵͳ
	 * @param userid
	 * @param appid   ��Ϊ null
	 * @param appcode ��Ϊ null
	 * @param ip
	 * @return
	 * Administrator
	 * com.sxsihe.oxhide.ssouser.dao.hibernateImpl
	 * SsousersDAOImpl.java
	 * 2012����3:24:31
	 * oxhide
	 */
	public JSONArray getApps(String userid,String appid,String appcode, String ip) ;
	/**
	 * ��ȡ��ʾ�˵�
	 * 
	 * @param userid
	 * @return
	 */
	public String getReourcePromt(String userid, String ip) ;


	/**
	 * ����û��Ƿ��з��ʱ���Ϊappcode�ı���ΪresourceCode����Դ
	 * 
	 * @param userid
	 * @param appcode
	 * @param resourceCode
	 * @return
	 */
	public boolean checkUserHasResource(String userid, String appcode, String resCode) ;

	/**
	 * ��ѯ�û������н�ɫ��Ϣ
	 * 
	 * @param userid
	 * @return Administrator
	 *         com.sxsihe.oxhide.ssouser
	 *         .dao.hibernateImpl List<Ssoroles>
	 */
	public List<Ssoroles> getUsersRoles(String userid) ;

	
	/**
	 * Ϊ��Ϣ���Ļ�ȡƥ����û�
	 * 
	 * @Title: MessageBaseService.java
	 * @Package com.sxsihe.oxhide.token.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-12-20 ����09:43:12
	 * @version V1.0
	 */
	public List getMessUsers(JSONObject param, Application application);
}