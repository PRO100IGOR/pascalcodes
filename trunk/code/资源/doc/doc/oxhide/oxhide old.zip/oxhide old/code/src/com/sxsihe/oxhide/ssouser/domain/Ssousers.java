package com.sxsihe.oxhide.ssouser.domain;

import java.util.HashSet;
import java.util.Set;

import com.sxsihe.oxhide.employee.domain.Employee;

/**
 * Ssousers entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Ssousers implements java.io.Serializable {

	// Fields

	private String userid;
	private Employee employee;
	private String username;
	private String password;
	private Integer isvalidation;
	private Integer issingel;
	private String facestyle;
	private String android;
	private Set tokens = new HashSet(0);

	public Set getTokens() {
		return tokens;
	}

	public void setTokens(Set tokens) {
		this.tokens = tokens;
	}

	public String getAndroid() {
		return android;
	}

	public void setAndroid(String android) {
		this.android = android;
	}

	private String apple;
	private Set usersroleses = new HashSet(0);

	// Constructors

	/** default constructor */
	public Ssousers() {
	}

	/** full constructor */
	public Ssousers(Employee employee, String username, String password, Integer isvalidation, Set usersroleses) {
		this.employee = employee;
		this.username = username;
		this.password = password;
		this.isvalidation = isvalidation;
		this.usersroleses = usersroleses;
	}

	// Property accessors

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public Employee getEmployee() {
		return this.employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Set getUsersroleses() {
		return this.usersroleses;
	}

	public void setUsersroleses(Set usersroleses) {
		this.usersroleses = usersroleses;
	}

	public String getFacestyle() {
		return facestyle;
	}

	public void setFacestyle(String facestyle) {
		this.facestyle = facestyle;
	}

	public Integer getIssingel() {
		return issingel;
	}

	public void setIssingel(Integer issingel) {
		this.issingel = issingel;
	}

	public String getApple() {
		return apple;
	}

	public void setApple(String apple) {
		this.apple = apple;
	}

}
