package com.sxsihe.coder.dataid.dao.hibernateImpl;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.coder.dataid.domain.Dataid;
import com.sxsihe.coder.dataid.dao.DataidDAO;
/**
 * 
 * <p>Title:com.sxsihe.coder.dataid.dao.hibernateImpl.DataidDAOImpl</p>
 * <p>Description:dataid���ݲ�ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-03
 * @modify
 * @date
 */
public class DataidDAOImpl extends BaseDAOImpl implements DataidDAO {
	/**
	 * ������룬ָ��dao��Ӧʵ����
	 */
	public Class getEntityClass() {
		return Dataid.class;
	}
}
	