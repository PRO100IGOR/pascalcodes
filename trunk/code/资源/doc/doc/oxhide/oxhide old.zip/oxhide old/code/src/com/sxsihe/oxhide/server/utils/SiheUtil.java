package com.sxsihe.oxhide.server.utils;

public interface SiheUtil {
	/**
	 * AES����,��Կ 1234567890abcdef 
	 * @return
	 */
	public String AESEncrypt(String str);
	
	/**
	 * AES����,��Կ 1234567890abcdef 
	 * @param str
	 * @return
	 */
	public String AESDecrypt(String str);
}
	