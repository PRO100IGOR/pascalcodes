package com.sxsihe.oxhide.dept.action;

import com.ite.oxhide.struts.actionEx.BaseDeleteAction;

/**
 *<p>Title:com.sxsihe.oxhide.dept.action.DeptDeleteAction</p>
 *<p>Description:����DeleteAction</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class DeptDeleteAction extends BaseDeleteAction{

}