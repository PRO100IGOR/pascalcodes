package com.sxsihe.oxhide.organ.dao.hibernateImpl;

import java.util.*;

import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.organ.domain.Organ;
import com.sxsihe.oxhide.organ.dao.OrganDAO;

/**
 *<p>
 * Title:com.sxsihe.oxhide.organ.dao.OrganDAOImpl
 * </p>
 *<p>
 * Description:DAOImpl
 * </p>
 *<p>
 * Copyright: Copyright (c) 2007
 * </p>
 *<p>
 * Company: ITE
 * </p>
 *
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class OrganDAOImpl extends BaseDAOImpl implements OrganDAO {
	/**
	 * (non-Javadoc)
	 *
	 * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	 */
	public Class getEntityClass() {
		// TODO Auto-generated method stub
		return Organ.class;
	}

	/**
	 * �ݹ��ѯ����(����ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����04:47:12
	 * @version V1.0
	 */
	private void getChildOrganDg(String organid, List organList) {
		String hql = "from Organ o where o.porgan.organid = :organid";
		Map map = new HashMap();
		map.put("organid", organid);
		List temp = this.queryHql(hql, map);
		organList.addAll(temp);
		for (int i = 0; i < temp.size(); i++) {
			Organ organ = (Organ) temp.get(i);
			getChildOrganDg(organ.getOrganid(), organList);
		}
	}

	/**
	 *�ݹ��ѯ����(�ַ���ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����04:51:54
	 * @version V1.0
	 */
	private void getChildOrganStringDg(String organid, StringBuilder organList) {
		String hql = "select o.organid from Organ o where o.porgan.organid = :organid";
		Map map = new HashMap();
		map.put("organid", organid);
		List temp = this.queryHql(hql, map);
		for (int i = 0; i < temp.size(); i++) {
			String organidTemp = (String) temp.get(i);
			organList.append(organidTemp);
			organList.append(",");
			getChildOrganStringDg(organidTemp, organList);
		}
	}

	/**
	 * ��ѯ�����ӻ���(����ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����04:50:14
	 * @version V1.0
	 */
	public List getChildOrgan(String organid, boolean containSelf) {
		List organList = new ArrayList();
		getChildOrganDg(organid, organList);
		if (containSelf) {
			organList.add(this.findEntityBykey(organid));
		}
		return organList;
	}

	/**
	 * ��ѯ�����ӻ���(����ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����04:50:25
	 * @version V1.0
	 */
	public List getChildOrgan(String organid) {
		List organList = new ArrayList();
		getChildOrganDg(organid, organList);
		return organList;
	}

	/**
	 *��ѯ�����ӻ���(�ַ���ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����05:14:28
	 * @version V1.0
	 */
	public String[] getChildOrganIds(String organid) {
		StringBuilder organList = new StringBuilder();
		getChildOrganStringDg(organid, organList);
		String ids = organList.length() > 0 ? "" : organList.substring(0, organList.length() - 1);
		return ids.split(",");
	}

	/**
	 * ��ѯ�����ӻ���(�ַ���ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����05:14:50
	 * @version V1.0
	 */
	public String[] getChildOrganIds(String organid, boolean containSelf) {
		StringBuilder organList = new StringBuilder();
		getChildOrganStringDg(organid, organList);
		if (containSelf) {
			organList.append(organid);
			return organList.toString().split(",");
		}
		String ids = organList.length() > 0 ? "" : organList.substring(0, organList.length() - 1);
		return ids.split(",");
	}

}