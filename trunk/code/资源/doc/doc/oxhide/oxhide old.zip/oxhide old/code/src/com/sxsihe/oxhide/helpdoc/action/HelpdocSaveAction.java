package com.sxsihe.oxhide.helpdoc.action;

import javax.servlet.http.HttpServletRequest;

import java.io.Serializable;
import org.apache.struts.action.ActionForm;

import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.helpdoc.domain.Helpdoc;
import com.sxsihe.oxhide.helpdoc.form.HelpdocForm;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.helpdoc.action.HelpdocSaveAction</p>
 * <p>Description:helpdoc����action</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-09-28
 * @modify
 * @date
 */
 public class HelpdocSaveAction extends BaseSaveAction {
	/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 * 
	 * @param form
	 * @param type ���ӻ����޸�
	 * @return
	 */
	protected Serializable getPersisPo(ActionForm form, String type) {
		HelpdocForm vForm = (HelpdocForm) form;
		Helpdoc po;
		if (type.equals("add"))
			po = new Helpdoc();
		else {
			po = (Helpdoc) service.findObjectBykey(vForm.getHid());
		}
		po.setHid(vForm.getHid());
		po.setHcontent(vForm.getHcontent());
		po.setItemid(vForm.getItemid());
		return po;
	}
	/**
	 * ������ʵ��Ĺ���ʵ��
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form, HttpServletRequest request, String type) {
	}
 }
	