package com.sxsihe.oxhide.message.token.dao.hibernateImpl;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.message.token.dao.TokensDAO;
import com.sxsihe.oxhide.message.token.domain.Tokens;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.token.dao.hibernateImpl.TokensDAOImpl</p>
 * <p>Description:tokens���ݲ�ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-19
 * @modify
 * @date
 */
public class TokensDAOImpl extends BaseDAOImpl implements TokensDAO {
	/**
	 * ������룬ָ��dao��Ӧʵ����
	 */
	public Class getEntityClass() {
		return Tokens.class;
	}
}
	