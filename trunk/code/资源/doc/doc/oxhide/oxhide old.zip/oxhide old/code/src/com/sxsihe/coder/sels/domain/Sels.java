package com.sxsihe.coder.sels.domain;

import com.sxsihe.coder.columns.domain.Columns;
import com.sxsihe.coder.tables.domain.Tables;

/**
 * Sels entity. @author MyEclipse Persistence Tools
 */

public class Sels implements java.io.Serializable {

	// Fields

	private String sid;
	private String sname;
	private Integer swith;
	private String orderno;
	private String isadv;
	private String showtype;
	private String cname;
	private Tables tables;
	private Columns columns;
	private String timer;
	private String cid;
	private String data;
	private String getdata;
	// Constructors

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getGetdata() {
		return getdata;
	}

	public void setGetdata(String getdata) {
		this.getdata = getdata;
	}

	public String getCid() {
		return cid;
	}

	public void setCid(String cid) {
		this.cid = cid;
	}

	public String getTimer() {
		return timer;
	}

	public void setTimer(String timer) {
		this.timer = timer;
	}

	public Tables getTables() {
		return tables;
	}

	public void setTables(Tables tables) {
		this.tables = tables;
	}

	public Columns getColumns() {
		return columns;
	}

	public void setColumns(Columns columns) {
		this.columns = columns;
	}

	/** default constructor */
	public Sels() {
	}

	/** full constructor */
	public Sels(String cid, String tid, String sname, Integer swith, String orderno, String isadv, String showtype, String cname) {
		this.sname = sname;
		this.swith = swith;
		this.orderno = orderno;
		this.isadv = isadv;
		this.showtype = showtype;
		this.cname = cname;
	}

	// Property accessors

	public String getSid() {
		return this.sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}


	public String getSname() {
		return this.sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public Integer getSwith() {
		return this.swith;
	}

	public void setSwith(Integer swith) {
		this.swith = swith;
	}

	public String getOrderno() {
		return this.orderno;
	}

	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}

	public String getIsadv() {
		return this.isadv;
	}

	public void setIsadv(String isadv) {
		this.isadv = isadv;
	}

	public String getShowtype() {
		return this.showtype;
	}

	public void setShowtype(String showtype) {
		this.showtype = showtype;
	}

	public String getCname() {
		return this.cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

}