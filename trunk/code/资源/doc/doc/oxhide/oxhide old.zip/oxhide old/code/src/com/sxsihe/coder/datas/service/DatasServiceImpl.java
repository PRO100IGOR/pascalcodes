package com.sxsihe.coder.datas.service;
import com.ite.oxhide.service.BaseServiceImpl;
/**
 * 
 * <p>Title:com.sxsihe.coder.datas.service.DatasServiceImpl</p>
 * <p>Description:datas����ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-03
 * @modify
 * @date
 */
 public class DatasServiceImpl extends BaseServiceImpl implements DatasService{
 }
	