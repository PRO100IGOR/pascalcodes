package com.sxsihe.oxhide.message;

import com.sxsihe.oxhide.ssouser.domain.Ssousers;

public class Sender {
	private String id;
	private int times;
	private int timestotal;
	private String message;
	private String token;
	private String userid;
	private Ssousers ssousers;
	private String href;
	private String dateTime;
	private String appid;
	private String rid;
	private String target;
	private String isnote;
	private String btn;
	private String types;
	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	public String getBtn() {
		return btn;
	}

	public void setBtn(String btn) {
		this.btn = btn;
	}

	public String getIsnote() {
		return isnote;
	}

	public void setIsnote(String isnote) {
		this.isnote = isnote;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}
	/**
	 * ��ԴID
	 * @return
	 * Administrator
	 * com.sxsihe.oxhide.message
	 * Sender.java
	 * 2012����6:32:28
	 * oxhide
	 */
	public String getRid() {
		return rid;
	}

	public void setRid(String rid) {
		this.rid = rid;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public String getDateTime() {
		return dateTime;
	}

	public void setDateTime(String dateTime) {
		this.dateTime = dateTime;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	public Ssousers getSsousers() {
		return ssousers;
	}

	public void setSsousers(Ssousers ssousers) {
		this.ssousers = ssousers;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	private String appcode;
	private int iskf;
	public int getIskf() {
		return iskf;
	}

	public void setIskf(int iskf) {
		this.iskf = iskf;
	}

	public String getAppcode() {
		return appcode;
	}

	public void setAppcode(String appcode) {
		this.appcode = appcode;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public int getTimes() {
		return times;
	}

	public void setTimes(int times) {
		this.times = times;
	}

	public int getTimestotal() {
		return timestotal;
	}

	public void setTimestotal(int timestotal) {
		this.timestotal = timestotal;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
}
