package com.sxsihe.oxhide.schema.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.schema.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:��ʽ����
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-05-04
 * 
 * @modify
 * @date
 */
public class SchemaForm extends BaseForm {
	private String dialog;
	/* schemaid */
	private String schemaid;

	public void setSchemaid(String schemaid) {
		this.schemaid = schemaid;
	}

	public String getSchemaid() {
		return this.schemaid;
	}

	/* ��ʽ���� */
	private String schemaname;

	public String getDialog() {
		return dialog;
	}

	public void setDialog(String dialog) {
		this.dialog = dialog;
	}

	public void setSchemaname(String schemaname) {
		this.schemaname = schemaname;
	}

	public String getSchemaname() {
		return this.schemaname;
	}

	/* ��ʽ�� */
	private String folder;

	public void setFolder(String folder) {
		this.folder = folder;
	}

	public String getFolder() {
		return this.folder;
	}

}
