package com.sxsihe.utils.tld;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;

import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.accessories.Accessories;
import com.sxsihe.accessories.AccessoriesService;

public class Access extends BodyTagSupport {
	private String itemId;

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public int doStartTag() throws JspException {
		AccessoriesService accessoriesService = (AccessoriesService) SpringContextUtil.getBean("accessService");
		List list = accessoriesService.getAccessoriesListByItem(itemId);
		StringBuilder builder = new StringBuilder();
		for (Object o : list) {
			Accessories accessories = (Accessories) o;
			builder.append("<a");
			builder.append(" href='accessories.do?action=downloadById&id=");
			builder.append(accessories.getId());
			builder.append("'>");
			builder.append(accessories.getFileName());
			builder.append("</a>; ");
		}
		try {
			this.pageContext.getOut().print(builder.toString());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return SKIP_PAGE;
	}
}
