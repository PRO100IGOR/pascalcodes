package com.sxsihe.coder.dataid.domain;

import java.util.HashSet;
import java.util.Set;

import com.sxsihe.coder.tables.domain.Tables;

/**
 * Dataid entity. @author MyEclipse Persistence Tools
 */

public class Dataid implements java.io.Serializable {

	// Fields

	private String dtid;
	private Tables tables;
	private Dataid dataid;
	public Dataid getDataid() {
		return dataid;
	}


	public void setDataid(Dataid dataid) {
		this.dataid = dataid;
	}


	private Set datas = new HashSet(0);
	// Constructors

	public Set getDatas() {
		return datas;
	}


	public void setDatas(Set datas) {
		this.datas = datas;
	}


	/** default constructor */
	public Dataid() {
	}


	// Property accessors

	public String getDtid() {
		return this.dtid;
	}

	public void setDtid(String dtid) {
		this.dtid = dtid;
	}


	public Tables getTables() {
		return tables;
	}


	public void setTables(Tables tables) {
		this.tables = tables;
	}


}