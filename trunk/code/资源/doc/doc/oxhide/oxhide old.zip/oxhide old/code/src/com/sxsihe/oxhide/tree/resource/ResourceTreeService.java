package com.sxsihe.oxhide.tree.resource;

import com.ite.oxhide.struts.menu.MenuDataPick;

public interface ResourceTreeService extends MenuDataPick{

}
