package com.sxsihe.oxhide.employee.dao;

import java.util.*;

import com.ite.oxhide.persistence.BaseDAOIface;
import com.ite.oxhide.persistence.ConditionBlock;
import com.sxsihe.oxhide.employee.domain.Employee;

/**
 * <p>
 * Title:com.sxsihe.oxhide.employee.dao.
 * EmployeeDAO
 * </p>
 * <p>
 * Description:DAO
 * </p>
 * <p>
 * Copyright: Copyright (c) 2009
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public interface EmployeeDAO extends BaseDAOIface {

	/**
	 * ��ȡ��������� zcc Apr 22, 2011
	 * 
	 * @return
	 */
	public int getOrderNo(String postid);

	/**
	 * �߼���ѯ����
	 * 
	 * @param condition
	 * @return Administrator
	 *         com.sxsihe.oxhide.employee
	 *         .dao.hibernateImpl
	 *         EmployeeDAOImpl.java 2012����6:54:50
	 *         oxhide
	 */
	public int getEmpAdvCount(ConditionBlock condition);

	/**
	 * �߼���ѯԱ��
	 * 
	 * @param block
	 * @param sortMap
	 * @param index
	 * @param count
	 * @return Administrator
	 *         com.sxsihe.oxhide.employee
	 *         .dao.hibernateImpl
	 *         EmployeeDAOImpl.java 2012����6:37:55
	 *         oxhide
	 */
	public List<Employee> getEmpAdv(ConditionBlock condition, Map sortMap, int beginNo, int pageSize);
}