package com.sxsihe.oxhide.application.domain;

public class ApplicationSimply {

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getAppname() {
		return appname;
	}

	public void setAppname(String appname) {
		this.appname = appname;
	}

	public String getAppurl() {
		return appurl;
	}

	public void setAppurl(String appurl) {
		this.appurl = appurl;
	}

	public String getAppindex() {
		return appindex;
	}

	public void setAppindex(String appindex) {
		this.appindex = appindex;
	}

	public String getApptitle() {
		return apptitle;
	}

	public void setApptitle(String apptitle) {
		this.apptitle = apptitle;
	}

	public String getIco() {
		return ico;
	}

	public void setIco(String ico) {
		this.ico = ico;
	}

	public String getBigico() {
		return bigico;
	}

	public void setBigico(String bigico) {
		this.bigico = bigico;
	}

	public String getSimplyname() {
		return simplyname;
	}

	public void setSimplyname(String simplyname) {
		this.simplyname = simplyname;
	}

	public String getLargeico() {
		return largeico;
	}

	public void setLargeico(String largeico) {
		this.largeico = largeico;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAppurlw() {
		return appurlw;
	}

	public void setAppurlw(String appurlw) {
		this.appurlw = appurlw;
	}

	public String getAppcode() {
		return appcode;
	}

	public void setAppcode(String appcode) {
		this.appcode = appcode;
	}

	private String apptitle;
	private String ico;
	private String bigico;
	private String simplyname;
	private String largeico;
	private String remark;
	private String appurlw;
	private String appcode;
	private String appid;
	private String appname;
	private String appurl;
	private String appindex;

	public ApplicationSimply() {

	}

	public ApplicationSimply(ApplicationSimply simply) {
		this.apptitle = simply.getApptitle();
		this.ico = simply.getIco();
		this.bigico = simply.getBigico();
		this.simplyname = simply.getSimplyname();
		this.largeico = simply.getLargeico();
		this.remark = simply.getRemark();
		this.appurlw = simply.getAppurlw();
		this.appcode = simply.getAppcode();
		this.appid = simply.getAppid();
		this.appname = simply.getAppname();
		this.appurl = simply.getAppurl();
		this.appindex = simply.getAppindex();
	}

}
