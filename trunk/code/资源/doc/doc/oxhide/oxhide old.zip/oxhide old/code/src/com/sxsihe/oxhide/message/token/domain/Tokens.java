package com.sxsihe.oxhide.message.token.domain;

import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;

/**
 * Tokens entity. @author MyEclipse Persistence Tools
 */

public class Tokens implements java.io.Serializable {

	// Fields

	private String tid;
	private Application application;
	private Ssousers ssousers;
	private String token;
	private String tokentype;

	// Constructors

	/** default constructor */
	public Tokens() {
	}

	/** full constructor */
	public Tokens(String userid, String appid, String token, String tokentype) {
		this.token = token;
		this.tokentype = tokentype;
	}

	// Property accessors

	public String getTid() {
		return this.tid;
	}

	public void setTid(String tid) {
		this.tid = tid;
	}



	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Ssousers getSsousers() {
		return ssousers;
	}

	public void setSsousers(Ssousers ssousers) {
		this.ssousers = ssousers;
	}

	public String getToken() {
		return this.token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getTokentype() {
		return this.tokentype;
	}

	public void setTokentype(String tokentype) {
		this.tokentype = tokentype;
	}

}