package com.sxsihe.oxhide.systemlog.service;

import com.ite.oxhide.service.BaseServiceIface;
/**
 *<p>Title:com.sxsihe.oxhide.systemlog.service.LogService</p>
 *<p>Description:Service</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author 
 * @version 1.0
 * @date 2011-07-08
 *
 * @modify 
 * @date
 */
 public interface SystemlogService extends BaseServiceIface{
 }