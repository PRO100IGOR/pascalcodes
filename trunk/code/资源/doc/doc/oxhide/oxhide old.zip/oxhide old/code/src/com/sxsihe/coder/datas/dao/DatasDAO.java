package com.sxsihe.coder.datas.dao;
import com.ite.oxhide.persistence.BaseDAOIface;
/**
 * 
 * <p>Title:com.sxsihe.coder.datas.dao.DatasDAO</p>
 * <p>Description:datas���ݲ�ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-03
 * @modify
 * @date
 */
 public interface DatasDAO extends BaseDAOIface{
 }
	