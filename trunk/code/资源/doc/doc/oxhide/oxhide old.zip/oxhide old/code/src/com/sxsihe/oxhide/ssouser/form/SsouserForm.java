package com.sxsihe.oxhide.ssouser.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssouser.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:�û�
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class SsouserForm extends BaseForm {
	private Integer issingel;
	private String facestyle;
	private String apple;
	private String android;

	public String getAndroid() {
		return android;
	}

	public void setAndroid(String android) {
		this.android = android;
	}

	/* userid */
	private String userid;

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUserid() {
		return this.userid;
	}

	/* �û��� */
	private String username;

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsername() {
		return this.username;
	}

	/* ���� */
	private String password;

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return this.password;
	}

	/* isvalidation */
	private Integer isvalidation;

	public void setIsvalidation(Integer isvalidation) {
		this.isvalidation = isvalidation;
	}

	public Integer getIsvalidation() {
		return this.isvalidation;
	}

	private String employeeid;
	private String employeename;

	public String getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmployeename() {
		return employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public String getFacestyle() {
		return facestyle;
	}

	public void setFacestyle(String facestyle) {
		this.facestyle = facestyle;
	}

	public Integer getIssingel() {
		return issingel;
	}

	public void setIssingel(Integer issingel) {
		this.issingel = issingel;
	}

	public String getApple() {
		return apple;
	}

	public void setApple(String apple) {
		this.apple = apple;
	}

}
