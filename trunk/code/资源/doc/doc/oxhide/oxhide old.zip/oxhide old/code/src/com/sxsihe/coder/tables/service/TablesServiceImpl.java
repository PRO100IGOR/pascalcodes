package com.sxsihe.coder.tables.service;

import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.coder.columns.domain.Columns;
import com.sxsihe.coder.dataid.service.DataidService;
import com.sxsihe.coder.tables.dao.TablesDAO;
import com.sxsihe.coder.tables.domain.SimplyLeaf;
import com.sxsihe.coder.tables.domain.Tables;

/**
 * 
 * <p>
 * Title:com.sxsihe.oxhide.coder.tables.service.
 * TablesServiceImpl
 * </p>
 * <p>
 * Description:tables����ʵ��
 * </p>
 * <p>
 * Copyright: Copyright (c) 2012
 * </p>
 * <p>
 * Company: �ĺ�
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-10-30
 * @modify
 * @date
 */
public class TablesServiceImpl extends BaseServiceImpl implements TablesService {
	/**
	 * ��֤�����Ƿ��Ѿ�������������ͼռ��
	 * 
	 * @Title: TablesDAOImpl.java
	 * @Package 
	 *          com.sxsihe.coder.tables.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-5 ����10:53:51
	 * @version V1.0
	 */
	public boolean checkTableName(String tableName) {
		return ((TablesDAO) getDao()).checkTableName(tableName);
	}

	/**
	 * ִ�з��ݵȵ�sql���
	 * 
	 * @Title: TablesDAOImpl.java
	 * @Package 
	 *          com.sxsihe.coder.tables.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-5 ����11:39:25
	 * @version V1.0
	 */
	public void execSql(String sql) {
		((TablesDAO) getDao()).execSql(sql);
	}

	/**
	 * ��ѯ��¼����
	 * 
	 * @Title: TablesDAOImpl.java
	 * @Package 
	 *          com.sxsihe.coder.tables.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-5 ����03:46:23
	 * @version V1.0
	 */
	public int getCountByCondition(String tableCode, List<SimplyLeaf> leafs) {
		return ((TablesDAO) getDao()).getCountByCondition(tableCode, leafs);
	}

	/**
	 * ��ҳ��ѯ����
	 * 
	 * @Title: TablesDAOImpl.java
	 * @Package 
	 *          com.sxsihe.coder.tables.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-5 ����03:46:44
	 * @version V1.0
	 */
	public List<Map> findObjectByCondition(String tableCode, List<SimplyLeaf> leafs, List<Columns> cols, int pageSize, int pageNow) {
		return ((TablesDAO) getDao()).findObjectByCondition(tableCode, leafs, cols, pageSize, pageNow);
	}

	/**
	 * ɾ����Ӧid�Ķ�̬��������
	 * 
	 * @Title: TablesServiceImpl.java
	 * @Package com.sxsihe.coder.tables.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-8 ����04:46:15
	 * @version V1.0
	 */
	public void deleteDataById(String id) {
		DataidService dataidService = (DataidService) SpringContextUtil.getBean("dataidService");
		dataidService.deleteByKey(id);
	}

	public JSONObject getDataById(String typeid, String dtid) {
		return ((TablesDAO) getDao()).getDataById(typeid, dtid);
	}

	/**
	 * ���ݱ����ȡ
	 * 
	 * @param code
	 * @return Administrator
	 *         com.sxsihe.coder.tables.service
	 *         TablesServiceImpl.java
	 *         2012����4:31:29 oxhide
	 */
	public Tables getTableByCode(String code) {
		String hql = "from Tables t where t.tcode = '" + code + "'";
		List list = this.queryHql(hql, null);
		if (!list.isEmpty())
			return (Tables) list.get(0);
		return null;
	}
}
