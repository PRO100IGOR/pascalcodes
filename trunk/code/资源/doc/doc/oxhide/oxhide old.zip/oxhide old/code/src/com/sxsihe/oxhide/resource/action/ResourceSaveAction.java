package com.sxsihe.oxhide.resource.action;

import java.util.Iterator;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.resource.form.ResourceForm;
import com.sxsihe.oxhide.resource.service.ResourceService;
import com.sxsihe.utils.common.RandomGUID;

/**
 * <p>
 * Title:com.sxsihe.oxhide.resource.action.ResourceSaveAction
 * </p>
 * <p>
 * Description:��ԴSaveAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 *
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */

public class ResourceSaveAction extends BaseSaveAction {
	/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 *
	 * @param form
	 * @return
	 */
	protected Serializable getPersisPo(ActionForm form, String type) {
		ResourceForm vForm = (ResourceForm) form;
		Resources po;
		if (type.equals("add")) {
			po = new Resources();
			po.setResourceid(RandomGUID.getGUID().replaceAll("-", ""));
		} else {
			String resourceid = vForm.getResourceid();
			po = (Resources) service.findObjectBykey(resourceid);
		}

		po.setResourcename(vForm.getResourcename());
		po.setResourceurl(vForm.getResourceurl());
		po.setIsvalidation(vForm.getIsvalidation());
		po.setResourcecode(vForm.getResourcecode());
		if (StringUtils.isNotEmpty(vForm.getAppid())) {
			Application application = new Application();
			application.setAppid(vForm.getAppid());
			po.setApplication(application);
		}
		po.setDisplayAppId(vForm.getDisplayAppId());
		po.setDisplayPId(vForm.getDisplayPId());
		po.setLargeico(vForm.getLargeico());
		po.setDisplay(vForm.getDisplay());
		po.setSimplyname(vForm.getSimplyname());
		if (StringUtils.isNotEmpty(vForm.getResourcepid())) {
			Resources resources = (Resources)getService().findObjectBykey(vForm.getResourcepid());
			po.setResourcesp(resources);
			if(vForm.isChangeDisplay()){
				dgResParent(po);
			}
		}
		po.setIco(vForm.getIco());
		po.setBigico(vForm.getBigico());
		po.setSelfclick(vForm.getSelfclick());
		po.setTabname(vForm.getTabname());
		po.setTarget(vForm.getTarget());
		po.setMenutype(vForm.getMenutype());
		po.setRemark(vForm.getRemark());
		po.setPrompt(vForm.getPrompt());
		po.setMobileico(vForm.getMobileico());
		po.setMobileurl(vForm.getMobileurl());
		if (type.equals("add")) {
			po.setOrderno(((ResourceService) this.getService()).getOrderNo(po.getApplication().getAppid(), po.getResourcesp() == null ? "" : po.getResourcesp().getResourceid()));
		} else {
			po.setOrderno(vForm.getOrderno());
			dgRes(po, vForm.isChangeDisplay());
		}
		return po;
	}

	/**
	 * ������ʵ��Ĺ���ʵ��
	 *
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form, HttpServletRequest request, String type) {
	}

	/**
	 * �������� zcc Apr 22, 2011
	 *
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward saveorder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		String[] array = request.getParameterValues("resourceid");
		for (int i = 0; i < array.length; i++) {
			Resources resources = (Resources) this.getService().findObjectBykey(array[i]);
			resources.setOrderno(i + 1);
			this.getService().update(resources);
		}
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	/**
	 * ���޸�����Դ����ʾ����Դ��ϵͳʱ��Ҳ�޸���������Դ
	 *
	 * @param po
	 */
	private void dgRes(Resources po, boolean changeDisplay) {
		for (Iterator<Resources> iterator = po.getResourcees().iterator(); iterator.hasNext();) {
			Resources resources = iterator.next();
			resources.setDisplayAppId(po.getDisplayAppId());
			if (changeDisplay)
				resources.setDisplay(po.getDisplay());
			getService().update(resources);
			dgRes(resources, changeDisplay);
		}
	}

	/**
	 * ���޸�����Դ����ʾ��ʽʱ��Ҳ�޸����ĸ���Դ
	 *
	 * @param po
	 */
	private void dgResParent(Resources po) {
		Resources resources = po.getResourcesp();
		if (resources != null) {
			resources.setDisplay(po.getDisplay());
			getService().update(resources);
			dgResParent(resources);
		}
	}
}