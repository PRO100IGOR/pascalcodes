package com.sxsihe.utils.param;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class Configs implements ServletContextListener{

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		System.out.println("�ر���");
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		System.out.println("������");
	}

}
