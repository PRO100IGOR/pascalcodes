package com.sxsihe.oxhide.ssouser.service;

import com.ite.oxhide.service.BaseServiceIface;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.login.domain.UserSession;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import java.util.*;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssouser.service.
 * SsouserService
 * </p>
 * <p>
 * Description:�û�Service
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public interface SsouserService extends BaseServiceIface {
	/**
	 * ��ȡ��ʾ�������ϵĲ˵�(ϵͳ�����)
	 * 
	 * @Title: SsousersDAOImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.dao.
	 *          hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-12-18 ����11:55:06
	 * @version V1.0
	 */
	public JSONArray getDesRes(String userid, String ip);

	/**
	 * ��ȡ��ݲ˵�
	 * 
	 * @param userid
	 * @return
	 */
	public JSONArray getQuickResourcesByUser(String userid, String ip);

	/**
	 * ��ȡ��ʾ�˵�
	 * 
	 * @param userid
	 * @return
	 */
	public String getReourcePromt(String userid, String ip);

	/**
	 * ��½��֤ zcc Apr 25, 2011
	 * 
	 * @param username
	 * @param password
	 * @return
	 */
	public UserSession getUserByName(String username, String password, List<Ssousers> ssouserArr);

	/**
	 * ����Ҫ�����ȡ�û���Ϣ
	 */
	public UserSession getUserByNameNotPass(String username, List<Ssousers> ssouserArr);

	/**
	 * �����û���ϵͳ
	 */
	public JSONArray getApps(String userid, String ip,String appid,String appcode);

	/**
	 * ��ȡ��ͨ�˵� override
	 * 
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-18 ����07:12:49
	 * @version V1.0
	 */
	public JSONArray getResourcesByUserAndApp(String appid, String userid, String ip);

	/**
	 * ����û��Ƿ��з��ʱ���Ϊappcode�ı���ΪresourceCode����Դ
	 * 
	 * @param userid
	 * @param appcode
	 * @param resourceCode
	 * @return
	 */
	public boolean checkUserHasResource(String userid, String appcode, String resCode);

	/**
	 * �û���¼
	 * {[username,password],[apple],[android],
	 * [appcode],[display]} otherParam ���Ӳ���
	 * 
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-19 ����02:51:34
	 * @version V1.0
	 */
	public JSONObject login(String data, JSONObject otherParam);
	/**
	 * Ϊ��Ϣ���Ļ�ȡƥ����û�
	 * 
	 * @Title: MessageBaseService.java
	 * @Package com.sxsihe.oxhide.token.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-12-20 ����09:43:12
	 * @version V1.0
	 */
	public List getMessUsers(JSONObject param, Application application);
	/**
	 * ��������
	 * 
	 * @Title: SsouserServiceImpl.java
	 * @Package com.sxsihe.oxhide.ssouser.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-19 ����06:15:23
	 * @version V1.0
	 */
	public boolean saveToken(String data);

	/**
	 * ��ѯ�û������н�ɫ��Ϣ
	 * 
	 * @param userid
	 * @return Administrator
	 *         com.sxsihe.oxhide.ssouser
	 *         .dao.hibernateImpl List<Ssoroles>
	 */
	public List<Ssoroles> getUsersRoles(String userid);
}