package com.sxsihe.coder.columns.service;
import com.ite.oxhide.service.BaseServiceIface;
/**
 *
 * <p>Title:com.sxsihe.oxhide.coder.columns.service.ColumnsService</p>
 * <p>Description:columns����ӿ�</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-11-02
 * @modify
 * @date
 */
 public interface ColumnsService extends BaseServiceIface{
 }
