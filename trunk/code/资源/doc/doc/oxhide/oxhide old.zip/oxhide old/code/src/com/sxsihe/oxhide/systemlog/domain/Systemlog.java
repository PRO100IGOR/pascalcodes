package com.sxsihe.oxhide.systemlog.domain;

/**
 * Systemlog entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Systemlog implements java.io.Serializable {

	private String sid;
	private String operateTime;
	private String operateIp;
	private String operatePerson;
	private String operateEmp;
	private String operateSys;
	private String operateContent;
	private String remark;
	private String operateModel;
	private String operateType;
	// Constructors

	public String getOperateModel() {
		return operateModel;
	}

	public void setOperateModel(String operateModel) {
		this.operateModel = operateModel;
	}

	/** default constructor */
	public Systemlog() {
	}

	/** full constructor */
	public Systemlog(String operateTime, String operateIp, String operatePerson,
			String operateEmp, String operateSys, String operateContent,
			String remark) {
		this.operateTime = operateTime;
		this.operateIp = operateIp;
		this.operatePerson = operatePerson;
		this.operateEmp = operateEmp;
		this.operateSys = operateSys;
		this.operateContent = operateContent;
		this.remark = remark;
	}

	// Property accessors

	public String getSid() {
		return this.sid;
	}

	public void setSid(String sid) {
		this.sid = sid;
	}

	public String getOperateTime() {
		return this.operateTime;
	}

	public void setOperateTime(String eTime) {
		this.operateTime = eTime;
	}

	public String getOperateIp() {
		return this.operateIp;
	}

	public void setOperateIp(String operateIp) {
		this.operateIp = operateIp;
	}

	public String getOperatePerson() {
		return this.operatePerson;
	}

	public void setOperatePerson(String operatePerson) {
		this.operatePerson = operatePerson;
	}

	public String getOperateEmp() {
		return this.operateEmp;
	}

	public void setOperateEmp(String operateEmp) {
		this.operateEmp = operateEmp;
	}

	public String getOperateSys() {
		return this.operateSys;
	}

	public void setOperateSys(String operateSys) {
		this.operateSys = operateSys;
	}

	public String getOperateContent() {
		return this.operateContent;
	}

	public void setOperateContent(String operateContent) {
		this.operateContent = operateContent;
	}

	public String getRemark() {
		return this.remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}

}