package com.sxsihe.oxhide.employee.action;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import org.hibernate.Hibernate;
import org.springframework.util.FileCopyUtils;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.oxhide.educationhistory.domain.Educationhistory;
import com.sxsihe.oxhide.educationhistory.service.EducationhistoryService;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.employee.form.EmployeeForm;
import com.sxsihe.oxhide.employee.form.EmployeeConditionForm;
import com.sxsihe.oxhide.employee.service.EmployeeService;
import com.sxsihe.oxhide.login.domain.UserSession;
import com.sxsihe.oxhide.post.domain.Posts;
import com.sxsihe.oxhide.server.dictionary.DictionaryServer;
import com.sxsihe.oxhide.workhistory.domain.Workhistory;
import com.sxsihe.oxhide.workhistory.service.WorkhistoryService;
import com.sxsihe.utils.common.RandomGUID;
import com.sxsihe.utils.properties.Reader;
import com.sxsihe.utils.system.SystemLogHelper;

/**
 * <p>
 * Title:com.sxsihe.oxhide.employee.action.EmployeeSaveAction
 * </p>
 * <p>
 * Description:Ա��SaveAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 *
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */

public class EmployeeSaveAction extends BaseSaveAction {
	private EducationhistoryService educationhistoryService;
	private WorkhistoryService workhistoryService;

	public EducationhistoryService getEducationhistoryService() {
		return educationhistoryService;
	}

	public void setEducationhistoryService(EducationhistoryService educationhistoryService) {
		this.educationhistoryService = educationhistoryService;
	}

	public WorkhistoryService getWorkhistoryService() {
		return workhistoryService;
	}

	public void setWorkhistoryService(WorkhistoryService workhistoryService) {
		this.workhistoryService = workhistoryService;
	}

	/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 *
	 * @param form
	 * @return
	 * @throws BaseException
	 */
	protected Serializable getPersisPo(ActionForm form, String type) {
		EmployeeForm vForm = (EmployeeForm) form;
		Employee po;
		if (type.equals("add")) {
			po = new Employee();
			po.setEmployeeid(RandomGUID.getGUID().replaceAll("-", ""));
		} else {
			String employeeid = vForm.getEmployeeid();
			po = (Employee) service.findObjectBykey(employeeid);
		}

		po.setEmployeecode(vForm.getEmployeecode());
		po.setEmployeename(vForm.getEmployeename());
		po.setSex(vForm.getSex());
		po.setBirthday(vForm.getBirthday());
		po.setIsvalidation(vForm.getIsvalidation());
		po.setRemark(vForm.getRemark());
		po.setOrderno(vForm.getOrderno());
		po.setNation(vForm.getNation());
		po.setWorkstarttime(vForm.getWorkstarttime());
		po.setOutlook(vForm.getOutlook());
		po.setOrigin(vForm.getOrigin());
		po.setTitle(vForm.getTitle());
		po.setEducation(vForm.getEducation());
		po.setProfessional(vForm.getProfessional());
		po.setTitleid(vForm.getTitleid());
		po.setAccounttype(vForm.getAccounttype());
		po.setAccount(vForm.getAccount());
		po.setIdentity(vForm.getIdentity());
		po.setIdentityplace(vForm.getIdentityplace());
		po.setEmail(vForm.getEmail());
		po.setPhone(vForm.getPhone());
		po.setProfessionallife(vForm.getProfessionallife());
		po.setProfessionaltype(vForm.getProfessionaltype());
		po.setWorktime(vForm.getWorktime());
		po.setNowworkbegin(vForm.getNowworkbegin());
		po.setNowworkend(vForm.getNowworkend());
		po.setWorktype(vForm.getWorktype());
		po.setOtherprofessional(vForm.getOtherprofessional());
		po.setOtherprofessionalid(vForm.getOtherprofessionalid());
		po.setNational(vForm.getNational());
		po.setAssociation(vForm.getAssociation());
		po.setTraintime(vForm.getTraintime());
		po.setOtherprofessionalidtime(vForm.getOtherprofessionalidtime());
		po.setReportscores(vForm.getReportscores());
		Posts posts = new Posts();
		posts.setPostid(vForm.getPostid());
		po.setMainplace(vForm.getMainplace());
		po.setBlood(vForm.getBlood());
		po.setMarry(vForm.getMarry());
		po.setMobile(vForm.getMobile());
		po.setDutydate(vForm.getDutydate());
		po.setCardid(vForm.getCardid());
		po.setPosts(posts);
		po.setEmailPassword(vForm.getEmailPassword());
		if (type.equals("add")) {
			po.setOrderno(((EmployeeService) this.getService()).getOrderNo(po.getPosts().getPostid()));
		} else {
			po.setOrderno(vForm.getOrderno());
		}
		return po;
	}

	/**
	 * ������ʵ��Ĺ���ʵ��
	 *
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form, HttpServletRequest request, String type) {
	}

	private byte[] getByteFromStream(InputStream inStream) throws IOException {
		ByteArrayOutputStream bytestream = new ByteArrayOutputStream();
		int len;
		while (((len = inStream.read()) != -1)) {
			bytestream.write(len);
		}
		byte imgdata[] = bytestream.toByteArray();
		// byte[] imgdata = bytestream.toByteArray();
		bytestream.close();
		return imgdata;
	}

	/**
	 * ����
	 *
	 * @param request
	 * @param po
	 * @throws BaseException
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws SQLException
	 */
	private void saveEmp(HttpServletRequest request, Employee po, EmployeeForm vForm) throws BaseException {

		DictionaryServer dictionaryServer = (DictionaryServer) SpringContextUtil.getBean("dictionaryClient");
		String value = dictionaryServer.getDicValue("PTPZXX", "photosize");
		value = StringUtils.isNotEmpty(value) ? value : "1";

		if (vForm.getPhoto().getFileSize() > 1024 * 1024 * new Integer(value)) {
			throw new BaseException("��Ƭ̫��");
		}
		value = dictionaryServer.getDicValue("PTPZXX", "pensize");
		value = StringUtils.isNotEmpty(value) ? value : "1";

		if (vForm.getPen().getFileSize() > 1024 * 1024 * new Integer(value)) {
			throw new BaseException("����ǩ��ͼƬ̫��");
		}

		String[] delWork = StringUtils.isEmpty(request.getParameter("delWork")) ? new String[0] : request.getParameter("delWork").split(",");
		String[] delEdu = StringUtils.isEmpty(request.getParameter("delEdu")) ? new String[0] : request.getParameter("delEdu").split(",");
		try {
			educationhistoryService.deleteBatchByKeys(delEdu);
			workhistoryService.deleteBatchByKeys(delWork);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		try {
			if (vForm.getPhoto().getFileSize() > 0) {
				po.setPhoto(Hibernate.createBlob(vForm.getPhoto().getInputStream()));
			}
			if (vForm.getPen().getFileSize() > 0) {
				po.setPen(Hibernate.createBlob(vForm.getPen().getInputStream()));
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		getService().save(po);

		List edus = new ArrayList();
		String[] eid = request.getParameterValues("eid");
		String[] education = request.getParameterValues("edueducation");
		String[] professional = request.getParameterValues("eduprofessional");
		String[] graduation = request.getParameterValues("edugraduation");
		String[] schoolname = request.getParameterValues("eduschoolname");
		String[] certificate = request.getParameterValues("educertificate");
		String[] edutype = request.getParameterValues("eduedutype");
		if (eid != null) {
			for (int i = 0; i < eid.length; i++) {
				Educationhistory educationhistory = new Educationhistory();
				educationhistory.setCertificate(certificate[i]);
				educationhistory.setEducation(education[i]);
				if (!eid[i].equals("null")) {
					educationhistory.setEid(eid[i]);
				}
				educationhistory.setEmployee(po);
				educationhistory.setGraduation(graduation[i]);
				educationhistory.setProfessional(professional[i]);
				educationhistory.setSchoolname(schoolname[i]);
				educationhistory.setEdutype(edutype[i]);
				edus.add(educationhistory);
			}
		}

		List works = new ArrayList();
		String[] hid = request.getParameterValues("hid");
		String[] begintime = request.getParameterValues("begintime");
		String[] endtime = request.getParameterValues("endtime");
		String[] organname = request.getParameterValues("workorganname");
		String[] organid = request.getParameterValues("workorganid");
		String[] dept = request.getParameterValues("workdept");
		String[] deptid = request.getParameterValues("workdeptid");
		String[] post = request.getParameterValues("workpost");
		String[] postid = request.getParameterValues("workpostid");
		if (begintime != null) {
			for (int i = 0; i < begintime.length; i++) {
				Workhistory workhistory = new Workhistory();
				workhistory.setBegintime(begintime[i]);
				workhistory.setDept(dept[i]);
				workhistory.setDeptid(deptid[i]);
				workhistory.setEmployee(po);
				workhistory.setEndtime(endtime[i]);
				if (!hid[i].equals("null")) {
					workhistory.setHid(hid[i]);
				}
				workhistory.setOrganid(organid[i]);
				workhistory.setOrganname(organname[i]);
				workhistory.setPost(post[i]);
				workhistory.setPostid(postid[i]);
				works.add(workhistory);
			}
		}
		educationhistoryService.saveBatch(edus);
		workhistoryService.saveBatch(works);
	}

	// /**
	// * ��������
	// * @param mapping
	// * @param form
	// * @param request
	// * @param response
	// * @return
	// */
	// public ActionForward workChange(ActionMapping mapping, ActionForm form,
	// HttpServletRequest request, HttpServletResponse response) {
	// String id = request.getParameter("id");
	// Employee po = (Employee) getService().findObjectBykey(id);
	// Workhistory workhistoryLast = null;
	// for (Iterator iterator = po.getWorkhistory().iterator();
	// iterator.hasNext();) {
	// Workhistory temp = (Workhistory)iterator.next();
	// if (StringUtils.isEmpty(args)) {
	//
	// }
	// }
	// // Workhistory workhistory = new Workhistory();
	// // workhistory.setBegintime(begintime)
	// // String postid = request.getParameter("postid");
	// // po.setPosts(posts)
	// return new ActionForward("/core/success/opSuccess.jsp");
	// }
	/**
	 * �������� zcc Apr 22, 2011
	 *
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward saveOrder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		String[] array = request.getParameterValues("employeeid");
		for (int i = 0; i < array.length; i++) {
			Employee employee = (Employee) getService().findObjectBykey(array[i]);
			employee.setEmployeeid(array[i]);
			employee.setOrderno(i + 1);
			this.getService().update(employee);
		}
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	public ActionForward add(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		boolean is = repeatSubmit(mapping, form, request);
		if (is) {
			return mapping.findForward("showAdd");
		}
		EmployeeForm vForm = (EmployeeForm) form;
		Serializable po = getPersisPo(form, "add");
		saveEmp(request, (Employee) po, vForm);
		String submit = request.getParameter("isSaveAndAdd");
		request.setAttribute("isSaveAndAdd", Boolean.valueOf(true));
		SystemLogHelper.addLog(request, "����һ����¼", "1", "");
		if ("true".equals(submit)) {
			saveToken(request);
			String uri = request.getRequestURI();
			uri = uri.replaceAll("Save", "Show").replaceAll(request.getContextPath(), "") + "?action=showAdd";
			return new ActionForward(uri);
		}
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	public ActionForward update(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		boolean is = repeatSubmit(mapping, form, request);
		if (is) {
			return mapping.findForward("showUpdate");
		}
		EmployeeForm vForm = (EmployeeForm) form;
		if (vForm.getPhoto().getFileSize() != 0) {
			if (vForm.getPhoto().getFileSize() > 1024 * 1024 * 1) {
				throw new BaseException("��Ƭ̫��");
			}
		}
		if (vForm.getPen().getFileSize() != 0) {
			if (vForm.getPen().getFileSize() > 1024 * 1024 * 1) {
				throw new BaseException("����ǩ��ͼƬ̫��");
			}
		}
		SystemLogHelper.addLog(request, "�޸�һ����¼", "1", "");
		Serializable po = getPersisPo(form, "update");
		saveEmp(request, (Employee) po, vForm);
		request.setAttribute("isSaveAndAdd", Boolean.valueOf(true));
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	public ActionForward review(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		boolean is = repeatSubmit(mapping, form, request);
		if (is)
			return mapping.findForward("showAdd");
		Serializable po = getPersisPo(form, "add");
		setPersistAssociatePo(po, form, request, "add");
		getService().add(po);
		String submit = request.getParameter("isSaveAndAdd");
		request.setAttribute("isSaveAndAdd", Boolean.valueOf(true));
		if ("true".equals(submit)) {
			ActionMessages messages = new ActionMessages();
			ActionMessage mes = new ActionMessage("messages.confirm", " ���ӳɹ�!!!");
			messages.add("org.apache.struts.action.GLOBAL_MESSAGE", mes);
			saveMessages(request, messages);
			saveToken(request);
			String uri = request.getRequestURI();
			uri = uri.replaceAll("Save", "Show").replaceAll(request.getContextPath(), "") + "?action=showAdd&id=";
			return new ActionForward(uri);
		}
		return new ActionForward("/core/success/opSuccess.jsp");
	}
}