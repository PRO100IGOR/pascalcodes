package com.sxsihe.oxhide.message.dwr;

import org.directwebremoting.ScriptSessions;

public class DwrScriptHandel implements Runnable {
	private String script;

	public String getScript() {
		return script;
	}

	public void setScript(String script) {
		this.script = script;
	}

	public DwrScriptHandel(String script) {
		this.setScript(script);
	}

	public void run() {
		ScriptSessions.addScript(script);
	}

}
