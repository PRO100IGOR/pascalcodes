package com.sxsihe.oxhide.dictionarycontent.dao.hibernateImpl;

import java.util.*;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.dictionarycontent.domain.Dictionarycontent;
import com.sxsihe.oxhide.dictionarycontent.dao.DictionarycontentDAO;
/**
 *<p>Title:com.sxsihe.oxhide.dictionarycontent.dao.DictionarycontentDAOImpl</p>
 *<p>Description:DAOImpl</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class DictionarycontentDAOImpl extends BaseDAOImpl implements DictionarycontentDAO{
   /**
	   * (non-Javadoc)
	   * @see com.ite.oxhide.persistence.BaseDAOImpl#getEntityClass()
	   */
	   public Class getEntityClass() {
		      // TODO Auto-generated method stub
		      return Dictionarycontent.class;
	   }
}