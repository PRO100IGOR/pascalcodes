package com.sxsihe.accessories;

import com.ite.oxhide.common.util.DataUtils;
import com.ite.oxhide.common.util.DrawSimpleDiagramUtils;
import com.ite.oxhide.common.util.StringUtils;
import com.sxsihe.oxhide.login.domain.UserSession;
import com.sxsihe.utils.common.CharsetSwitch;
import com.sxsihe.utils.common.RandomGUID;
import com.sxsihe.utils.common.StrTool;
import com.sxsihe.utils.system.SystemLogHelper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import javax.mail.internet.MimeUtility;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.actions.DispatchAction;

public class AccessoriesAction extends DispatchAction {
	private String IMG_EXTEND_NAME = "jpg,jpeg,gif,png";
	private AccessoriesService service;

	public AccessoriesService getService() {
		return this.service;
	}

	public void setService(AccessoriesService service) {
		this.service = service;
	}

	public ActionForward upload(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		String itemId = request.getParameter("itemId");
		String isManager = request.getParameter("isManager");
		String appName = request.getParameter("appName");
		String showAsImgStr = request.getParameter("showAsImg");
		String type = request.getParameter("type");
		String maxCount = request.getParameter("maxCount");
		String minCount = request.getParameter("minCount");
		String path = request.getParameter("path");
		String forward = request.getParameter("forward");
		forward = StringUtils.isEmpty(forward) ? "accPage" : forward;
		String relativePath = StringUtils.isEmpty(path) ? ("/upload" + appName + "/") : path;
		String uploadPath = this.servlet.getServletContext().getRealPath("/") + relativePath;
		String old_itemId = itemId;
		int fsize = -1;
		String extend = null;
		if (!(DataUtils.isEmpty(type))) {
			Properties prop = new Properties();
			prop.load(super.getClass().getResourceAsStream("/accessories.properties"));
			fsize = Integer.parseInt(prop.getProperty("accessories.type." + type + ".size"));
			extend = prop.getProperty("accessories.type." + type + ".extend");
		}
		short showAsImg = 0;
		try {
			showAsImg = Short.parseShort(showAsImgStr);
		} catch (NumberFormatException e) {
			showAsImg = 0;
		}
		String msg = "";

		if (!(new File(uploadPath).isDirectory())) {
			new File(uploadPath).mkdirs();
		}
		DiskFileUpload fu = new DiskFileUpload();

		fu.setSizeMax(1048576000L);
		if (fsize != -1) {
			fu.setSizeMax(fsize * 1024);
		}
		fu.setSizeThreshold(4096);

		fu.setRepositoryPath(uploadPath);
		String flagSubmit = "false";
		List fileItems = null;
		try {
			fileItems = fu.parseRequest(request);
		} catch (FileUploadBase.SizeLimitExceededException e) {
			msg = "��������û���ϴ��ɹ���";
			return new ActionForward("/accessories.do?action=show&forward=" + forward + "&isManager=" + isManager + "&itemId=" + itemId + "&msg=" + CharsetSwitch.encode(msg) + "&appName=" + appName + "&showAsImg=" + showAsImg + "&type=" + type
					+ "&maxCount=" + maxCount + "&minCount=" + minCount + "&flagSubmit=" + flagSubmit + "&path=" + path, true);
		}

		Iterator iter = fileItems.iterator();
		long size = 0L;

		while (iter.hasNext()) {
			FileItem fi = (FileItem) iter.next();

			String fileName = null;
			fileName = fi.getName();
			size = fi.getSize();

			if (size > fu.getSizeMax() || size == 0L) {
				continue;
			}

			if (StringUtils.isEmpty(fileName)) {
				continue;
			}
			
			fileName = fileName.replace('\\', '/');
			String[] names = fileName.split("/");
			fileName = names[(names.length - 1)];

			String extention = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
			if ((extend != null) && (extend.indexOf(extention) < 0)) {
				msg = "�������Ͳ��ԣ�ֻ֧��������չ����<br/>" + extend + "!";
				return new ActionForward("/accessories.do?action=show&forward=" + forward + "&isManager=" + isManager + "&itemId=" + itemId + "&msg=" + CharsetSwitch.encode(msg) + "&appName=" + appName + "&showAsImg=" + showAsImg + "&type=" + type
						+ "&maxCount=" + maxCount + "&minCount=" + minCount + "&flagSubmit=" + flagSubmit + "&path=" + path, true);
			}
			long time = System.currentTimeMillis();
			Accessories acc = new Accessories();
			acc.setItemId(old_itemId);
			acc.setFileName(fileName.toLowerCase());
			acc.setPath(relativePath + acc.getItemId() + time + "." + extention);
			acc.setSize(size);
			acc.setStat(Integer.valueOf(0));
			acc.setUploadDate(StrTool.formatDateTime(new Date()));
			UserSession userSession = (UserSession) request.getSession().getAttribute("USERSESSION");
			if (userSession != null) {
				acc.setEmployeeid(userSession.getEmployeeid());
				acc.setEmployeename(userSession.getEmployeename());
			}
			if (this.IMG_EXTEND_NAME.indexOf(extention.substring(1)) != -1)
				acc.setShowAsImage(showAsImg);
			else {
				acc.setShowAsImage((short) 0);
			}
			acc.setFiletype(type);
			acc.setRealpath(uploadPath + acc.getItemId() + time + "." + extention);
			this.service.add(acc);

			fi.write(new File(acc.getRealpath()));
			msg = "�ļ��ϴ��ɹ���";
			flagSubmit = "true";
			String ext = extention.substring(1, extention.length());
			if ((!("jpg".equalsIgnoreCase(ext))) && (!("jpeg".equalsIgnoreCase(ext))) && (!("gif".equalsIgnoreCase(ext))) && (!("png".equalsIgnoreCase(ext))) && (!("bmp".equalsIgnoreCase(ext))))
				continue;
			String annexpath_from = uploadPath + acc.getItemId() + time + extention;
			int width = 640;
			int height = 420;
			DrawSimpleDiagramUtils.getSmallPicture(annexpath_from, width, height);
		}
		return new ActionForward("/accessories.do?action=show&forward=" + forward + "&isManager=" + isManager + "&itemId=" + itemId + "&msg=" + CharsetSwitch.encode(msg) + "&appName=" + appName + "&showAsImg=" + showAsImg + "&type=" + type
				+ "&maxCount=" + maxCount + "&minCount=" + minCount + "&flagSubmit=" + flagSubmit + "&path=" + path, true);
	}

	public ActionForward delete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		String id = request.getParameter("id");
		String filePath = request.getParameter("filePath");
		String forward = request.getParameter("forward");
		forward = StringUtils.isEmpty(forward) ? "accPage" : forward;
		String itemId = request.getParameter("itemId");
		String isManager = request.getParameter("isManager");
		String appName = request.getParameter("appName");
		String showAsImg = request.getParameter("showAsImg");
		String type = request.getParameter("type");
		String maxCount = request.getParameter("maxCount");
		String minCount = request.getParameter("minCount");
		String path = request.getParameter("path");

		String serverPath = this.servlet.getServletContext().getRealPath("/");
		File file = new File(serverPath + filePath);
		file.delete();
		this.service.delete(id);
		String msg = "�ɹ�ɾ���ļ���";

		return new ActionForward("/accessories.do?action=show&forward=" + forward + "&isManager=" + isManager + "&itemId=" + itemId + "&msg=" + CharsetSwitch.encode(msg) + "&appName=" + appName + "&showAsImg=" + showAsImg + "&type=" + type
				+ "&maxCount=" + maxCount + "&minCount=" + minCount + "&path=" + path, true);
	}
	
	public ActionForward downloadById(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		String serverPath = this.servlet.getServletContext().getRealPath("/");
		String forward = request.getParameter("forward");
		forward = StringUtils.isEmpty(forward) ? "accPage" : forward;
		String id = request.getParameter("id");
		Accessories acc = getService().getAccessories(id);
		InputStream in = null;
		OutputStream out = null;
		File file = new File(serverPath + acc.getPath());
		try {
			in = new FileInputStream(file);
			response.setContentType("application/unkown");
			response.addHeader("Content-Disposition", "attachment; filename=\"" + new String(acc.getFileName().getBytes("GBK"), "ISO8859-1") + "\"");
			out = response.getOutputStream();
			out.flush();
			int read = 0;
			while (((((read = in.read()) != -1) ? 1 : 0) & ((in != null) ? 1 : 0)) != 0) {
				out.write(read);
			}
		} catch (FileNotFoundException e) {
			String msg = "��Ҫ���ص���Դ�����ڣ������Ѿ���ɾ����";
			return new ActionForward("/accessories.do?action=show&forward=" + forward, true);
		} catch (IOException localIOException1) {
		} finally {
			try {
				in.close();
				out.close();
			} catch (IOException localIOException2) {
			} catch (NullPointerException localNullPointerException1) {
			}
		}
		return null;
	} 
	
	public ActionForward download(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
		String serverPath = this.servlet.getServletContext().getRealPath("/");
		String filePath = request.getParameter("filePath");
		String fileName = CharsetSwitch.decode(request.getParameter("fileName"));
		String forward = request.getParameter("forward");
		forward = StringUtils.isEmpty(forward) ? "accPage" : forward;
		String itemId = request.getParameter("itemId");
		String isManager = request.getParameter("isManager");
		String appName = request.getParameter("appName");
		String showAsImg = request.getParameter("showAsImg");
		String type = request.getParameter("type");
		String maxCount = request.getParameter("maxCount");
		String minCount = request.getParameter("minCount");
		String path = request.getParameter("path");
		InputStream in = null;
		OutputStream out = null;
		File file = new File(serverPath + filePath);
		try {
			in = new FileInputStream(file);
			response.setContentType("application/unkown");
			response.addHeader("Content-Disposition", "attachment; filename=\"" + new String(fileName.getBytes("GBK"), "ISO8859-1") + "\"");
			out = response.getOutputStream();
			out.flush();
			int read = 0;
			while (((((read = in.read()) != -1) ? 1 : 0) & ((in != null) ? 1 : 0)) != 0) {
				out.write(read);
			}
		} catch (FileNotFoundException e) {
			String msg = "��Ҫ���ص���Դ�����ڣ������Ѿ���ɾ����";
			return new ActionForward("/accessories.do?action=show&forward=" + forward + "&isManager=" + isManager + "&itemId=" + itemId + "&msg=" + CharsetSwitch.encode(msg) + "&appName=" + appName + "&showAsImg=" + showAsImg + "&type=" + type
					+ "&maxCount=" + maxCount + "&minCount=" + minCount + "&path=" + path, true);
		} catch (IOException localIOException1) {
		} finally {
			try {
				in.close();
				out.close();
			} catch (IOException localIOException2) {
			} catch (NullPointerException localNullPointerException1) {
			}
		}
		return null;
	}

	/**
	 * ���ӡ��޸ġ��鿴����ʱ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 */
	public ActionForward show(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {

		request.setAttribute("isManager", StringUtils.isEmpty(request.getParameter("isManager")) ? "true" : request.getParameter("isManager"));

		String type = request.getParameter("type");
		String path = request.getParameter("path");
		Properties prop = new Properties();
		try {
			prop.load(super.getClass().getResourceAsStream("/accessories.properties"));
		} catch (IOException e) {
			SystemLogHelper.addLog(request, "ȱ�ٸ��������ļ���Ȩ�޲���", "0", "�ϴ�����");
		}
		int fsize = Integer.parseInt(prop.getProperty("accessories.type." + type + ".size"));
		String extend = prop.getProperty("accessories.type." + type + ".extend");
		request.setAttribute("fsize", fsize);
		request.setAttribute("extend", extend);
		request.setAttribute("type", type);
		request.setAttribute("path", path);

		String itemId = request.getParameter("itemId");
		if (StringUtils.isEmpty(itemId)) {
			itemId = RandomGUID.getGUID();
		}
		request.setAttribute("itemId", itemId);

		List list = this.service.getAccessoriesListByItem(itemId);
		request.setAttribute("list", list);
		request.setAttribute("accessCount", list.size());

		request.setAttribute("maxCount", StringUtils.isEmpty(request.getParameter("maxCount")) ? "0" : request.getParameter("maxCount"));
		request.setAttribute("showAsImg", StringUtils.isEmpty(request.getParameter("showAsImg")) ? "false" : request.getParameter("showAsImg"));

		request.setAttribute("msg", request.getParameter("msg"));
		request.setAttribute("appName", request.getParameter("appName"));
		request.setAttribute("flagSubmit", request.getParameter("flagSubmit"));
		request.setAttribute("minCount", request.getParameter("minCount"));
		String forward = request.getParameter("forward");
		request.setAttribute("forward", forward);

		return mapping.findForward(StringUtils.isEmpty(forward) ? "accPage" : forward);
	}

}