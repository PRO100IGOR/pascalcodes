package com.sxsihe.oxhide.message;

import com.sxsihe.oxhide.ssouser.domain.Ssousers;

public class Address {
	private Ssousers ssousers;

	public Ssousers getSsousers() {
		return ssousers;
	}

	public void setSsousers(Ssousers ssousers) {
		this.ssousers = ssousers;
	}

	private String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	private String userid;
	private String address;
}
