package com.sxsihe.oxhide.helpdoc.service;
import com.ite.oxhide.service.BaseServiceImpl;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.helpdoc.service.HelpdocServiceImpl</p>
 * <p>Description:helpdoc����ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-09-28
 * @modify
 * @date
 */
 public class HelpdocServiceImpl extends BaseServiceImpl implements HelpdocService{
 }
	