package com.sxsihe.oxhide.tree.organ;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.struts.menu.MenuDes;
import com.ite.oxhide.struts.menu.MenuNode;
import com.sxsihe.base.PublicVariable;
import com.sxsihe.oxhide.dept.domain.Deptment;
import com.sxsihe.oxhide.employee.domain.Employee;
import com.sxsihe.oxhide.organ.domain.Organ;
import com.sxsihe.oxhide.post.domain.Posts;
import com.sxsihe.oxhide.server.dept.DeptServer;
import com.sxsihe.oxhide.server.employee.EmployeeServer;
import com.sxsihe.oxhide.server.organ.OrganServer;
import com.sxsihe.oxhide.server.post.PostServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletRequest;
import javax.servlet.jsp.PageContext;

public class OrganTreeServiceImpl implements OrganTreeServices {
	private OrganServer organServer;
	private DeptServer deptServer;
	private PostServer postServer;
	private EmployeeServer employeeServer;
	private OrganExtandService extandService;

	public OrganExtandService getExtandService() {
		return extandService;
	}

	public void setExtandService(OrganExtandService extandService) {
		this.extandService = extandService;
	}

	/**
	 * ��ʾͼ�� com.sxsihe.oxhide.tree.organ.OrganTreeServiceImpl.java ʱ�� Dec 27,
	 * 2011 ���� �ų���
	 */
	public List<MenuDes> getMenuDes(String type) {
		List list = new ArrayList();

		type = type.split("_")[0];
		MenuDes menuDes = new MenuDes();
		menuDes.setImg(PublicVariable.ORGANICON);
		menuDes.setName("����");
		list.add(menuDes);
		if (type.equals("organ")) {
			return list;
		}
		menuDes = new MenuDes();
		menuDes.setImg(PublicVariable.DEPTICON);
		menuDes.setName("����");
		list.add(menuDes);
		if (type.equals("dept")) {
			return list;
		}
		menuDes = new MenuDes();
		menuDes.setImg(PublicVariable.POSTICON);
		menuDes.setName("��λ");
		list.add(menuDes);
		if (type.equals("post")) {
			return list;
		}
		menuDes = new MenuDes();
		menuDes.setImg(PublicVariable.EMPLOYEEICON);
		menuDes.setName("Ա��");
		list.add(menuDes);

		if (extandService != null) {
			List temp = extandService.getMenuDes(type);
			if (temp != null)
				list.addAll(temp);
		}

		return list;
	}

	/**
	 * һ���Լ��� com.sxsihe.oxhide.tree.organ.OrganTreeServiceImpl.java ʱ�� Dec 27,
	 * 2011 ���� �ų���
	 */
	public List<MenuNode> getMenuNodeData(String type, PageContext pageContext) {
		/* ���ؽ�� */
		List nodeList = new ArrayList();

		/* ����begin */
		ServletRequest request = pageContext.getRequest();
		String organid = request.getParameter("organid");
		String deptid = request.getParameter("deptid");
		String postid = request.getParameter("postid");
		String dir = request.getParameter("dir");
		boolean dirBoolean = "up".equals(dir);
		type = type.split("_")[0];
		String ids = request.getParameter("ids");
		/* ����end */

		/* ���ػ��� */
		ConditionBlock block = new ConditionBlock();
		Map shotMap = new HashMap();
		shotMap.put("organname", true);
		if (StringUtils.isNotEmpty(organid)) {// �Ƿ�ָ������id
			block.and(new ConditionLeaf("organid", "corganid", ConditionLeaf.EQ, organid, false));
		} else {
			block.and(new ConditionLeaf("porgan.organid", "corganid", ConditionLeaf.EQ, null, false));
		}
		List<Organ> organList = this.organServer.findObjectsByCondition(block, shotMap);
		/* ���ӻ������� */
		List tempOrgan = new ArrayList();
		for (Organ organ : organList) {
			addOrganDg(nodeList, tempOrgan, organ, type, ids, dirBoolean, organid);
		}
		organList.addAll(tempOrgan);
		/* ���ز��� */
		if (!(type.equals("organ"))) {
			for (Organ organ : organList) {
				block = new ConditionBlock();
				if (StringUtils.isNotEmpty(deptid) && organ.getOrganid().equals(organid)) {
					block.and(new ConditionLeaf("deptid", "cdeptid", ConditionLeaf.EQ, deptid, false));
				} else {
					block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, null, false));
				}
				block.and(new ConditionLeaf("organ.organid", "corganid", ConditionLeaf.EQ, organ.getOrganid(), false));
				shotMap = new HashMap();
				shotMap.put("orderno", true);
				List<Deptment> deptList = this.deptServer.findObjectsByCondition(block, shotMap);
				/* ���Ӳ��� */
				List tempDept = new ArrayList();
				for (Deptment deptment : deptList) {
					addDeptDg(nodeList, tempDept, deptment, type, ids, dirBoolean, deptid);
				}
				deptList.addAll(tempDept);
				/* ���ظ�λ */
				if (!(type.equals("dept"))) {
					for (Deptment deptment : deptList) {
						block = new ConditionBlock();
						if (StringUtils.isNotEmpty(postid) && deptment.getDeptid().equals(deptid)) {
							block.and(new ConditionLeaf("postid", "cpostid", ConditionLeaf.EQ, postid, false));
						} else {
							block.and(new ConditionLeaf("posts.postid", "cpostida", ConditionLeaf.EQ, null, false));
						}
						block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, deptment.getDeptid(), false));
						shotMap = new HashMap();
						shotMap.put("orderno", true);
						List<Posts> postList = this.postServer.findObjectsByCondition(block, shotMap);
						/* ���Ӹ�λ */
						List tempPost = new ArrayList();
						for (Posts posts : postList) {
							addPostDg(nodeList, tempPost, posts, type, ids, dirBoolean, postid);
						}
						postList.addAll(tempPost);
						if (!(type.equals("post"))) {
							for (Posts posts : postList) {
								block = new ConditionBlock();
								block.and(new ConditionLeaf("posts.postid", "cpostid", ConditionLeaf.EQ, posts.getPostid(), false));
								shotMap = new HashMap();
								shotMap.put("orderno", true);
								List<Employee> empList = this.employeeServer.findObjectsByCondition(block, shotMap);
								for (Employee employee : empList) {
									addNode(nodeList, employee, "employee", "post_" + posts.getPostid(), type, ids);
								}
							}
						}
					}
				}
			}
		}

		if (extandService != null) {
			List temp = extandService.getMenuNodeData(type, pageContext);
			if (temp != null)
				nodeList.addAll(temp);
		}

		return nodeList;
	}

	public List<MenuNode> getMenuNodeData(String parentId, String parentType, String type, PageContext pageContext) {
		/* ���ؽ�� */
		List nodeList = new ArrayList();
		/* ����begin */
		type = type.split("_")[0];
		/* ����end */
		ConditionBlock block = new ConditionBlock();
		Map shotMap = new HashMap();

		if (StringUtils.isEmpty(parentId)) {
			block.and(new ConditionLeaf("porgan.organid", "corganid", ConditionLeaf.EQ, null, false));
			shotMap.put("organname", true);
			List<Organ> organList = this.organServer.findObjectsByCondition(block, shotMap);
			for (Organ organ : organList) {
				addNode(nodeList, organ, "organ", null, type, null);
			}
		} else if ("organ".equals(parentType)) {
			String organidParent = parentId.split("_")[1];
			block = new ConditionBlock();
			shotMap = new HashMap();
			block.and(new ConditionLeaf("porgan.organid", "corganid", ConditionLeaf.EQ, organidParent, false));
			shotMap.put("organname", true);
			List<Organ> organList = this.organServer.findObjectsByCondition(block, shotMap);
			for (Organ organ : organList) {
				addNode(nodeList, organ, "organ", parentId, type, null);
			}
			if (!(type.equals("organ"))) {
				block = new ConditionBlock();
				block.and(new ConditionLeaf("organ.organid", "corganid", ConditionLeaf.EQ, organidParent, false));
				block.and(new ConditionLeaf("deptment.deptid", "cdeptida", ConditionLeaf.EQ, null, false));
				shotMap = new HashMap();
				shotMap.put("orderno", true);
				List<Deptment> deptList = this.deptServer.findObjectsByCondition(block, shotMap);
				for (Deptment deptment : deptList) {
					addNode(nodeList, deptment, "dept", parentId, type, null);
				}
			}
		} else if ("dept".equals(parentType)) {
			String deptidParent = parentId.split("_")[1];
			block = new ConditionBlock();
			block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, deptidParent, false));
			shotMap = new HashMap();
			shotMap.put("orderno", true);
			List<Deptment> deptList = this.deptServer.findObjectsByCondition(block, shotMap);
			for (Deptment deptment : deptList) {
				addNode(nodeList, deptment, "dept", parentId, type, null);
			}
			if (!(type.equals("dept"))) {
				block = new ConditionBlock();
				block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, deptidParent, false));
				block.and(new ConditionLeaf("posts.postid", "cpostida", ConditionLeaf.EQ, null, false));
				shotMap = new HashMap();
				shotMap.put("orderno", true);
				List<Posts> postList = this.postServer.findObjectsByCondition(block, shotMap);
				for (Posts posts : postList) {
					addNode(nodeList, posts, "post", parentId, type, null);
				}
			}
		} else if ("post".equals(parentType)) {
			String postidParent = parentId.split("_")[1];
			block = new ConditionBlock();
			block.and(new ConditionLeaf("posts.postid", "cpostid", ConditionLeaf.EQ, postidParent, false));
			shotMap = new HashMap();
			shotMap.put("orderno", true);
			List<Posts> postList = this.postServer.findObjectsByCondition(block, shotMap);
			for (Posts posts : postList) {
				addNode(nodeList, posts, "post", parentId, type, null);
			}
			if (!(type.equals("post"))) {
				block = new ConditionBlock();
				block.and(new ConditionLeaf("posts.postid", "cpostid", ConditionLeaf.EQ, postidParent, false));
				shotMap = new HashMap();
				shotMap.put("orderno", true);
				List<Employee> empList = this.employeeServer.findObjectsByCondition(block, shotMap);
				for (Employee employee : empList) {
					addNode(nodeList, employee, "employee", parentId, type, null);
				}
			}
		}

		if (extandService != null) {
			List temp = extandService.getMenuNodeData(parentId, parentType, type, pageContext);
			if (temp != null)
				nodeList.addAll(temp);
		}
		return nodeList;
	}

	private void addNode(List nodeList, Object o, String nodeType, String parentid, String typeBegin, String ids) {
		MenuNode node = new MenuNode();
		node.setType(nodeType);
		if (nodeType.equals("organ")) {
			Organ organ = (Organ) o;
			node.setId("organ_" + organ.getOrganid());
			node.setTitle(organ.getOrganname());
			node.setIcon(PublicVariable.ORGANICON);
			node.setOpenIcon(PublicVariable.ORGANOPENICON);
		} else if (nodeType.equals("dept")) {
			Deptment deptment = (Deptment) o;
			node.setId("dept_" + deptment.getDeptid());
			node.setTitle(deptment.getDeptname());
			node.setIcon(PublicVariable.DEPTICON);
			node.setOpenIcon(PublicVariable.DEPTOPENICON);
		} else if (nodeType.equals("post")) {
			Posts post = (Posts) o;
			node.setId("post_" + post.getPostid());
			node.setTitle(post.getPostname());
			node.setIcon(PublicVariable.POSTICON);
			node.setOpenIcon(PublicVariable.POSTOPENICON);
		} else if (nodeType.equals("employee")) {
			Employee employee = (Employee) o;
			node.setId("emp_" + employee.getEmployeeid());

			node.setTitle(employee.getEmployeename());
			node.setIcon(PublicVariable.EMPLOYEEICON);
			node.setOpenIcon(PublicVariable.EMPLOYEEOPENICON);
		}
		node.setParentId(parentid);
		if (StringUtils.isNotEmpty(ids) && (nodeType.equals(typeBegin)) && (ids.indexOf(node.getId().split("_")[1]) != -1)) {
			node.setSelected("true");
		}
		nodeList.add(node);
	}

	/**
	 * �ݹ����ӻ��� dir=true ��ʾ�ϣ���֮��
	 * com.sxsihe.oxhide.tree.organ.OrganTreeServiceImpl.java ʱ�� Dec 27, 2011 ����
	 * �ų���
	 */
	private void addOrganDg(List nodeList, List organList, Organ organ, String type, String ids, boolean dir, String organid) {
		addNode(nodeList, organ, "organ", organ.getPorgan() == null || organ.getOrganid().equals(organid) ? null : "organ_" + organ.getPorgan().getOrganid(), type, ids);
		if (dir) {
			Organ parent = organ.getPorgan();
			if (parent != null) {
				organList.add(parent);
				addOrganDg(nodeList, organList, parent, type, ids, dir, organid);
			}
		} else {
			ConditionBlock block = new ConditionBlock();
			Map sortMap = new HashMap();
			sortMap.put("organname", true);
			block.and(new ConditionLeaf("porgan.organid", "corganid", ConditionLeaf.EQ, organ.getOrganid(), false));
			List<Organ> list = organServer.findObjectsByCondition(block, sortMap);
			organList.addAll(list);
			for (Organ organChild : list) {
				addOrganDg(nodeList, organList, organChild, type, ids, dir, organid);
			}
		}
	}

	/**
	 * �ݹ鲿�� com.sxsihe.oxhide.tree.organ.OrganTreeServiceImpl.java ʱ�� Dec 27,
	 * 2011 ���� �ų���
	 */
	private void addDeptDg(List nodeList, List deptList, Deptment deptment, String type, String ids, boolean dir, String deptid) {
		addNode(nodeList, deptment, "dept", deptment.getDeptment() == null || deptment.getDeptid().equals(deptid) ? "organ_" + deptment.getOrgan().getOrganid() : "dept_" + deptment.getDeptment().getDeptid(), type, ids);
		if (dir) {
			Deptment parent = deptment.getDeptment();
			if (parent != null) {
				deptList.add(parent);
				addDeptDg(nodeList, deptList, parent, type, ids, dir, deptid);
			}
		} else {
			ConditionBlock block = new ConditionBlock();
			Map sortMap = new HashMap();
			sortMap.put("orderno", true);
			block.and(new ConditionLeaf("deptment.deptid", "cdeptid", ConditionLeaf.EQ, deptment.getDeptid(), false));
			List<Deptment> list = deptServer.findObjectsByCondition(block, sortMap);
			deptList.addAll(list);
			for (Deptment deptChild : list) {
				addDeptDg(nodeList, deptList, deptChild, type, ids, dir, deptid);
			}
		}
	}

	/**
	 * �ݹ����Ӹ�λ com.sxsihe.oxhide.tree.organ.OrganTreeServiceImpl.java ʱ�� Dec 27,
	 * 2011 ���� �ų���
	 */
	private void addPostDg(List nodeList, List postList, Posts posts, String type, String ids, boolean dir, String postid) {
		addNode(nodeList, posts, "post", posts.getPosts() == null || posts.getPostid().equals(postid) ? "dept_" + posts.getDeptment().getDeptid() : "post_" + posts.getPosts().getPostid(), type, ids);
		if (dir) {
			Posts parent = posts.getPosts();
			if (parent != null) {
				postList.add(parent);
				addPostDg(nodeList, postList, parent, type, ids, dir, postid);
			}
		} else {
			ConditionBlock block = new ConditionBlock();
			Map sortMap = new HashMap();
			sortMap.put("orderno", true);
			block.and(new ConditionLeaf("posts.postid", "cpostida", ConditionLeaf.EQ, posts.getPostid(), false));
			List<Posts> list = postServer.findObjectsByCondition(block, sortMap);
			postList.addAll(list);
			for (Posts postsChild : list) {
				addPostDg(nodeList, postList, postsChild, type, ids, dir, postid);
			}
		}
	}

	public OrganServer getOrganServer() {
		return this.organServer;
	}

	public void setOrganServer(OrganServer organServer) {
		this.organServer = organServer;
	}

	public DeptServer getDeptServer() {
		return this.deptServer;
	}

	public void setDeptServer(DeptServer deptServer) {
		this.deptServer = deptServer;
	}

	public PostServer getPostServer() {
		return this.postServer;
	}

	public void setPostServer(PostServer postServer) {
		this.postServer = postServer;
	}

	public EmployeeServer getEmployeeServer() {
		return this.employeeServer;
	}

	public void setEmployeeServer(EmployeeServer employeeServer) {
		this.employeeServer = employeeServer;
	}
}