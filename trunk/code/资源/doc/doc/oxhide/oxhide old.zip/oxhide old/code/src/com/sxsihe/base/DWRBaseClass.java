package com.sxsihe.base;

import java.util.HashMap;
import java.util.Map;

import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.ssouser.service.SsouserService;
import com.sxsihe.oxhide.application.service.ApplicationService;
import com.sxsihe.oxhide.dept.service.DeptService;
import com.sxsihe.oxhide.dictionary.service.DictionaryService;
import com.sxsihe.oxhide.dictionarycontent.service.DictionarycontentService;
import com.sxsihe.oxhide.organ.service.OrganService;
import com.sxsihe.oxhide.post.service.PostService;

/**
 * <p>
 * title:com.ite.base.DWRBaseClass
 * </p>
 * <p>
 * Description:DWR��,���ں�̨��������
 * </p>
 * <p>
 * copyright:copyright (c) 2009
 * </p>
 * <p>
 * Company:ITE
 * </p>
 *
 * @version 1.0
 * @builder 2010-02-03
 */
public class DWRBaseClass {

	/**
	 * ���������������Ƿ����
	 *
	 * @param type
	 *            ��ӦSpring�����ļ���service bean id������·��,��һ����ĸСд
	 * @param id
	 *            ����
	 * @return true��ʾ����
	 */
	public boolean checkObjcect(String type, String id) {
		BaseServiceIface typesServiceIface = (BaseServiceIface) SpringContextUtil.getBean(type);
		Object o = typesServiceIface.findObjectBykey(id);
		return o != null;
	}

	/**
	 * ��֤���������Ƿ�Ψһ zcc Apr 22, 2011
	 *
	 * @param deptid
	 * @param organid
	 * @param deptname
	 * @return true=������ false=����
	 */
	public boolean checkDeptName(String deptid, String organid, String deptname) {
		DeptService deptService = (DeptService) SpringContextUtil.getBean("deptService");
		String hql = "from Deptment dept where (dept.deptid != :deptid or :deptid is null) and dept.organ.organid = :organid and dept.deptname = :deptname";
		Map map = new HashMap();
		map.put("deptid", deptid);
		map.put("organid", organid);
		map.put("deptname", deptname);
		return deptService.queryHql(hql, map).isEmpty();
	}

	/**
	 * ��֤���������Ƿ�Ψһ zcc Apr 22, 2011
	 *
	 * @param organid
	 * @param organname
	 * @return
	 */
	public boolean checkOrganName(String organid, String organname) {
		OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
		String hql = "from Organ organ where (organ.organid != :organid or :organid is null)  and organ.organname = :organname";
		Map map = new HashMap();
		map.put("organid", organid);
		map.put("organname", organname);
		return organService.queryHql(hql, map).isEmpty();
	}

	/**
	 * ��֤��λΨһ�� zcc Apr 22, 2011
	 *
	 * @param postid
	 * @param deptid
	 * @param postname
	 * @return
	 */
	public boolean checkPostName(String postid, String deptid, String postname) {
		PostService postService = (PostService) SpringContextUtil.getBean("postService");
		String hql = "from Posts post where post.deptment.deptid = :deptid and post.postname = :postname and (post.postid != :postid or :postid  is null)";
		Map map = new HashMap();
		map.put("deptid", deptid);
		map.put("postname", postname);
		map.put("postid", postid);
		return postService.queryHql(hql, map).isEmpty();
	}

	/**
	 * �����û���Ψһ zcc Apr 22, 2011
	 *
	 * @param username
	 * @param userid
	 * @return
	 */
	public boolean checkUserName(String username, String userid) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		String hql = "from Ssousers u where u.username = :username and (u.userid != :userid or :userid is null)";
		Map map = new HashMap();
		map.put("username", username);
		map.put("userid", userid);
		return ssouserService.queryHql(hql, map).isEmpty();
	}

	/**
	 * ������ɫ��Ψһ zcc Apr 22, 2011
	 *
	 * @param rolename
	 * @param roleid
	 * @return
	 */
	public boolean checkRoleName(String rolename, String roleid) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		String hql = "from Ssoroles u where u.rolename = :rolename and (u.roleid != :roleid or :roleid is null)";
		Map map = new HashMap();
		map.put("rolename", rolename);
		map.put("roleid", roleid);
		return ssouserService.queryHql(hql, map).isEmpty();
	}

	/**
	 * ������Դ���� zcc Apr 22, 2011
	 *
	 * @param rolename
	 * @param roleid
	 * @return
	 */
	public boolean checkresourceName(String resourcename, String resourceid) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		String hql = "from Resources u where u.resourcename = :resourcename and (u.resourceid != :resourceid or :resourceid is null) ";
		Map map = new HashMap();
		map.put("resourcename", resourcename);
		map.put("resourceid", resourceid);
		return ssouserService.queryHql(hql, map).isEmpty();
	}
	/**
	 * ��֤��Դ���
	 * @param resourcename
	 * @param resourceid
	 * @return
	 */
	public boolean checkresourceSimplyName(String resourcename, String resourceid) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		String hql = "from Resources u where u.simplyname = :resourcename and (u.resourceid != :resourceid or :resourceid is null)";
		Map map = new HashMap();
		map.put("resourcename", resourcename);
		map.put("resourceid", resourceid);
		return ssouserService.queryHql(hql, map).isEmpty();
	}
	/**
	 * ��֤��Դtabname
	 * @param resourcename
	 * @param resourceid
	 * @return
	 */
	public boolean checkresourceTabName(String tabname, String resourceid) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		String hql = "from Resources u where u.tabname = :tabname and (u.resourceid != :resourceid or :resourceid is null)";
		Map map = new HashMap();
		map.put("tabname", tabname);
		map.put("resourceid", resourceid);
		return ssouserService.queryHql(hql, map).isEmpty();
	}
	/**
	 * ������Դ��ַ zcc Apr 22, 2011
	 * @param rolename
	 * @param roleid
	 * @return
	 */
	public boolean checkresourceUrl(String resourceurl, String resourceid) {
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		String hql = "from Resources u where u.resourceurl = :resourceurl and (u.resourceid != :resourceid or :resourceid is null) ";
		Map map = new HashMap();
		map.put("resourceurl", resourceurl);
		map.put("resourceid", resourceid);
		return ssouserService.queryHql(hql, map).isEmpty();
	}



	/**
	 * ��֤ϵͳ���� zcc Apr 25, 2011
	 *
	 * @param appname
	 * @param appid
	 * @return
	 */
	public boolean checkAppName(String appname, String appid) {
		ApplicationService applicationService = (ApplicationService) SpringContextUtil.getBean("applicationService");
		String hql = "from Application u where u.appname = :appname and (u.appid != :appid or :appid is null)";
		Map map = new HashMap();
		map.put("appname", appname);
		map.put("appid", appid);
		return applicationService.queryHql(hql, map).isEmpty();
	}
	/**
	 * ��֤ϵͳ���
	 * @param appname
	 * @param appid
	 * @return
	 */
	public boolean checkAppSimplyName(String appname, String appid) {
		ApplicationService applicationService = (ApplicationService) SpringContextUtil.getBean("applicationService");
		String hql = "from Application u where u.simplyname = :appname and (u.appid != :appid or :appid is null) ";
		Map map = new HashMap();
		map.put("appname", appname);
		map.put("appid", appid);
		return applicationService.queryHql(hql, map).isEmpty();
	}
	/**
	 * �����ֵ�����
	 * @param dname
	 * @param did
	 * @return
	 */
	public boolean checkDictionaryTypeName(String dname, String did) {
		DictionaryService dictionaryService = (DictionaryService) SpringContextUtil.getBean("dictionaryService");
		String hql = "from Dictionary u where u.dname = :dname and (u.did != :did  or :did is null)";
		Map map = new HashMap();
		map.put("dname", dname);
		map.put("did", did);
		return dictionaryService.queryHql(hql, map).isEmpty();
	}
	/**
	 * �����ֵ� ���ͱ���
	 * @param dname
	 * @param did
	 * @return
	 */
	public boolean checkDictionaryCode(String dcode, String did) {
		DictionaryService dictionaryService = (DictionaryService) SpringContextUtil.getBean("dictionaryService");
		String hql = "from Dictionary u where u.dcode = :dcode and (u.did != :did  or :did is null) ";
		Map map = new HashMap();
		map.put("dcode", dcode);
		map.put("did", did);
		return dictionaryService.queryHql(hql, map).isEmpty();
	}

	/**
	 * �����ֵ�
	 * @param dcvalue
	 * @param did
	 * @param dcid
	 * @return
	 */
	public boolean checkDictionaryName(String dcvalue, String did, String dcid) {
		DictionarycontentService dictionarycontentService = (DictionarycontentService) SpringContextUtil.getBean("dictionarycontentService");
		String hql = "from Dictionarycontent u where u.dcvalue = :dcvalue and (u.dcid != :dcid or :dcid is null) and u.dictionary.did = :did";
		Map map = new HashMap();
		map.put("dcvalue", dcvalue);
		map.put("did", did);
		map.put("dcid", dcid);
		return dictionarycontentService.queryHql(hql, map).isEmpty();
	}

	/**
	 * ��֤�û�ƻ��id
	 * @param userid
	 * @return
	 */
	public boolean checkUserAppleId(String userid,String apple){
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		String hql = "from Ssousers u where u.apple = :apple and (u.userid != :userid or :userid is null)";
		Map map = new HashMap();
		map.put("userid", userid);
		map.put("apple", apple);
		return ssouserService.queryHql(hql, map).isEmpty();
	}
	/**
	 * ��֤��׿id
	* @Title: DWRBaseClass.java
	* @Package com.sxsihe.base
	* @Description: TODO
	* @author �ų���
	* @date 2011-11-19 ����02:33:28
	* @version V1.0
	 */
	public boolean checkUserAndroidId(String userid,String android){
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		String hql = "from Ssousers u where u.android = :android and (u.userid != :userid or :userid is null)";
		Map map = new HashMap();
		map.put("userid", userid);
		map.put("android", android);
		return ssouserService.queryHql(hql, map).isEmpty();
	}

}
