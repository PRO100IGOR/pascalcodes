package com.sxsihe.oxhide.ssoroles.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.HashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.actionEx.BaseSaveAction;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.rolesapp.domain.Rolesapp;
import com.sxsihe.oxhide.rolesapp.service.RolesappService;
import com.sxsihe.oxhide.rolesresource.domain.Rolesresources;
import com.sxsihe.oxhide.rolesresource.service.RolesresourceService;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;
import com.sxsihe.oxhide.ssoroles.form.SsorolesForm;
import com.sxsihe.oxhide.ssoroles.service.SsorolesService;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.oxhide.usersroles.domain.Usersroles;
import com.sxsihe.oxhide.usersroles.service.UsersrolesService;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssoroles.action.SsorolesSaveAction
 * </p>
 * <p>
 * Description:��ɫSaveAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */

public class SsorolesSaveAction extends BaseSaveAction {
	/**
	 * ��FORM�õ��־û�PO,���ת�����ӣ���������д
	 * 
	 * @param form
	 * @return
	 */
	protected Serializable getPersisPo(ActionForm form, String type) {
		SsorolesForm vForm = (SsorolesForm) form;
		Ssoroles po;
		if (type.equals("add"))
			po = new Ssoroles();
		else {
			String roleid = vForm.getRoleid();
			po = (Ssoroles) service.findObjectBykey(roleid);
		}

		po.setRoleid(vForm.getRoleid());
		po.setRolename(vForm.getRolename());
		po.setRolecode(vForm.getRolecode());
		po.setRemark(vForm.getRemark());
		po.setIsvalidation(vForm.getIsvalidation());

		return po;
	}

	/**
	 * ����ַ���Դ zcc Apr 25, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward saveroleresource(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String ids = request.getParameter("resids");
		String id = request.getParameter("id");
		Ssoroles ssoroles = new Ssoroles();
		ssoroles.setRoleid(id);
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("ssoroles.roleid", "croleid", ConditionLeaf.EQ, id, true));
		RolesappService rolesappService = (RolesappService) SpringContextUtil.getBean("rolesappService");
		rolesappService.deleteBatch(rolesappService.findObjectsByCondition(block, null));
		RolesresourceService rolesresourceService = (RolesresourceService) SpringContextUtil.getBean("rolesresourceService");
		rolesresourceService.deleteBatch(rolesresourceService.findObjectsByCondition(block, null));

		String[] idsArr = ids.split(",");
		for (int i = 0; i < idsArr.length; i++) {
			if (idsArr[i].trim().equals("")) {
				continue;
			}
			Resources resources = new Resources();
			resources.setResourceid(idsArr[i]);
			Rolesresources rolesresources = new Rolesresources();
			rolesresources.setResources(resources);
			rolesresources.setSsoroles(ssoroles);
			this.getService().add(rolesresources);
		}

		ids = request.getParameter("appids");
		idsArr = ids.split(",");
		for (int i = 0; i < idsArr.length; i++) {
			if (idsArr[i].trim().equals("")) {
				continue;
			}
			Application application = new Application();
			application.setAppid(idsArr[i]);
			Rolesapp rolesapp = new Rolesapp();
			rolesapp.setApplication(application);
			rolesapp.setSsoroles(ssoroles);
			rolesappService.add(rolesapp);
		}
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	/**
	 * �û������ɫ zcc Apr 25, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward saveuserroles(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String ids = request.getParameter("ids");
		String id = request.getParameter("id");
		Ssousers ssousers = new Ssousers();
		ssousers.setUserid(id);
		String[] idsArr = ids.split(",");
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("ssousers.userid", "cuserid", ConditionLeaf.EQ, id, true));
		UsersrolesService usersrolesService = (UsersrolesService) SpringContextUtil.getBean("usersrolesService");
		usersrolesService.deleteBatch(usersrolesService.findObjectsByCondition(block, null));
		List preList = new ArrayList(); 
		for (int i = 0; i < idsArr.length; i++) {
			Ssoroles ssoroles = new Ssoroles();
			ssoroles.setRoleid(idsArr[i]);
			Usersroles usersroles = new Usersroles();
			usersroles.setSsoroles(ssoroles);
			usersroles.setSsousers(ssousers);
			preList.add(usersroles);
		}
		usersrolesService.saveBatch(preList);
		return new ActionForward("/core/success/opSuccess.jsp");
	}

	/**
	 * ������ʵ��Ĺ���ʵ��
	 * 
	 * @param mainPo
	 * @param request
	 * @param type
	 */
	protected void setPersistAssociatePo(Serializable mainPo, ActionForm form, HttpServletRequest request, String type) {
	}
	
	
	/**
	 * ��ɫ�����û� zcc Apr 25, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward saveroleuser(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String ids = request.getParameter("ids");
		String id = request.getParameter("id");
		Ssoroles ssoroles = new Ssoroles();
		ssoroles.setRoleid(id);
		String[] idsArr = ids.split(",");
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("ssoroles.roleid", "croleid", ConditionLeaf.EQ, id, true));
		UsersrolesService usersrolesService = (UsersrolesService) SpringContextUtil.getBean("usersrolesService");
		usersrolesService.deleteBatch(usersrolesService.findObjectsByCondition(block, null));
		List preList = new ArrayList(); 
		for (int i = 0; i < idsArr.length; i++) {
			Ssousers ssousers = new Ssousers();
			ssousers.setUserid(idsArr[i]);
			Usersroles usersroles = new Usersroles();
			usersroles.setSsoroles(ssoroles);
			usersroles.setSsousers(ssousers);
			preList.add(usersroles);
		}
		usersrolesService.saveBatch(preList);
		return new ActionForward("/core/success/opSuccess.jsp");
	}
}