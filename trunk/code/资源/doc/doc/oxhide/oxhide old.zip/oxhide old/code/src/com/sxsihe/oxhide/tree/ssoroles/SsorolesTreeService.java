package com.sxsihe.oxhide.tree.ssoroles;

import com.ite.oxhide.struts.menu.MenuDataPick;

public interface SsorolesTreeService extends MenuDataPick{

}
