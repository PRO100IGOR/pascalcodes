package com.sxsihe.oxhide.helpdoc.dao.hibernateImpl;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.helpdoc.domain.Helpdoc;
import com.sxsihe.oxhide.helpdoc.dao.HelpdocDAO;
/**
 * 
 * <p>Title:com.sxsihe.oxhide.helpdoc.dao.hibernateImpl.HelpdocDAOImpl</p>
 * <p>Description:helpdoc���ݲ�ʵ��</p>
 * <p>Copyright: Copyright (c) 2012</p>
 * <p>Company: �ĺ�</p>
 * @author �ų���
 * @version 1.0
 * @date 2011-09-28
 * @modify
 * @date
 */
public class HelpdocDAOImpl extends BaseDAOImpl implements HelpdocDAO {
	/**
	 * ������룬ָ��dao��Ӧʵ����
	 */
	public Class getEntityClass() {
		return Helpdoc.class;
	}
}
	