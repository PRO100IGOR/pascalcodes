package com.sxsihe.oxhide.application.action;

import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.application.form.ApplicationConditionForm;
import com.sxsihe.oxhide.application.form.ApplicationForm;
import com.sxsihe.oxhide.message.SenderManger;
import com.sxsihe.oxhide.message.android.AndroidService;
import com.sxsihe.oxhide.message.mobile.service.UnmobileService;
import com.sxsihe.oxhide.message.token.service.TokensService;
import com.sxsihe.oxhide.schema.service.SchemaService;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.oxhide.ssouser.service.SsouserService;
import com.sxsihe.utils.common.RandomGUID;
import com.sxsihe.oxhide.message.Sender;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.extremecomponents.table.limit.Limit;

public class ApplicationShowAction extends BaseShowAction {
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		SchemaService schemaService = (SchemaService) SpringContextUtil.getBean("schemaService");
		request.setAttribute("list", schemaService.getAll());
		ApplicationForm vForm = (ApplicationForm) form;
		vForm.setAppid(RandomGUID.getGUID().replaceAll("-", ""));
	}

	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		SchemaService schemaService = (SchemaService) SpringContextUtil.getBean("schemaService");
		request.setAttribute("list", schemaService.getAll());
	}

	/**
	 * �鿴�󶨵�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showToken(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		String type = request.getParameter("type");
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("application.appid", "cappid", ConditionLeaf.EQ, id, true));
		block.and(new ConditionLeaf("tokentype", "ctokentype", ConditionLeaf.EQ, type, true));
		TokensService tokensService = (TokensService) SpringContextUtil.getBean("tokensService");
		List list = tokensService.findObjectsByCondition(block, null);
		request.setAttribute("list", list);
		request.setAttribute("totalRows", list.size());
		request.setAttribute("type", "type");
		return mapping.findForward("showToken");
	}

	public ActionForward showSenderView(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
		String type = request.getParameter("type");
		if (type.equals("dwr")) {
			request.setAttribute("view", senderManger.getDwrById(id));
		} else if (type.equals("apple")) {
			request.setAttribute("view", senderManger.getAppleById(id));
		} else if (type.equals("android")) {
			request.setAttribute("view", senderManger.getAndroidById(id));
		}
		return mapping.findForward("showSenderView");
	}

	/**
	 * ��ʾ�����Ķ��ŵ��û�
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showUnMobile(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		UnmobileService unmobileService = (UnmobileService) SpringContextUtil.getBean("unmobileService");
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("application.appid", "cappid", ConditionLeaf.EQ, id, true));
		List list = unmobileService.findObjectsByCondition(block, null);
		request.setAttribute("list", list);
		request.setAttribute("totalRows", list.size());
		return mapping.findForward("showUnMobile");
	}

	/**
	 * ��׿��ַ
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 *             Administrator
	 *             com.sxsihe.oxhide.
	 *             application.action
	 *             ApplicationShowAction.java
	 *             2012����10:32:36 oxhide
	 */
	public ActionForward showAddress(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		AndroidService androidService = (AndroidService) SpringContextUtil.getBean("android");
		List list = androidService.getAddress();
		request.setAttribute("list", list);
		request.setAttribute("totalRows", list.size());
		return mapping.findForward("showAddress");
	}

	/**
	 * ��׿��ƻ���ƶ�����
	 */
	public ActionForward showSender(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		String type = request.getParameter("type");
		Application application = (Application) getService().findObjectBykey(id);
		SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		List list = null;
		if (type.equals("apple")) {
			list = senderManger.getApples(application.getAppcode());
		} else {
			list = senderManger.getAndroids(application.getAppcode());
		}
		for (int i = 0; i < list.size(); i++) {
			Sender sender = (Sender) list.get(i);
			sender.setSsousers((Ssousers) ssouserService.findObjectBykey(sender.getUserid()));
		}
		request.setAttribute("type", "type");
		request.setAttribute("totalRows", list.size());
		request.setAttribute("list", list);
		return mapping.findForward("showSender");
	}

	public ActionForward showDwr(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		Application application = (Application) getService().findObjectBykey(id);
		SenderManger senderManger = (SenderManger) SpringContextUtil.getBean("senderManger");
		SsouserService ssouserService = (SsouserService) SpringContextUtil.getBean("ssouserService");
		List list = senderManger.getDwrsByAppcode(application.getAppcode());
		for (int i = 0; i < list.size(); i++) {
			Sender sender = (Sender) list.get(i);
			sender.setSsousers((Ssousers) ssouserService.findObjectBykey(sender.getUserid()));
		}
		request.setAttribute("totalRows", list.size());
		request.setAttribute("list", list);
		return mapping.findForward("showDwr");
	}

	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (!(form instanceof ApplicationForm))
				return form;
			Application pos = (Application) po;
			ApplicationForm vForm = (ApplicationForm) form;
			BeanUtils.setProperty(vForm, "appid", PropertyUtils.getProperty(pos, "appid"));
			BeanUtils.setProperty(vForm, "appname", PropertyUtils.getProperty(pos, "appname"));
			BeanUtils.setProperty(vForm, "appurl", PropertyUtils.getProperty(pos, "appurl"));
			BeanUtils.setProperty(vForm, "appindex", PropertyUtils.getProperty(pos, "appindex"));
			BeanUtils.setProperty(vForm, "apptitle", PropertyUtils.getProperty(pos, "apptitle"));
			BeanUtils.setProperty(vForm, "ico", PropertyUtils.getProperty(pos, "ico"));
			BeanUtils.setProperty(vForm, "bigico", PropertyUtils.getProperty(pos, "bigico"));
			BeanUtils.setProperty(vForm, "orderno", PropertyUtils.getProperty(pos, "orderno"));
			BeanUtils.setProperty(vForm, "appcode", PropertyUtils.getProperty(pos, "appcode"));
			BeanUtils.setProperty(vForm, "largeico", PropertyUtils.getProperty(pos, "largeico"));
			BeanUtils.setProperty(vForm, "simplyname", PropertyUtils.getProperty(pos, "simplyname"));
			BeanUtils.setProperty(vForm, "appurlw", PropertyUtils.getProperty(pos, "appurlw"));
			BeanUtils.setProperty(vForm, "remark", PropertyUtils.getProperty(pos, "remark"));
			BeanUtils.setProperty(vForm, "applekey", PropertyUtils.getProperty(pos, "applekey"));
			BeanUtils.setProperty(vForm, "androidkey", PropertyUtils.getProperty(pos, "androidkey"));
			BeanUtils.setProperty(vForm, "androidkf", PropertyUtils.getProperty(pos, "androidkf"));
			BeanUtils.setProperty(vForm, "applekf", PropertyUtils.getProperty(pos, "applekf"));
			BeanUtils.setProperty(vForm, "timer", PropertyUtils.getProperty(pos, "timer"));
			BeanUtils.setProperty(vForm, "timeenable", PropertyUtils.getProperty(pos, "timeenable"));
			BeanUtils.setProperty(vForm, "times", PropertyUtils.getProperty(pos, "times"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return form;
	}

	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		ApplicationConditionForm applicationConditionForm = (ApplicationConditionForm) conditionForm;
		if (applicationConditionForm != null) {
			block.and(new ConditionLeaf("appname", "cappname", ConditionLeaf.LIKE, applicationConditionForm.getCappname(), true));
			block.and(new ConditionLeaf("apptitle", "capptitle", ConditionLeaf.LIKE, applicationConditionForm.getCapptitle(), true));
		}
		return getService().getTotalObjects(block);
	}

	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		ApplicationConditionForm applicationConditionForm = (ApplicationConditionForm) conditionForm;
		if (applicationConditionForm != null) {
			block.and(new ConditionLeaf("appname", "cappname", ConditionLeaf.LIKE, applicationConditionForm.getCappname(), true));
			block.and(new ConditionLeaf("apptitle", "capptitle", ConditionLeaf.LIKE, applicationConditionForm.getCapptitle(), true));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = getSortMap(limit);
		else
			sortMap = new HashMap();
		sortMap.put("orderno", Boolean.valueOf(true));
		List list = null;
		if (limit != null)
			list = getService().findObjectsByCondition(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed());
		else
			list = getService().findObjectsByCondition(block, sortMap);
		return list;
	}

	public ActionForward showOrderList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		saveToken(request);
		ConditionBlock block = new ConditionBlock();
		Map sortMap = new HashMap();
		sortMap.put("orderno", Boolean.valueOf(true));
		List list = getService().findObjectsByCondition(block, sortMap);
		request.setAttribute("totalRows", Integer.valueOf(list.size()));
		request.setAttribute("list", list);
		return mapping.findForward("showOrderList");
	}
}