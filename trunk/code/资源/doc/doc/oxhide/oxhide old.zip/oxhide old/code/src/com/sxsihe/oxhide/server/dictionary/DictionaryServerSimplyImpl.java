package com.sxsihe.oxhide.server.dictionary;

import java.util.List;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.dictionarycontent.domain.Dictionarycontent;
import com.sxsihe.oxhide.dictionarycontent.service.DictionarycontentService;
import com.sxsihe.utils.common.DataUtils;

public class DictionaryServerSimplyImpl implements DictionaryServerSimply{
	/**
	 * ����json��ʽ���������ֵ�
	 *
	 * @param code
	 *            ����
	 * @return
	 */
	public String getDicAsString(String code) {
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("dictionary.dcode", "cdcode", ConditionLeaf.EQ, code, false));
		DictionarycontentService dictionarycontentService = (DictionarycontentService)SpringContextUtil.getBean("dictionarycontentService");
		List list = dictionarycontentService.findObjectsByCondition(block, null);
		StringBuilder builder = new StringBuilder();
		builder.append("{");
		for (int i = 0; i < list.size(); i++) {
			Dictionarycontent dictionarycontent = (Dictionarycontent) list.get(i);
			if (i != list.size() - 1) {
				builder.append("\"" + dictionarycontent.getDcode() + "\":" + "\"" + dictionarycontent.getDcvalue() + "\",");
			} else {
				builder.append("\"" + dictionarycontent.getDcode() + "\":" + "\"" + dictionarycontent.getDcvalue() + "\"");
			}
		}
		builder.append("}");
		return builder.toString();
	}
	
	/**
	 * ��ѯĳ�������ֵ������
	 * @param dicType
	 * @param dicCode
	 * @return
	 */
	public String getDicValue(String dicType,String dicCode){
		ConditionBlock block = new ConditionBlock();
		block.and(new ConditionLeaf("dictionary.dcode", "cdcode", ConditionLeaf.EQ, dicType, false));
		block.and(new ConditionLeaf("dcode", "ccdcode", ConditionLeaf.EQ, dicCode, false));
		DictionarycontentService dictionarycontentService = (DictionarycontentService)SpringContextUtil.getBean("dictionarycontentService");
		List<Dictionarycontent> list = DataUtils.copyPoJos(dictionarycontentService.findObjectsByCondition(block, null),Dictionarycontent.class);
		for (int i = 0; i < list.size(); i++) {
			Dictionarycontent dictionarycontent = list.get(i);
			return dictionarycontent.getDcvalue();
		}
		return "";
	}
}
