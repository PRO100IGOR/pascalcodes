package com.sxsihe.oxhide.organ.service;

import com.ite.oxhide.service.BaseServiceImpl;

import com.sxsihe.oxhide.organ.dao.OrganDAO;
import java.util.List;

/**
 *<p>
 * Title:com.sxsihe.oxhide.organ.service.OrganServiceImpl
 * </p>
 *<p>
 * Description:���� Service
 * </p>
 *<p>
 * Copyright: Copyright (c) 2007
 * </p>
 *<p>
 * Company: ITE
 * </p>
 *
 * @author zcc
 * @version 1.0
 * @date 2011-04-21
 *
 * @modify
 * @date
 */
public class OrganServiceImpl extends BaseServiceImpl implements OrganService {
	/**
	 * ��ѯ�����ӻ���(����ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����04:50:14
	 * @version V1.0
	 */
	public List getChildOrgan(String organid, boolean containSelf) {
		return ((OrganDAO) getDao()).getChildOrgan(organid, containSelf);
	}

	/**
	 * ��ѯ�����ӻ���(����ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����04:50:25
	 * @version V1.0
	 */
	public List getChildOrgan(String organid) {
		return ((OrganDAO) getDao()).getChildOrgan(organid);
	}

	/**
	 *��ѯ�����ӻ���(�ַ���ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����05:14:28
	 * @version V1.0
	 */
	public String[] getChildOrganIds(String organid) {
		return ((OrganDAO) getDao()).getChildOrganIds(organid);
	}

	/**
	 * ��ѯ�����ӻ���(�ַ���ģʽ)
	 *
	 * @Title: OrganDAOImpl.java
	 * @Package com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����05:14:50
	 * @version V1.0
	 */
	public String[] getChildOrganIds(String organid, boolean containSelf) {
		return ((OrganDAO) getDao()).getChildOrganIds(organid, containSelf);
	}
}