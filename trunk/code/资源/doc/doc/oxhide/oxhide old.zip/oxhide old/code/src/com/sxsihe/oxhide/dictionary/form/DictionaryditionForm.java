package com.sxsihe.oxhide.dictionary.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.application.form.ApplicationConditionForm
 * </p>
 * <p>
 * Description:Ӧ��ϵͳ
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 * 
 * @modify
 * @date
 */
public class DictionaryditionForm extends BaseForm {
	private String dname;
	private String dcode;

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getDcode() {
		return dcode;
	}

	public void setDcode(String dcode) {
		this.dcode = dcode;
	}
}
