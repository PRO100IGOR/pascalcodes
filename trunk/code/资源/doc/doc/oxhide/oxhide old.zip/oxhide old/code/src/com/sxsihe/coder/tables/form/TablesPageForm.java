package com.sxsihe.coder.tables.form;


/**
 * ���뷭ҳFORM
 * @author �ų���
 */
public class TablesPageForm  {
	private String pageNow;
	private String pages;
	private String showCount;
	private String sels;

	public String getPageNow() {
		return pageNow;
	}

	public void setPageNow(String pageNow) {
		this.pageNow = pageNow;
	}

	public String getPages() {
		return pages;
	}

	public void setPages(String pages) {
		this.pages = pages;
	}

	public String getShowCount() {
		return showCount;
	}

	public void setShowCount(String showCount) {
		this.showCount = showCount;
	}

	public String getSels() {
		return sels;
	}

	public void setSels(String sels) {
		this.sels = sels;
	}

}
