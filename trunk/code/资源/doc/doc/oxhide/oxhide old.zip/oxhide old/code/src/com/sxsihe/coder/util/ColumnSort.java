package com.sxsihe.coder.util;

import java.util.Comparator;

import com.sxsihe.coder.columns.domain.Columns;

public class ColumnSort implements Comparator<Columns> {

	public int compare(Columns o1, Columns o2) {
		// TODO Auto-generated method stub
		int no1 = new Integer(o1.getOrderno());
		int no2 = new Integer(o2.getOrderno());
		if (no1 > no2) {
			return 1;
		} else if (no1 < no2) {
			return -1;
		}
		return 0;
	}

}
