package com.sxsihe.oxhide.ssouser.dao.hibernateImpl;

import java.util.*;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import net.sf.json.JsonConfig;
import net.sf.json.util.PropertyFilter;

import org.hibernate.Hibernate;
import org.hibernate.SQLQuery;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.application.domain.ApplicationSimply;
import com.sxsihe.oxhide.resource.domain.ResourceSimply;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;
import com.sxsihe.oxhide.ssouser.domain.Ssousers;
import com.sxsihe.oxhide.ssouser.dao.SsousersDAO;
import com.sxsihe.utils.net.ApplicationUrl;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssouser.dao.
 * SsousersDAOImpl
 * </p>
 * <p>
 * Description:DAOImpl
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author Administrator
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class SsousersDAOImpl extends BaseDAOImpl implements SsousersDAO {

	public Class getEntityClass() {
		// TODO Auto-generated method stub
		return Ssousers.class;
	}

	/**
	 * ��ȡ��Դ
	 * 
	 * @param appid
	 * @param userid
	 * @param ip
	 * @param display
	 * @param eq
	 *            display�ȽϹ�ϵ eq==null��ʾȫ�� display
	 * @return Administrator
	 *         com.sxsihe.oxhide.ssouser
	 *         .dao.hibernateImpl
	 *         SsousersDAOImpl.java 2012����10:42:54
	 *         oxhide
	 */
	public JSONArray getResource(String appid, String userid, String ip, String display,  JsonConfig config) {
		String sql = "select {t.*} from  resources t where  (" + display + ") and (displayappid = :appid or (:appid is null or :appid = '') ) and resourceid " + "in( select distinct r.resourceid  from resources r where  (r.resourceid "
				+ "in (select rr.resourceid from rolesresources rr where (rr.roleid in (select " + "ur.roleid from usersroles ur where ur.userid  = :userid   )))) or :userid = '1')"
				+ " order by t.displayappid,t.orderno";
		SQLQuery query = (SQLQuery) this.getSession().createSQLQuery(sql).addEntity("t", ResourceSimply.class).setParameter("userid", userid).setParameter("appid", appid);

		List<ResourceSimply> list = query.list();
		Map<String, ResourceSimply> map = new HashMap<String, ResourceSimply>();
		List<ResourceSimply> res = new ArrayList<ResourceSimply>();
		List<ResourceSimply> resListSim = new ArrayList<ResourceSimply>();
		try {
			for (ResourceSimply resourceSimply : list) {
				ResourceSimply simply = new ResourceSimply(resourceSimply);
				if (StringUtils.isEmpty(simply.getMobileico())) {
					simply.setMobileico("resource/base/theme/public/img/mobileicon/001.png");
				}
				if (StringUtils.isEmpty(simply.getIco())) {
					simply.setIco("resource/base/theme/public/img/icon/001.png");
				}
				if (StringUtils.isEmpty(simply.getBigico())) {
					simply.setBigico("resource/base/theme/public/img/bigicon/001.png");
				}
				if (StringUtils.isEmpty(simply.getLargeico())) {
					simply.setLargeico("resource/base/theme/public/img/largeicon/001.png");
				}

				if (StringUtils.isEmpty(simply.getRemark())) {
					simply.setRemark("���޼��");
				} else {
					simply.setRemark(simply.getRemark().replaceAll("\\n\\r", "<br/>"));
				}
				if (StringUtils.isNotEmpty(simply.getResourceurl())) {
					simply.setResourceurl(ApplicationUrl.getUrl(simply.getApplication(), ip) + "/" + simply.getResourceurl());
				}
				if (StringUtils.isNotEmpty(simply.getPrompt())) {
					simply.setPrompt(ApplicationUrl.getUrl(simply.getApplication(), ip) + "/" + simply.getPrompt());
				}
				map.put(simply.getResourceid(), simply);
				resListSim.add(simply);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		for (ResourceSimply resourceSimply : resListSim) {
			if (StringUtils.isNotEmpty(resourceSimply.getDisplayPId())) {
				if (map.containsKey(resourceSimply.getDisplayPId())) {
					map.get(resourceSimply.getDisplayPId()).getResource().add(resourceSimply);
				} else {
					System.out.println("��ǰ�û��ܷ���" + resourceSimply.getResourcename() + "("+resourceSimply.getResourceid()+")����û��Ȩ�޷����丸��Դ(" + resourceSimply.getDisplayPId() + "),ԭ������Ǹ��Ӳ˵�����ʾ��ʽ��ͬ����û�и����ɫȨ��,�˲˵���Ϊ�����˵�����...");
					res.add(resourceSimply);
				}
			} else {
				res.add(resourceSimply);
			}
		}
		return config == null ? JSONArray.fromObject(res) : JSONArray.fromObject(res, config);
	}

	/**
	 * �����û���ϵͳ
	 * 
	 * @param userid
	 * @param appid
	 * @param recode
	 *            ����Դ
	 * @param appcode
	 * @param ip
	 * @return Administrator
	 *         com.sxsihe.oxhide.ssouser
	 *         .dao.hibernateImpl
	 *         SsousersDAOImpl.java 2012����4:11:43
	 *         oxhide
	 */
	public JSONArray getApps(String userid, String appid, String appcode, String ip) {
		String sql = "select {t.*} from  application t where (t.appid = :appid or :appid is null )  and (t.appcode = :appcode or :appcode is null ) and  (t.appid "
				+ "in (select  distinct (select r.displayappid from resources  r " + "where r.resourceid = rs.resourceid and  (r.display = 1 or r.display = 3 ))"
				+ " from rolesresources rs where (rs.roleid in (select  ur.roleid  from usersroles ur" + " where ur.userid  = :userid  ))) or :userid = '1') order by t.orderno";
		SQLQuery query = this.getSession().createSQLQuery(sql);
		query.setParameter("userid", userid);
		query.setParameter("appid", appid);
		query.setParameter("appcode", appcode);
		query.addEntity("t", ApplicationSimply.class);
		List<ApplicationSimply> appList = query.list();
		JsonConfig config = new JsonConfig();
		config.setJsonPropertyFilter(new PropertyFilter() {
			public boolean apply(Object source, String name, Object value) {
				return ",appurlw,".indexOf("," + name + ",") > -1;
			}
		});
		List list = new ArrayList();
		for (ApplicationSimply applicationSimply : appList) {
			ApplicationSimply simply = new ApplicationSimply(applicationSimply);
			simply.setAppindex(ApplicationUrl.getUrl(simply.getAppurl(), simply.getAppurlw(), ip) + "/" + simply.getAppindex());
			simply.setAppurl(ApplicationUrl.getUrl(simply.getAppurl(), simply.getAppurlw(), ip));
			if (StringUtils.isEmpty(simply.getRemark())) {
				simply.setRemark("���޼��");
			} else {
				simply.setRemark(simply.getRemark().replaceAll("\\n\\r", "<br/>"));
			}
			if (StringUtils.isEmpty(simply.getIco())) {
				simply.setIco("resource/base/theme/public/img/icon/001.png");
			}
			if (StringUtils.isEmpty(simply.getBigico())) {
				simply.setBigico("resource/base/theme/public/img/bigicon/001.png");
			}
			if (StringUtils.isEmpty(simply.getLargeico())) {
				simply.setLargeico("resource/base/theme/public/img/largeicon/001.png");
			}
			list.add(simply);
		}
		return JSONArray.fromObject(list, config);
	}

	/**
	 * ��ȡ��ʾ�˵�
	 * 
	 * @param userid
	 * @return
	 */
	public String getReourcePromt(String userid, String ip) {
		List resourceList = new ArrayList();
		String sql = "select t.resourceid,t.displaypid,t.displayappid,t.prompt," + "(select a.appurl from application a where a.appid = t.appid) appurl,"
				+ "(select a.appurlw from application a where a.appid = t.appid) appurlw from " + " resources t where t.display <> 0 and (t.prompt is not null or t.prompt <> '') and t.resourceid "
				+ "in( select distinct r.resourceid  from resources r where  (r.resourceid " + "in (select rr.resourceid from rolesresources rr where (rr.roleid in (select "
				+ "ur.roleid from usersroles ur where ur.userid  = :userid   ))  ) or :userid = '1')) order by t.resourcepid,t.orderno";
		SQLQuery query = this.getSession().createSQLQuery(sql);
		query.setParameter("userid", userid);
		query.addScalar("resourceid", Hibernate.STRING);
		query.addScalar("displaypid", Hibernate.STRING);
		query.addScalar("prompt", Hibernate.STRING);
		query.addScalar("appurl", Hibernate.STRING);
		query.addScalar("appurlw", Hibernate.STRING);
		List resList = query.list();

		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < resList.size(); i++) {
			Object[] objects = (Object[]) resList.get(i);
			if (StringUtils.isNotEmpty((objects[2] + ""))) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("id", objects[0]);
				jsonObject.put("appid", objects[1]);
				jsonObject.put("prompt", ApplicationUrl.getUrl(objects[3], objects[4], ip) + "/" + objects[2]);
				jsonArray.add(jsonObject);
			}
		}
		return jsonArray.toString();
	}

	/**
	 * ����û��Ƿ��з��ʱ���Ϊappcode�ı���ΪresourceCode����Դ
	 * 
	 * @param userid
	 * @param appcode
	 * @param resourceCode
	 * @return
	 */
	public boolean checkUserHasResource(String userid, String appcode, String resCode) {
		String sql = "select count(*) count from rolesresources  rr where (rr.roleid in " + "(select ur.roleid from usersroles ur where ur.userid = :userid) and rr.resourceid "
				+ "in (select r.resourceid from resources r where r.resourcecode = :resourcecode and "
				+ "r.displayappid = (select a.appid from application a where a.appcode = :appcode)) or :userid = '1')";
		SQLQuery query = this.getSession().createSQLQuery(sql);
		query.setParameter("userid", userid);
		query.setParameter("appcode", appcode);
		query.setParameter("resourcecode", resCode);
		query.addScalar("count", Hibernate.INTEGER);
		List resList = query.list();
		if (!resList.isEmpty()) {
			Integer count = (Integer) resList.get(0);
			if (count > 0) {
				return true;
			}
		}
		return false;
	}

	/**
	 * ��ѯ�û������н�ɫ��Ϣ
	 * 
	 * @param userid
	 * @return Administrator
	 *         com.sxsihe.oxhide.ssouser
	 *         .dao.hibernateImpl List<Ssoroles>
	 */
	public List<Ssoroles> getUsersRoles(String userid) {
		String sql = "select {t.*} from ssoroles t where t.roleid in (select u.roleid from usersroles u where (u.userid = :userid or :userid = 1))";
		return getSession().createSQLQuery(sql).addEntity("t", Ssoroles.class).setParameter("userid", userid).list();
	}

	/**
	 * Ϊ��Ϣ���Ļ�ȡƥ����û�
	 * 
	 * @Title: MessageBaseService.java
	 * @Package com.sxsihe.oxhide.token.service
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-12-20 ����09:43:12
	 * @version V1.0
	 */
	public List getMessUsers(JSONObject param, Application application) {
		StringBuffer sql = new StringBuffer();
		sql.append(" select {tu.*} from ssousers tu where userid in ( \n\r");
		sql.append("       select userid from usersroles where roleid in ( \n\r");
		sql.append("              select roleid from rolesresources where resourceid in( \n\r");
		sql.append("                     select resourceid  from resources r where (resourcecode = :rescode or :rescode is null) and appid = :appid \n\r");
		sql.append("              ) \n\r");
		sql.append("       ) and employeeid in  ( \n\r");
		sql.append("              select employeeid from employee e where e.postid in ( \n\r");
		sql.append("                     select postid  from posts where deptid in ( \n\r");
		sql.append("                            select deptid from deptment where organid in ( \n\r");
		sql.append("                                               select organid from organ where (organid = :organid or :organid is null) and (organcode = :organcode or :organcode is null) \n\r");
		sql.append("                                          )  \n\r");
		sql.append("                                          and (deptcode = :deptcode or :deptcode is null)  \n\r");
		sql.append("                                          and (deptid = :deptid or :deptid is null)) \n\r");
		sql.append("                           and (postcode = :postcode or :postcode is null) \n\r");
		sql.append("                           and (postid = :postid or :postid is null) \n\r");
		sql.append("                )) \n\r");
		sql.append("           and (employeeid = :employeeid or :employeeid is null) \n\r");
		sql.append(" ) and (userid = :userid or :userid is null) \n\r");
		SQLQuery query = getSession().createSQLQuery(sql.toString());
		return query.addEntity("tu", Ssousers.class).setParameter("rescode", param.getString("rescode", null)).setParameter("appid", application.getAppid())
				.setParameter("organid", param.getString("organid", null)).setParameter("organcode", param.getString("organcode", null)).setParameter("deptcode", param.getString("deptcode", null))
				.setParameter("deptid", param.getString("deptid", null)).setParameter("postcode", param.getString("postcode", null)).setParameter("postid", param.getString("postid", null))
				.setParameter("employeeid", param.getString("employeeid", null)).setParameter("userid", param.getString("userid", null)).list();
	}

}
