package com.sxsihe.oxhide.rolesapp.service;

import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.struts.menu.MenuDataPick;
import java.util.*;
/**
 *<p>Title:com.sxsihe.oxhide.rolesapp.service.RolesappService</p>
 *<p>Description:��ɫϵͳService</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 *
 * @modify 
 * @date
 */
 public interface RolesappService extends BaseServiceIface{
 }