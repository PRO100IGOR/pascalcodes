package com.sxsihe.accessories;

import java.util.List;
import java.util.Map;

public abstract interface AccessoriesDao {
	public abstract void add(Accessories paramAccessories);

	public abstract void update(Accessories paramAccessories);

	public abstract void delete(Accessories paramAccessories);

	public abstract void delete(String paramString);

	public abstract Accessories getAccessories(String paramString);

	public abstract List getAccessoriesListByItem(String paramString);

	public abstract List getAccessoriesNoSubmit();

	public List getAccessByHql(String hql, Map<String, Object> keyValue);
	public void save(Accessories acc);
}