package com.sxsihe.accessories;

import java.io.Serializable;

public class Accessories implements Serializable {
	private String id;
	private String itemId;
	private String path;
	private String fileName;
	private long size;
	private String uploadDate;
	private short showAsImage;
	private String employeeid;
	private String employeename;
	private String filetype;
	private Integer stat;
	private String realpath;
	public String getRealpath() {
		return realpath;
	}

	public void setRealpath(String realpath) {
		this.realpath = realpath;
	}

	public Integer getStat() {
		return this.stat;
	}

	public void setStat(Integer stat) {
		this.stat = stat;
	}

	public Accessories() {
	}

	public Accessories(String itemId, String path, String fileName, long size, String uploadDate, short showAsImage) {
		this.itemId = itemId;
		this.path = path;
		this.fileName = fileName;
		this.size = size;
		this.uploadDate = uploadDate;
		this.showAsImage = showAsImage;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getItemId() {
		return this.itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	public String getPath() {
		return this.path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public long getSize() {
		return this.size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getUploadDate() {
		return this.uploadDate;
	}

	public void setUploadDate(String uploadDate) {
		this.uploadDate = uploadDate;
	}

	public short getShowAsImage() {
		return this.showAsImage;
	}

	public void setShowAsImage(short showAsImage) {
		this.showAsImage = showAsImage;
	}

	public String getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmployeename() {
		return employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public String getFiletype() {
		return filetype;
	}

	public void setFiletype(String filetype) {
		this.filetype = filetype;
	}
}