package com.sxsihe.oxhide.dictionary.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dictionary.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:�����ֵ�����
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class DictionaryForm extends BaseForm {
	/* did */
	private String dcode;
	private String did;
	private String remark;
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public void setDid(String did) {
		this.did = did;
	}

	public String getDid() {
		return this.did;
	}

	/* dname */
	private String dname;

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getDname() {
		return this.dname;
	}

	public String getDcode() {
		return dcode;
	}

	public void setDcode(String dcode) {
		this.dcode = dcode;
	}
}
