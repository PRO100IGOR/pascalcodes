;(function(J){
	var	isIe =  !-[1,];
	J.players = {};
	J.initPlay = function(url,id){
		id = id || "player";
		var temp;
		if(isIe){
			J("<OBJECT id=\""+id+"\"  classid=\"clsid:6BF52A52-394A-11d3-B153-00C04F79FAA6\" width=0 height=0><param name=\"URL\" value=\""+url+"\" /> <param name=\"AutoStart\" value=\"false\" /> </OBJECT> " ).prependTo("body").hide();
		}else{
			J("<OBJECT id=\""+id+"\"  type=\"application/x-ms-wmp\"  autostart=\"false\" src=\""+url+"\" width=0 height=0 ></OBJECT> " ).prependTo("body");
		}
	};
	J.play = function(id){
		id = id || "player";
		var temp = J("#"+id);
		if(temp.length > 0){
			temp[0].controls.stop();
			temp[0].controls.play();
		}
	};
	J.stop = function(id){
		id = id || "player";
		var temp = J("#"+id);
		if(temp.length > 0){
			temp[0].controls.stop();
		}
	}
})(jQuery);