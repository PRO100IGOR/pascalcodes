package com.sxsihe.oxhide.dept.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.dept.form.DeptConditionForm
 * </p>
 * <p>
 * Description:����
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class DeptConditionForm extends BaseForm {
	/* �������� */
	private String cdeptname;

	public void setCdeptname(String cdeptname) {
		this.cdeptname = cdeptname;
	}

	public String getCdeptname() {
		return this.cdeptname;
	}

	private String corganid;

	public String getCorganid() {
		return corganid;
	}

	public void setCorganid(String corganid) {
		this.corganid = corganid;
	}
}
