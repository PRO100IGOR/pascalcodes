package com.sxsihe.oxhide.systemlog.form;

import com.ite.oxhide.struts.form.BaseForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.systemlog.form.${variable.getOneUpper($variable.name)}Form
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2008
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author
 * @version 1.0
 * @date 2011-07-08
 * 
 * @modify
 * @date
 */
public class SystemlogConditionForm extends BaseForm {
	private String operateType;
	private String operateModel;
	/* operateTime */
	private String operateTimea;
	private String operateTimeb;

	/* operateIp */
	private String operateIp;

	public void setOperateIp(String operateIp) {
		this.operateIp = operateIp;
	}

	public String getOperateIp() {
		return this.operateIp;
	}

	/* operatePerson */
	private String operatePerson;

	public void setOperatePerson(String operatePerson) {
		this.operatePerson = operatePerson;
	}

	public String getOperatePerson() {
		return this.operatePerson;
	}

	/* operateEmp */
	private String operateEmp;

	public void setOperateEmp(String operateEmp) {
		this.operateEmp = operateEmp;
	}

	public String getOperateEmp() {
		return this.operateEmp;
	}

	/* operateSys */
	private String operateSys;

	public void setOperateSys(String operateSys) {
		this.operateSys = operateSys;
	}

	public String getOperateSys() {
		return this.operateSys;
	}

	/* operateContent */
	private String operateContent;

	public void setOperateContent(String operateContent) {
		this.operateContent = operateContent;
	}

	public String getOperateContent() {
		return this.operateContent;
	}


	public String getOperateTimea() {
		return operateTimea;
	}

	public void setOperateTimea(String operateTimea) {
		this.operateTimea = operateTimea;
	}

	public String getOperateTimeb() {
		return operateTimeb;
	}

	public void setOperateTimeb(String operateTimeb) {
		this.operateTimeb = operateTimeb;
	}

	public String getOperateModel() {
		return operateModel;
	}

	public void setOperateModel(String operateModel) {
		this.operateModel = operateModel;
	}

	public String getOperateType() {
		return operateType;
	}

	public void setOperateType(String operateType) {
		this.operateType = operateType;
	}
}
