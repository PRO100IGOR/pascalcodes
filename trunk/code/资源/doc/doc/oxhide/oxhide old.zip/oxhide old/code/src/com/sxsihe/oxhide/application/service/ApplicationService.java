package com.sxsihe.oxhide.application.service;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.struts.menu.MenuDataPick;
import com.sxsihe.oxhide.resource.domain.Resources;

import java.util.*;
/**
 *<p>Title:com.sxsihe.oxhide.application.service.ApplicationService</p>
 *<p>Description:Ӧ��ϵͳService</p>
 *<p>Copyright: Copyright (c) 2008</p>
 *<p>Company: ITE</p>
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 *
 * @modify 
 * @date
 */
 public interface ApplicationService extends BaseServiceIface{
		/**
		 * ��ȡ���������
		 * zcc
		 * Apr 22, 2011
		 * @return
		 */
		public int getOrderNo();
	
 }