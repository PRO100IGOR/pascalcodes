package com.sxsihe.oxhide.server.application;

import java.util.List;
import java.util.Map;

import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.service.BaseServiceIface;
import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.utils.common.DataUtils;

public class ApplicationServerImpl implements ApplicationServer {
	private BaseServiceIface service;

	public BaseServiceIface getService() {
		return service;
	}

	public void setService(BaseServiceIface service) {
		this.service = service;
	}

	public Application findObjectBykey(String key) {
		Object object = service.findObjectBykey(key);
		try {
			return (Application)DataUtils.copyPoJo(object, Application.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	public List<Application> findObjectsByCondition(ConditionBlock block, Map sortMap) {
		
		List list = service.findObjectsByCondition(DataUtils.changeCode(block), sortMap);
		
		return DataUtils.copyPoJos(list, Application.class);
	}

	public List<Application> getAll() {
		List list = service.getAll();
		return DataUtils.copyPoJos(list, Application.class);
	}

}
