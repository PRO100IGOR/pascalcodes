package com.sxsihe.oxhide.usersroles.service;

import com.ite.oxhide.service.BaseServiceImpl;
import com.ite.oxhide.struts.menu.MenuDataPick;
import org.apache.commons.beanutils.PropertyUtils;
import com.sxsihe.oxhide.usersroles.domain.Usersroles;
import com.ite.oxhide.common.util.*;
import java.util.*;
import java.io.*;
import org.apache.commons.beanutils.BeanUtils;

/**
 *<p>Title:com.sxsihe.oxhide.usersroles.service.UsersrolesServiceImpl</p>
 *<p>Description:�û���ɫService</p>
 *<p>Copyright: Copyright (c) 2007</p>
 *<p>Company: ITE</p>
 * @author zcc
 * @version 1.0
 * @date 2011-04-25
 *
 * @modify 
 * @date
 */
 public class UsersrolesServiceImpl 
     extends BaseServiceImpl 
     implements UsersrolesService{
}