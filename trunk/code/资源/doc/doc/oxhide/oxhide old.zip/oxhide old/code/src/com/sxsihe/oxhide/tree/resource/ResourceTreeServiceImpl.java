package com.sxsihe.oxhide.tree.resource;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Iterator;

import javax.servlet.jsp.PageContext;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.spring.SpringContextUtil;
import com.ite.oxhide.struts.menu.MenuDes;
import com.ite.oxhide.struts.menu.MenuNode;
import com.sxsihe.base.PublicVariable;

import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.server.application.ApplicationServer;
import com.sxsihe.oxhide.server.resource.ResourceServer;

public class ResourceTreeServiceImpl implements ResourceTreeService {
	private String[] displays = {"����","","���","����"};
	public List<MenuNode> getMenuNodeData(String type, PageContext pageContext) {
		List list = new ArrayList();
		String ida = pageContext.getRequest().getParameter("ida");
		ida = StringUtils.isEmpty(ida) ? "" : ","+ida+",";
		String idr = pageContext.getRequest().getParameter("idr");
		idr = StringUtils.isEmpty(idr) ? "" : ","+idr+",";
		String appid = pageContext.getRequest().getParameter("appid");
		appid = StringUtils.isEmpty(appid) ? "" : appid;

		String[] types = type.split("_");
		type = types[0];
		ApplicationServer applicationServer = (ApplicationServer) SpringContextUtil.getBean("applictionClient");
		ResourceServer resourceServer = (ResourceServer) SpringContextUtil.getBean("resourceClient");
		List appList = null;
		if (StringUtils.isEmpty(appid))
			appList = applicationServer.getAll();
		else {
			appList = new ArrayList();
			appList.add(applicationServer.findObjectBykey(appid));
		}
		addNode(list, appList, ida, "app");
		ConditionBlock block = null;
		if (!type.equals("0")) {
			for (int i = 0; i < appList.size(); i++) {
				block = new ConditionBlock();
				Application application = (Application) appList.get(i);
				block.and(new ConditionLeaf("displayAppId", "cappid", ConditionLeaf.EQ, application.getAppid(), false));
				addNode(list, resourceServer.findObjectsByCondition(block, null), idr, "resource");
			}
		}
		return list;
	}

	public List<MenuNode> getMenuNodeData(String arg0, String arg1, String arg2, PageContext arg3) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * ���ӽ�� zcc Apr 25, 2011
	 * 
	 * @param nodeList
	 *            ���list
	 * @param list
	 *            ����list
	 * @param ids
	 *            ѡ�е�id����
	 * @param types
	 *            ����
	 */
	private void addNode(List nodeList, Collection list, String ids, String types) {
		Iterator iterator = list.iterator();
		while (iterator.hasNext()) {
			MenuNode node = new MenuNode();
			boolean exits = false;
			if (types.equals("app")) {
				Application application = (Application) iterator.next();
				node.setId("app_" + application.getAppid());
				node.setTitle(application.getAppname());
				node.setIcon(PublicVariable.APPICON);
				node.setOpenIcon(PublicVariable.APPOPENICON);
				node.setType("0");
				exits = ids.indexOf(","+application.getAppid()) != -1;
			} else {
				Resources resources = (Resources) iterator.next();
				node.setIcon(PublicVariable.MENUICON);
				if(resources.getDisplay() == 1){
					node.setTitle(resources.getResourcename());
				}else{
					node.setTitle(resources.getResourcename() + "(" + displays[resources.getDisplay()] + ")");
				}
				
				node.setOpenIcon(PublicVariable.MENUOPENICON);
				if (resources.getResourcesp() != null)
					node.setParentId("res_" + resources.getDisplayPId());
				else
					node.setParentId("app_" + resources.getDisplayAppId());
				node.setType("1");
				node.setId("res_" + resources.getResourceid());
				exits = ids.indexOf(","+resources.getResourceid() + ",") != -1;
			}
			node.setChecked("true");
			node.setSelected(exits + "");
			nodeList.add(node);
		}
	}

	public List<MenuDes> getMenuDes(String type) {
		type = type.split("_")[0];
		List list = new ArrayList();
		MenuDes menuDes = new MenuDes();
		menuDes.setImg(PublicVariable.APPICON);
		menuDes.setName("Ӧ��ϵͳ");
		list.add(menuDes);
		if (type.equals("0")) {
			return list;
		}

		menuDes = new MenuDes();
		menuDes.setImg(PublicVariable.MENUICON);
		menuDes.setName("�˵�");
		list.add(menuDes);
		return list;
	}
}
