package com.sxsihe.coder.tables.dao.hibernateImpl;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.persistence.BaseDAOImpl;
import com.sxsihe.coder.columns.domain.Columns;
import com.sxsihe.coder.tables.dao.TablesDAO;
import com.sxsihe.coder.tables.domain.SimplyLeaf;
import com.sxsihe.coder.tables.domain.Tables;
import com.sxsihe.utils.properties.Reader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class TablesDAOImpl extends BaseDAOImpl implements TablesDAO {
	public Class getEntityClass() {
		return Tables.class;
	}

	public boolean checkTableName(String tableName) {
		Reader reader = new Reader("config.properties");
		String sqlName = reader.getProperty("jdbc.driverClassName");
		reader = new Reader("sql.properties");
		String sql = reader.getProperty(sqlName + ".tableNameCheck");
		String schema = reader.getProperty("schema");
		SQLQuery sqlquery = getSession().createSQLQuery(sql);
		sqlquery.addScalar("count", Hibernate.INTEGER).setParameter("schema", schema).setParameter("table", tableName);
		List list = sqlquery.list();
		int result = ((Integer) list.get(0)).intValue();
		if (result > 0) {
			return false;
		}
		sql = reader.getProperty(sqlName + ".viewNameCheck");
		sqlquery = getSession().createSQLQuery(sql);
		sqlquery.addScalar("count", Hibernate.INTEGER).setParameter("schema", schema).setParameter("table", tableName);
		list = sqlquery.list();
		result = ((Integer) list.get(0)).intValue();
		return (result == 0);
	}

	public void execSql(String sql) {
		Session session = getSession();
		Transaction tx = session.beginTransaction();
		try {
			Statement st = session.connection().createStatement();
			st.execute(sql);
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int getCountByCondition(String tableCode, List<SimplyLeaf> leafs) {
		StringBuilder sql = new StringBuilder();
		sql.append("select count(*) count from ");
		sql.append(tableCode);
		sql.append("_view v where 1=1 ");
		for (int i = 0; i < leafs.size(); ++i) {
			SimplyLeaf simplyLeaf = (SimplyLeaf) leafs.get(i);
			sql.append(simplyLeaf.getSql());
		}
		SQLQuery sqlquery = getSession().createSQLQuery(sql.toString());
		sqlquery.addScalar("count", Hibernate.INTEGER);
		int count = ((Integer) sqlquery.list().get(0)).intValue();
		return count;
	}

	public List<Map> findObjectByCondition(String tableCode, List<SimplyLeaf> leafs, List<Columns> cols, int pageSize, int pageNow) {
		StringBuilder sql = new StringBuilder();
		sql.append("select * from ");
		sql.append(tableCode);
		sql.append("_view v where 1=1 ");
		for (int i = 0; i < leafs.size(); ++i) {
			SimplyLeaf simplyLeaf = (SimplyLeaf) leafs.get(i);
			sql.append(simplyLeaf.getSql());
		}
		SQLQuery sqlquery = getSession().createSQLQuery(sql.toString());
		for (int i = 0; i < cols.size(); ++i) {
			Columns columns = (Columns) cols.get(i);
			sqlquery.addScalar(columns.getCcode(), Hibernate.STRING);
		}
		sqlquery.addScalar("dtid", Hibernate.STRING);
		if (pageSize != 1) {
			sqlquery.setFirstResult(pageSize * (pageNow - 1));
			sqlquery.setMaxResults(pageSize * pageNow);
		}
		List result = sqlquery.list();
		List list = new ArrayList();
		for (int i = 0; i < result.size(); ++i) {
			Object[] rArr = (Object[]) result.get(i);
			Map map = new HashMap();
			for (int j = 0; j < rArr.length - 1; ++j) {
				Columns columns = (Columns) cols.get(j);
				map.put(columns.getCcode(), (rArr[j] == null) ? "" : rArr[j].toString());
			}
			map.put("dtid", rArr[(rArr.length - 1)].toString());
			list.add(map);
		}
		return list;
	}

	public JSONObject getDataById(String tid, String dtid) {
		JSONObject result = null;
		try {
			Statement st = getSession().connection().createStatement();
			Transaction tx = getSession().beginTransaction();
			String sqltcode = "SELECT TCODE FROM TABLES WHERE TID='" + tid + "'";
			ResultSet rstcode = st.executeQuery(sqltcode);
			String prename = null;
			while (rstcode.next())
				prename = rstcode.getString("TCODE").toLowerCase();

			String sql = "SELECT * FROM " + prename + "_view where dtid = '" + dtid + "'";
			ResultSet rs = st.executeQuery(sql);
			tx.commit();
			int count = rs.getMetaData().getColumnCount();
			List list = new ArrayList();
			for (int i = 1; i <= count; ++i)
				list.add(rs.getMetaData().getColumnLabel(i));

			result = new JSONObject();
			while (rs.next())
				for (int i = 0; i < list.size(); ++i) {
					String key = (String) list.get(i);
					String temp = rs.getString(key);
					result.put(key.toLowerCase(), StringUtils.isEmpty(temp) ? "" : temp);
				}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (HibernateException e) {
			e.printStackTrace();
		}

		return result;
	}
}