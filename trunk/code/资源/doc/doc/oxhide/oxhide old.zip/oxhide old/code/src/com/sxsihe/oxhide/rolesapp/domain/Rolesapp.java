package com.sxsihe.oxhide.rolesapp.domain;

import com.sxsihe.oxhide.application.domain.Application;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;

/**
 * Rolesapp entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Rolesapp implements java.io.Serializable {

	// Fields

	private String rolesappid;
	private Application application;
	private Ssoroles ssoroles;

	// Constructors

	/** default constructor */
	public Rolesapp() {
	}

	public String getRolesappid() {
		return rolesappid;
	}

	public void setRolesappid(String rolesappid) {
		this.rolesappid = rolesappid;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Ssoroles getSsoroles() {
		return ssoroles;
	}

	public void setSsoroles(Ssoroles ssoroles) {
		this.ssoroles = ssoroles;
	}

}