package com.sxsihe.oxhide.message;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sxsihe.oxhide.message.Sender;

public class SenderManger {
	private Connection connection;

	public SenderManger() {
		PreparedStatement preparedStatement = null;
		try {
			Class.forName("org.hsqldb.jdbc.JDBCDriver");
			this.connection = DriverManager.getConnection("jdbc:hsqldb:mem:aname", "sa", "");
			String sql = "create table apple (id varchar(32),times int,message varchar(1000),timestotal int,token varchar(80),appcode varchar(32),iskf int,userid varchar(32),datetime varchar(19),appid varchar(32),rid varchar(32))";
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			sql = "create table android (id varchar(32),message varchar(1000),appcode varchar(32),userid varchar(32),datetime varchar(19),appid varchar(32),rid varchar(32))";
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			sql = "create table dwr (id varchar(32),message varchar(1000),appcode varchar(32),userid varchar(32),href varchar(200),datetime varchar(19),appid varchar(32),rid varchar(32),target varchar(6),isnote varchar(5),btn varchar(5),types varchar(32))";
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
			sql = "create table address (id varchar(32),userid varchar(32),address varchar(25))"; // �û��ĵ�ַ����
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void addApple(Sender sender) {
		String sql = "insert into apple values(?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, sender.getId());
			preparedStatement.setInt(2, sender.getTimes());
			preparedStatement.setString(3, sender.getMessage());
			preparedStatement.setInt(4, sender.getTimestotal());
			preparedStatement.setString(5, sender.getToken());
			preparedStatement.setString(6, sender.getAppcode());
			preparedStatement.setInt(7, sender.getIskf());
			preparedStatement.setString(8, sender.getUserid());
			preparedStatement.setString(9, sender.getDateTime());
			preparedStatement.setString(10, sender.getAppid());
			preparedStatement.setString(11, sender.getRid());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void addAppleTimes(String id) {
		String sql = "update apple set times = times + 1 where id = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delApple(String id) {
		String sql = "delete from apple where id = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delAllApple(String appcode) {
		String sql = "delete from apple where appcode = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, appcode);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delAppleByToken(String token) {
		String sql = "delete from apple where token = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, token);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List getApples(String appcode) {
		List list = new ArrayList();
		String sql = "select * from apple where appcode = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, appcode);
			rs = preparedStatement.executeQuery();
			Sender sender = null;
			while (rs.next()) {
				sender = new Sender();
				sender.setAppcode(rs.getString("appcode"));
				sender.setId(rs.getString("id"));
				sender.setMessage(rs.getString("message"));
				sender.setTimes(rs.getInt("times"));
				sender.setTimestotal(rs.getInt("timestotal"));
				sender.setToken(rs.getString("token"));
				sender.setIskf(rs.getInt("iskf"));
				sender.setUserid(rs.getString("userid"));
				sender.setDateTime(rs.getString("datetime"));
				sender.setAppid(rs.getString("appid"));
				sender.setRid(rs.getString("rid"));
				list.add(sender);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public Sender getAppleById(String id) {
		String sql = "select * from apple where id = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			rs = preparedStatement.executeQuery();
			Sender sender = null;
			if (rs.next()) {
				sender = new Sender();
				sender.setAppcode(rs.getString("appcode"));
				sender.setId(rs.getString("id"));
				sender.setMessage(rs.getString("message"));
				sender.setTimes(rs.getInt("times"));
				sender.setTimestotal(rs.getInt("timestotal"));
				sender.setToken(rs.getString("token"));
				sender.setIskf(rs.getInt("iskf"));
				sender.setUserid(rs.getString("userid"));
				sender.setDateTime(rs.getString("datetime"));
				sender.setAppid(rs.getString("appid"));
				sender.setRid(rs.getString("rid"));
				return sender;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public void addAndroid(Sender sender) {
		String sql = "insert into android values(?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, sender.getId());
			preparedStatement.setString(2, sender.getMessage());
			preparedStatement.setString(3, sender.getAppcode());
			preparedStatement.setString(4, sender.getUserid());
			preparedStatement.setString(5, sender.getDateTime());
			preparedStatement.setString(6, sender.getAppid());
			preparedStatement.setString(7, sender.getRid());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delAndroid(String id) {
		String sql = "delete from android where id = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delAllAndroid(String appcode) {
		String sql = "delete from android  where appcode = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, appcode);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List getAndroids(String appcode) {
		List list = new ArrayList();
		String sql = "select * from android where appcode = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, appcode);
			rs = preparedStatement.executeQuery();
			Sender sender = null;
			while (rs.next()) {
				sender = new Sender();
				sender.setAppcode(rs.getString("appcode"));
				sender.setId(rs.getString("id"));
				sender.setMessage(rs.getString("message"));
				sender.setUserid(rs.getString("userid"));
				sender.setDateTime(rs.getString("datetime"));
				sender.setAppid(rs.getString("appid"));
				sender.setRid(rs.getString("rid"));
				list.add(sender);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public Sender getAndroidById(String id) {
		String sql = "select * from android where id = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			rs = preparedStatement.executeQuery();
			Sender sender = null;
			if (rs.next()) {
				sender = new Sender();
				sender.setAppcode(rs.getString("appcode"));
				sender.setId(rs.getString("id"));
				sender.setMessage(rs.getString("message"));
				sender.setUserid(rs.getString("userid"));
				sender.setDateTime(rs.getString("datetime"));
				sender.setAppid(rs.getString("appid"));
				sender.setRid(rs.getString("rid"));
				return sender;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public List getAndroidByUserid(String userid) {
		List list = new ArrayList();
		String sql = "select * from android where userid = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, userid);
			rs = preparedStatement.executeQuery();
			Sender sender = null;
			while (rs.next()) {
				sender = new Sender();
				sender.setAppcode(rs.getString("appcode"));
				sender.setId(rs.getString("id"));
				sender.setMessage(rs.getString("message"));
				sender.setUserid(rs.getString("userid"));
				sender.setDateTime(rs.getString("datetime"));
				sender.setAppid(rs.getString("appid"));
				sender.setRid(rs.getString("rid"));
				list.add(sender);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public void addDwr(Sender sender) {
		String sql = "insert into dwr values(?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, sender.getId());
			preparedStatement.setString(2, sender.getMessage());
			preparedStatement.setString(3, sender.getAppcode());
			preparedStatement.setString(4, sender.getUserid());
			preparedStatement.setString(5, sender.getHref());
			preparedStatement.setString(6, sender.getDateTime());
			preparedStatement.setString(7, sender.getAppid());
			preparedStatement.setString(8, sender.getRid());
			preparedStatement.setString(9, sender.getTarget());
			preparedStatement.setString(10, sender.getIsnote());
			preparedStatement.setString(11, sender.getBtn());
			preparedStatement.setString(12, sender.getTypes());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delDwr(String id) {
		String sql = "delete from dwr where id = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delAllDwr(String appcode) {
		String sql = "delete from dwr where appcode = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, appcode);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delDwrByUserId(String userid) {
		String sql = "delete from dwr where userid = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, userid);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List getDwrsByUserId(String userid) {
		List list = new ArrayList();
		String sql = "select * from dwr where userid = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {

			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, userid);
			rs = preparedStatement.executeQuery();
			Sender sender = null;
			while (rs.next()) {
				sender = new Sender();
				sender.setAppcode(rs.getString("appcode"));
				sender.setId(rs.getString("id"));
				sender.setMessage(rs.getString("message"));
				sender.setUserid(rs.getString("userid"));
				sender.setHref(rs.getString("href"));
				sender.setAppid(rs.getString("appid"));
				sender.setRid(rs.getString("rid"));
				sender.setTarget(rs.getString("target"));
				sender.setDateTime(rs.getString("datetime"));
				sender.setIsnote(rs.getString("isnote"));
				sender.setBtn(rs.getString("btn"));
				sender.setTypes(rs.getString("types"));
				list.add(sender);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public List getDwrsByAppcode(String appcode) {
		List list = new ArrayList();
		String sql = "select * from dwr where appcode = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {

			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, appcode);
			rs = preparedStatement.executeQuery();
			Sender sender = null;
			while (rs.next()) {
				sender = new Sender();
				sender.setAppcode(rs.getString("appcode"));
				sender.setId(rs.getString("id"));
				sender.setMessage(rs.getString("message"));
				sender.setUserid(rs.getString("userid"));
				sender.setHref(rs.getString("href"));
				sender.setAppid(rs.getString("appid"));
				sender.setRid(rs.getString("rid"));
				sender.setTarget(rs.getString("target"));
				sender.setDateTime(rs.getString("datetime"));
				sender.setIsnote(rs.getString("isnote"));
				sender.setBtn(rs.getString("btn"));
				sender.setTypes(rs.getString("types"));
				list.add(sender);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public Sender getDwrById(String id) {
		String sql = "select * from dwr where id = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			rs = preparedStatement.executeQuery();
			Sender sender = null;
			if (rs.next()) {
				sender = new Sender();
				sender.setAppcode(rs.getString("appcode"));
				sender.setId(rs.getString("id"));
				sender.setMessage(rs.getString("message"));
				sender.setUserid(rs.getString("userid"));
				sender.setHref(rs.getString("href"));
				sender.setAppid(rs.getString("appid"));
				sender.setRid(rs.getString("rid"));
				sender.setTarget(rs.getString("target"));
				sender.setDateTime(rs.getString("datetime"));
				sender.setIsnote(rs.getString("isnote"));
				sender.setBtn(rs.getString("btn"));
				sender.setTypes(rs.getString("types"));
				return sender;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public void addAddress(Address address) {
		String sql = "insert into address values(?,?,?)";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, address.getId());
			preparedStatement.setString(2, address.getUserid());
			preparedStatement.setString(3, address.getAddress());
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delAddress(String id) {
		String sql = "delete from address where id = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delAllAddress() {
		String sql = "delete from address";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delAddressByUserid(String userid) {
		String sql = "delete from address where userid = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, userid);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public List getAddress() {
		List list = new ArrayList();
		String sql = "select * from address";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			rs = preparedStatement.executeQuery();
			Address address = null;
			while (rs.next()) {
				address = new Address();
				address.setId(rs.getString("id"));
				address.setAddress(rs.getString("address"));
				address.setUserid(rs.getString("userid"));
				list.add(address);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public List getAddressByUserid(String userid) {
		List list = new ArrayList();
		String sql = "select * from address where userid = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, userid);
			rs = preparedStatement.executeQuery();
			Address address = null;
			while (rs.next()) {
				address = new Address();
				address.setId(rs.getString("id"));
				address.setAddress(rs.getString("address"));
				address.setUserid(rs.getString("userid"));
				list.add(address);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public Address getAddressById(String id) {
		String sql = "select * from address where id = ?";
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, id);
			rs = preparedStatement.executeQuery();
			Address address = null;
			if (rs.next()) {
				address = new Address();
				address.setId(rs.getString("id"));
				address.setAddress(rs.getString("address"));
				address.setUserid(rs.getString("userid"));
				return address;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public void delAddressByAddress(String address) {
		String sql = "delete from address where address = ?";
		PreparedStatement preparedStatement = null;
		try {
			preparedStatement = this.connection.prepareStatement(sql);
			preparedStatement.setString(1, address);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
