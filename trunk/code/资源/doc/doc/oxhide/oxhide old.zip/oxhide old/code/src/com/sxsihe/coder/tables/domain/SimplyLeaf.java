package com.sxsihe.coder.tables.domain;

public class SimplyLeaf {
	private String cname;
	private String ccname;
	private Integer cwith;
	private String value;

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getCcname() {
		return ccname;
	}

	public void setCcname(String ccname) {
		this.ccname = ccname;
	}

	public Integer getCwith() {
		return cwith;
	}

	public void setCwith(Integer cwith) {
		this.cwith = cwith;
	}

	public SimplyLeaf(String cname, String ccname, Integer cwith, String value) {
		this.cname = cname;
		this.ccname = ccname;
		this.cwith = cwith;
		this.value = value;
	}

	public String getSql() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append(" and (");
		switch (this.cwith) {
		case 901:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" > '");
			stringBuilder.append(this.value);
			stringBuilder.append("' ");
			break;
		case 902:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" >= '");
			stringBuilder.append(this.value);
			stringBuilder.append("' ");
			break;
		case 903:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" <= '");
			stringBuilder.append(this.value);
			stringBuilder.append("' ");
			break;
		case 904:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" < '");
			stringBuilder.append(this.value);
			stringBuilder.append("' ");
			break;
		case 905:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" = '");
			stringBuilder.append(this.value);
			stringBuilder.append("' ");
			break;
		case 906:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" <> '");
			stringBuilder.append(this.value);
			stringBuilder.append("' ");
			break;
		case 907:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" like '%");
			stringBuilder.append(this.value);
			stringBuilder.append("%' ");
			break;
		case 917:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" not like '%");
			stringBuilder.append(this.value);
			stringBuilder.append("%' ");
			break;
		case 910:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" in '");
			stringBuilder.append(this.value);
			stringBuilder.append("' ");
			break;
		case 913:
			stringBuilder.append(" v.");
			stringBuilder.append(this.cname);
			stringBuilder.append(" not in '");
			stringBuilder.append(this.value);
			stringBuilder.append("' ");
			break;
		}
		stringBuilder.append(" or '");
		stringBuilder.append(this.value);
		stringBuilder.append("' = '') ");
		return stringBuilder.toString();
	}
}
