package com.sxsihe.oxhide.rolesresource.domain;

import com.sxsihe.oxhide.resource.domain.Resources;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;

/**
 * Rolesresources entity.
 * 
 * @author MyEclipse Persistence Tools
 */

public class Rolesresources implements java.io.Serializable {

	// Fields

	private String resourceroleid;
	private Resources resources;
	private Ssoroles ssoroles;

	// Constructors

	/** default constructor */
	public Rolesresources() {
	}

	/** full constructor */
	public Rolesresources(Resources resources, Ssoroles ssoroles) {
		this.resources = resources;
		this.ssoroles = ssoroles;
	}

	// Property accessors

	public String getResourceroleid() {
		return this.resourceroleid;
	}

	public void setResourceroleid(String resourceroleid) {
		this.resourceroleid = resourceroleid;
	}

	public Resources getResources() {
		return this.resources;
	}

	public void setResources(Resources resources) {
		this.resources = resources;
	}

	public Ssoroles getSsoroles() {
		return this.ssoroles;
	}

	public void setSsoroles(Ssoroles ssoroles) {
		this.ssoroles = ssoroles;
	}

}