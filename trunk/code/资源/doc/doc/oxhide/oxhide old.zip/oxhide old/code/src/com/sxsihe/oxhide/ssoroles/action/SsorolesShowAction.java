package com.sxsihe.oxhide.ssoroles.action;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import java.io.*;
import com.ite.oxhide.persistence.*;

import org.extremecomponents.table.limit.Limit;
import com.ite.oxhide.exception.BaseException;
import com.ite.oxhide.struts.actionEx.BaseShowAction;
import org.apache.commons.beanutils.PropertyUtils;
import com.sxsihe.oxhide.rolesapp.domain.Rolesapp;
import com.sxsihe.oxhide.rolesresource.domain.Rolesresources;
import com.sxsihe.oxhide.ssoroles.domain.Ssoroles;
import com.sxsihe.oxhide.ssoroles.form.SsorolesForm;
import com.sxsihe.oxhide.ssoroles.form.SsorolesconditionForm;

/**
 * <p>
 * Title:com.sxsihe.oxhide.ssoroles.action.SsorolesShowAction
 * </p>
 * <p>
 * Description:��ɫshowAction
 * </p>
 * <p>
 * Copyright: Copyright (c) 2007
 * </p>
 * <p>
 * Company: ITE
 * </p>
 * 
 * @author �ų���
 * @version 1.0
 * @date 2011-04-21
 * 
 * @modify
 * @date
 */
public class SsorolesShowAction extends BaseShowAction {

	/**
	 * ��ʾ��Դ�� zcc Apr 25, 2011
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws BaseException
	 */
	public ActionForward showTree(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
		String id = request.getParameter("id");
		Ssoroles po = (Ssoroles) getService().findObjectBykey(id);
		if (po.getRolesresourceses() != null) {
			Iterator ite = po.getRolesresourceses().iterator();
			StringBuilder stringBuilder = new StringBuilder();
			while (ite.hasNext()) {
				Rolesresources rolesresources = (Rolesresources) ite.next();
				stringBuilder.append(rolesresources.getResources().getResourceid() + ",");
			}
			request.setAttribute("idr", stringBuilder.toString());
		}
		if (po.getRolesapp() != null) {
			Iterator ite = po.getRolesapp().iterator();
			StringBuilder stringBuilder = new StringBuilder();
			while (ite.hasNext()) {
				Rolesapp rolesapp = (Rolesapp) ite.next();
				stringBuilder.append(rolesapp.getApplication().getAppid() + ",");
			}
			request.setAttribute("ida", stringBuilder.toString());
		}
		request.setAttribute("id", id);
		return mapping.findForward("showTree");
	}

	/**
	 * ��ʾ����ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowAdd(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}


	/**
	 * ��ʾ�޸�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}


	/**
	 * ��ʾ�б�ҳ�����
	 * 
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @throws BaseException
	 */
	protected void nextShowList(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws BaseException {
	}

	/**
	 * @param form
	 * @return
	 */
	protected ActionForm getForm(Serializable po, ActionForm form) {
		try {
			if (form instanceof SsorolesForm) {
				Ssoroles pos = (Ssoroles) po;
				SsorolesForm vForm = (SsorolesForm) form;
				BeanUtils.setProperty(vForm, "roleid", PropertyUtils.getProperty(pos, "roleid"));
				BeanUtils.setProperty(vForm, "rolename", PropertyUtils.getProperty(pos, "rolename"));
				BeanUtils.setProperty(vForm, "rolecode", PropertyUtils.getProperty(pos, "rolecode"));
				BeanUtils.setProperty(vForm, "remark", PropertyUtils.getProperty(pos, "remark"));
				BeanUtils.setProperty(vForm, "isvalidation", PropertyUtils.getProperty(pos, "isvalidation"));
			}
		} catch (Exception e) {
		}
		return form;
	}

	/**
	 * �Զ����ѯ�����ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected int customSelectCount(ActionForm conditionForm, HttpServletRequest request, HttpServletResponse response, Limit limit) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		SsorolesconditionForm ssorolesconditionForm = (SsorolesconditionForm) conditionForm;
		if (ssorolesconditionForm != null) {
			block.and(new ConditionLeaf("rolename", "cdcvalue", ConditionLeaf.LIKE, ssorolesconditionForm.getDvalue(), true));
			block.and(new ConditionLeaf("rolecode", "cdcode", ConditionLeaf.LIKE, ssorolesconditionForm.getDcode(), true));
		}
		return getService().getTotalObjects(block);
	}

	/**
	 * �Զ����ѯ�б��ӿڷ���
	 * 
	 * @param conditionForm
	 * @param limit
	 * @return
	 */
	protected List customSelect(ActionForm conditionForm, Limit limit, HttpServletRequest request, HttpServletResponse response, ActionMapping mapping) {
		ConditionBlock block = null;
		if (limit != null)
			block = getConditionBlock(limit);
		else
			block = new ConditionBlock();
		SsorolesconditionForm ssorolesconditionForm = (SsorolesconditionForm) conditionForm;
		if (ssorolesconditionForm != null) {
			block.and(new ConditionLeaf("rolename", "cdcvalue", ConditionLeaf.LIKE, ssorolesconditionForm.getDvalue(), true));
			block.and(new ConditionLeaf("rolecode", "cdcode", ConditionLeaf.LIKE, ssorolesconditionForm.getDcode(), true));
		}
		Map sortMap = null;
		if (limit != null)
			sortMap = this.getSortMap(limit);
		else
			sortMap = new HashMap();
		List list = null;
		if (limit != null)
			list = getService().findObjectsByCondition(block, sortMap, (limit.getPage() - 1) * limit.getCurrentRowsDisplayed(), limit.getCurrentRowsDisplayed());
		else
			list = getService().findObjectsByCondition(block, sortMap);
		return list;
	}

}
