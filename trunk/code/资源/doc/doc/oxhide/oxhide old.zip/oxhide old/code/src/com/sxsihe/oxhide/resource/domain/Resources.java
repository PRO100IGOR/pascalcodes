package com.sxsihe.oxhide.resource.domain;

import java.util.HashSet;
import java.util.Set;

import com.sxsihe.oxhide.application.domain.Application;

/**
 * Resources entity.
 *
 * @author MyEclipse Persistence Tools
 */

public class Resources implements java.io.Serializable {

	// Fields

	private String resourceid;
	private String resourcename;
	private String resourceurl;
	private String isvalidation;
	private String resourcecode;
	private Integer target;
	private Resources resourcesp;
	private Application application;
	private Set rolesresourceses = new HashSet(0);
	private Set resourcees = new HashSet(0);
	private String ico;
	private String bigico;
	private String selfclick;
	private String tabname;
	private Integer orderno;
	private Integer display;
	private Integer menutype;
	private String simplyname;
	private String largeico;
	private String remark;
	private String prompt;
	private String displayPId;
	private String displayAppId;
	private String mobileico;
	private String mobileurl;
	public String getMobileurl() {
		return mobileurl;
	}

	public void setMobileurl(String mobileurl) {
		this.mobileurl = mobileurl;
	}

	public String getMobileico() {
		return mobileico;
	}

	public void setMobileico(String mobileico) {
		this.mobileico = mobileico;
	}

	public String getDisplayPId() {
		return displayPId;
	}

	public void setDisplayPId(String displayPId) {
		this.displayPId = displayPId;
	}

	public String getDisplayAppId() {
		return displayAppId;
	}

	public void setDisplayAppId(String displayAppId) {
		this.displayAppId = displayAppId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getSimplyname() {
		return simplyname;
	}

	public void setSimplyname(String simplyname) {
		this.simplyname = simplyname;
	}

	public String getLargeico() {
		return largeico;
	}

	public void setLargeico(String largeico) {
		this.largeico = largeico;
	}

	public Integer getMenutype() {
		return menutype;
	}

	public void setMenutype(Integer menutype) {
		this.menutype = menutype;
	}

	public Integer getDisplay() {
		return display;
	}

	public void setDisplay(Integer display) {
		this.display = display;
	}

	public Integer getOrderno() {
		return orderno;
	}

	public void setOrderno(Integer orderno) {
		this.orderno = orderno;
	}
	// Constructors


	public String getSelfclick() {
		return selfclick;
	}

	public void setSelfclick(String selfclick) {
		this.selfclick = selfclick;
	}
	// Constructors

	public String getBigico() {
		return bigico;
	}

	public void setBigico(String bigico) {
		this.bigico = bigico;
	}

	public String getIco() {
		return ico;
	}

	public void setIco(String ico) {
		this.ico = ico;
	}

	/** default constructor */
	public Resources() {
	}

	/** full constructor */
	public Resources(String resourcename, String resourceurl, String isvalidation, String resourcecode, Integer resourcetype, Set rolesresourceses) {
		this.resourcename = resourcename;
		this.resourceurl = resourceurl;
		this.isvalidation = isvalidation;
		this.resourcecode = resourcecode;
		this.rolesresourceses = rolesresourceses;
	}

	// Property accessors

	public String getResourceid() {
		return this.resourceid;
	}

	public void setResourceid(String resourceid) {
		this.resourceid = resourceid;
	}

	public String getResourcename() {
		return this.resourcename;
	}

	public void setResourcename(String resourcename) {
		this.resourcename = resourcename;
	}

	public String getResourceurl() {
		return this.resourceurl;
	}

	public void setResourceurl(String resourceurl) {
		this.resourceurl = resourceurl;
	}

	public String getIsvalidation() {
		return this.isvalidation;
	}

	public void setIsvalidation(String isvalidation) {
		this.isvalidation = isvalidation;
	}

	public String getResourcecode() {
		return this.resourcecode;
	}

	public void setResourcecode(String resourcecode) {
		this.resourcecode = resourcecode;
	}


	public Set getRolesresourceses() {
		return this.rolesresourceses;
	}

	public void setRolesresourceses(Set rolesresourceses) {
		this.rolesresourceses = rolesresourceses;
	}

	public Resources getResourcesp() {
		return resourcesp;
	}

	public void setResourcesp(Resources resourcesp) {
		this.resourcesp = resourcesp;
	}

	public Set getResourcees() {
		return resourcees;
	}

	public void setResourcees(Set resourcees) {
		this.resourcees = resourcees;
	}

	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public String getTabname() {
		return tabname;
	}

	public void setTabname(String tabname) {
		this.tabname = tabname;
	}

	public Integer getTarget() {
		return target;
	}

	public void setTarget(Integer target) {
		this.target = target;
	}

	public String getPrompt() {
		return prompt;
	}

	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}




}