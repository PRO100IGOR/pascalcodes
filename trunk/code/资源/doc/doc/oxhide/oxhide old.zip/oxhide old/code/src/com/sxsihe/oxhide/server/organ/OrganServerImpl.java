package com.sxsihe.oxhide.server.organ;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONArray;

import com.ite.oxhide.common.util.StringUtils;
import com.ite.oxhide.persistence.ConditionBlock;
import com.ite.oxhide.persistence.ConditionLeaf;
import com.ite.oxhide.service.BaseServiceIface;
import com.ite.oxhide.spring.SpringContextUtil;
import com.sxsihe.oxhide.organ.domain.Organ;
import com.sxsihe.oxhide.organ.service.OrganService;
import com.sxsihe.utils.common.CharsetSwitch;
import com.sxsihe.utils.common.DataUtils;

public class OrganServerImpl implements OrganServer {

	/**
	 * �����б�����
	 * 
	 * @param block
	 * @param sortMap
	 * @return
	 */
	public List<Organ> findObjectsByCondition(ConditionBlock block, Map sortMap) {
		try {
			OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
			List list = organService.findObjectsByCondition(DataUtils.changeCode(block), sortMap);
			return DataUtils.copyPoJos(list, Organ.class);
		} catch (Exception e) {
			return new ArrayList<Organ>();
		}

	}

	/**
	 * ����������ѯ����
	 * 
	 * @param key
	 * @return
	 */
	public Organ findObjectBykey(String key) {
		OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
		Object object = organService.findObjectBykey(key);
		try {
			return (Organ) DataUtils.copyPoJo(object, Organ.class);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * ��ѯȫ��
	 * 
	 * @return
	 */
	public List<Organ> getAll() {
		OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
		List list = organService.getAll();
		return DataUtils.copyPoJos(list, Organ.class);
	}

	/**
	 * ��ѯ�����ӻ���(����ģʽ)
	 * 
	 * @Title: OrganDAOImpl.java
	 * @Package 
	 *          com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����04:50:14
	 * @version V1.0
	 */
	public List<Organ> getChildOrgan(String organid, boolean containSelf) {
		OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
		return DataUtils.copyPoJos(organService.getChildOrgan(organid, containSelf), Organ.class);
	}

	/**
	 * ��ѯ�����ӻ���(����ģʽ)
	 * 
	 * @Title: OrganDAOImpl.java
	 * @Package 
	 *          com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����04:50:25
	 * @version V1.0
	 */
	public List<Organ> getChildOrgan(String organid) {
		OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
		return DataUtils.copyPoJos(organService.getChildOrgan(organid), Organ.class);
	}

	/**
	 * ��ѯ�����ӻ���(�ַ���ģʽ)
	 * 
	 * @Title: OrganDAOImpl.java
	 * @Package 
	 *          com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����05:14:28
	 * @version V1.0
	 */
	public String getChildOrganIds(String organid) {
		OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
		JSONArray array = JSONArray.fromObject(organService.getChildOrganIds(organid));
		return array.toString();
	}

	/**
	 * ��ѯ�����ӻ���(�ַ���ģʽ)
	 * 
	 * @Title: OrganDAOImpl.java
	 * @Package 
	 *          com.sxsihe.oxhide.organ.dao.hibernateImpl
	 * @Description: TODO
	 * @author �ų���
	 * @date 2011-11-14 ����05:14:50
	 * @version V1.0
	 */
	public String getChildOrganIds(String organid, boolean containSelf) {
		OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
		JSONArray array = JSONArray.fromObject(organService.getChildOrganIds(organid, containSelf));
		return array.toString();
	}
	
	/**
	 * ����
	 * @param organ
	 * Administrator
	 * com.sxsihe.oxhide.server.organ
	 * OrganServer.java
	 * 2012����9:46:54
	 * oxhide
	 */
	public void save(Organ organ) {
		OrganService organService = (OrganService) SpringContextUtil.getBean("organService");
		try {
			organService.save((Organ) DataUtils.changeCode(organ,Organ.class));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
